#!/usr/bin/env python3
"""Check a KRIVI OS build before shipping it.

    python3 tools/check_image.py <KriviOS.ino.bin> [merged_image.bin]

* the app image must fit the app0 slot defined in KriviOS/partitions.csv
  (Arduino uses that file, not the Tools > Partition Scheme menu; an image that
  overflows the slot is refused by the bootloader: red LED, endless resets)
* a merged image must have the bootloader, partition table and app at the
  right offsets, and must not run into the next partition
"""
import os, sys, csv

HERE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(HERE, "..", "KriviOS", "partitions.csv")

def num(s):
    s = s.strip().upper()
    if s.endswith("K"): return int(s[:-1], 0) * 1024
    if s.endswith("M"): return int(s[:-1], 0) * 1024 * 1024
    return int(s, 0)

def table():
    rows = []
    with open(CSV) as f:
        for r in csv.reader(l for l in f if l.strip() and not l.lstrip().startswith("#")):
            r = [c.strip() for c in r]
            rows.append({"name": r[0], "type": r[1], "sub": r[2], "off": num(r[3]), "size": num(r[4])})
    return rows

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    parts = table()
    app0 = next(p for p in parts if p["name"] == "app0")
    after = min((p["off"] for p in parts if p["off"] > app0["off"]), default=4 * 1024 * 1024)
    ok = True
    app = open(sys.argv[1], "rb").read()
    pct = 100.0 * len(app) / app0["size"]
    if len(app) > app0["size"]:
        print(f"FAIL  app image {len(app):,} B is larger than app0 ({app0['size']:,} B) by {len(app) - app0['size']:,} B")
        ok = False
    else:
        print(f"ok    app image {len(app):,} B fits app0 {app0['size']:,} B ({pct:.1f}%, {app0['size'] - len(app):,} B free)")
    if app[:1] != b"\xe9":
        print("FAIL  app image does not start with the ESP image magic 0xE9"); ok = False
    if len(sys.argv) > 2:
        m = open(sys.argv[2], "rb").read()
        checks = [(0x1000, "bootloader"), (app0["off"], "app")]
        for off, what in checks:
            if m[off:off + 1] != b"\xe9":
                print(f"FAIL  merged image: no {what} at 0x{off:X}"); ok = False
        if m[0x8000:0x8002] != b"\xaa\x50":
            print("FAIL  merged image: no partition table at 0x8000"); ok = False
        if m[app0["off"]:app0["off"] + len(app)] != app:
            print("FAIL  merged image: app bytes differ from the build"); ok = False
        if len(m) > after:
            print(f"FAIL  merged image ends at 0x{len(m):X}, past the next partition at 0x{after:X}"); ok = False
        if ok:
            print(f"ok    merged image layout (ends 0x{len(m):X}, next partition 0x{after:X})")
    print("PASS" if ok else "NOT SAFE TO FLASH")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
