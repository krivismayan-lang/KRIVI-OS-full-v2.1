#!/usr/bin/env python3
"""
KRIVI Maps - offline tile downloader (run on your PC, writes straight to the SD card).

  python3 maps_fetch.py --place "Atlanta, Georgia" --radius-km 8 --zoom 10-15 \
                        --contact you@example.com --out /media/SD/maps/tiles          (style: voyager = Google-like)
  python3 maps_fetch.py --bbox 33.70 -84.45 33.82 -84.30 --zoom 12-16 --contact you@example.com --out tiles
  python3 maps_fetch.py --place "Paris" --zoom 10-14 --dry-run          (just count tiles / MB)

Please be gentle: the free tile servers (OpenStreetMap, CARTO) are not meant for bulk downloads
(https://operations.osmfoundation.org/policies/tiles/ and CARTO's basemap terms). This tool identifies itself, waits between requests,
skips tiles you already have and refuses big jobs unless you pass --yes. For large areas use another
provider or your own tile server with --url.   Map data (c) OpenStreetMap contributors.
Pure Python 3 standard library. --jpeg (optional) needs Pillow and shrinks tiles ~2x.
"""
import argparse, math, os, sys, time, json, urllib.request, urllib.parse, urllib.error, io

AVG_KB = 25   # typical tile size (Voyager PNGs are a bit bigger than OSM's)
STYLES = {   # must match the app: tiles go to <out>/<style>/z/x/y.png
    "voyager": "https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
    "light":   "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
    "osm":     "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
}

def tile_xy(lat, lon, z):
    lat = max(-85.0511, min(85.0511, lat)); n = 2 ** z
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.log(math.tan(math.radians(lat)) + 1.0 / math.cos(math.radians(lat))) / math.pi) / 2.0 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))

def tiles_for(bbox, z):
    s, w, n, e = bbox
    x0, y1 = tile_xy(s, w, z); x1, y0 = tile_xy(n, e, z)
    return [(z, x, y) for x in range(min(x0, x1), max(x0, x1) + 1) for y in range(min(y0, y1), max(y0, y1) + 1)]

def parse_zoom(s):
    a, _, b = s.partition("-"); a = int(a); b = int(b or a)
    if not (0 <= a <= b <= 19): raise SystemExit("--zoom must be between 0 and 19, e.g. 10-15")
    return a, b

def geocode(place, ua):
    url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=" + urllib.parse.quote(place)
    req = urllib.request.Request(url, headers={"User-Agent": ua})
    with urllib.request.urlopen(req, timeout=20) as r: data = json.load(r)
    if not data: raise SystemExit(f"could not find '{place}'")
    return float(data[0]["lat"]), float(data[0]["lon"]), data[0].get("display_name", place)

def bbox_around(lat, lon, km):
    dlat = km / 111.32; dlon = km / (111.32 * max(0.05, math.cos(math.radians(lat))))
    return (lat - dlat, lon - dlon, lat + dlat, lon + dlon)

def main(argv=None):
    ap = argparse.ArgumentParser(description="Download map tiles for offline use in KRIVI Maps")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--place", help='place name, e.g. "Atlanta, Georgia"')
    g.add_argument("--bbox", nargs=4, type=float, metavar=("SOUTH", "WEST", "NORTH", "EAST"))
    ap.add_argument("--radius-km", type=float, default=8.0, help="with --place: half-width of the area (default 8)")
    ap.add_argument("--zoom", default="10-15", help="zoom range, e.g. 10-15 (default). 16+ gets big fast")
    ap.add_argument("--out", default="tiles", help="output folder (the SD card's maps/tiles); a <style> sub-folder is added")
    ap.add_argument("--style", choices=sorted(STYLES), default="voyager", help="voyager (Google-like, default), light or osm - must match the style chosen in the app")
    ap.add_argument("--url", help="custom tile URL template (then tiles go to <out>/custom/ - use style=custom in /sys/maps.txt)")
    ap.add_argument("--contact", help="your email/URL, put into the User-Agent (required for real downloads)")
    ap.add_argument("--delay", type=float, default=0.4, help="seconds between requests (default 0.4)")
    ap.add_argument("--max-tiles", type=int, default=2500, help="refuse bigger jobs unless --yes (default 2500)")
    ap.add_argument("--yes", action="store_true", help="allow jobs above --max-tiles")
    ap.add_argument("--dry-run", action="store_true", help="only count tiles and estimate size")
    ap.add_argument("--jpeg", action="store_true", help="re-save tiles as JPEG q70 (needs Pillow)")
    a = ap.parse_args(argv)
    z0, z1 = parse_zoom(a.zoom)
    style_id = "custom" if a.url else a.style
    tmpl = a.url or STYLES[a.style]
    root = os.path.join(a.out, style_id)
    ua = f"KRIVI-OS-maps_fetch/1.0 (personal offline cache; contact: {a.contact or 'unset'})"
    if a.place:
        if a.dry_run is False and not a.contact: raise SystemExit("please pass --contact you@example.com (OSM asks downloaders to identify themselves)")
        lat, lon, name = geocode(a.place, ua); bbox = bbox_around(lat, lon, a.radius_km); print(f"{name}\n  centre {lat:.4f}, {lon:.4f}, +/- {a.radius_km} km")
    else:
        bbox = tuple(a.bbox)
    allt = []
    for z in range(z0, z1 + 1):
        t = tiles_for(bbox, z); allt += t; print(f"  zoom {z:2d}: {len(t):6d} tiles")
    todo = [(z, x, y) for (z, x, y) in allt if not any(os.path.exists(os.path.join(root, str(z), str(x), f"{y}.{e}")) for e in ("png", "jpg"))]
    print(f"total {len(allt)} tiles, {len(allt) - len(todo)} already on disk, {len(todo)} to download  (~{len(todo) * AVG_KB / 1024:.0f} MB, ~{len(todo) * (a.delay + 0.15) / 60:.0f} min)")
    if a.dry_run: return 0
    if not a.contact: raise SystemExit("please pass --contact you@example.com (OSM asks downloaders to identify themselves)")
    if len(todo) > a.max_tiles and not a.yes:
        raise SystemExit(f"{len(todo)} tiles is a lot for a free community server. Reduce --zoom / --radius-km, or pass --yes if you really mean it.")
    if a.jpeg:
        try: from PIL import Image
        except ImportError: raise SystemExit("--jpeg needs Pillow:  pip install pillow")
    done = failed = 0
    for i, (z, x, y) in enumerate(todo, 1):
        url = tmpl.replace("{z}", str(z)).replace("{x}", str(x)).replace("{y}", str(y))
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": ua}), timeout=20) as r: data = r.read()
        except (urllib.error.URLError, OSError) as e:
            failed += 1; print(f"  ! {z}/{x}/{y}: {e}")
            if failed > 20: raise SystemExit("too many failures - stopping (check your network / the server's policy)")
            continue
        ext = "png" if data[:4] == b"\x89PNG" else "jpg" if data[:2] == b"\xff\xd8" else None
        if not ext: failed += 1; print(f"  ! {z}/{x}/{y}: not an image"); continue
        if a.jpeg and ext == "png":
            buf = io.BytesIO(); Image.open(io.BytesIO(data)).convert("RGB").save(buf, "JPEG", quality=70, optimize=True); data = buf.getvalue(); ext = "jpg"
        d = os.path.join(root, str(z), str(x)); os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, f"{y}.{ext}"), "wb") as f: f.write(data)
        done += 1
        if i % 25 == 0 or i == len(todo): print(f"  {i}/{len(todo)}")
        time.sleep(a.delay)
    print(f"done: {done} downloaded, {failed} failed -> {root}")
    return 0 if not failed else 1

if __name__ == "__main__":
    sys.exit(main())
