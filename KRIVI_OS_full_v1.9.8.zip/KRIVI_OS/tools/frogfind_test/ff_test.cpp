// ============================================================================
//  FrogFind browser - PC tests + screen previews
//
//  Build & run (from this folder), with TFT_eSPI installed:
//    g++ -std=c++17 -O1 -g -fsanitize=address,undefined -I<path>/TFT_eSPI ff_test.cpp -o ff_test
//    ./ff_test
//  Writes preview_*.ppm next to it (240x320, drawn by the app's own ff_ui.h
//  code with TFT_eSPI's fonts).
// ============================================================================
#include "fb_gfx.h"
#include <cassert>
#include <random>
#include <set>
#include <map>

static int g_pass = 0, g_fail = 0;
#define CHECK(c) do { if (c) ++g_pass; else { ++g_fail; printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)
#define CHECK_EQ(a, b) do { auto _a = (a); auto _b = (b); if (_a == _b) ++g_pass; else { ++g_fail; \
  printf("  FAIL %s:%d  %s\n      got: [%s]\n     want: [%s]\n", __FILE__, __LINE__, #a, std::string(_a).c_str(), std::string(_b).c_str()); } } while (0)

static FbGfx *G;

// ------------------------------------------------------------------ helpers
struct Parsed {
  ffc::Doc d;
  std::vector<char> pool;
  uint64_t safePos = 0, pos = 0;
  std::string title;
};
// same procedure as frog::parseFrom() on the device: 1 KB chunks until full
static void parseInto(Parsed &P, const std::string &html, size_t off, uint32_t poolCap, uint32_t segCap, bool plain = false) {
  P.pool.assign(poolCap, 0);
  P.d.pool = P.pool.data(); P.d.poolCap = poolCap; P.d.segCap = segCap;
  P.d.linkCountCap = 220; P.d.linkByteCap = poolCap / 2;
  P.d.reset();
  ffc::Layout L(P.d, ffui::PL, ffui::PR, ffui::width2, nullptr); L.plain = plain;
  ffc::Html H(L); H.plain = plain;
  for (size_t i = off; i < html.size() && !P.d.full; i += 1024)
    H.feed(html.data() + i, std::min<size_t>(1024, html.size() - i));
  H.finish();
  P.safePos = H.safePos; P.pos = H.pos; P.title = H.title;
}
static std::string segText(const ffc::Doc &d, int i) { return std::string(d.pool + d.segs[i].off, d.segs[i].len); }
static std::string lineText(const ffc::Doc &d, int l) {
  int f, n = d.segsOnLine(l, f); std::string s;
  for (int k = 0; k < n; ++k) s += segText(d, f + k);
  return s;
}
static std::string allText(const ffc::Doc &d) { std::string s; for (int l = 0; l < d.lines; ++l) s += lineText(d, l) + "\n"; return s; }
// the text as one flowing string (lines joined) - for phrases that may wrap
static std::string flat(const ffc::Doc &d) {
  std::string s;
  for (int l = 0; l < d.lines; ++l) { std::string t = lineText(d, l); if (t.empty()) continue; if (!s.empty()) s += ' '; s += t; }
  return s;
}
static void checkDocInvariants(const ffc::Doc &d, const char *what) {
  bool ok = true;
  for (size_t i = 0; i < d.segs.size(); ++i) {
    const ffc::Seg &s = d.segs[i];
    if (i && s.line < d.segs[i - 1].line) { ok = false; printf("  [%s] segs out of order at %zu\n", what, i); break; }
    if (s.off + s.len > d.poolUsed) { ok = false; printf("  [%s] seg past pool\n", what); break; }
    if (s.link >= (int)d.links.size()) { ok = false; printf("  [%s] bad link index\n", what); break; }
    if (!(s.flags & ffc::F_HR) && s.x + ffui::width2(d.pool + s.off, s.len, nullptr) > ffui::PR) {
      ok = false; printf("  [%s] seg overflows the right margin: line %d x %d '%s'\n", what, s.line, s.x, segText(d, (int)i).c_str()); break;
    }
    if (s.x < ffui::PL) { ok = false; printf("  [%s] seg left of margin\n", what); break; }
  }
  CHECK(ok);
  CHECK(d.poolUsed <= d.poolCap);
  CHECK(d.segs.size() <= d.segCap);
  CHECK(d.lineStart.size() == (size_t)d.lines + 1);
}

// ------------------------------------------------------------------ sample pages (FrogFind's real templates)
static const char *RESULTS =
  "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 2.0//EN\">\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n\n"
  "<html>\n<head>\n\t<title>FrogFind!</title>\n</head>\n<body>\n\n"
  "    <form action=\"/\" method=\"get\">\n"
  "    <a href=\"/\"><font size=6 color=\"#008000\">Frog</font><font size=6 color=\"#000000\">Find!</font></a> Leap again: <input type=\"text\" size=\"30\" name=\"q\" value=\"esp32 pinout\">\n"
  "    <input type=\"submit\" value=\"Ribbbit!\">\n    </form>\n    <hr>\n    <br>\n"
  "    <center>Search Results for <b>esp32 pinout</b></center>\n    <br>\n"
  "    <hr><br><a href='/read.php?a=https%3A%2F%2Frandomnerdtutorials.com%2Fesp32%2Dpinout%2Dreference%2Dgpios%2F&amp;rut=8f2c7a'><font size='4'><b>ESP32 Pinout Reference: Which GPIO pins should you use?</b></font><br><font color='#008000' size='2'>randomnerdtutorials.com/esp32-pinout-reference-gpios/</font></a><br>The <b>ESP32</b> chip comes with 48 pins with multiple functions. Not all pins are exposed in all <b>ESP32</b> development boards, and some pins cannot be used.<br><br><hr>"
  "<br><a href='/read.php?a=https%3A%2F%2Flastminuteengineers.com%2Fesp32%2Dpinout%2Dreference%2F&amp;rut=11aa'><font size='4'><b>ESP32 Pinout Reference - Last Minute Engineers</b></font><br><font color='#008000' size='2'>lastminuteengineers.com/esp32-pinout-reference/</font></a><br>Learn about the <b>ESP32</b> pinout - GPIO, ADC, DAC, touch, PWM, I2C, SPI &amp; UART pins &mdash; with a handy diagram.<br><br><hr>"
  "<br><a href='/read.php?a=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FESP32&amp;rut=99'><font size='4'><b>ESP32 - Wikipedia</b></font><br><font color='#008000' size='2'>en.wikipedia.org/wiki/ESP32</font></a><br>ESP32 is a series of low-cost, low-power system-on-chip microcontrollers with integrated Wi-Fi and dual-mode Bluetooth.<br><br><hr>\n"
  "</body>\n</html>\n";

static const char *ARTICLE =
  "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 2.0//EN\">\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n <html>\n <head>\n     <title>ESP32 - Wikipedia</title>\n </head>\n <body>\n"
  "    <p>\n        <form action=\"/read.php\" method=\"get\">\n        <a href=\"/\">Back to <b><font color=\"#008000\">Frog</font><font color=\"000000\">Find!</font></a></b> | Browsing URL: <input type=\"text\" size=\"38\" name=\"a\" value=\"https://en.wikipedia.org/wiki/ESP32\">\n        <input type=\"submit\" value=\"Go!\">\n        </form>\n    </p>\n    <hr>\n"
  "    <h1>ESP32</h1>\n"
  "    <p> View page images: <a href='image.php?i=https://upload.wikimedia.org/wikipedia/commons/2/20/ESP32_Espressif_ESP-WROOM-32_Dev_Board.jpg'>[1]</a>  <a href='image.php?i=https://upload.wikimedia.org/x/Esp32_board.jpg'>[2]</a> </small></p>\n"
  "    <p><font size=\"4\"><div><p>The <b>ESP32</b> is a series of low-cost, low-power <a href=\"/read.php?a=https://en.wikipedia.org/wiki/System_on_a_chip\">system on a chip</a> microcontrollers with integrated <a href=\"/read.php?a=https://en.wikipedia.org/wiki/Wi-Fi\">Wi-Fi</a> and dual-mode <a href=\"/read.php?a=https://en.wikipedia.org/wiki/Bluetooth\">Bluetooth</a>. The ESP32 series employs a Tensilica Xtensa LX6 microprocessor.</p>\n"
  "<h2>Features</h2><ul><li>Processors: Xtensa dual-core 32-bit LX6 microprocessor, operating at 160 or 240 MHz and performing at up to 600 DMIPS</li><li>Memory: 520 KiB RAM, 448 KiB ROM</li><li>Wireless connectivity: Wi-Fi 802.11 b/g/n</li></ul>\n"
  "<script>var x = '<p>should not show</p>';</script><style>p{color:red}</style>"
  "<h2>History</h2><p>Espressif&#8217;s ESP32 was announced in September 2016 &mdash; it succeeded the ESP8266. It runs from &minus;40&deg;C to 125&deg;C.</p>"
  "<blockquote>Caf\xC3\xA9 na\xC3\xAFve r&eacute;sum&eacute; &ldquo;quoted&rdquo; \xF0\x9F\x98\x80 end</blockquote>"
  "<p>See <a href=\"#cite_note-1\">[1]</a>, <a href=\"mailto:x@y.z\">email</a> and <a href=\"/read.php?a=https://www.espressif.com/en/products/socs/esp32#specs\">Espressif</a>.</p></div></font></p>\n </body>\n </html>\n";

// ------------------------------------------------------------------ tests
static void testRotation() {
  printf("rotation mapping\n");
  for (int r = 0; r < 4; ++r) {
    bool ok = true;
    int Wr = (r & 1) ? 320 : 240, Hr = (r & 1) ? 240 : 320;
    for (int y = 0; y < Hr; y += 7) for (int x = 0; x < Wr; x += 7) {
      int rx, ry, bx, by; ffc::toRaw(r, x, y, rx, ry);
      if (rx < 0 || rx > 239 || ry < 0 || ry > 319) ok = false;
      ffc::fromRaw(r, rx, ry, bx, by);
      if (bx != x || by != y) ok = false;
    }
    CHECK(ok);
  }
  // rotation 1 = rotation 0 with rows/columns swapped (MADCTL MV vs MX)
  int px, py;
  ffc::mapPoint(1, 0, 0, 0, px, py);       CHECK(px == 239 && py == 0);
  ffc::mapPoint(1, 0, 319, 239, px, py);   CHECK(px == 0 && py == 319);
  ffc::mapPoint(1, 0, 160, 120, px, py);   CHECK(px == 119 && py == 160);
  // flipped display (rot 3) is rot 1 turned 180: same physical point
  int a, b, c2, d2;
  ffc::mapPoint(1, 0, 50, 60, a, b); ffc::mapPoint(3, 0, 319 - 50, 239 - 60, c2, d2); CHECK(a == c2 && b == d2);
  CHECK(ffc::portraitFor(1, false) == 0); CHECK(ffc::portraitFor(1, true) == 2);
  CHECK(ffc::portraitFor(3, false) == 2); CHECK(ffc::portraitFor(3, true) == 0);
  // portrait corners land on portrait corners
  ffc::mapPoint(1, 0, 319, 0, px, py); CHECK(px == 239 && py == 319);
}

static void testUrls() {
  printf("urls\n");
  CHECK_EQ(ffc::urlEncode("esp32 pinout & more", true), "esp32+pinout+%26+more");
  CHECK_EQ(ffc::urlDecode("esp32+pinout+%26+more"), "esp32 pinout & more");
  CHECK_EQ(ffc::fromTyped("  esp32 pinout "), "http://frogfind.com/?q=esp32+pinout");
  CHECK_EQ(ffc::fromTyped("wikipedia.org"), "http://frogfind.com/read.php?a=http%3A%2F%2Fwikipedia.org");
  CHECK_EQ(ffc::fromTyped("https://example.com/a?b=c&d=e"), "http://frogfind.com/read.php?a=https%3A%2F%2Fexample.com%2Fa%3Fb%3Dc%26d%3De");
  CHECK_EQ(ffc::fromTyped("frogfind.com/about.php"), "http://frogfind.com/about.php");
  CHECK(ffc::looksLikeUrl("en.wikipedia.org/wiki/ESP32"));
  CHECK(ffc::looksLikeUrl("www.bbc.co.uk"));
  CHECK(!ffc::looksLikeUrl("esp32"));
  CHECK(!ffc::looksLikeUrl("3.14"));
  CHECK(!ffc::looksLikeUrl("how are you."));
  CHECK(!ffc::looksLikeUrl("hello world.com"));
  const std::string S = "http://frogfind.com/?q=esp32+pinout";
  const std::string R = "http://frogfind.com/read.php?a=https://en.wikipedia.org/wiki/ESP32";
  CHECK_EQ(ffc::resolve(S, "/read.php?a=https%3A%2F%2Fx.com%2F&rut=8f"), "http://frogfind.com/read.php?a=https%3A%2F%2Fx.com%2F&rut=8f");
  CHECK_EQ(ffc::resolve(R, "/read.php?a=https://en.wikipedia.org/wiki/Wi-Fi#History"), "http://frogfind.com/read.php?a=https://en.wikipedia.org/wiki/Wi-Fi");
  CHECK_EQ(ffc::resolve(R, "image.php?i=https://up.org/a b.jpg"), "http://frogfind.com/image_compressed.php?i=https://up.org/a%20b.jpg");
  CHECK_EQ(ffc::resolve(S, "https://youtube.com/ActionRetro"), "http://frogfind.com/read.php?a=https%3A%2F%2Fyoutube.com%2FActionRetro");
  CHECK_EQ(ffc::resolve(S, "//cdn.example.com/x"), "http://frogfind.com/read.php?a=http%3A%2F%2Fcdn.example.com%2Fx");
  CHECK_EQ(ffc::resolve(S, "about.php"), "http://frogfind.com/about.php");
  CHECK_EQ(ffc::resolve(S, "https://www.frogfind.com/about.php"), "http://frogfind.com/about.php");
  CHECK_EQ(ffc::resolve(S, "mailto:a@b.c"), "");
  CHECK_EQ(ffc::resolve(S, "#top"), "");
  CHECK_EQ(ffc::resolve(S, "javascript:void(0)"), "");
  CHECK_EQ(ffc::resolve(S, "  "), "");
  CHECK(ffc::isImageUrl(ffc::resolve(R, "image.php?i=https://x/y.jpg")));
  CHECK_EQ(ffc::displayAddress(S), "esp32 pinout");
  CHECK_EQ(ffc::displayAddress("http://frogfind.com/read.php?a=https%3A%2F%2Fx.com%2Fp&rut=9"), "https://x.com/p");
  CHECK_EQ(ffc::displayAddress(R), "https://en.wikipedia.org/wiki/ESP32");
  CHECK_EQ(ffc::origin("http://frogfind.com/read.php?a=x"), "http://frogfind.com");
}

static void testText() {
  printf("entities + utf-8\n");
  CHECK_EQ(ffc::decodeEntities("a &amp; b &lt;c&gt; &#39;q&#39; &eacute;t&eacute; &#x263A;! &bogus; &amp"), "a & b <c> 'q' ete ! &bogus; &amp");
  Parsed P;
  parseInto(P, "<p>caf\xC3\xA9 \xE2\x80\x94 \xF0\x9F\x98\x80 na\xC3\xAFve &mdash; 5&deg; \xC2\xA9 2026</p>", 0, 4000, 400);
  CHECK_EQ(allText(P.d), "cafe - naive - 5` (c) 2026\n");
  parseInto(P, "line one\nline two\n\nline four", 0, 4000, 400, true);
  CHECK(P.d.lines == 4);
  CHECK_EQ(lineText(P.d, 1), "line two");
  CHECK_EQ(lineText(P.d, 3), "line four");
  parseInto(P, "<p>a<!-- <b>hidden</b> -->b</p><p>1 < 2 and 3 > 2</p>", 0, 4000, 400);
  CHECK_EQ(allText(P.d), "ab\n\n1 < 2 and 3 > 2\n");
  // a word longer than a line is split, every piece fits
  std::string longw(300, 'x');
  parseInto(P, "<p>" + longw + "</p>", 0, 4000, 400);
  checkDocInvariants(P.d, "long word");
  CHECK(P.d.lines >= 3);
}

static void testResults() {
  printf("search results page\n");
  Parsed P; parseInto(P, RESULTS, 0, 30000, 2700);
  const ffc::Doc &d = P.d;
  checkDocInvariants(d, "results");
  std::string t = flat(d);
  CHECK_EQ(P.title, "FrogFind!");
  CHECK(t.find("Leap again") == std::string::npos);            // the HTML form is skipped (native search bar)
  CHECK(t.find("Search Results for esp32 pinout") != std::string::npos);
  CHECK(t.find("ESP32 Pinout Reference: Which GPIO pins") != std::string::npos);
  CHECK(t.find("SPI & UART pins - with a handy diagram") != std::string::npos);
  CHECK(d.links.size() == 3);
  if (d.links.size() == 3) {
    CHECK_EQ(d.links[0], "/read.php?a=https%3A%2F%2Frandomnerdtutorials.com%2Fesp32%2Dpinout%2Dreference%2Dgpios%2F&rut=8f2c7a");
    CHECK_EQ(ffc::resolve("http://frogfind.com/?q=esp32+pinout", d.links[2]), "http://frogfind.com/read.php?a=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FESP32&rut=99");
  }
  bool green = false, boldLink = false;
  for (auto &s : d.segs) {
    if ((s.flags & ffc::F_GREEN) && (s.flags & ffc::F_LINK)) green = true;
    if ((s.flags & ffc::F_BOLD) && (s.flags & ffc::F_LINK)) boldLink = true;
  }
  CHECK(green); CHECK(boldLink);
  // tapping on the first result title hits link 0
  int seg = -1, li = -1;
  for (int l = 0; l < d.lines && li < 0; ++l) {
    int f, n = d.segsOnLine(l, f);
    for (int k = 0; k < n; ++k) if (d.segs[f + k].link == 0) {
      int x = d.segs[f + k].x + 5, y = ffui::CY + l * ffui::LH + 8;
      li = ffui::linkAt(d, 0, x, y, false, seg); break;
    }
  }
  CHECK(li == 0);
  // tapping empty space hits nothing
  CHECK(ffui::linkAt(d, 0, 235, ffui::CY + 2, false, seg) == -1);
}

static void testArticle() {
  printf("article page\n");
  Parsed P; parseInto(P, ARTICLE, 0, 30000, 2700);
  const ffc::Doc &d = P.d;
  checkDocInvariants(d, "article");
  std::string t = flat(d);
  CHECK_EQ(P.title, "ESP32 - Wikipedia");
  CHECK(t.find("Browsing URL") == std::string::npos);
  CHECK(t.find("should not show") == std::string::npos);        // <script> skipped
  CHECK(t.find("color:red") == std::string::npos);              // <style> skipped
  CHECK(t.find("Espressif's ESP32 was announced in September 2016 - it succeeded") != std::string::npos);
  CHECK(t.find("-40`C to 125`C") != std::string::npos);
  CHECK(t.find("Cafe naive resume \"quoted\"  end") == std::string::npos);
  CHECK(t.find("Cafe naive resume \"quoted\" end") != std::string::npos);
  // heading styled
  bool head = false;
  for (int i = 0; i < (int)d.segs.size(); ++i) if (segText(d, i) == "ESP32" && (d.segs[i].flags & ffc::F_HEAD)) head = true;
  CHECK(head);
  // list items: bullet, and the wrapped line lines up under the text
  int liLine = -1;
  for (int l = 0; l < d.lines; ++l) if (lineText(d, l).rfind("* Processors:", 0) == 0) { liLine = l; break; }
  CHECK(liLine >= 0);
  if (liLine >= 0) {
    int f, n = d.segsOnLine(liLine + 1, f);
    int bulletW = ffui::width2("* ", 2, nullptr);
    CHECK(n > 0 && d.segs[f].x == ffui::PL + 12 + bulletW);
  }
  // links: image viewer, fragments, mailto
  const std::string base = "http://frogfind.com/read.php?a=https://en.wikipedia.org/wiki/ESP32";
  std::map<std::string, std::string> res;
  for (auto &h : d.links) res[h] = ffc::resolve(base, h);
  CHECK(ffc::isImageUrl(res["image.php?i=https://upload.wikimedia.org/wikipedia/commons/2/20/ESP32_Espressif_ESP-WROOM-32_Dev_Board.jpg"]));
  CHECK_EQ(res["#cite_note-1"], "");
  CHECK_EQ(res["mailto:x@y.z"], "");
  CHECK_EQ(res["/read.php?a=https://www.espressif.com/en/products/socs/esp32#specs"], "http://frogfind.com/read.php?a=https://www.espressif.com/en/products/socs/esp32");
  // spaces before links are not underlined
  for (auto &s : d.segs) if ((s.flags & ffc::F_LINK) && d.pool[s.off] == ' ') { CHECK(!"link segment starts with a space"); break; }
}

static void testLongPageParts() {
  printf("long page in parts\n");
  std::string html = "<html><head><title>Long</title></head><body>";
  for (int i = 1; i <= 400; ++i) {
    char b[160];
    snprintf(b, sizeof(b), "<p>P%04d lorem ipsum dolor sit amet, <a href=\"/read.php?a=https://x.org/%d\">link %d</a> consectetur.</p>\n", i, i, i);
    html += b;
  }
  html += "</body></html>";
  std::set<int> seen;
  size_t off = 0; int parts = 0;
  for (;;) {
    Parsed P; parseInto(P, html, off, 3000, 300);
    checkDocInvariants(P.d, "part");
    std::string t = allText(P.d);
    for (size_t p = t.find('P'); p != std::string::npos; p = t.find('P', p + 1))
      if (p + 4 < t.size() && isdigit((unsigned char)t[p + 1])) seen.insert(atoi(t.c_str() + p + 1));
    ++parts;
    if (!P.d.full) break;
    size_t next = off + (P.safePos ? P.safePos : P.pos);
    CHECK(next > off);
    if (next <= off || parts > 200) break;
    off = next;
  }
  CHECK(parts > 3);
  bool all = true; for (int i = 1; i <= 400; ++i) if (!seen.count(i)) { all = false; printf("  missing P%04d\n", i); break; }
  CHECK(all);
  printf("  %d parts, every paragraph present\n", parts);
}

static void testFuzz() {
  printf("fuzz (random bytes + tag soup)\n");
  std::mt19937 rng(1234);
  const char *bits[] = {"<p>", "</p>", "<a href='/x'>", "</a>", "<b>", "</b>", "<li>", "<ul>", "</ul>", "<br>", "<hr>",
                        "&amp;", "&#9731;", "&", "<", ">", "\"", "'", "<!--", "-->", "<script>", "</script>", "<h1>", "</h1>",
                        "<font color=green>", "</font>", "<form>", "</form>", "\xC3", "\xA9", "\xF0\x9F", " ", "\n", "word", "longgggggggggggggggggggggggggword"};
  bool ok = true;
  for (int it = 0; it < 300; ++it) {
    std::string s;
    int n = 200 + rng() % 4000;
    for (int i = 0; i < n; ++i) {
      if (rng() % 3 == 0) s += (char)(rng() % 256);
      else s += bits[rng() % (sizeof(bits) / sizeof(bits[0]))];
    }
    Parsed P; parseInto(P, s, 0, 1500 + rng() % 6000, 100 + rng() % 600, rng() % 7 == 0);
    int before = g_fail;
    checkDocInvariants(P.d, "fuzz");
    if (g_fail != before) { ok = false; break; }
  }
  CHECK(ok);
}

static void testKeyboard() {
  printf("keyboard\n");
  std::set<int> codes;
  for (int layer = 0; layer < 3; ++layer)
    for (int up = 0; up < 2; ++up) {
      ffc::KKey k[48]; int n = ffc::kbBuild(layer, up, k);
      CHECK(n > 0 && n <= 48);
      bool hasEnter = false, hasBs = false, hasSpace = false, inside = true, sizes = true, noOverlap = true, centers = true, fits = true;
      for (int i = 0; i < n; ++i) {
        codes.insert(k[i].code);
        hasEnter |= k[i].code == ffc::K_ENTER; hasBs |= k[i].code == ffc::K_BS; hasSpace |= k[i].code == ' ';
        if (k[i].x < 0 || k[i].x + k[i].w > 240 || k[i].y < ffc::KB_Y0 || k[i].y + k[i].h > 320) inside = false;
        if (k[i].w < 23 || k[i].h < 40) sizes = false;
        for (int j = i + 1; j < n; ++j)
          if (k[i].x < k[j].x + k[j].w && k[j].x < k[i].x + k[i].w && k[i].y < k[j].y + k[j].h && k[j].y < k[i].y + k[i].h) noOverlap = false;
        if (ffc::kbHit(k, n, k[i].x + k[i].w / 2, k[i].y + k[i].h / 2) != i) centers = false;
        if (ffui::keyIsChar(k[i]) && strlen(k[i].label) == 1) {
          int f = ffui::keyFont(*G, k[i]);
          if (G->textWidth(k[i].label, f) > k[i].w) {
            fits = false; printf("  label '%s' (%d px, font %d) too wide for key (%d px)\n", k[i].label, G->textWidth(k[i].label, f), f, k[i].w);
          }
        }
      }
      CHECK(hasEnter); CHECK(hasBs); CHECK(hasSpace); CHECK(inside); CHECK(sizes); CHECK(noOverlap); CHECK(centers); CHECK(fits);
    }
  bool allAscii = true;
  for (int c = 32; c < 127; ++c) if (!codes.count(c)) { allAscii = false; printf("  character '%c' (%d) not on any layer\n", c, c); }
  CHECK(allAscii);
  // touches in the gaps/edges still land on a key; above the keyboard does not
  ffc::KKey k[48]; int n = ffc::kbBuild(0, false, k);
  CHECK(ffc::kbHit(k, n, 0, 319) >= 0);
  CHECK(ffc::kbHit(k, n, 239, ffc::KB_Y0) >= 0);
  CHECK(ffc::kbHit(k, n, 1, ffc::KB_Y0 + ffc::KB_ROWH + 5) >= 0);
  CHECK(ffc::kbHit(k, n, 120, ffc::KB_Y0 - 20) == -1);
  // letter layout
  CHECK(k[0].code == 'q' && k[9].code == 'p' && k[10].code == 'a' && k[19].code == ffc::K_SHIFT);
  ffc::KKey ku[48]; ffc::kbBuild(0, true, ku);
  CHECK(ku[0].code == 'Q' && !strcmp(ku[0].label, "Q"));
}

// ------------------------------------------------------------------ previews
static void topToolbarPage(FbGfx &g, const std::string &addr, const ffc::Doc &d, int top, bool canBack) {
  ffui::drawTopBar(g, addr, false);
  ffui::drawPage(g, d, top, -1, false);
  ffui::drawToolbar(g, canBack, ffui::totalLines(d, false) > ffui::VIS, false);
}
static void previews() {
  printf("writing previews\n");
  {
    FbGfx g; ffui::initWidths(g);
    g.fillRect(0, 0, 240, 320, ffui::BG);
    std::vector<std::string> rec = {"esp32 pinout", "en.wikipedia.org/wiki/Frog", "weather atlanta", "how do magnets work"};
    ffui::drawTopBar(g, "Search or type a URL", true);
    ffui::drawHome(g, rec, true);
    ffui::drawToolbar(g, false, false, true);
    g.savePPM("preview_1_home.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    ffui::Kb k; k.prompt = "FrogFind!"; k.text = "esp32 pino";
    ffui::drawKbScreen(g, k);
    // finger on "u" with the pop-up bubble
    for (int i = 0; i < k.n; ++i) if (k.keys[i].code == 'u') { k.pressed = i; ffui::drawKey(g, k, i, true); ffui::drawBubble(g, k, i); }
    g.savePPM("preview_2_keyboard_abc.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    ffui::Kb k; k.prompt = "FrogFind!"; k.text = "en.wikipedia.org/wiki/ESP32"; k.upper = true;
    ffui::drawKbScreen(g, k);
    g.savePPM("preview_3_keyboard_shift.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    ffui::Kb k; k.prompt = "FrogFind!"; k.text = "price of 2 + 2 = $4?"; k.layer = ffc::LAYER_123;
    ffui::drawKbScreen(g, k);
    g.savePPM("preview_4_keyboard_123.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    ffui::Kb k; k.prompt = "FrogFind!"; k.text = "a [b] {c} #d %e ^f *g +h =i _j \\k |l ~m <n> `o"; k.layer = ffc::LAYER_SYM;
    ffui::drawKbScreen(g, k);
    g.savePPM("preview_5_keyboard_symbols.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    Parsed P; parseInto(P, RESULTS, 0, 30000, 2700);
    topToolbarPage(g, "esp32 pinout", P.d, 0, true);
    g.savePPM("preview_6_results.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    Parsed P; parseInto(P, ARTICLE, 0, 30000, 2700);
    topToolbarPage(g, P.title, P.d, 0, true);
    g.savePPM("preview_7_article.ppm");
    FbGfx g2; ffui::initWidths(g2);
    topToolbarPage(g2, P.title, P.d, 10, true);
    g2.savePPM("preview_8_article_scrolled.ppm");
  }
  {
    FbGfx g; ffui::initWidths(g);
    ffui::drawTopBar(g, "esp32 pinout", false);
    ffui::drawLoading(g, "Leaping to page...", "http://frogfind.com/?q=esp32+pinout");
    ffui::drawProgress(g, 420);
    g.fillRect(0, ffui::CY + 150, 240, 14, ffui::BG);
    g.text("12 of 29 KB", 120, ffui::CY + 157, 1, ffui::DIM, ffui::BG, ffui::DMC);
    ffui::drawToolbar(g, true, false, false, false);
    g.savePPM("preview_9_loading.ppm");
  }
}

int main() {
  G = new FbGfx(); ffui::initWidths(*G);
  testRotation();
  testUrls();
  testText();
  testResults();
  testArticle();
  testLongPageParts();
  testFuzz();
  testKeyboard();
  previews();
  printf("\n%d checks passed, %d failed\n", g_pass, g_fail);
  delete G;
  return g_fail ? 1 : 0;
}
