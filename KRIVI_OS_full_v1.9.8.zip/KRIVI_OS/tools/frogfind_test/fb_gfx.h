// PC framebuffer implementation of ffui::Gfx using TFT_eSPI's own font data
// (fonts 1, 2 and 4 are drawn exactly the way TFT_eSPI draws them).
#pragma once
#include <cstdio>
#include <cmath>
#include <cstring>
#include "../../KriviOS/ff_ui.h"

#ifndef PROGMEM
#define PROGMEM
#endif
#include "Fonts/glcdfont.c"
#include "Fonts/Font16.c"
#include "Fonts/Font32rle.c"

struct FbGfx : ffui::Gfx {
  uint16_t fb[240 * 320];
  int W = 240, H = 320;
  FbGfx() { memset(fb, 0, sizeof(fb)); }
  void px(int x, int y, uint16_t c) { if (x >= 0 && y >= 0 && x < W && y < H) fb[y * W + x] = c; }
  void fillRect(int x, int y, int w, int h, uint16_t c) override {
    for (int j = y; j < y + h; ++j) for (int i = x; i < x + w; ++i) px(i, j, c);
  }
  static int inset(int r, int d) {               // horizontal inset of a rounded corner row
    if (d >= r) return 0;
    double dy = r - d - 0.5;
    return (int)std::lround(r - std::sqrt(std::max(0.0, (double)r * r - dy * dy)));
  }
  void fillRoundRect(int x, int y, int w, int h, int r, uint16_t c) override {
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    for (int j = 0; j < h; ++j) {
      int d = std::min(j, h - 1 - j), in = inset(r, d);
      for (int i = x + in; i < x + w - in; ++i) px(i, y + j, c);
    }
  }
  void drawRoundRect(int x, int y, int w, int h, int r, uint16_t c) override {
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    auto in = [&](int i, int j) {                 // inside the filled rounded rect?
      if (i < 0 || j < 0 || i >= w || j >= h) return false;
      int d = std::min(j, h - 1 - j), k = inset(r, d);
      return i >= k && i < w - k;
    };
    for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i)
      if (in(i, j) && (!in(i - 1, j) || !in(i + 1, j) || !in(i, j - 1) || !in(i, j + 1))) px(x + i, y + j, c);
  }
  void hline(int x, int y, int w, uint16_t c) override { for (int i = 0; i < w; ++i) px(x + i, y, c); }
  void vline(int x, int y, int h, uint16_t c) override { for (int j = 0; j < h; ++j) px(x, y + j, c); }
  void line(int x0, int y0, int x1, int y1, uint16_t c) override {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) { px(x0, y0, c); if (x0 == x1 && y0 == y1) break; int e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
  }
  void circle(int x0, int y0, int r, uint16_t c) override {
    int f = 1 - r, ddx = 1, ddy = -2 * r, x = 0, y = r;
    px(x0, y0 + r, c); px(x0, y0 - r, c); px(x0 + r, y0, c); px(x0 - r, y0, c);
    while (x < y) {
      if (f >= 0) { y--; ddy += 2; f += ddy; }
      x++; ddx += 2; f += ddx;
      px(x0 + x, y0 + y, c); px(x0 - x, y0 + y, c); px(x0 + x, y0 - y, c); px(x0 - x, y0 - y, c);
      px(x0 + y, y0 + x, c); px(x0 - y, y0 + x, c); px(x0 + y, y0 - x, c); px(x0 - y, y0 - x, c);
    }
  }
  void fillCircle(int x0, int y0, int r, uint16_t c) override {
    for (int dy = -r; dy <= r; ++dy) { int dx = (int)std::floor(std::sqrt((double)r * r - dy * dy) + 0.5); hline(x0 - dx, y0 + dy, 2 * dx + 1, c); }
  }
  void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c) override {
    int minx = std::min({x0, x1, x2}), maxx = std::max({x0, x1, x2}), miny = std::min({y0, y1, y2}), maxy = std::max({y0, y1, y2});
    auto e = [](int ax, int ay, int bx, int by, int px_, int py_) { return (long)(bx - ax) * (py_ - ay) - (long)(by - ay) * (px_ - ax); };
    long area = e(x0, y0, x1, y1, x2, y2);
    for (int y = miny; y <= maxy; ++y) for (int x = minx; x <= maxx; ++x) {
      long a = e(x1, y1, x2, y2, x, y), b = e(x2, y2, x0, y0, x, y), d = e(x0, y0, x1, y1, x, y);
      if (area >= 0 ? (a >= 0 && b >= 0 && d >= 0) : (a <= 0 && b <= 0 && d <= 0)) px(x, y, c);
    }
  }
  static int fontH(int f) { return f == 1 ? 8 : f == 2 ? 16 : f == 4 ? 26 : 16; }
  int charW(unsigned char ch, int font) {
    if (font == 1) return 6;
    unsigned u = (ch > 31 && ch < 128) ? ch - 32 : 0;
    return font == 2 ? widtbl_f16[u] : widtbl_f32[u];
  }
  int textWidth(const char *s, int font) override { int w = 0; while (*s) w += charW((unsigned char)*s++, font); return w; }
  int drawChar(unsigned char ch, int x, int y, int font, uint16_t fg, uint16_t bg) {
    if (font == 1) {
      for (int i = 0; i < 6; ++i) {
        unsigned char line = i < 5 ? ::font[ch * 5 + i] : 0;
        for (int j = 0; j < 8; ++j) { if (line & 1) px(x + i, y + j, fg); else if (bg != fg) px(x + i, y + j, bg); line >>= 1; }
      }
      return 6;
    }
    if (ch < 32 || ch > 127) return 0;
    unsigned u = ch - 32;
    if (font == 2) {
      int width = widtbl_f16[u], h = 16, w = (width + 6) / 8;
      const unsigned char *p = chrtbl_f16[u];
      for (int i = 0; i < h; ++i) {
        if (bg != fg) for (int k = 0; k < width; ++k) px(x + k, y + i, bg);
        for (int k = 0; k < w; ++k) {
          unsigned char line = p[w * i + k];
          for (int b = 0; b < 8; ++b) if (line & (0x80 >> b)) px(x + k * 8 + b, y + i, fg);
        }
      }
      return width;
    }
    // font 4: run-length encoded
    int width = widtbl_f32[u], height = 26;
    const unsigned char *p = chrtbl_f32[u];
    int total = width * height, pc = 0;
    while (pc < total) {
      unsigned char line = *p++;
      if (line & 0x80) { int n = (line & 0x7F) + 1; while (n-- && pc < total) { px(x + pc % width, y + pc / width, fg); pc++; } }
      else { int n = line + 1; while (n-- && pc < total) { if (bg != fg) px(x + pc % width, y + pc / width, bg); pc++; } }
    }
    return width;
  }
  void text(const char *s, int x, int y, int font, uint16_t fg, uint16_t bg, int datum) override {
    int w = textWidth(s, font), h = fontH(font);
    switch (datum) {
      case ffui::DTC: x -= w / 2; break;
      case ffui::DTR: x -= w; break;
      case ffui::DML: y -= h / 2; break;
      case ffui::DMC: x -= w / 2; y -= h / 2; break;
      case ffui::DMR: x -= w; y -= h / 2; break;
    }
    while (*s) x += drawChar((unsigned char)*s++, x, y, font, fg, bg);
  }
  bool savePPM(const char *path) {
    FILE *f = fopen(path, "wb"); if (!f) return false;
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    for (int i = 0; i < W * H; ++i) {
      uint16_t c = fb[i];
      unsigned char rgb[3] = {(unsigned char)(((c >> 11) & 31) * 255 / 31), (unsigned char)(((c >> 5) & 63) * 255 / 63), (unsigned char)((c & 31) * 255 / 31)};
      fwrite(rgb, 1, 3, f);
    }
    fclose(f); return true;
  }
};
