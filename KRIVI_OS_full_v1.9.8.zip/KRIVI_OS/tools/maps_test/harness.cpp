// Host-side tests for app_maps.cpp (Arduino / TFT / SD / WiFi / HTTP mocked, virtual clock, fake internet)
#include "krivi.h"
#include "HTTPClient.h"
#include "TJpg_Decoder.h"
#include <functional>
#include <deque>
#include <fstream>
#include <sstream>

SerialC Serial; SDClass SD; TFT_eSPI tft; WiFiC WiFi; TJpgDecoder TJpgDec;
int g_trickle = 1 << 20;
int (*g_server)(const std::string &, std::string &, bool &) = nullptr;
std::vector<std::string> g_log;
static uint16_t FB[320 * 240];
static uint64_t vt_us = 0;
uint32_t millis() { return (uint32_t)(vt_us / 1000); }
uint32_t micros() { vt_us += 100; return (uint32_t)vt_us; }
static void tick();
void delay(uint32_t ms) { vt_us += (uint64_t)ms * 1000; tick(); }
uint32_t esp_random() { static uint32_t s = 1; s = s * 1664525u + 1013904223u; return s; }
void TFT_eSprite::pushSprite(int, int) {}
namespace sys { bool sdOk = true; void *bigAlloc(uint32_t b) { return malloc(b); } bool wifiConnect(uint32_t, bool) { return true; } }
namespace audio { void click() {} }

// ---------------------------------------------------------------- scripted touch + ui mocks
struct Seg { uint64_t t0, t1; float x0, y0, x1, y1; };
static std::vector<Seg> segs;
static void addTap(int x, int y, int ms = 110) { segs.push_back({vt_us + 30000, vt_us + 30000 + (uint64_t)ms * 1000, (float)x, (float)y, (float)x, (float)y}); }
static void addDrag(int x0, int y0, int x1, int y1, int ms = 500) { segs.push_back({vt_us + 30000, vt_us + 30000 + (uint64_t)ms * 1000, (float)x0, (float)y0, (float)x1, (float)y1}); }
namespace touch { bool read(int16_t &x, int16_t &y) {
  vt_us += 300;
  for (auto &s : segs) if (vt_us >= s.t0 && vt_us < s.t1) { float f = (float)(vt_us - s.t0) / (float)(s.t1 - s.t0); x = (int16_t)(s.x0 + (s.x1 - s.x0) * f); y = (int16_t)(s.y0 + (s.y1 - s.y0) * f); return true; }
  return false; } }
static std::deque<std::string> g_inputs; static std::vector<std::string> g_toasts;
namespace ui {
static Touch T; static uint8_t s_pressCnt = 0, s_relCnt = 0;
Touch &state() { return T; }
void clearEvents() { T.pressed = T.released = T.tap = false; T.swipe = 0; }
Touch &poll() {
  int16_t x, y; bool d = touch::read(x, y);
  if (d) { s_relCnt = 0;
    if (!T.down) { if (++s_pressCnt >= 2) { T.down = true; T.pressed = true; T.x = T.sx = x; T.y = T.sy = y; T.t0 = millis(); } }
    else { T.x = (T.x + 3 * x) / 4; T.y = (T.y + 3 * y) / 4; }
  } else { s_pressCnt = 0;
    if (T.down && ++s_relCnt >= 3) { T.down = false; T.released = true; int dx = T.x - T.sx, dy = T.y - T.sy; uint32_t dur = millis() - T.t0;
      if (abs(dx) < 20 && abs(dy) < 20 && dur < 800) T.tap = true;
      if (max(abs(dx), abs(dy)) > 32) { if (abs(dx) > abs(dy)) T.swipe = dx > 0 ? SW_RIGHT : SW_LEFT; else T.swipe = dy > 0 ? SW_DOWN : SW_UP; } } }
  return T; }
bool inRect(int x, int y, int rx, int ry, int rw, int rh) { return x >= rx && x < rx + rw && y >= ry && y < ry + rh; }
bool exitHit(const Touch &t) { return t.pressed && t.x >= EXIT_X0 && t.x <= EXIT_X1 && t.y >= EXIT_Y0 && t.y <= EXIT_Y1; }
void header(const char *title, uint16_t accent, const char *sub) { tft.fillRect(0, 0, 320, 24, C_PANEL); tft.fillRect(0, 24, 320, 2, accent); tft.setTextColor(C_TEXT); tft.drawString(title, 15, 5, 2); if (sub) tft.drawString(sub, 140, 8, 1); tft.fillRoundRect(260, 4, 56, 19, 4, C_EXIT); tft.drawString("EXIT", 280, 6, 2); }
void button(int x, int y, int w, int h, const char *label, uint16_t bg, uint16_t fg, uint8_t font) { tft.fillRoundRect(x, y, w, h, 5, bg); tft.drawRoundRect(x, y, w, h, 5, RGB565(90, 100, 130)); uint8_t od = tft.datum; tft.setTextColor(fg); tft.setTextDatum(MC_DATUM); tft.drawString(label, x + w / 2, y + h / 2 + 1, font); tft.setTextDatum(od); }
void centerText(const char *s, int cx, int cy, uint16_t fg, uint16_t, uint8_t font) { uint8_t od = tft.datum; tft.setTextColor(fg); tft.setTextDatum(MC_DATUM); tft.drawString(s, cx, cy, font); tft.setTextDatum(od); }
void clearBody(uint16_t c) { tft.fillRect(0, HDR_H, SCR_W, SCR_H - HDR_H, c); }
void toast(const char *m, uint16_t) { g_toasts.push_back(m); printf("    [toast] %s\n", m); }
void msgBox(const char *t, const char *m) { g_toasts.push_back(m); printf("    [msgBox] %s: %.60s\n", t, m); }
bool textInput(String &text, const char *, int, bool) { if (g_inputs.empty()) return false; text = String(g_inputs.front().c_str()); g_inputs.pop_front(); return true; }
}
void AppCtx::header(const char *sub) { ui::header("Maps", RGB565(0, 180, 170), sub); }

static void shot(const char *name) {
  system("mkdir -p /tmp/mshots");
  char p[96]; snprintf(p, sizeof(p), "/tmp/mshots/%s.ppm", name);
  FILE *f = fopen(p, "wb"); fprintf(f, "P6\n320 240\n255\n");
  for (int i = 0; i < 320 * 240; i++) { uint16_t c = FB[i]; uint8_t rgb[3] = {(uint8_t)(((c >> 11) & 31) * 255 / 31), (uint8_t)(((c >> 5) & 63) * 255 / 63), (uint8_t)((c & 31) * 255 / 31)}; fwrite(rgb, 1, 3, f); }
  fclose(f);
  snprintf(p, sizeof(p), "/tmp/mshots/%s.txt", name); f = fopen(p, "w");
  for (auto &t : tft.texts) fprintf(f, "%d\t%d\t%d\t%d\t%u\t%s\n", t.x, t.y, t.datum, t.font, t.fg, t.s.c_str());
  fclose(f);
}
struct Step { uint32_t ms; std::function<void()> fn; };
static std::vector<Step> steps; static size_t nextStep = 0;
static void tick() { while (nextStep < steps.size() && millis() >= steps[nextStep].ms) { auto f = steps[nextStep].fn; nextStep++; f(); } }

#include "../../KriviOS/app_maps.cpp"      // same TU: we can see the anonymous namespace

// ---------------------------------------------------------------- helpers
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { printf("  FAIL: " __VA_ARGS__); printf("  (line %d)\n", __LINE__); fails++; } else { printf("  ok:   " __VA_ARGS__); printf("\n"); } } while (0)
static std::string readFile(const std::string &p) { std::ifstream f(p, std::ios::binary); std::stringstream ss; ss << f.rdbuf(); return ss.str(); }

static int fakeServer(const std::string &url, std::string &body, bool &chunked) {
  static bool ipFail = false; (void)ipFail;
  auto has = [&](const char *s) { return url.find(s) != std::string::npos; };
  if (has("ipwho.is")) { body = readFile("fixtures/ipwho.json"); return 200; }
  if (has("ip-api.com")) { body = readFile("fixtures/ipapi.json"); return 200; }
  if (has("nominatim.openstreetmap.org/search")) { body = readFile(has("q=empty") ? "fixtures/nominatim_empty.json" : has("q=boom") ? "fixtures/nominatim_error.json" : "fixtures/nominatim.json"); return 200; }
  if (has("nominatim.openstreetmap.org/reverse")) { body = readFile("fixtures/reverse.json"); return 200; }
  if (has("routing.openstreetmap.de")) { chunked = true; body = readFile(has("routed-foot") ? "fixtures/osrm_error.json" : has("routed-bike") ? "fixtures/osrm_utf8.json" : "fixtures/osrm.json"); return 200; }
  int z, x, y; const char *sty = nullptr;
  if (sscanf(url.c_str(), "https://a.basemaps.cartocdn.com/rastertiles/voyager/%d/%d/%d.png", &z, &x, &y) == 3) sty = "google";
  else if (sscanf(url.c_str(), "https://a.basemaps.cartocdn.com/light_all/%d/%d/%d.png", &z, &x, &y) == 3) sty = "google";
  else if (sscanf(url.c_str(), "https://tile.openstreetmap.org/%d/%d/%d.png", &z, &x, &y) == 3) sty = "osm";
  if (sty) {
    char cmd[200]; snprintf(cmd, sizeof(cmd), "python3 gen_tile.py %d %d %d /tmp/_tile.png %s", z, x, y, sty); if (system(cmd)) return 500;
    body = readFile("/tmp/_tile.png"); return 200;
  }
  return 404;
}
static void freshState() { if (M) free(M); M = (MS *)calloc(1, sizeof(MS)); defaults(); M->hl = -1; strcpy(M->pname, "Dropped pin"); }

// ---------------------------------------------------------------- unit tests
struct Cap { std::vector<std::string> v; };
static void capLeaf(void *u, const char *path, const char *val) { ((Cap *)u)->v.push_back(std::string(path) + "=" + val); }
static bool hasKV(const Cap &c, const std::string &kv) { for (auto &s : c.v) if (s == kv) return true; return false; }
static Cap scanWith(const std::string &doc, int mode, uint32_t seed = 1) {
  Cap c; JS js; js.init(capLeaf, nullptr, nullptr, &c);
  if (mode == 0) for (unsigned char ch : doc) js.feed(ch);
  return c;
}

struct PngCtx { std::vector<uint16_t> *dst; int w; };
static void pngRowCb(void *u, int y, uint16_t *line) { PngCtx *c = (PngCtx *)u; if ((size_t)(y + 1) * c->w <= c->dst->size()) memcpy(c->dst->data() + (size_t)y * c->w, line, c->w * 2); }

static void unitTests() {
  printf("== JSON reader ==\n");
  std::string nom = readFile("fixtures/nominatim.json");
  Cap a = scanWith(nom, 0);
  CHECK(hasKV(a, "0.lat=33.7851") && hasKV(a, "0.lon=-84.3738"), "Nominatim: lat/lon strings of result 0");
  CHECK(hasKV(a, "1.display_name=Cafe Eclair, Marietta Street, Atlanta, Georgia, United States"), "UTF-8 accents folded to ASCII (accented Cafe Eclair)");
  CHECK(hasKV(a, "2.name=Tour Eiffel") && hasKV(a, "2.extratags.a=b,c"), "array of objects + nested object paths");
  std::string rt = readFile("fixtures/osrm.json");
  Cap b; { JS js; js.init(capLeaf, nullptr, nullptr, &b); for (unsigned char ch : rt) js.feed(ch); }
  CHECK(hasKV(b, "code=Ok") && hasKV(b, "routes.0.legs.0.steps.3.maneuver.exit=2"), "OSRM: code and roundabout exit via deep path");
  CHECK(hasKV(b, "routes.0.legs.0.steps.3.name=Rue de l'Ete Nandu"), "\\u00e9 escapes folded (Rue de l'\\u00c9t\\u00e9 \\u00d1and\\u00fa)");
  // same result when fed in random-sized slices and whole-file vs one char (state machine must not care)
  Cap b2; { JS js; js.init(capLeaf, nullptr, nullptr, &b2); std::string u8 = readFile("fixtures/osrm_utf8.json"); for (unsigned char ch : u8) js.feed(ch); }
  CHECK(hasKV(b2, "routes.0.legs.0.steps.3.name=Rue de l'Ete Nandu") && hasKV(b2, "routes.0.legs.0.steps.0.maneuver.type=depart"), "pretty-printed raw-UTF-8 document gives the same leaves");
  Cap e; { JS js; js.init(capLeaf, nullptr, nullptr, &e); std::string s = readFile("fixtures/nominatim_error.json"); for (unsigned char ch : s) js.feed(ch); }
  CHECK(hasKV(e, "error.code=429"), "error object path = error.code (search handler ignores it)");
  Cap w; { JS js; js.init(capLeaf, nullptr, nullptr, &w); std::string s = "{\"a\":[1,2.5e3,-4,true,null,{\"b\":[]},[[7]]],\"c\":\"x\\\"y\\\\z\\/\"}"; for (unsigned char ch : s) js.feed(ch); }
  CHECK(hasKV(w, "a.1=2.5e3") && hasKV(w, "a.4=null") && hasKV(w, "a.6.0.0=7") && hasKV(w, "c=x\"y\\z/"), "numbers, literals, empty arrays, nested arrays, escapes");

  printf("== polyline ==\n");
  { Poly p; p.reset(); const char *enc = "_p~iF~ps|U_ulLnnqC_mqNvxq`@"; double la, lo; std::vector<std::pair<double, double>> o;
    for (const char *c = enc; *c; ++c) if (p.feed(*c, la, lo)) o.push_back({la, lo});
    CHECK(o.size() == 3 && fabs(o[0].first - 38.5) < 1e-9 && fabs(o[0].second + 120.2) < 1e-9 && fabs(o[2].first - 43.252) < 1e-9 && fabs(o[2].second + 126.453) < 1e-9, "Google's reference polyline decodes to (38.5,-120.2) (40.7,-120.95) (43.252,-126.453)"); }

  printf("== projection ==\n");
  { // independent formula check: Eiffel Tower at z10 -> tile x=519, y=352 (OSM slippy-map math)
    Pt p = ll2p(48.8584, 2.2945); int sh = ZB - 10;
    double n = pow(2, 10); int tx = (int)floor((2.2945 + 180) / 360 * n); int ty = (int)floor((1 - log(tan(48.8584 * PIV / 180) + 1 / cos(48.8584 * PIV / 180)) / PIV) / 2 * n);
    CHECK((p.x >> sh) / 256 == tx && (p.y >> sh) / 256 == ty, "tile of the Eiffel Tower at z10 = %d/%d (reference formula %d/%d)", (p.x >> sh) / 256, (p.y >> sh) / 256, tx, ty);
    double la, lo; p2ll(p, la, lo); CHECK(fabs(la - 48.8584) < 1e-5 && fabs(lo - 2.2945) < 1e-5, "ll -> px -> ll round trip within 1e-5 deg (%.6f, %.6f)", la, lo);
    CHECK(fabs(mPerPx(0, 0) - 156543.03392) < 1e-3 && fabs(mPerPx(60, 10) - 76.4457) < 0.01, "metres per pixel: equator z0 = 156543 m, 60N z10 = %.3f m", mPerPx(60, 10));
    Pt q = ll2p(-89, 200); CHECK(q.x >= 0 && q.y >= 0 && q.y < WORLD, "out-of-range coordinates clamp safely"); }

  printf("== turn instructions ==\n");
  { Stp s; memset(&s, 0, sizeof(s)); char o[80];
    s.type = T_TURN; s.mod = modCode("left"); strcpy(s.name, "Main Street"); stepText(s, o, sizeof(o)); CHECK(!strcmp(o, "Turn left onto Main Street"), "'%s'", o);
    s.type = T_RBOUT; s.ex = 2; stepText(s, o, sizeof(o)); CHECK(!strcmp(o, "Roundabout: take exit 2 onto Main Street"), "'%s'", o);
    s.type = T_ARRIVE; s.mod = modCode("left"); s.name[0] = 0; stepText(s, o, sizeof(o)); CHECK(!strcmp(o, "Arrive at destination (on the left)"), "'%s'", o);
    s.type = T_FORK; s.mod = modCode("slight right"); strcpy(s.name, "I-85"); stepText(s, o, sizeof(o)); CHECK(!strcmp(o, "Keep right onto I-85"), "'%s'", o);
    CHECK(typeCode("end of road") == T_ENDROAD && typeCode("rotary") == T_RBOUT && typeCode("exit rotary") == T_RBEXIT && modCode("sharp left") == 8, "type / modifier name tables"); }
  freshState();
  { char o[24]; M->mi = false; fmtDist(o, sizeof o, 950); CHECK(!strcmp(o, "950 m"), "950 m -> '%s'", o); fmtDist(o, sizeof o, 12345); CHECK(!strcmp(o, "12.3 km"), "12345 m -> '%s'", o);
    M->mi = true; fmtDist(o, sizeof o, 12345); CHECK(!strcmp(o, "7.7 mi"), "12345 m (miles) -> '%s'", o); fmtDist(o, sizeof o, 100); CHECK(!strcmp(o, "330 ft"), "100 m (miles) -> '%s'", o);
    fmtTime(o, sizeof o, 3900); CHECK(!strcmp(o, "1 h 05 min"), "3900 s -> '%s'", o); }
  { char u[80]; subst("https://t/{z}/{x}/{y}.png", 12, 345, 678, u, sizeof u); CHECK(!strcmp(u, "https://t/12/345/678.png"), "tile URL template '%s'", u);
    char e[40]; urlEnc("Caf\xc3\xa9 & co", e, sizeof e); CHECK(!strcmp(e, "Caf%C3%A9%20%26%20co"), "URL-encoding '%s'", e); }

  printf("== PNG decoder (own inflate) vs Pillow ==\n");
  const char *names[] = {"p8", "p8_lvl0", "p8_lvl9", "p4", "p2", "p1", "g1", "rgb", "rgba", "gray", "graya", "tiny_fixed", "odd_rgb", "odd_p8", "odd_p4", "noise_rgb_multiidat", "tiny_p"};
  for (const char *nm : names) {
    char fn[96]; snprintf(fn, sizeof fn, "fixtures/png_%s.png", nm);
    std::string raw = readFile(fn); int W = ((uint8_t)raw[16] << 24) | ((uint8_t)raw[17] << 16) | ((uint8_t)raw[18] << 8) | (uint8_t)raw[19];
    int depth = (uint8_t)raw[24], ctype = (uint8_t)raw[25]; int nidat = 0; for (size_t i = 0; i + 4 < raw.size(); ++i) if (!memcmp(&raw[i], "IDAT", 4)) nidat++;
    system("mkdir -p /tmp/sdroot_maps/t"); { std::ofstream o("/tmp/sdroot_maps/t/x.png", std::ios::binary); o << raw; }
    File f = SD.open("/t/x.png"); std::string exp = readFile(std::string("fixtures/png_") + nm + ".rgb565");
    std::vector<uint16_t> got(exp.size() / 2, 0xFFFF); PngCtx ctx{&got, W};
    int w = 0, h = 0; int rc = pngDecode(f, pngRowCb, &ctx, &w, &h); f.close();
    long bad = 0; if (rc == 0) for (size_t i = 0; i < got.size(); ++i) { uint16_t e = (uint8_t)exp[2 * i] | ((uint8_t)exp[2 * i + 1] << 8); if (got[i] != e) bad++; }
    CHECK(rc == 0 && bad == 0, "%-20s %3dx%-3d depth %2d ctype %d idat-chunks %d  rc=%d  bad pixels=%ld", nm, w, h, depth, ctype, nidat, rc, bad);
  }
  { std::string raw = readFile("fixtures/png_rgb.png"); raw.resize(raw.size() / 2);                    // truncated file must fail cleanly, not hang/crash
    { std::ofstream o("/tmp/sdroot_maps/t/x.png", std::ios::binary); o << raw; }
    File f = SD.open("/t/x.png"); std::vector<uint16_t> got(256 * 256); PngCtx ctx{&got, 256}; int w, h; int rc = pngDecode(f, pngRowCb, &ctx, &w, &h); f.close();
    CHECK(rc < 0, "truncated PNG -> clean error (rc=%d)", rc); }
  { std::string raw = "not a png at all, just some html <html>"; { std::ofstream o("/tmp/sdroot_maps/t/x.png", std::ios::binary); o << raw; }
    File f = SD.open("/t/x.png"); int w, h; CHECK(pngDecode(f, nullptr, nullptr, &w, &h) < 0, "garbage file rejected"); f.close(); }
}

// ---------------------------------------------------------------- network-layer tests (fake internet)
static void netTests() {
  printf("== network flows (fake server, chunked + trickling responses) ==\n");
  g_server = fakeServer; system("rm -rf /tmp/sdroot_maps; mkdir -p /tmp/sdroot_maps");
  freshState();
  for (int tr : {1 << 20, 37, 1}) {
    g_trickle = tr; g_log.clear();
    bool ok = routeFetch(0, 33.7490, -84.3880, 33.7851, -84.3738);
    // ground truth from the generator
    std::ifstream ex("fixtures/osrm.expect"); std::string l; std::getline(ex, l); double td, tdur; int nst, npp; sscanf(l.c_str(), "%lf %lf %d %d", &td, &tdur, &nst, &npp);
    CHECK(ok && M->ns == nst && fabs(M->rdist - td) < 0.01 && fabs(M->rdur - tdur) < 0.01, "route via chunked stream, %d byte/read: %d steps, %.0f m, %.0f s", tr, M->ns, M->rdist, M->rdur);
    int bad = 0;
    for (int i = 0; i < nst && std::getline(ex, l); ++i) {
      char ty[32], md[32], nm[80]; int exi, d, du; double lo, la; std::string t = l; for (auto &c : t) if (c == '|') c = '\t';
      std::istringstream is(t); std::string f[8]; for (int k = 0; k < 8; ++k) std::getline(is, f[k], '\t');
      (void)ty; (void)md; (void)nm; (void)exi; (void)d; (void)du; (void)lo; (void)la;
      const Stp &s = M->steps[i]; double elo, ela; p2ll(s.p, ela, elo);
      if (s.type != typeCode(f[0].c_str()) || s.mod != modCode(f[1].c_str()) || s.ex != atoi(f[2].c_str()) || (int)s.dist != atoi(f[3].c_str()) || fabs(elo - atof(f[6].c_str())) > 2e-5 || fabs(ela - atof(f[7].c_str())) > 2e-5) { bad++; printf("    step %d mismatch: %s | type %d mod %d dist %u at %.5f,%.5f\n", i, l.c_str(), s.type, s.mod, s.dist, ela, elo); }
    }
    CHECK(bad == 0, "all %d steps (type, modifier, exit, distance, location) match the server data", nst);
    std::getline(ex, l); double fl, flo, ll_, llo; sscanf(l.c_str() + 2, "%lf,%lf", &fl, &flo); const char *lastp = strrchr(l.c_str(), ' '); sscanf(lastp + 1, "%lf,%lf", &ll_, &llo);
    double a1, o1, a2, o2; p2ll(M->pts[0], a1, o1); p2ll(M->pts[M->np - 1], a2, o2);
    CHECK(M->np >= npp && fabs(a1 - fl) < 2e-5 && fabs(o1 - flo) < 2e-5 && fabs(a2 - ll_) < 2e-5 && fabs(o2 - llo) < 2e-5, "polyline streamed in %d points, endpoints exact", M->np);
  }
  g_trickle = 1 << 20;
  CHECK(!routeFetch(2, 33.7, -84.3, 33.8, -84.3) && !strcmp(M->lastErr, "no route found"), "walking server answers NoRoute -> clean error '%s'", M->lastErr);
  CHECK(routeFetch(1, 33.7, -84.3, 33.8, -84.3) && M->ns > 3, "bike route (pretty-printed UTF-8 reply) ok");
  { bool ok = geocode("piedmont park"); CHECK(ok && M->nres == 3 && !strcmp(M->res[0].name, "Piedmont Park") && fabs(M->res[0].lat - 33.7851) < 1e-6, "search: %d results, first '%s'", M->nres, M->res[0].name);
    CHECK(!strcmp(M->res[1].name, "Cafe Eclair") && !strncmp(M->res[1].sub, "Marietta Street", 15), "unnamed result takes name from display_name: '%s' / '%s'", M->res[1].name, M->res[1].sub);
    CHECK(geocode("empty") && M->nres == 0, "empty answer -> 0 results"); CHECK(geocode("boom") && M->nres == 0, "429 error object -> 0 results (no crash)"); }
  { char nm[40]; CHECK(revGeocode(33.78, -84.37, nm, sizeof nm) && !strncmp(nm, "1320, Monroe Drive", 18), "reverse geocode -> '%s'", nm); }
  { memset(M->locName, 0, sizeof M->locName); M->locKnown = false; bool ok = ipLocate(); CHECK(ok && fabs(M->lat - 33.7489954) < 1e-6 && fabs(M->lon + 84.3879824) < 1e-6 && M->imp && M->mi, "IP location: %s (%.4f, %.4f), miles auto-on for US", M->locName, M->lat, M->lon); }
  { // tile download goes to the cache once, then never again
    system("rm -rf /tmp/sdroot_maps/maps"); g_log.clear(); M->style = 0; Http H; bool a = downloadTile(H, 13, 2161, 3362); bool isP; char path[48];
    CHECK(a && tileExists(13, 2161, 3362, path, sizeof path, isP) && isP, "tile downloaded and cached at %s", path);
    File f = SD.open(path); int w, h; std::vector<uint16_t> got(256 * 256); PngCtx c{&got, 256}; CHECK(pngDecode(f, pngRowCb, &c, &w, &h) == 0 && w == 256, "cached tile decodes (256x256)"); f.close();
    CHECK(!strcmp(path, "/maps/tiles/voyager/13/2161/3362.png") && g_log.size() == 1 && g_log[0].find("cartocdn.com/rastertiles/voyager/13/2161/3362.png") != std::string::npos, "default style = Voyager: URL '%s'", g_log[0].c_str());
    // each style has its own cache folder, so styles never mix
    M->style = 2; CHECK(!tileExists(13, 2161, 3362, path, sizeof path, isP), "switching to OSM style: voyager tile is NOT reused (separate cache)");
    g_log.clear(); Http H2; bool b2 = downloadTile(H2, 13, 2161, 3362); CHECK(b2 && tileExists(13, 2161, 3362, path, sizeof path, isP) && !strcmp(path, "/maps/tiles/osm/13/2161/3362.png") && g_log[0].find("tile.openstreetmap.org") != std::string::npos, "OSM style tile cached at %s", path);
    M->style = 0; CHECK(tileExists(13, 2161, 3362, path, sizeof path, isP) && !strcmp(path, "/maps/tiles/voyager/13/2161/3362.png"), "back to Voyager: its cached tile is found again (no re-download)");
    M->style = 3; strcpy(M->tile, "https://example.org/t/{z}/{x}/{y}.png"); g_log.clear(); { Http H3; downloadTile(H3, 5, 1, 1); } CHECK(!g_log.empty() && g_log[0] == "https://example.org/t/5/1/1.png", "custom tile template used when style=custom"); M->style = 0; }
}

// ---------------------------------------------------------------- full-app scripted session
static void screenTap(int x, int y) { addTap(x, y); }
static void buildScenario() {
  auto at = [&](uint32_t ms, std::function<void()> f) { steps.push_back({ms, f}); };
  uint32_t t = 4000; auto S = [&](uint32_t dt) { t += dt; return t; };
  at(S(0), [] { shot("m01_start_ip_located"); printf("    start: online=%d loc=%s %.3f,%.3f  z=%d  net calls=%zu\n", M->online, M->locName, M->lat, M->lon, M->z, g_log.size()); });
  at(S(200), [] { g_inputs.push_back("piedmont park"); screenTap(28, 225); });                 // FIND
  at(S(2500), [] { shot("m02_search_results"); });
  at(S(100), [] { screenTap(120, 63); });                                                       // first result
  at(S(3500), [] { shot("m03_pin_zoomed"); printf("    pin=%d '%s' z=%d\n", M->havePin, M->pname, M->z); });
  at(S(100), [] { screenTap(81, 225); });                                                       // ROUTE
  at(S(1200), [] { shot("m04_route_profile"); });
  at(S(100), [] { screenTap(120, 63); });                                                       // BY CAR
  at(S(6000), [] { shot("m05_route_drawn"); printf("    route=%d steps=%d pts=%d %.0f m z=%d\n", M->haveRoute, M->ns, M->np, M->rdist, M->z); });
  at(S(100), [] { screenTap(134, 225); });                                                      // STEPS
  at(S(1500), [] { shot("m06_steps"); });
  at(S(100), [] { screenTap(120, 147); });                                                      // step 3
  at(S(4000), [] { shot("m07_step_zoom"); printf("    highlighted step=%d z=%d\n", M->hl, M->z); });
  at(S(100), [] { screenTap(299, 36); screenTap(299, 36); });                                   // zoom + (second tap merged)
  at(S(3500), [] { shot("m08_zoomed_in"); });
  at(S(100), [] { screenTap(187, 225); });                                                      // SAVED
  at(S(1200), [] { shot("m09_saved_menu"); });
  at(S(100), [] { g_inputs.push_back("Park Run"); screenTap(120, 63); });                       // + Save current pin
  at(S(2500), [] { printf("    favourites=%d\n", M->nfav); });
  at(S(100), [] { screenTap(293, 225); });                                                      // MENU
  at(S(1200), [] { shot("m10_menu"); });
  at(S(100), [] { screenTap(120, 63); });                                                       // toggle OFFLINE (stays in menu)
  at(S(800), [] { printf("    mode now %s\n", M->online ? "ONLINE" : "OFFLINE"); screenTap(293, 212); });  // BACK
  at(S(2500), [] { g_log.clear(); addDrag(250, 120, 80, 100, 600); });                          // pan in offline mode
  at(S(4500), [] { shot("m11_offline_pan"); printf("    network calls while OFFLINE: %zu (must be 0)\n", g_log.size()); });
  at(S(100), [] { screenTap(299, 66); });                                                       // zoom out (z lower -> maybe no tiles)
  at(S(3000), [] { shot("m12_offline_no_tiles"); printf("    network calls while OFFLINE: %zu (must be 0)\n", g_log.size()); });
  at(S(100), [] { screenTap(293, 225); });                                                      // MENU
  at(S(1200), [] { screenTap(120, 97); });                                                      // Style -> LIGHT GREY (offline, not cached)
  at(S(3000), [] { shot("m13_style_light_offline"); printf("    style now %s, network calls while OFFLINE: %zu\n", styleId(), g_log.size()); });
  at(S(100), [] { screenTap(285, 12); });                                                       // EXIT
}

int main(int argc, char **argv) {
  tft.buf = FB; tft.W = 320; tft.H = 240;
  bool unit = argc < 2 || !strcmp(argv[1], "unit"), ui_ = argc < 2 || !strcmp(argv[1], "ui");
  if (unit) { freshState(); g_server = fakeServer; unitTests(); netTests(); }
  if (ui_) {
    printf("== FULL APP SESSION ==\n");
    system("rm -rf /tmp/sdroot_maps; mkdir -p /tmp/sdroot_maps"); g_server = fakeServer; g_log.clear(); vt_us = 0; segs.clear(); steps.clear(); nextStep = 0; g_trickle = 1 << 20;
    buildScenario();
    AppCtx c; static AppDef def = {86, 2, "Maps", "Maps", "MAP", RGB565(0, 180, 170), app_maps, "", ""}; c.def = &def;
    app_maps(c);
    CHECK(c.exitReq, "app exited through the EXIT box");
    CHECK(M == nullptr, "memory freed on exit");
    std::string cfg = readFile("/tmp/sdroot_maps/sys/maps.txt"), fav = readFile("/tmp/sdroot_maps/data/maps/favorites.txt");
    CHECK(cfg.find("mode=offline") != std::string::npos && cfg.find("style=voyager") != std::string::npos && cfg.find("loc=33.74") != std::string::npos && cfg.find("units=auto") != std::string::npos, "settings saved to /sys/maps.txt (mode, loc, view)");
    CHECK(fav.find("Park Run") != std::string::npos, "favourite saved to /data/maps/favorites.txt: %s", fav.substr(0, 40).c_str());
  }
  printf("\n%s (%d failures)\n", fails ? "SOME CHECKS FAILED" : "ALL CHECKS PASSED", fails);
  return fails ? 1 : 0;
}
