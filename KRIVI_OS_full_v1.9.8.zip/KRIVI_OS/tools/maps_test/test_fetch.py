#!/usr/bin/env python3
"""Tests tools/maps_fetch.py against a local fake tile server (no internet needed)."""
import http.server, threading, subprocess, sys, os, shutil, math, time, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import maps_fetch as mf
seen = []
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        seen.append((self.path, self.headers.get("User-Agent")))
        parts = self.path.strip("/").replace(".png", "").split("/")
        if parts == ["bad", "0", "0"]: self.send_response(200); self.end_headers(); self.wfile.write(b"<html>blocked</html>"); return
        z, x, y = parts; out = tempfile.mktemp(suffix=".png")
        subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), "gen_tile.py"), z, x, y, out], check=True)
        data = open(out, "rb").read(); os.remove(out)
        self.send_response(200); self.send_header("Content-Type", "image/png"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
port = srv.server_address[1]; ok = True
def check(c, msg):
    global ok; print(("  ok:   " if c else "  FAIL: ") + msg); ok &= bool(c)
# 1. independent tile maths: Eiffel Tower z10 -> 518/352
check(mf.tile_xy(48.8584, 2.2945, 10) == (518, 352), "tile_xy(Eiffel, z10) = (518, 352)")
# 2. tile counts for a bbox equal a brute-force count
bb = (33.70, -84.45, 33.82, -84.30)
for z in (10, 13, 15):
    n = 2 ** z; xs = {int((lo + 180) / 360 * n) for lo in [bb[1] + (bb[3] - bb[1]) * i / 4000 for i in range(4001)]}
    ys = {int((1 - math.log(math.tan(math.radians(la)) + 1 / math.cos(math.radians(la))) / math.pi) / 2 * n) for la in [bb[0] + (bb[2] - bb[0]) * i / 4000 for i in range(4001)]}
    check(len(mf.tiles_for(bb, z)) == len(xs) * len(ys), f"z{z}: {len(mf.tiles_for(bb, z))} tiles == brute force {len(xs) * len(ys)}")
# 3. dry run writes nothing
d = tempfile.mkdtemp()
r = subprocess.run([sys.executable, "../maps_fetch.py", "--bbox", *map(str, bb), "--zoom", "11-13", "--out", d, "--dry-run"], capture_output=True, text=True, cwd=os.path.dirname(__file__) or ".")
check(r.returncode == 0 and "to download" in r.stdout and not os.listdir(d), "--dry-run prints an estimate and writes nothing")
# 4. refuses without --contact, refuses big jobs without --yes
r = subprocess.run([sys.executable, "../maps_fetch.py", "--bbox", *map(str, bb), "--zoom", "11-12", "--out", d], capture_output=True, text=True, cwd=os.path.dirname(__file__) or ".")
check(r.returncode != 0 and "--contact" in (r.stderr + r.stdout), "refuses real downloads without --contact")
r = subprocess.run([sys.executable, "../maps_fetch.py", "--bbox", *map(str, bb), "--zoom", "10-17", "--out", d, "--contact", "t@x.y", "--max-tiles", "50", "--url", f"http://127.0.0.1:{port}/{{z}}/{{x}}/{{y}}.png"], capture_output=True, text=True, cwd=os.path.dirname(__file__) or ".")
check(r.returncode != 0 and "--yes" in (r.stderr + r.stdout) and not seen, "refuses a big job without --yes (and sent no requests)")
# 5. real run against the local server: files land in z/x/y.png, UA identifies us, existing tiles are skipped
url = f"http://127.0.0.1:{port}/{{z}}/{{x}}/{{y}}.png"
rc = mf.main(["--bbox", *map(str, bb), "--zoom", "11-12", "--out", d, "--contact", "me@example.com", "--url", url, "--delay", "0.01"])
files = [os.path.join(dp, f) for dp, _, fs in os.walk(d) for f in fs]
exp = len(mf.tiles_for(bb, 11)) + len(mf.tiles_for(bb, 12))
check(rc == 0 and len(files) == exp and all(os.sep + "custom" + os.sep in f for f in files), f"downloaded {len(files)} tiles into <out>/custom/z/x/y.png (expected {exp})")
check(all(ua and "me@example.com" in ua for _, ua in seen), "every request carried a User-Agent with the contact address")
n_before = len(seen); mf.main(["--bbox", *map(str, bb), "--zoom", "11-12", "--out", d, "--contact", "me@example.com", "--url", url, "--delay", "0.01"])
check(len(seen) == n_before, "second run skips everything already on disk (0 new requests)")
# 6. non-image replies are rejected, not saved
d2 = tempfile.mkdtemp(); mf.main(["--bbox", "0", "0", "0.0001", "0.0001", "--zoom", "0-0", "--out", d2, "--contact", "me@x.y", "--url", f"http://127.0.0.1:{port}/bad/0/0.png", "--delay", "0.01"])
check(not [f for _, _, fs in os.walk(d2) for f in fs], "an HTML 'blocked' page is not saved as a tile")
# 7. built-in styles resolve to the same URLs/folders the app uses
check(mf.STYLES["voyager"].startswith("https://a.basemaps.cartocdn.com/rastertiles/voyager/") and set(mf.STYLES) == {"voyager", "light", "osm"}, "style table: voyager / light / osm")
r = subprocess.run([sys.executable, "../maps_fetch.py", "--bbox", *map(str, bb), "--zoom", "12-12", "--out", d, "--style", "osm", "--dry-run"], capture_output=True, text=True, cwd=os.path.dirname(__file__) or ".")
check(r.returncode == 0 and "to download" in r.stdout, "--style osm dry-run works")
shutil.rmtree(d, ignore_errors=True); shutil.rmtree(d2, ignore_errors=True)
print("\n" + ("ALL FETCH TESTS PASSED" if ok else "SOME FETCH TESTS FAILED")); sys.exit(0 if ok else 1)
