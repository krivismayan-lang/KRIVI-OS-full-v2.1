#!/usr/bin/env python3
import json, math, os, struct, random
from PIL import Image, ImageDraw
os.makedirs("fixtures", exist_ok=True)
def c565(r, g, b): return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
def dump565(im, name):
    rgb = im.convert("RGB"); w, h = rgb.size
    with open(f"fixtures/{name}.rgb565", "wb") as f:
        for y in range(h):
            for x in range(w):
                f.write(struct.pack("<H", c565(*rgb.getpixel((x, y)))))
# ---------------- PNG decoder fixtures (many formats / compressors) -----------------
rnd = random.Random(5)
def art(w, h):
    im = Image.new("RGB", (w, h)); d = ImageDraw.Draw(im)
    for yy in range(h):
        d.line([(0, yy), (w, yy)], fill=(yy * 255 // h, 255 - yy * 255 // h, 128))
    for _ in range(40):
        xa, xb, ya, yb = sorted((rnd.randrange(w), rnd.randrange(w))) + sorted((rnd.randrange(h), rnd.randrange(h)))
        d.rectangle([xa, ya, xb, yb], outline=(rnd.randrange(256),) * 3, fill=tuple(rnd.randrange(256) for _ in range(3)))
    for _ in range(300): d.point((rnd.randrange(w), rnd.randrange(h)), fill=(255, 255, 255))
    return im
A = art(256, 256); small = art(8, 8); noise = Image.frombytes("RGB", (256, 256), bytes(rnd.randrange(256) for _ in range(256 * 256 * 3)))
cases = {
 "p8": A.quantize(colors=200), "p8_lvl0": A.quantize(colors=200), "p8_lvl9": A.quantize(colors=200),
 "p4": A.quantize(colors=16), "p2": A.quantize(colors=4), "p1": A.quantize(colors=2), "g1": A.convert("1"),
 "rgb": A, "rgba": A.convert("RGBA"), "gray": A.convert("L"), "graya": A.convert("LA"),
 "tiny_fixed": small, "odd_rgb": art(37, 21), "odd_p8": art(35, 19).quantize(colors=100), "odd_p4": art(33, 7).quantize(colors=16), "noise_rgb_multiidat": noise, "tiny_p": small.quantize(colors=8),
}
for name, im in cases.items():
    kw = dict(optimize=True)
    if name == "p8_lvl0": kw = dict(compress_level=0)
    if name == "p8_lvl9": kw = dict(compress_level=9)
    if name in ("p4", "p2", "p1"): kw = dict(optimize=True, bits=4 if name == "p4" else 2 if name == "p2" else 1)
    im.save(f"fixtures/png_{name}.png", **kw)
    dump565(im if im.mode not in ("LA",) else im.convert("RGB"), f"png_{name}")
# ---------------- API responses -----------------
def enc_poly(pts):
    out = []; plat = plon = 0
    for la, lo in pts:
        for v, p in ((round(la * 1e5), plat), (round(lo * 1e5), plon)):
            d = v - p; d = ~(d << 1) if d < 0 else d << 1
            while d >= 0x20: out.append(chr((0x20 | (d & 0x1f)) + 63)); d >>= 5
            out.append(chr(d + 63))
        plat, plon = round(la * 1e5), round(lo * 1e5)
    return "".join(out)
# route Atlanta-ish: start (33.7490,-84.3880) -> Piedmont Park (33.7851,-84.3738)
path = [(33.7490, -84.3880), (33.7530, -84.3875), (33.7570, -84.3866), (33.7612, -84.3860), (33.7655, -84.3841), (33.7701, -84.3822), (33.7742, -84.3790), (33.7790, -84.3765), (33.7851, -84.3738)]
def hav(a, b):
    R = 6371000; p1, p2 = math.radians(a[0]), math.radians(b[0]); dp = p2 - p1; dl = math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2; return 2 * R * math.asin(math.sqrt(h))
names = ["Peachtree Street Northeast", "", "Ponce de Leon Avenue Northeast", "Rue de l'\u00c9t\u00e9 \u00d1and\u00fa", "Monroe Drive", "Piedmont Avenue Northeast", "Park Drive", "Charles Allen Drive"]
types = [("depart", "right", None), ("turn", "left", None), ("new name", "straight", None), ("roundabout", "right", 2), ("exit roundabout", "right", None), ("fork", "slight left", None), ("end of road", "left", None), ("arrive", "right", None)]
steps = []; segs = list(zip(path[:-1], path[1:])); total = 0
for i, (a, b) in enumerate(segs):
    dist = hav(a, b); total += dist; t, m, ex = types[i]
    man = {"bearing_after": 10, "bearing_before": 0, "location": [a[1], a[0]], "modifier": m, "type": t}
    if ex: man["exit"] = ex
    steps.append({"geometry": enc_poly([a, b]), "maneuver": man, "mode": "driving", "driving_side": "right", "name": names[i], "intersections": [{"out": 0, "entry": [True, True], "bearings": [10, 190], "location": [a[1], a[0]], "lanes": [{"valid": True, "indications": ["left"]}]}], "weight": dist / 10, "duration": dist / 11.0, "distance": dist})
last = path[-1]; steps.append({"geometry": enc_poly([last, last]), "maneuver": {"bearing_after": 0, "bearing_before": 10, "location": [last[1], last[0]], "modifier": "right", "type": "arrive"}, "mode": "driving", "driving_side": "right", "name": "", "intersections": [{"in": 0, "entry": [True], "bearings": [190], "location": [last[1], last[0]]}], "weight": 0, "duration": 0, "distance": 0})
route = {"code": "Ok", "routes": [{"geometry": enc_poly(path), "legs": [{"steps": steps, "summary": "Peachtree", "weight": total / 10, "duration": total / 11.0, "distance": total}], "weight_name": "routability", "weight": total / 10, "duration": total / 11.0, "distance": total}], "waypoints": [{"hint": "abc", "distance": 3.2, "name": "", "location": [path[0][1], path[0][0]]}, {"hint": "def", "distance": 1.1, "name": "Park Drive", "location": [last[1], last[0]]}]}
open("fixtures/osrm.json", "w").write(json.dumps(route))                       # \u escapes
open("fixtures/osrm_utf8.json", "w", encoding="utf-8").write(json.dumps(route, ensure_ascii=False, indent=1))   # raw UTF-8 + whitespace
open("fixtures/osrm_error.json", "w").write(json.dumps({"code": "NoRoute", "message": "Impossible route between points"}))
with open("fixtures/osrm.expect", "w") as f:
    f.write(f"{total:.3f} {total/11.0:.3f} {len(steps)} {len(path)}\n")
    for s in steps:
        m = s["maneuver"]; f.write(f"{m['type']}|{m.get('modifier','')}|{m.get('exit',0)}|{int(s['distance'])}|{int(s['duration'])}|{s['name']}|{m['location'][0]:.6f}|{m['location'][1]:.6f}\n")
    f.write("P " + " ".join(f"{a:.5f},{b:.5f}" for a, b in path) + "\n")
nom = [
 {"place_id": 1, "licence": "x", "osm_type": "way", "lat": "33.7851", "lon": "-84.3738", "category": "leisure", "type": "park", "place_rank": 24, "importance": 0.6, "addresstype": "leisure", "name": "Piedmont Park", "display_name": "Piedmont Park, Piedmont Avenue Northeast, Midtown, Atlanta, Fulton County, Georgia, 30309, United States", "boundingbox": ["33.78", "33.79", "-84.38", "-84.37"]},
 {"place_id": 2, "lat": "33.7500", "lon": "-84.3900", "name": "", "display_name": "Caf\u00e9 \u00c9clair, Marietta Street, Atlanta, Georgia, United States", "boundingbox": ["1", "2", "3", "4"]},
 {"place_id": 3, "lat": "48.8584", "lon": "2.2945", "name": "Tour Eiffel", "display_name": "Tour Eiffel, 5, Avenue Anatole France, Paris, France", "extratags": {"a": "b,c"}},
]
open("fixtures/nominatim.json", "w", encoding="utf-8").write(json.dumps(nom, ensure_ascii=False))
open("fixtures/nominatim_empty.json", "w").write("[]")
open("fixtures/nominatim_error.json", "w").write(json.dumps({"error": {"code": 429, "message": "Bandwidth limit exceeded"}}))
open("fixtures/reverse.json", "w", encoding="utf-8").write(json.dumps({"place_id": 9, "lat": "33.78", "lon": "-84.37", "name": "", "display_name": "1320, Monroe Drive Northeast, Midtown, Atlanta, Georgia, 30306, United States"}))
open("fixtures/ipwho.json", "w").write(json.dumps({"ip": "203.0.113.9", "success": True, "type": "IPv4", "continent": "North America", "country": "United States", "country_code": "US", "region": "Georgia", "region_code": "GA", "city": "Atlanta", "latitude": 33.7489954, "longitude": -84.3879824, "is_eu": False, "connection": {"asn": 1, "org": "Example ISP"}, "timezone": {"id": "America/New_York"}}))
open("fixtures/ipapi.json", "w").write(json.dumps({"status": "success", "country": "Germany", "regionName": "Berlin", "city": "Berlin", "lat": 52.52, "lon": 13.405}))
print("fixtures written")
