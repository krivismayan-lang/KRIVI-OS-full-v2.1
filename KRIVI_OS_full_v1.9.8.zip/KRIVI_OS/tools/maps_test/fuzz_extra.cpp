// extra robustness tests appended via #include trick: corrupt/random input must never crash or hang
#define main harness_main
#include "harness.cpp"
#undef main
#include <random>
int main() {
  tft.buf = FB; freshState(); g_server = fakeServer; system("mkdir -p /tmp/sdroot_maps/t");
  std::mt19937 rng(7); int crashes = 0;
  // 1. PNG: flip random bytes / truncate every fixture many times
  const char *names[] = {"p8", "p4", "rgb", "rgba", "gray", "noise_rgb_multiidat", "p8_lvl0", "tiny_fixed"}; long runs = 0, okc = 0, errc = 0;
  for (const char *nm : names) { std::string raw = readFile(std::string("fixtures/png_") + nm + ".png");
    for (int k = 0; k < 150; ++k) { std::string m = raw; int nflip = 1 + rng() % 6; for (int j = 0; j < nflip; ++j) m[rng() % m.size()] ^= (uint8_t)(1 + rng() % 255); if (k % 5 == 0) m.resize(rng() % m.size());
      { std::ofstream o("/tmp/sdroot_maps/t/f.png", std::ios::binary); o << m; } File f = SD.open("/t/f.png"); std::vector<uint16_t> got(1024 * 1024); PngCtx c{&got, 1024}; int w, h;
      int rc = pngDecode(f, pngRowCb, &c, &w, &h); f.close(); runs++; if (rc == 0) okc++; else errc++; } }
  printf("PNG fuzz: %ld corrupted files -> %ld decoded, %ld rejected, no crash/hang\n", runs, okc, errc);
  // 2. JSON: random bytes and truncated/deep documents
  long n = 0; for (int k = 0; k < 400; ++k) { std::string d; int len = rng() % 3000; for (int i = 0; i < len; ++i) { static const char al[] = "{}[]\",:\\ut0123456789.-eE falsn\xc3\xa9\xe2\x82\xac"; d += al[rng() % (sizeof(al) - 1)]; }
    JS js; Cap c; js.init(capLeaf, nullptr, nullptr, &c); for (unsigned char ch : d) js.feed(ch); n += d.size(); }
  { std::string deep(5000, '['); JS js; Cap c; js.init(capLeaf, nullptr, nullptr, &c); for (unsigned char ch : deep) js.feed(ch); std::string long_str = "{\"a\":\"" + std::string(100000, 'x') + "\"}"; JS j2; Cap c2; j2.init(capLeaf, nullptr, nullptr, &c2); for (unsigned char ch : long_str) j2.feed(ch); }
  { std::string key = "{\"" + std::string(5000, 'k') + "\":1}"; JS j3; Cap c3; j3.init(capLeaf, nullptr, nullptr, &c3); for (unsigned char ch : key) j3.feed(ch); }
  printf("JSON fuzz: %ld random bytes + 5000-deep nesting + 100 KB string + 5 KB key: no crash\n", n);
  // 3. route parser against random corruption of the real OSRM reply (steps/points arrays must stay within bounds)
  std::string rt = readFile("fixtures/osrm.json"); long rr = 0, rok = 0;
  for (int k = 0; k < 200; ++k) { std::string m = rt; for (int j = 0; j < 4; ++j) m[rng() % m.size()] = (char)(rng() % 128); RouteOut ro; memset(&ro, 0, sizeof ro); ro.poly.reset(); RO = &ro; M->np = 0; M->cnt = 0; M->stride = 1; M->ns = 0;
    JS js; js.init(onRoute, routeBig, routeChr, nullptr); for (unsigned char ch : m) js.feed(ch); RO = nullptr; rr++; if (M->np <= MAXPTS && M->ns <= MAXSTEPS) rok++; }
  printf("route parser fuzz: %ld corrupted replies, array bounds respected in %ld\n", rr, rok);
  // 4. a huge polyline (200k points) must decimate into <= MAXPTS and keep endpoints
  { RouteOut ro; memset(&ro, 0, sizeof ro); ro.poly.reset(); RO = &ro; M->np = 0; M->cnt = 0; M->stride = 1; for (int i = 0; i < 200000; ++i) addRoutePt(33.0 + i * 1e-5, -84.0 + i * 1e-5); RO = nullptr;
    double a, o; p2ll(M->pts[0], a, o); printf("polyline decimation: 200000 points -> %d stored (limit %d), stride %d, first point %.5f,%.5f\n", M->np, MAXPTS, M->stride, a, o); if (M->np > MAXPTS) crashes++; }
  return crashes;
}
