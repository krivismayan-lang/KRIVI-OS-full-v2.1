#!/usr/bin/env python3
"""Paint a synthetic 256x256 test tile for (z,x,y). Roads/parks depend only on WORLD pixels so tiles join up.
   style 'osm' (default): plain OSM-ish colours.   style 'google': a stand-in for CARTO Voyager / Google-like colours.
   NOTE: these are NOT real map tiles - just something to exercise the app and preview the overlay look."""
import sys, random
from PIL import Image, ImageDraw, ImageFont
z, x, y, out = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
style = sys.argv[5] if len(sys.argv) > 5 else "osm"
G = style == "google"
land = (238, 238, 236) if G else (242, 239, 233)
im = Image.new("RGB", (256, 256), land); d = ImageDraw.Draw(im)
wx0, wy0 = x * 256, y * 256
k = 2 ** (z - 13)
def rng(cx, cy, s): return random.Random(cx * 73856093 ^ cy * 19349663 ^ s * 83492791 ^ z)
cs = max(64, int(160 * k))
try: font = ImageFont.load_default(size=9)
except TypeError: font = ImageFont.load_default()
for cy in range(wy0 // cs - 1, (wy0 + 256) // cs + 2):
    for cx in range(wx0 // cs - 1, (wx0 + 256) // cs + 2):
        v = rng(cx, cy, 1).random()
        if G: col = (200, 230, 196) if v < 0.14 else (170, 218, 255) if v < 0.19 else (246, 235, 222) if v < 0.5 else (232, 232, 230) if v < 0.8 else (240, 240, 238)
        else: col = (200, 230, 190) if v < 0.16 else (170, 210, 240) if v < 0.22 else (226, 222, 214) if v < 0.7 else (236, 230, 222)
        d.rectangle([cx * cs - wx0, cy * cs - wy0, (cx + 1) * cs - wx0, (cy + 1) * cs - wy0], fill=col)
        r = rng(cx, cy, 2)
        if G and r.random() < 0.55 and k >= 1:                    # category icon like Google's POI dots
            px, py = cx * cs - wx0 + r.randrange(14, cs - 14), cy * cs - wy0 + r.randrange(14, cs - 14)
            c = [(194, 24, 91), (25, 118, 210), (211, 47, 47), (0, 150, 136), (245, 124, 0)][r.randrange(5)]
            d.ellipse([px - 5, py - 5, px + 5, py + 5], fill=c); d.ellipse([px - 2, py - 2, px + 2, py + 2], fill=(255, 255, 255))
def road(px0, py0, px1, py1, major, vert, idx):
    if G:
        w = (max(4, int(8 * min(k, 1.6))) if major else max(2, int(4 * min(k, 1.6))))
        case = (233, 183, 90) if major else (205, 205, 205); fill = (252, 214, 125) if major else (255, 255, 255)
    else:
        w = (max(3, int(9 * min(k, 1.6))) if major else max(2, int(4 * min(k, 1.6)))); case = (190, 186, 178); fill = (255, 240, 170) if major else (255, 255, 255)
    for ww, c in ((w + 2, case), (w, fill)):
        if vert: d.rectangle([px0 - ww // 2, 0, px0 + ww // 2, 255], fill=c)
        else: d.rectangle([0, py0 - ww // 2, 255, py0 + ww // 2], fill=c)
for i in range(wx0 // cs - 1, (wx0 + 256) // cs + 2): road(i * cs - wx0, 0, 0, 0, i % 4 == 0, True, i)
for j in range(wy0 // cs - 1, (wy0 + 256) // cs + 2): road(0, j * cs - wy0, 0, 0, j % 4 == 0, False, j)
if G and k >= 1:                                                   # street-name labels (tiny, dark grey like Google)
    names = ["Av. Reforma", "Calle Rio Lerma", "Insurgentes", "Calle Puebla", "Av. Chapultepec", "Calle Sevilla", "Calle Liverpool"]
    for j in range(wy0 // cs - 1, (wy0 + 256) // cs + 2):
        py = j * cs - wy0
        if 0 < py < 256: d.text((20 + (j * 37) % 120, py - 12), names[j % len(names)], fill=(110, 113, 118), font=font)
    for i in range(wx0 // cs - 1, (wx0 + 256) // cs + 2):
        px = i * cs - wx0
        if 0 < px < 256: d.text((px + 5, 40 + (i * 53) % 150), names[(i + 3) % len(names)], fill=(110, 113, 118), font=font)
d.text((100, 120), f"{z}/{x}/{y}", fill=(150, 150, 155), font=font)
im.quantize(colors=128).save(out) if not G else im.save(out)       # real Voyager tiles are RGB/RGBA, OSM tiles are palette
