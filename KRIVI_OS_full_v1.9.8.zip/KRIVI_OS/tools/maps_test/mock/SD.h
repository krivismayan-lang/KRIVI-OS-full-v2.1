#pragma once
#include "Arduino.h"
#include <string>
#include <unistd.h>
#define FILE_WRITE "w"
class File {
 public:
  FILE *fp = nullptr;
  operator bool() const { return fp != nullptr; }
  void close() { if (fp) fclose(fp); fp = nullptr; }
  bool available() { if (!fp) return false; int c = fgetc(fp); if (c == EOF) return false; ungetc(c, fp); return true; }
  String readStringUntil(char t) { std::string o; int c; while ((c = fgetc(fp)) != EOF && c != t) o += (char)c; return String(o); }
  size_t print(const char *s) { return fputs(s, fp); }
  size_t printf(const char *f, ...) { va_list a; va_start(a, f); int n = vfprintf(fp, f, a); va_end(a); return n; }
  size_t write(const uint8_t *d, size_t n) { return fwrite(d, 1, n, fp); }
  int read(uint8_t *b, size_t n) { return (int)fread(b, 1, n, fp); }
  size_t size() { long p = ftell(fp); fseek(fp, 0, SEEK_END); long s = ftell(fp); fseek(fp, p, SEEK_SET); return s; }
  bool seek(uint32_t pos) { return fseek(fp, pos, SEEK_SET) == 0; }
};
struct SDClass {
  std::string root = "/tmp/sdroot_maps";
  File open(const char *p, const char *mode = "r") { File f; std::string full = root + p; f.fp = fopen(full.c_str(), mode); return f; }
  bool exists(const char *p) { std::string full = root + p; return access(full.c_str(), F_OK) == 0; }
  bool mkdir(const char *p) { std::string full = root + p; return ::mkdir(full.c_str(), 0777) == 0; }
  bool remove(const char *p) { std::string full = root + p; return ::remove(full.c_str()) == 0; }
  bool rename(const char *a, const char *b) { std::string x = root + a, y = root + b; return ::rename(x.c_str(), y.c_str()) == 0; }
};
extern SDClass SD;
