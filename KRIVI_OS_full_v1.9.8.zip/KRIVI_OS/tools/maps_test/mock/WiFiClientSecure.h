#pragma once
#include "Arduino.h"
#include <string>
#define WL_CONNECTED 3
struct WiFiC { int status() { return 3; } };
extern WiFiC WiFi;
extern int g_trickle;                 // max bytes returned per available() (simulates slow network)
class WiFiClient {
 public:
  std::string data; size_t pos = 0;
  int available() { size_t r = data.size() - pos; return (int)(r > (size_t)g_trickle ? g_trickle : r); }
  int read(uint8_t *b, size_t n) { size_t r = data.size() - pos; if (n > r) n = r; memcpy(b, data.data() + pos, n); pos += n; return (int)n; }
  bool connected() { return pos < data.size(); }
};
class WiFiClientSecure : public WiFiClient { public: void setInsecure() {} };
