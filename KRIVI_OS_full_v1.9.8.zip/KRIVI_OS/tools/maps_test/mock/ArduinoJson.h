#pragma once
struct JsonObject { };
struct JsonDocument { };
