#pragma once
#include "WiFiClientSecure.h"
#define HTTPC_STRICT_FOLLOW_REDIRECTS 1
// fake internet: returns the HTTP code; fills body; chunked => served with Transfer-Encoding: chunked
extern int (*g_server)(const std::string &url, std::string &body, bool &chunked);
extern std::vector<std::string> g_log;
class HTTPClient {
 public:
  std::string url; WiFiClient stream; bool chunked = false; int size = -1;
  void setReuse(bool) {} void setTimeout(int) {} void setFollowRedirects(int) {} void setUserAgent(const String &) {} void useHTTP10(bool) {}
  void collectHeaders(const char *k[], size_t n) {}
  bool begin(WiFiClient &, const String &u) { url = u.c_str(); return true; }
  int GET() {
    std::string body; chunked = false; g_log.push_back(url);
    int code = g_server(url, body, chunked);
    if (code != 200) return code;
    if (!chunked) { stream.data = body; size = (int)body.size(); }
    else {                                      // encode as chunked in odd-sized pieces + extension + trailer
      std::string o; size_t i = 0; int k = 0; static const int sizes[] = {7, 1000, 33, 4096, 5};
      while (i < body.size()) { size_t n = std::min<size_t>(sizes[k++ % 5], body.size() - i); char h[32]; snprintf(h, sizeof h, "%zx\r\n", n); o += h; o += body.substr(i, n); o += "\r\n"; i += n; }
      o += "0\r\n\r\n"; stream.data = o; size = -1;
    }
    stream.pos = 0; return 200;
  }
  WiFiClient *getStreamPtr() { return &stream; }
  int getSize() { return size; }
  String header(const char *) { return String(chunked ? "chunked" : ""); }
  void end() {}
};
