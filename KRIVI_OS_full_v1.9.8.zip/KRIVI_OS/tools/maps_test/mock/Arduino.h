#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdarg.h>
#include <algorithm>
#include <string>
#include <vector>
using std::min; using std::max; using std::abs;
#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
uint32_t millis(); uint32_t micros(); void delay(uint32_t ms);
uint32_t esp_random();
#define PI 3.14159265358979f
#include <ctype.h>
#include <sys/stat.h>
class String {
 public:
  std::string s;
  String() {} String(const char *c) : s(c ? c : "") {} String(const std::string &x) : s(x) {}
  const char *c_str() const { return s.c_str(); }
  size_t length() const { return s.size(); }
  void trim() { while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back(); size_t i=0; while(i<s.size()&&isspace((unsigned char)s[i]))i++; s=s.substr(i); }
  bool startsWith(const char *p) const { return s.rfind(p,0)==0; }
  bool endsWith(const char *p) const { size_t n=strlen(p); return s.size()>=n && s.compare(s.size()-n,n,p)==0; }
  String substring(int a, int b=-1) const { return String(b<0? s.substr(a): s.substr(a,b-a)); }
  void toLowerCase() { for(auto&c:s) c=tolower(c); }
  int indexOf(char c, int from=0) const { auto p=s.find(c,from); return p==std::string::npos?-1:(int)p; }
  int lastIndexOf(char c, int from=-1) const { auto p=from<0? s.rfind(c): s.rfind(c,from); return p==std::string::npos?-1:(int)p; }
  String operator+(const String &o) const { return String(s+o.s); }
  String(int v) : s(std::to_string(v)) {}
  int indexOf(const char *p) const { auto q=s.find(p); return q==std::string::npos?-1:(int)q; }
  bool operator==(const char *o) const { return s==o; }
  bool operator!=(const char *o) const { return s!=o; }
};
struct SerialC { void begin(int){} void printf(const char*,...){} };
extern SerialC Serial;
