#pragma once
#include "Arduino.h"
#include <vector>
#include <string>
#define TFT_BLACK 0x0000
#define TFT_WHITE 0xFFFF
#define TFT_BL 21
#define TL_DATUM 0
#define TC_DATUM 1
#define TR_DATUM 2
#define ML_DATUM 3
#define MC_DATUM 4
#define MR_DATUM 5
#define BL_DATUM 6
#define BC_DATUM 7
#define BR_DATUM 8
struct TextOp { int x, y, datum, font; uint16_t fg; std::string s; };
class TFT_eSPI {
 public:
  uint16_t *buf = nullptr; int W = 320, H = 240;
  std::vector<TextOp> texts;
  uint16_t fg = 0xFFFF; uint8_t datum = 0;
  TFT_eSPI() {}
  void init() {} void setRotation(int) {} void setSwapBytes(bool) {} void setTextFont(int) {}
  void setTextColor(uint16_t f) { fg = f; } void setTextColor(uint16_t f, uint16_t) { fg = f; }
  void setTextDatum(uint8_t d) { datum = d; }
  static uint16_t color565(uint8_t r, uint8_t g, uint8_t b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
  uint16_t alphaBlend(uint8_t a, uint16_t f, uint16_t b) {
    uint16_t fgR = (f >> 11) & 31, fgG = (f >> 5) & 63, fgB = f & 31, bgR = (b >> 11) & 31, bgG = (b >> 5) & 63, bgB = b & 31;
    uint16_t r = (fgR * a + bgR * (255 - a)) / 255, g = (fgG * a + bgG * (255 - a)) / 255, bl = (fgB * a + bgB * (255 - a)) / 255;
    return (r << 11) | (g << 5) | bl;
  }
  int textWidth(const char *s, int font = 1) { return strlen(s) * (font == 1 ? 6 : font == 2 ? 8 : 14); }
  int textWidth(const String &s, int font = 1) { return textWidth(s.c_str(), font); }
  void eraseTexts(int x, int y, int w, int h) {
    texts.erase(std::remove_if(texts.begin(), texts.end(), [&](const TextOp &t) { return t.x >= x && t.x < x + w && t.y >= y && t.y < y + h; }), texts.end());
  }
  void px(int x, int y, uint16_t c) { if (x >= 0 && y >= 0 && x < W && y < H) buf[y * W + x] = c; }
  void drawPixel(int x, int y, uint16_t c) { px(x, y, c); }
  void fillRect(int x, int y, int w, int h, uint16_t c) { eraseTexts(x, y, w, h); for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) px(i, j, c); }
  void fillScreen(uint16_t c) { fillRect(0, 0, W, H, c); }
  void drawFastHLine(int x, int y, int w, uint16_t c) { for (int i = 0; i < w; i++) px(x + i, y, c); }
  void drawFastVLine(int x, int y, int h, uint16_t c) { for (int j = 0; j < h; j++) px(x, y + j, c); }
  void drawRect(int x, int y, int w, int h, uint16_t c) { drawFastHLine(x, y, w, c); drawFastHLine(x, y + h - 1, w, c); drawFastVLine(x, y, h, c); drawFastVLine(x + w - 1, y, h, c); }
  void drawLine(int x0, int y0, int x1, int y1, uint16_t c) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) { px(x0, y0, c); if (x0 == x1 && y0 == y1) break; int e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
  }
  void fillCircle(int cx, int cy, int r, uint16_t c) { for (int j = -r; j <= r; j++) for (int i = -r; i <= r; i++) if (i * i + j * j <= r * r + r / 2) px(cx + i, cy + j, c); }
  void drawCircle(int cx, int cy, int r, uint16_t c) { for (int j = -r - 1; j <= r + 1; j++) for (int i = -r - 1; i <= r + 1; i++) { int d = i * i + j * j; if (d >= r * r - r && d <= r * r + r) px(cx + i, cy + j, c); } }
  void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c) { int mnx=std::min({x0,x1,x2}),mxx=std::max({x0,x1,x2}),mny=std::min({y0,y1,y2}),mxy=std::max({y0,y1,y2}); for(int y=mny;y<=mxy;y++)for(int x=mnx;x<=mxx;x++){ auto e=[&](int ax,int ay,int bx,int by){return (x-ax)*(by-ay)-(y-ay)*(bx-ax);}; int a=e(x0,y0,x1,y1),b=e(x1,y1,x2,y2),cc=e(x2,y2,x0,y0); if((a>=0&&b>=0&&cc>=0)||(a<=0&&b<=0&&cc<=0)) px(x,y,c);} }
  void fillRoundRect(int x, int y, int w, int h, int r, uint16_t c) { fillRect(x, y, w, h, c); }
  void drawRoundRect(int x, int y, int w, int h, int r, uint16_t c) { drawRect(x, y, w, h, c); }
  void pushImage(int x, int y, int w, int h, uint16_t *d) { for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) px(x + i, y + j, d[j * w + i]); }
  int drawString(const char *s, int x, int y, int font = 1) { texts.push_back({x, y, datum, font, fg, s}); return 0; }
  int drawString(const String &s, int x, int y, int font = 1) { return drawString(s.c_str(), x, y, font); }
};
class TFT_eSprite : public TFT_eSPI {
 public:
  TFT_eSPI *par; int depth = 16;
  TFT_eSprite(TFT_eSPI *p) : par(p) {}
  void setColorDepth(int d) { depth = d; }
  void *createSprite(int w, int h) { W = w; H = h; buf = (uint16_t *)calloc(w * h, 2); return buf; }
  void deleteSprite() { free(buf); buf = nullptr; }
  void fillSprite(uint16_t c) { for (int i = 0; i < W * H; i++) buf[i] = c; texts.clear(); }
  void pushSprite(int x, int y);
};
extern TFT_eSPI tft;
