#pragma once
#include "TFT_eSPI.h"
struct TJpgDecoder {
  bool (*cb)(int16_t, int16_t, uint16_t, uint16_t, uint16_t *) = nullptr;
  void setSwapBytes(bool) {} void setJpgScale(int) {}
  void setCallback(bool (*c)(int16_t, int16_t, uint16_t, uint16_t, uint16_t *)) { cb = c; }
  int drawJpg(int x, int y, const uint8_t *, uint32_t) { static uint16_t blk[16 * 16]; for (int i = 0; i < 256; i++) blk[i] = 0x7BEF; for (int by = 0; by < 256; by += 16) for (int bx = 0; bx < 256; bx += 16) cb(x + bx, y + by, 16, 16, blk); return 0; }
};
extern TJpgDecoder TJpgDec;
