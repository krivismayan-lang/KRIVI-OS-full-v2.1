import sys,glob
from PIL import Image, ImageDraw, ImageFont
D=sys.argv[1] if len(sys.argv)>1 else "/tmp/mshots"
F={1:ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",10),2:ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",14),4:ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",22)}
A={0:"la",1:"ma",2:"ra",3:"lm",4:"mm",5:"rm",6:"ld",7:"md",8:"rd"}
for p in sorted(glob.glob(D+"/*.ppm")):
    im=Image.open(p).convert("RGB"); d=ImageDraw.Draw(im)
    for l in open(p[:-4]+".txt"):
        x,y,da,fo,fg,s=l.rstrip("\n").split("\t",5); fg=int(fg)
        c=(((fg>>11)&31)*255//31,((fg>>5)&63)*255//63,(fg&31)*255//31)
        d.text((int(x),int(y)),s,fill=c,font=F.get(int(fo),F[2]),anchor=A[int(da)])
    im.resize((640,480),Image.NEAREST).save(p[:-4]+".png")
