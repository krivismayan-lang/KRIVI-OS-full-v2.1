#!/bin/sh
# Host-side tests for the Maps app (no ESP32 needed): g++ + python3 + Pillow.
# Builds app_maps.cpp against the REAL krivi.h with mocked Arduino/TFT/SD/WiFi, runs unit tests
# (JSON reader, polyline, projection, PNG decoder vs Pillow, chunked HTTP) and a scripted-touch session.
set -e
cd "$(dirname "$0")"
[ -d fixtures ] && [ -f fixtures/osrm.json ] || python3 gen_fixtures.py
g++ -std=gnu++17 -O1 -w -I mock -I ../../KriviOS harness.cpp -o /tmp/maps_harness
rm -rf /tmp/mshots
/tmp/maps_harness "$@"
