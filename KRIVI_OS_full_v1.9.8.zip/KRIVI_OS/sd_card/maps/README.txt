KRIVI Maps - offline tiles
===========================
Tiles live in  /maps/tiles/<style>/{zoom}/{x}/{y}.png   (.jpg also works)
  <style> = voyager (Google-like, default), light, osm, or custom.
Tiles the Maps app downloads while ONLINE are saved here automatically, so anywhere you have
looked at before keeps working with MODE = OFFLINE. Each style has its own folder.

To pre-load a whole area on your PC (needs Python 3):
  python3 tools/maps_fetch.py --place "Atlanta, Georgia" --radius-km 8 --zoom 10-15 \
          --contact you@example.com --out <SD card>/maps/tiles
(add --style light|osm to match the style you use; --dry-run first to see tiles / MB)
Please keep downloads small: the free tile servers are community services, not bulk mirrors
(https://operations.osmfoundation.org/policies/tiles/ and CARTO's basemap terms). For big regions use
another provider or your own tile server (--url, then style=custom in /sys/maps.txt).
Map data (c) OpenStreetMap contributors. Voyager / Light styles (c) CARTO.
