// ============================================================================
//  KRIVI OS - News Reader  (RSS + real photos)                      app 89
//
//  One story at a time, TV-news style: the real article photo on top, the
//  headline below, PREV/NEXT to flip through. FEED cycles between sources.
//
//  Feeds live in  /sys/news.txt  - one per line:   Label|https://feed-url
//  (blank/#-comment lines ignored). If the file is missing, sensible
//  defaults are used (Trump, Microsoft/Tech, World). Any RSS/Atom feed that
//  carries <media:content>, <media:thumbnail> or <enclosure> JPEG images
//  works; headlines still show when a story has no photo.
//
//  Photos are streamed to the SD card and decoded from there, so even big
//  feeds stay within the CYD's RAM.
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <TJpg_Decoder.h>
#include <vector>

namespace {

#define N_BG   RGB565(12, 14, 20)
#define N_CARD RGB565(20, 24, 34)

struct Feed { String label, url; };
struct Item { String title; String img; int imgW = 0; };

std::vector<Feed> g_feeds;
std::vector<Item> g_items;
int  g_feed = 0, g_idx = 0;
String g_err;

// layout
const int IX = 10, IY = 28, IBW = 300, IBH = 120;   // photo box
int g_imgBottom = IY + IBH;                           // for the clipped decoder
const int BY = 218, BH = 20;

const char *CACHE_XML = "/sys/cache/news.xml";
const char *CACHE_JPG = "/sys/cache/news.jpg";

// ---- JPEG output clipped to the photo box -----------------------------------
bool newsJpgOut(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bmp) {
  if (y >= g_imgBottom) return false;
  if (y + h > g_imgBottom) h = g_imgBottom - y;        // clip bottom edge
  tft.pushImage(x, y, w, h, bmp);
  return true;
}

// ---- feeds ------------------------------------------------------------------
void loadFeeds() {
  g_feeds.clear();
  if (sys::sdOk && SD.exists("/sys/news.txt")) {
    File f = SD.open("/sys/news.txt");
    while (f && f.available()) {
      String ln = f.readStringUntil('\n'); ln.trim();
      if (!ln.length() || ln[0] == '#') continue;
      int bar = ln.indexOf('|');
      Feed fd;
      if (bar > 0) { fd.label = ln.substring(0, bar); fd.url = ln.substring(bar + 1); }
      else         { fd.label = "Feed";               fd.url = ln; }
      fd.label.trim(); fd.url.trim();
      if (fd.url.startsWith("http")) g_feeds.push_back(fd);
    }
    if (f) f.close();
  }
  if (!g_feeds.size()) {                                // built-in defaults
    g_feeds.push_back({"Trump",     "https://www.theguardian.com/us-news/donaldtrump/rss"});
    g_feeds.push_back({"Microsoft", "https://www.theguardian.com/technology/microsoft/rss"});
    g_feeds.push_back({"World",     "https://feeds.bbci.co.uk/news/world/rss.xml"});
    g_feeds.push_back({"Tech",      "https://feeds.bbci.co.uk/news/technology/rss.xml"});
  }
}

// ---- tiny XML helpers -------------------------------------------------------
String decodeEntities(const char *s, int len) {
  String o; o.reserve(len);
  // strip a leading CDATA wrapper if present
  if (len >= 9 && !strncmp(s, "<![CDATA[", 9)) { s += 9; len -= 9; if (len >= 3 && !strncmp(s + len - 3, "]]>", 3)) len -= 3; }
  for (int i = 0; i < len; ++i) {
    if (s[i] == '&') {
      if (!strncmp(s + i, "&amp;", 5))  { o += '&';  i += 4; continue; }
      if (!strncmp(s + i, "&lt;", 4))   { o += '<';  i += 3; continue; }
      if (!strncmp(s + i, "&gt;", 4))   { o += '>';  i += 3; continue; }
      if (!strncmp(s + i, "&quot;", 6)) { o += '"';  i += 5; continue; }
      if (!strncmp(s + i, "&#39;", 5) || !strncmp(s + i, "&apos;", 6)) { o += '\''; i += (s[i + 2] == '3' ? 4 : 5); continue; }
      if (s[i + 1] == '#') {                            // numeric entity
        int j = i + 2, base = 10, code = 0;
        if (s[j] == 'x' || s[j] == 'X') { base = 16; j++; }
        while (j < len && s[j] != ';') { char c = s[j]; int d = (c >= '0' && c <= '9') ? c - '0' : (base == 16 ? ((c | 32) - 'a' + 10) : -1); if (d < 0 || d >= base) break; code = code * base + d; j++; }
        if (j < len && s[j] == ';') { o += (code < 128 && code > 0) ? (char)code : '?'; i = j; continue; }
      }
    }
    o += s[i];
  }
  o.trim();
  return o;
}

// find the first tag value <tag>...</tag> inside [a,b)
bool tagVal(const char *a, const char *b, const char *tag, String &out) {
  char open[24]; snprintf(open, sizeof(open), "<%s", tag);
  const char *p = strstr(a, open); if (!p || p >= b) return false;
  p = strchr(p, '>'); if (!p || p >= b) return false; p++;
  char close[24]; snprintf(close, sizeof(close), "</%s>", tag);
  const char *q = strstr(p, close); if (!q || q > b) q = b;
  out = decodeEntities(p, q - p);
  return out.length() > 0;
}

// pick the best image URL inside an item range
void pickImage(const char *a, const char *b, Item &it) {
  const char *best = nullptr; int bestLen = 0, bestScore = 1 << 30, bestW = 0;
  const char *p = a;
  while (p && p < b) {
    const char *u = strstr(p, "url=\""); if (!u || u >= b) break;
    const char *v = u + 5; const char *e = strchr(v, '"');
    if (!e || e > b) break;
    int ulen = e - v;
    // only JPEGs (TJpg can't do PNG/WebP); allow query strings after .jpg
    bool jpg = false;
    for (const char *k = v; k < e - 2; ++k) if ((k[0] == '.' && (k[1] | 32) == 'j' && (k[2] | 32) == 'p')) { jpg = true; break; }
    if (jpg) {
      int w = 0;                                        // look back for width="NNN"
      const char *wb = u - 90 < a ? a : u - 90;
      const char *wp = nullptr, *scan = wb;
      while ((scan = strstr(scan, "width=\"")) && scan < u) { wp = scan; scan += 7; }
      if (wp) w = atoi(wp + 7);
      int score = w > 0 ? abs(w - 300) : 500;           // prefer ~300px wide
      if (w > 0 && w < 150) score += 400;               // too small -> blocky
      if (score < bestScore) { bestScore = score; best = v; bestLen = ulen; bestW = w; }
    }
    p = e + 1;
  }
  if (best) { it.img = ""; it.img.concat(best, bestLen); it.imgW = bestW; }
}

// ---- download helpers -------------------------------------------------------
bool downloadToSD(const String &url, const char *path, uint32_t timeoutMs = 15000) {
  if (!sys::sdOk) return false;
  SD.remove(path);
  WiFiClientSecure sec; sec.setInsecure();
  WiFiClient plain;
  HTTPClient http;
  bool tls = url.startsWith("https");
  http.setReuse(false);
  http.setTimeout(timeoutMs);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setUserAgent("KRIVI-OS");
  const char *hk[] = {"Location"};
  http.collectHeaders(hk, 1);
  if (!(tls ? http.begin(sec, url) : http.begin(plain, url))) return false;
  int code = http.GET();
  if ((code == 301 || code == 302 || code == 307 || code == 308)) {
    String loc = http.header("Location"); http.end();
    if (loc.length()) return downloadToSD(loc, path, timeoutMs);
    return false;
  }
  if (code != 200) { http.end(); return false; }
  File f = SD.open(path, FILE_WRITE);
  if (!f) { http.end(); return false; }
  int n = http.writeToStream(&f);
  f.close(); http.end();
  return n > 0 && SD.exists(path);
}

// ---- parse feed XML off the SD card ----------------------------------------
bool parseFeed(String &err) {
  g_items.clear();
  File f = SD.open(CACHE_XML);
  if (!f) { err = "no feed file"; return false; }
  size_t sz = f.size();
  const size_t CAP = 56000;                             // read first chunk (enough for ~15 stories)
  size_t rd = sz < CAP ? sz : CAP;
  char *buf = (char *)malloc(rd + 1);
  if (!buf) { f.close(); err = "low memory"; return false; }
  size_t got = f.read((uint8_t *)buf, rd); f.close();
  buf[got] = 0;

  const char *p = buf, *end = buf + got;
  const int MAXITEMS = 14;
  while (g_items.size() < (size_t)MAXITEMS) {
    const char *is = strstr(p, "<item");
    if (!is) is = strstr(p, "<entry");                  // Atom fallback
    if (!is || is >= end) break;
    const char *ie = strstr(is, "</item>");
    if (!ie) ie = strstr(is, "</entry>");
    if (!ie || ie > end) ie = end;
    Item it;
    String title;
    if (tagVal(is, ie, "title", title)) {
      it.title = title;
      pickImage(is, ie, it);
      g_items.push_back(it);
    }
    p = ie + 1;
  }
  free(buf);
  if (!g_items.size()) { err = "no stories"; return false; }
  return true;
}

// ---- drawing ----------------------------------------------------------------
void drawButtons() {
  ui::button(2,   BY, 76, BH, "< PREV", C_PANEL2, C_TEXT, 1);
  ui::button(82,  BY, 76, BH, "NEXT >", C_PANEL2, C_TEXT, 1);
  ui::button(162, BY, 76, BH, g_feeds[g_feed].label.c_str(), RGB565(40,70,120), C_TEXT, 1);
  ui::button(242, BY, 76, BH, "RELOAD", C_PANEL2, C_DIM, 1);
}

void drawPlaceholder() {
  tft.fillRect(IX, IY, IBW, IBH, N_CARD);
  for (int i = 0; i < IBH; i += 2) tft.drawFastHLine(IX, IY + i, IBW, RGB565(22 + i / 6, 26 + i / 6, 38 + i / 5));
  const char *lbl = g_feeds[g_feed].label.c_str();
  ui::centerText("no photo", IX + IBW / 2, IY + IBH / 2 - 6, C_DIM, N_CARD, 2);
  ui::centerText(lbl, IX + IBW / 2, IY + IBH / 2 + 12, C_ACCENT, N_CARD, 1);
}

// word-wrap the headline into the area below the photo
void drawHeadline(const String &t) {
  int hy = IY + IBH + 6;
  tft.fillRect(0, hy, 320, BY - hy - 2, N_BG);
  tft.setTextColor(C_TEXT, N_BG); tft.setTextDatum(TL_DATUM);
  const int maxW = 300, lh = 18, maxLines = 3;
  String line; int y = hy, lines = 0;
  int i = 0, n = t.length();
  while (i < n && lines < maxLines) {
    int sp = t.indexOf(' ', i); if (sp < 0) sp = n;
    String word = t.substring(i, sp);
    String test = line.length() ? line + " " + word : word;
    if (tft.textWidth(test, 2) > maxW && line.length()) {
      tft.drawString(line, 10, y, 2); y += lh; lines++; line = word;
    } else line = test;
    i = sp + 1;
  }
  if (lines < maxLines && line.length()) { tft.drawString(line, 10, y, 2); lines++; }
}

void drawMeta() {
  char s[40];
  snprintf(s, sizeof(s), "%s  -  %d / %d", g_feeds[g_feed].label.c_str(), g_idx + 1, (int)g_items.size());
  tft.fillRect(0, BY - 16, 320, 14, N_BG);
  tft.setTextColor(C_DIM, N_BG); tft.setTextDatum(TL_DATUM);
  tft.drawString(s, 10, BY - 15, 1);
}

// show current story (headline immediately, then fetch + decode its photo)
void showStory(bool fetchImg) {
  if (!g_items.size()) return;
  Item &it = g_items[g_idx];
  drawHeadline(it.title);
  drawMeta();
  drawButtons();
  // photo
  tft.fillRect(IX, IY, IBW, IBH, N_CARD);
  if (!it.img.length()) { drawPlaceholder(); return; }
  ui::centerText("loading photo...", IX + IBW / 2, IY + IBH / 2, C_DIM, N_CARD, 2);
  if (!fetchImg) return;
  if (!sys::wifiConnect(12000, false)) { drawPlaceholder(); return; }
  bool ok = downloadToSD(it.img, CACHE_JPG);
  sys::radiosOff();
  if (!ok) { drawPlaceholder(); return; }
  File jf = SD.open(CACHE_JPG);
  if (!jf) { drawPlaceholder(); return; }
  int sw = it.imgW > 0 ? it.imgW : 300;
  int sc = sw > 620 ? 4 : sw > 330 ? 2 : 1;
  int drawW = sw / sc; if (drawW > IBW) { sc++; drawW = sw / sc; }
  int ox = IX + max(0, (IBW - drawW) / 2);
  tft.fillRect(IX, IY, IBW, IBH, N_BG);
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(newsJpgOut);
  TJpgDec.setJpgScale(sc);
  g_imgBottom = IY + IBH;
  if (TJpgDec.drawSdJpg(ox, IY, jf) != 0) { tft.fillRect(IX, IY, IBW, IBH, N_CARD); drawPlaceholder(); }
  // drawSdJpg closes the file
}

}  // namespace

void app_news(AppCtx &c) {
  g_items.clear(); g_feed = 0; g_idx = 0;
  loadFeeds();
  if (sys::sdOk) SD.mkdir("/sys/cache");
  c.header("RSS");
  ui::clearBody(N_BG);

  auto reload = [&]() {
    g_idx = 0; g_items.clear();
    ui::clearBody(N_BG);
    ui::centerText("Connecting WiFi...", 160, 108, C_WARN, N_BG, 2);
    if (!sys::wifiConnect(12000, false)) { ui::clearBody(N_BG); ui::centerText("WiFi failed", 160, 100, C_ERR, N_BG, 2); ui::centerText("set WiFi in Settings", 160, 122, C_DIM, N_BG, 1); drawButtons(); return; }
    ui::clearBody(N_BG);
    ui::centerText(g_feeds[g_feed].label.c_str(), 160, 100, C_ACCENT, N_BG, 4);
    ui::centerText("fetching headlines...", 160, 134, C_DIM, N_BG, 2);
    bool got = downloadToSD(g_feeds[g_feed].url, CACHE_XML);
    sys::radiosOff();
    String err;
    if (!got) err = "feed download failed";
    else if (!parseFeed(err)) {}
    ui::clearBody(N_BG);
    if (!g_items.size()) {
      ui::centerText("News unavailable", 160, 96, C_ERR, N_BG, 2);
      ui::centerText(err.length() ? err.c_str() : "try RELOAD", 160, 120, C_DIM, N_BG, 1);
      drawButtons(); return;
    }
    showStory(true);
  };

  reload();

  while (c.loop()) {
    Touch &t = *c.t;
    if (t.swipe == 4) { if (g_items.size()) { g_idx = (g_idx + 1) % g_items.size(); showStory(true); } continue; }   // swipe left -> next
    if (t.swipe == 2) { if (g_items.size()) { g_idx = (g_idx - 1 + g_items.size()) % g_items.size(); showStory(true); } continue; }
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 2, BY, 76, BH))   { if (g_items.size()) { g_idx = (g_idx - 1 + g_items.size()) % g_items.size(); showStory(true); } }
    else if (ui::inRect(t.sx, t.sy, 82, BY, 76, BH))  { if (g_items.size()) { g_idx = (g_idx + 1) % g_items.size(); showStory(true); } }
    else if (ui::inRect(t.sx, t.sy, 162, BY, 76, BH)) { g_feed = (g_feed + 1) % g_feeds.size(); c.header("RSS"); reload(); }
    else if (ui::inRect(t.sx, t.sy, 242, BY, 76, BH)) { reload(); }
  }
}
