// ============================================================================
//  System apps
//   74 System Settings Panel    75 NVS Flash Editor
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <nvs.h>
#include <nvs_flash.h>
#include <HTTPClient.h>
#include <vector>
#include <algorithm>

// ============================================================================
//  Wi-Fi picker (iPhone style): scan -> list -> tap to join.
//  Open networks join straight away; locked ones ask for the password;
//  school "username + password" (WPA2-Enterprise) ones ask for both.
//  After joining it checks for real internet and spots sign-in (captive) pages.
// ============================================================================
namespace wifipick {

#define W_BLUE  RGB565(10, 132, 255)
#define W_CARD  RGB565(28, 32, 46)
#define W_SEP   RGB565(48, 54, 74)

struct Net { String ssid; int rssi; uint8_t auth; };

const int LX = 8, LY = 50, LW = 304, RH = 30, VIS = 5;
const int BY = 206, BH = 30;

// 1 = internet OK, 0 = sign-in page in the way, -1 = no answer
int netCheck() {
  WiFiClient cl; HTTPClient h;
  h.setTimeout(5000);
  h.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  if (!h.begin(cl, "http://connectivitycheck.gstatic.com/generate_204")) return -1;
  int code = h.GET(); h.end();
  if (code == 204) return 1;
  return code > 0 ? 0 : -1;
}

void lockIcon(int x, int y, uint16_t col, uint16_t bg) {          // ~9x11 padlock
  tft.drawCircle(x + 4, y + 4, 3, col);
  tft.fillRect(x + 1, y + 4, 7, 2, bg);                            // keep only the top arc
  tft.drawFastVLine(x + 1, y + 3, 3, col); tft.drawFastVLine(x + 7, y + 3, 3, col);
  tft.fillRoundRect(x, y + 5, 9, 7, 1, col);
}

void bars(int x, int y, int rssi) {                               // 4 signal bars, 16 wide
  int lvl = rssi >= -55 ? 4 : rssi >= -67 ? 3 : rssi >= -78 ? 2 : 1;
  for (int i = 0; i < 4; ++i) {
    int h = 3 + i * 3;
    tft.fillRect(x + i * 4, y + 12 - h, 3, h, i < lvl ? C_TEXT : RGB565(70, 76, 96));
  }
}

void checkMark(int x, int y, uint16_t col) {
  for (int k = 0; k < 2; ++k) {
    tft.drawLine(x, y + 5 + k, x + 3, y + 8 + k, col);
    tft.drawLine(x + 3, y + 8 + k, x + 10, y + 1 + k, col);
  }
}

String fit(const String &s, int maxW) {
  if (tft.textWidth(s, 2) <= maxW) return s;
  String o = s;
  while (o.length() > 1 && tft.textWidth(o + "...", 2) > maxW) o.remove(o.length() - 1);
  return o + "...";
}

bool connectedTo(const String &ssid) {
  return WiFi.status() == WL_CONNECTED && WiFi.SSID() == ssid;
}

// try to join; on success save to settings.json, on failure put the old settings back
bool joinWith(AppCtx &c, const String &ssid, const String &pass, const String &user) {
  String oS = sys::cfg["wifi"]["ssid"] | "", oP = sys::cfg["wifi"]["pass"] | "",
         oU = sys::cfg["wifi"]["user"] | "", oI = sys::cfg["wifi"]["identity"] | "";
  c.header("Wi-Fi");
  ui::clearBody();
  ui::centerText("Joining", 160, 100, C_DIM, C_BG, 2);
  ui::centerText(fit(ssid, 300).c_str(), 160, 124, C_TEXT, C_BG, 4);

  sys::cfg["wifi"]["ssid"] = ssid;
  sys::cfg["wifi"]["pass"] = pass;
  if (user.length()) sys::cfg["wifi"]["user"] = user;
  else { sys::cfg["wifi"].remove("user"); sys::cfg["wifi"].remove("identity"); }

  WiFi.disconnect(true); delay(150);
  bool ok = sys::wifiConnect(16000, false);
  if (!ok) {
    sys::cfg["wifi"]["ssid"] = oS; sys::cfg["wifi"]["pass"] = oP;
    if (oU.length()) sys::cfg["wifi"]["user"] = oU; else sys::cfg["wifi"].remove("user");
    if (oI.length()) sys::cfg["wifi"]["identity"] = oI;
    ui::msgBox("COULDN'T JOIN", pass.length() || user.length()
                 ? "Check the password and try again.\nIs the network in range?"
                 : "The network didn't answer.\nMove closer and try again.");
    return false;
  }
  sys::saveSettings();
  ui::centerText("checking internet...", 160, 160, C_DIM, C_BG, 2);
  int net = netCheck();
  if (net == 1) { ui::toast("Connected - internet OK", C_OK); delay(900); }
  else if (net == 0) {
    char m[160];
    snprintf(m, sizeof(m), "Joined %s, but it wants a\nweb sign-in page the board can't\nfill in. Ask IT to register:\nMAC %s",
             ssid.c_str(), WiFi.macAddress().c_str());
    ui::msgBox("SIGN-IN NEEDED", m);
  } else { ui::toast("Joined - but no internet yet", C_WARN); delay(1200); }
  return true;
}

// returns false if the user hit the global EXIT
bool picker(AppCtx &c) {
  std::vector<Net> nets;
  int scroll = 0;

  auto status = [&](const char *msg, uint16_t col) {
    tft.fillRect(0, 26, 320, 22, C_BG);
    tft.setTextColor(col, C_BG); tft.setTextDatum(TL_DATUM);
    tft.drawString(msg, 10, 30, 2);
  };

  auto drawList = [&]() {
    tft.fillRect(0, 26, 320, BY - 28, C_BG);
    if (WiFi.status() == WL_CONNECTED) {
      String s = "Connected: " + WiFi.SSID();
      status(fit(s, 220).c_str(), C_OK);
    } else status("Choose a network", C_DIM);
    char cnt[16]; snprintf(cnt, sizeof(cnt), "%d found", (int)nets.size());
    tft.setTextColor(C_DIM, C_BG); tft.setTextDatum(TR_DATUM); tft.drawString(cnt, 312, 33, 1); tft.setTextDatum(TL_DATUM);

    int n = nets.size();
    if (!n) { ui::centerText("No networks found - tap SCAN", 160, 120, C_DIM, C_BG, 2); return; }
    if (scroll > n - VIS) scroll = max(0, n - VIS);
    if (scroll < 0) scroll = 0;
    int rows = min(VIS, n - scroll);
    tft.fillRoundRect(LX, LY, LW, rows * RH, 8, W_CARD);
    for (int r = 0; r < rows; ++r) {
      Net &w = nets[scroll + r];
      int y = LY + r * RH;
      bool cur = connectedTo(w.ssid);
      if (cur) checkMark(LX + 8, y + 10, W_BLUE);
      tft.setTextColor(cur ? W_BLUE : C_TEXT, W_CARD);
      tft.drawString(fit(w.ssid, 200), LX + 28, y + 7, 2);
      if (w.auth != WIFI_AUTH_OPEN) lockIcon(LX + LW - 46, y + 9, C_DIM, W_CARD);
      bars(LX + LW - 28, y + 9, w.rssi);
      if (r < rows - 1) tft.drawFastHLine(LX + 28, y + RH - 1, LW - 28, W_SEP);
    }
    if (n > VIS) {                                                 // scrollbar
      int trh = VIS * RH, bh = max(14, trh * VIS / n);
      int by = LY + (trh - bh) * scroll / max(1, n - VIS);
      tft.fillRect(LX + LW + 2, LY, 3, trh, C_BG);
      tft.fillRoundRect(LX + LW + 2, by, 3, bh, 1, C_DIM);
    }
  };

  auto drawButtons = [&]() {
    ui::button(4,   BY, 96,  BH, "< BACK", C_PANEL2, C_TEXT, 2);
    ui::button(108, BY, 100, BH, "SCAN",   W_BLUE,   TFT_WHITE, 2);
    ui::button(216, BY, 100, BH, "OTHER",  C_PANEL2, C_TEXT, 2);
  };

  auto scan = [&]() {
    status("Scanning...", C_WARN);
    tft.fillRect(0, LY, 320, BY - LY - 2, C_BG);
    WiFi.mode(WIFI_STA);
    if (WiFi.status() != WL_CONNECTED) WiFi.disconnect();
    int n = WiFi.scanNetworks(false, false);
    nets.clear();
    for (int i = 0; i < n; ++i) {
      String s = WiFi.SSID(i);
      if (!s.length()) continue;                                   // hidden -> use OTHER
      bool dup = false;
      for (auto &w : nets) if (w.ssid == s) {                      // schools have many APs
        dup = true; if (WiFi.RSSI(i) > w.rssi) w.rssi = WiFi.RSSI(i); break;
      }
      if (!dup && nets.size() < 40) nets.push_back({s, WiFi.RSSI(i), (uint8_t)WiFi.encryptionType(i)});
    }
    WiFi.scanDelete();
    String cur = WiFi.status() == WL_CONNECTED ? WiFi.SSID() : String();
    std::sort(nets.begin(), nets.end(), [&](const Net &a, const Net &b) {
      if ((a.ssid == cur) != (b.ssid == cur)) return a.ssid == cur;
      return a.rssi > b.rssi;
    });
    scroll = 0;
    drawList();
  };

  auto redraw = [&]() { c.header("Wi-Fi"); drawList(); drawButtons(); };

  c.header("Wi-Fi");
  ui::clearBody();
  drawButtons();
  scan();

  while (c.loop()) {
    Touch &t = *c.t;
    if (t.swipe == 1 && t.sy > LY && t.sy < BY) { scroll++; drawList(); continue; }
    if (t.swipe == 3 && t.sy > LY && t.sy < BY) { scroll--; drawList(); continue; }
    if (!t.tap) continue;

    if (ui::inRect(t.sx, t.sy, 4, BY, 96, BH)) return true;                 // BACK
    if (ui::inRect(t.sx, t.sy, 108, BY, 100, BH)) { scan(); continue; }      // SCAN
    if (ui::inRect(t.sx, t.sy, 216, BY, 100, BH)) {                         // OTHER (hidden net)
      String ssid = "", pass = "", user = "";
      if (ui::textInput(ssid, "Network name (SSID)", 32) && ssid.length() &&
          ui::textInput(pass, "Password (blank = none)", 63, true) &&
          ui::textInput(user, "School username (blank if none)", 63))
        joinWith(c, ssid, pass, user);
      redraw(); continue;
    }
    // tapped a network row
    int rows = min(VIS, (int)nets.size() - scroll);
    if (t.sy >= LY && t.sy < LY + rows * RH && t.sx >= LX && t.sx < LX + LW) {
      Net w = nets[scroll + (t.sy - LY) / RH];
      if (connectedTo(w.ssid)) { ui::toast("Already connected", C_OK); delay(700); redraw(); continue; }
      String savedS = sys::cfg["wifi"]["ssid"] | "";
      bool same = savedS == w.ssid;
      String pass = same ? String(sys::cfg["wifi"]["pass"] | "") : String("");
      String user = same ? String(sys::cfg["wifi"]["user"] | "") : String("");
      bool go = true;
      if (w.auth == WIFI_AUTH_WPA2_ENTERPRISE) {                            // school login
        go = ui::textInput(user, "School username / email", 63) && user.length() &&
             ui::textInput(pass, "School password", 63, true);
      } else if (w.auth != WIFI_AUTH_OPEN) {                                 // normal password
        String prompt = "Password for " + fit(w.ssid, 160);
        go = ui::textInput(pass, prompt.c_str(), 63, true) && pass.length();
        user = "";
      } else { pass = ""; user = ""; }                                       // open: join now
      if (go) joinWith(c, w.ssid, pass, user);
      redraw();
    }
  }
  return false;
}

}  // namespace wifipick

// ============================================================================
//  74  SYSTEM SETTINGS
// ============================================================================
void app_settings(AppCtx &c) {
  int bright = sys::cfg["display"]["brightness"] | 100;      // 10..100 %
  int vol = audio::master();
  // backlight PWM on GPIO21
  ledcSetup(7, 5000, 8); ledcAttachPin(TFT_BL, 7);
  auto applyBright = [&]() { ledcWrite(7, map(constrain(bright, 10, 100), 0, 100, 0, 255)); };
  applyBright();
  auto draw = [&]() {
    ui::clearBody();
    tft.setTextColor(C_TEXT, C_BG);
    tft.drawString("Brightness", 10, 32, 2); char s[16]; snprintf(s, 16, "%d%%", bright);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 32, 2);
    ui::bar(10, 50, 300, 12, bright / 100.0f, C_ACCENT, C_PANEL);
    tft.setTextColor(C_TEXT, C_BG); tft.drawString("Volume", 10, 72, 2); snprintf(s, 16, "%d", vol);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 72, 2);
    ui::bar(10, 90, 300, 12, vol / 255.0f, C_OK, C_PANEL);
    ui::button(10, 112, 150, 34, "WI-FI NETWORKS", W_BLUE, TFT_WHITE, 2);
    ui::button(166, 112, 150, 34, "SET CLOCK >Alarm", C_PANEL2, C_TEXT, 1);
    const char *ssid = sys::cfg["wifi"]["ssid"] | "";
    tft.setTextColor(C_DIM, C_BG);
    tft.drawString(String("WiFi: ") + (ssid[0] ? ssid : "(none)") + "   " + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("not connected")), 10, 152, 1);
    char info[64]; snprintf(info, 64, "Heap %u KB   Firmware " KRIVI_VERSION "   %s", ESP.getFreeHeap() / 1024, KRIVI_PANEL_NAME);
    tft.drawString(info, 10, 166, 1);
    ui::button(10, 182, 98, 34, "SAVE", RGB565(0, 110, 60), TFT_WHITE, 2);
    ui::button(112, 182, 96, 34, "PASSWORD", C_PANEL2, C_TEXT, 1);
    ui::button(212, 182, 104, 34, "REBOOT", C_PANEL2, C_TEXT, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("WI-FI NETWORKS lists what's around you - tap to join", 10, 222, 1);
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.down && ui::inRect(t.x, t.y, 10, 44, 300, 24)) { bright = constrain((t.x - 10) * 100 / 300, 10, 100); applyBright();
      tft.fillRect(10, 32, 300, 30, C_BG); tft.setTextColor(C_TEXT, C_BG); tft.drawString("Brightness", 10, 32, 2);
      char s[16]; snprintf(s, 16, "%d%%", bright); tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 32, 2); ui::bar(10, 50, 300, 12, bright / 100.0f, C_ACCENT, C_PANEL); continue; }
    if (t.down && ui::inRect(t.x, t.y, 10, 84, 300, 24)) { vol = constrain((t.x - 10) * 255 / 300, 0, 255); audio::setMaster(vol);
      tft.fillRect(10, 72, 300, 30, C_BG); tft.setTextColor(C_TEXT, C_BG); tft.drawString("Volume", 10, 72, 2);
      char s[16]; snprintf(s, 16, "%d", vol); tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 72, 2); ui::bar(10, 90, 300, 12, vol / 255.0f, C_OK, C_PANEL); audio::beep(1500, 10); continue; }
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 10, 112, 150, 34)) {
      if (!wifipick::picker(c)) break;                 // EXIT pressed inside the picker
      c.header(); draw();
    } else if (ui::inRect(t.sx, t.sy, 10, 182, 98, 34)) {
      sys::cfg["display"]["brightness"] = bright; sys::cfg["sound"]["volume"] = vol;
      bool ok = sys::saveSettings(); ui::toast(ok ? "saved to settings.json" : "SD not available", ok ? C_OK : C_ERR); delay(1000); draw();
    } else if (ui::inRect(t.sx, t.sy, 112, 182, 96, 34)) {
      String pw = sys::cfg["security"]["pass"] | "";
      if (ui::textInput(pw, "Device password (blank = no lock)", 32, true)) { sys::cfg["security"]["pass"] = pw; sys::saveSettings(); ui::toast(pw.length() ? "lock password set" : "lock cleared", C_OK); delay(900); }
      c.header(); draw();
    } else if (ui::inRect(t.sx, t.sy, 212, 182, 104, 34)) {
      if (ui::confirm("REBOOT", "Restart KRIVI OS now?")) { sys::saveSettings(); ESP.restart(); } c.header(); draw();
    }
  }
  sys::cfg["display"]["brightness"] = bright;
}

// ============================================================================
//  75  NVS FLASH EDITOR
// ============================================================================
void app_nvsedit(AppCtx &c) {
  nvs_flash_init();
  struct Ent { char ns[16]; char key[16]; uint8_t type; };
  std::vector<Ent> ents;
  auto scan = [&]() {
    ents.clear();
    nvs_iterator_t it = nvs_entry_find("nvs", nullptr, NVS_TYPE_ANY);
    while (it && ents.size() < 200) { nvs_entry_info_t info; nvs_entry_info(it, &info);
      Ent e; strlcpy(e.ns, info.namespace_name, 16); strlcpy(e.key, info.key, 16); e.type = info.type; ents.push_back(e);
      it = nvs_entry_next(it); }
    if (it) nvs_release_iterator(it);
  };
  scan();
  const char *tyName = "?";
  auto typeStr = [](uint8_t t) -> const char * {
    switch (t) { case NVS_TYPE_I8: return "i8"; case NVS_TYPE_U8: return "u8"; case NVS_TYPE_I16: return "i16"; case NVS_TYPE_U16: return "u16";
      case NVS_TYPE_I32: return "i32"; case NVS_TYPE_U32: return "u32"; case NVS_TYPE_I64: return "i64"; case NVS_TYPE_U64: return "u64";
      case NVS_TYPE_STR: return "str"; case NVS_TYPE_BLOB: return "blob"; default: return "?"; }
  };
  auto readVal = [&](const Ent &e) -> String {
    nvs_handle_t h; if (nvs_open(e.ns, NVS_READONLY, &h) != ESP_OK) return "?";
    String r = "?";
    if (e.type == NVS_TYPE_STR) { size_t n = 0; if (nvs_get_str(h, e.key, nullptr, &n) == ESP_OK && n < 128) { char *b = (char *)malloc(n); if (b) { nvs_get_str(h, e.key, b, &n); r = b; free(b); } } }
    else if (e.type == NVS_TYPE_I32) { int32_t v; if (nvs_get_i32(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_U32) { uint32_t v; if (nvs_get_u32(h, e.key, &v) == ESP_OK) r = String((unsigned)v); }
    else if (e.type == NVS_TYPE_U8) { uint8_t v; if (nvs_get_u8(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_I8) { int8_t v; if (nvs_get_i8(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_U16) { uint16_t v; if (nvs_get_u16(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_I16) { int16_t v; if (nvs_get_i16(h, e.key, &v) == ESP_OK) r = String(v); }
    nvs_close(h); return r;
  };
  int top = 0; const int RH = 18, Y0 = 44, ROWS = 9;
  auto draw = [&]() {
    ui::clearBody();
    tft.setTextColor(C_DIM, C_BG); char hd[48]; snprintf(hd, 48, "%d NVS entries (namespace : key = value)", (int)ents.size()); tft.drawString(hd, 6, 30, 1);
    for (int i = 0; i < ROWS && top + i < (int)ents.size(); ++i) { Ent &e = ents[top + i]; int y = Y0 + i * RH;
      tft.setTextColor(C_TEXT, C_BG); char s[64]; snprintf(s, 64, "%s:%s", e.ns, e.key); tft.drawString(s, 6, y, 1);
      tft.setTextColor(C_DIM, C_BG); tft.drawString(typeStr(e.type), 150, y, 1);
      tft.setTextColor(C_ACCENT, C_BG); tft.drawString(readVal(e).substring(0, 20), 182, y, 1); }
    ui::button(4, 210, 90, 26, "< UP", C_PANEL2, C_TEXT, 1); ui::button(226, 210, 90, 26, "DOWN >", C_PANEL2, C_TEXT, 1);
    tft.setTextColor(C_WARN, C_BG); tft.drawString("tap a str/int row to edit (caution!)", 100, 218, 1);
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.swipe == SW_UP || (t.tap && ui::inRect(t.sx, t.sy, 226, 210, 90, 26))) { if (top + ROWS < (int)ents.size()) { top += ROWS; draw(); } }
    else if (t.swipe == SW_DOWN || (t.tap && ui::inRect(t.sx, t.sy, 4, 210, 90, 26))) { if (top > 0) { top = max(0, top - ROWS); draw(); } }
    else if (t.tap && t.sy >= Y0 && t.sy < Y0 + ROWS * RH) {
      int idx = top + (t.sy - Y0) / RH; if (idx >= (int)ents.size()) continue;
      Ent &e = ents[idx];
      bool isStr = e.type == NVS_TYPE_STR;
      bool isInt = e.type == NVS_TYPE_I32 || e.type == NVS_TYPE_U32 || e.type == NVS_TYPE_U8 || e.type == NVS_TYPE_I8 || e.type == NVS_TYPE_U16 || e.type == NVS_TYPE_I16;
      if (!isStr && !isInt) { ui::msgBox("NVS", "Only string and integer keys are editable here."); c.header(); draw(); continue; }
      String v = readVal(e);
      if (ui::textInput(v, (String(e.ns) + ":" + e.key).c_str(), 64, false)) {
        nvs_handle_t h;
        if (nvs_open(e.ns, NVS_READWRITE, &h) == ESP_OK) {
          esp_err_t r;
          if (isStr) r = nvs_set_str(h, e.key, v.c_str());
          else { long n = v.toInt();
            if (e.type == NVS_TYPE_I32) r = nvs_set_i32(h, e.key, n); else if (e.type == NVS_TYPE_U32) r = nvs_set_u32(h, e.key, n);
            else if (e.type == NVS_TYPE_U8) r = nvs_set_u8(h, e.key, n); else if (e.type == NVS_TYPE_I8) r = nvs_set_i8(h, e.key, n);
            else if (e.type == NVS_TYPE_U16) r = nvs_set_u16(h, e.key, n); else r = nvs_set_i16(h, e.key, n); }
          if (r == ESP_OK) nvs_commit(h);
          nvs_close(h);
          ui::toast(r == ESP_OK ? "written" : "write failed", r == ESP_OK ? C_OK : C_ERR); delay(800);
        }
      }
      c.header(); draw();
    }
  }
}