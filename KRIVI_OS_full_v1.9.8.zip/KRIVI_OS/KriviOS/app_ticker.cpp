// ============================================================================
//  KRIVI OS - Trading / Ticker                                      app 90
//
//  A pocket TradingView: a candlestick chart with "AI" support/resistance
//  lines on top, the live price + 24h change big, and a colour-coded watch-
//  list below. Tap a row to load it into the chart.
//
//    * CRYPTO  - live prices + candles from CoinGecko  (free, NO key)
//    * STOCKS  - live quotes from Finnhub              (free key required)
//
//  Config  /sys/apps/app_90.json :
//    { "params": { "crypto": ["bitcoin","ethereum","solana","dogecoin"],
//                  "stocks": ["AAPL","MSFT","NVDA","TSLA","AMZN"] } }
//  Finnhub key  /sys/settings.json :  "finance": { "finnhub": "xxxx" }
//  (get a free key at finnhub.io - tap KEY to enter it on the device)
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <vector>

namespace {

// --- TradingView-ish palette -------------------------------------------------
#define T_BG    RGB565(14, 17, 23)     // near-black
#define T_GRID  RGB565(30, 36, 48)
#define T_PANEL RGB565(20, 25, 34)
#define T_UP    RGB565(38, 190, 150)   // green
#define T_DOWN  RGB565(240, 80, 80)    // red
#define T_RES   RGB565(240, 120, 70)   // resistance tag (orange-red)
#define T_SUP   RGB565(70, 180, 120)   // support tag (green)
#define T_AXIS  RGB565(150, 160, 180)

struct Row { String sym; String id; float last = 0; float chg = 0; bool ok = false; };
struct Candle { float o, h, l, c; };

bool   g_crypto = true;                 // which source is showing
std::vector<Row> g_rows;
int    g_sel = 0;                       // selected row
int    g_scroll = 0;                    // table scroll (row offset)

Candle g_ch[64]; int g_nc = 0;          // chart candles for selection
float  g_cmin = 0, g_cmax = 0;
String g_cErr;                          // chart error text

// chart geometry
const int CX = 4, CY = 26, CW = 312, CH = 92;      // chart box
const int AXW = 46;                                 // right price-axis width
const int PLW = CW - AXW;                            // plot width

// control row + table
const int BY = 122, BH = 20;
const int TH = 146;                                 // table header y
const int ROW0 = 162, ROWH = 15, VISROWS = 5;

// ---- small ticker map so crypto ids show as symbols -------------------------
const char *tickerFor(const String &id) {
  struct { const char *id, *t; } M[] = {
    {"bitcoin","BTC"},{"ethereum","ETH"},{"solana","SOL"},{"dogecoin","DOGE"},
    {"cardano","ADA"},{"ripple","XRP"},{"litecoin","LTC"},{"polkadot","DOT"},
    {"chainlink","LINK"},{"avalanche-2","AVAX"},{"tron","TRX"},{"polygon","MATIC"},
    {"binancecoin","BNB"},{"shiba-inu","SHIB"},{"uniswap","UNI"},{"monero","XMR"},
  };
  for (auto &m : M) if (id == m.id) return m.t;
  return nullptr;
}

const char *finnhubKey() { return sys::cfg["finance"]["finnhub"] | ""; }

// --- HTTP JSON GET (whole body then parse; robust over TLS) ------------------
bool httpJson(const String &url, JsonDocument &doc, String &err) {
  WiFiClientSecure cl; cl.setInsecure();
  HTTPClient http;
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setReuse(false);
  http.setTimeout(12000);
  http.setUserAgent("KRIVI-OS");
  if (!http.begin(cl, url)) { err = "begin failed"; return false; }
  int code = http.GET();
  if (code != 200) { err = "HTTP " + String(code); http.end(); return false; }
  String body = http.getString();
  http.end();
  if (!body.length()) { err = "empty reply"; return false; }
  DeserializationError e = deserializeJson(doc, body);
  if (e) { err = String("parse ") + e.c_str(); return false; }
  return true;
}

// pretty-print a price with sensible precision
void fmtPrice(float v, char *out, size_t n) {
  if (v >= 1000)      snprintf(out, n, "%.0f", v);
  else if (v >= 1)    snprintf(out, n, "%.2f", v);
  else if (v >= 0.01) snprintf(out, n, "%.4f", v);
  else                snprintf(out, n, "%.6f", v);
}

// ---------------------------------------------------------------- data loads
void loadConfig(AppCtx &c) {
  g_rows.clear();
  JsonArray a = g_crypto ? c.params["crypto"].as<JsonArray>()
                         : c.params["stocks"].as<JsonArray>();
  if (a.isNull()) {                                   // defaults if none in SD cfg
    const char *dc[] = {"bitcoin","ethereum","solana","dogecoin"};
    const char *ds[] = {"AAPL","MSFT","NVDA","TSLA","AMZN"};
    if (g_crypto) for (auto s : dc) { Row r; r.id = s; r.sym = tickerFor(s); g_rows.push_back(r); }
    else          for (auto s : ds) { Row r; r.id = s; r.sym = s; g_rows.push_back(r); }
    return;
  }
  for (JsonVariant v : a) {
    Row r; r.id = v.as<const char *>();
    r.sym = g_crypto ? (tickerFor(r.id) ? tickerFor(r.id) : r.id) : r.id;
    r.sym.toUpperCase();
    g_rows.push_back(r);
  }
}

// fill last price + 24h change for every row
bool loadQuotes(String &err) {
  if (!g_rows.size()) { err = "no symbols"; return false; }
  if (g_crypto) {
    String ids;
    for (size_t i = 0; i < g_rows.size(); ++i) { if (i) ids += "%2C"; ids += g_rows[i].id; }
    String url = "https://api.coingecko.com/api/v3/simple/price?ids=" + ids +
                 "&vs_currencies=usd&include_24hr_change=true";
    JsonDocument d;
    if (!httpJson(url, d, err)) return false;
    for (auto &r : g_rows) {
      JsonObject o = d[r.id];
      if (o.isNull()) { r.ok = false; continue; }
      r.last = o["usd"] | 0.0f;
      r.chg  = o["usd_24h_change"] | 0.0f;
      r.ok   = r.last > 0;
    }
    return true;
  }
  // stocks: one Finnhub quote per symbol
  const char *key = finnhubKey();
  if (!*key) { err = "no Finnhub key - tap KEY"; return false; }
  bool any = false;
  for (auto &r : g_rows) {
    String url = "https://finnhub.io/api/v1/quote?symbol=" + r.id + "&token=" + key;
    JsonDocument d; String e;
    if (!httpJson(url, d, e)) { r.ok = false; continue; }
    r.last = d["c"] | 0.0f;
    r.chg  = d["dp"] | 0.0f;                           // percent change
    r.ok   = r.last > 0;
    any |= r.ok;
    delay(120);                                        // be gentle on the free tier
  }
  if (!any) err = "no quotes (check key/symbols)";
  return any;
}

// build candles for the selected symbol
void loadChart() {
  g_nc = 0; g_cErr = "";
  if (g_sel < 0 || g_sel >= (int)g_rows.size()) return;
  Row &r = g_rows[g_sel];
  if (g_crypto) {
    String url = "https://api.coingecko.com/api/v3/coins/" + r.id +
                 "/ohlc?vs_currency=usd&days=1";          // [[t,o,h,l,c], ...]
    JsonDocument d;
    if (!httpJson(url, d, g_cErr)) return;
    JsonArray a = d.as<JsonArray>();
    int n = a.size(); if (n <= 0) { g_cErr = "no candles"; return; }
    int step = n > 60 ? (n + 59) / 60 : 1;               // downsample to <=60
    for (int i = 0; i < n && g_nc < 64; i += step) {
      JsonArray e = a[i];
      if (e.size() < 5) continue;
      Candle &cd = g_ch[g_nc++];
      cd.o = e[1] | 0.0f; cd.h = e[2] | 0.0f; cd.l = e[3] | 0.0f; cd.c = e[4] | 0.0f;
    }
  } else {
    // Finnhub free tier has no candle history - synthesize one day candle
    const char *key = finnhubKey();
    if (!*key) { g_cErr = "no key"; return; }
    String url = "https://finnhub.io/api/v1/quote?symbol=" + r.id + "&token=" + key;
    JsonDocument d;
    if (!httpJson(url, d, g_cErr)) return;
    float o = d["o"] | 0.0f, h = d["h"] | 0.0f, l = d["l"] | 0.0f,
          cc = d["c"] | 0.0f, pc = d["pc"] | 0.0f;
    if (cc <= 0) { g_cErr = "no data"; return; }
    // a few synthetic steps from prev-close -> open -> close so it reads as a chart
    Candle a0{pc, max(pc, o), min(pc, o), o};
    Candle a1{o, h, l, cc};
    g_ch[0] = a0; g_ch[1] = a1; g_nc = 2;
  }
  // chart range
  g_cmin = 1e30f; g_cmax = -1e30f;
  for (int i = 0; i < g_nc; ++i) { g_cmin = min(g_cmin, g_ch[i].l); g_cmax = max(g_cmax, g_ch[i].h); }
  if (g_cmax <= g_cmin) { g_cmax = g_cmin + 1; }
  float pad = (g_cmax - g_cmin) * 0.08f;
  g_cmin -= pad; g_cmax += pad;
}

// ---------------------------------------------------------------- drawing
int ypx(float price) {
  float f = (price - g_cmin) / (g_cmax - g_cmin);
  if (f < 0) f = 0; if (f > 1) f = 1;
  return (int)(CY + CH - f * CH);
}
void dashH(int y, uint16_t col) { for (int x = CX; x < CX + PLW; x += 6) tft.drawFastHLine(x, y, 3, col); }

void drawChart() {
  tft.fillRect(CX, CY, CW, CH, T_BG);
  Row &r = g_rows[g_sel];

  if (g_nc <= 0) {
    ui::centerText(g_cErr.length() ? g_cErr.c_str() : "no chart", CX + PLW / 2, CY + CH / 2, C_DIM, T_BG, 2);
  } else {
    // grid + price axis labels
    for (int i = 0; i <= 3; ++i) {
      int y = CY + i * CH / 3;
      tft.drawFastHLine(CX, y, PLW, T_GRID);
      float p = g_cmax - (g_cmax - g_cmin) * i / 3.0f;
      char b[16]; fmtPrice(p, b, sizeof(b));
      tft.setTextColor(C_DIM, T_BG); tft.setTextDatum(TL_DATUM);
      tft.drawString(b, CX + PLW + 3, y - 3, 1);
    }
    // AI support / resistance (recent high / low of the window)
    float res = -1e30f, sup = 1e30f;
    for (int i = 0; i < g_nc; ++i) { res = max(res, g_ch[i].h); sup = min(sup, g_ch[i].l); }
    int yr = ypx(res), ys = ypx(sup);
    dashH(yr, T_RES); dashH(ys, T_SUP);
    tft.setTextColor(T_RES, T_BG); tft.drawString("AI resistance", CX + 2, yr + 1, 1);
    tft.setTextColor(T_SUP, T_BG); tft.drawString("AI support", CX + 2, ys - 9, 1);

    // candles
    float bw = (float)PLW / g_nc;
    for (int i = 0; i < g_nc; ++i) {
      Candle &cd = g_ch[i];
      int cx = CX + (int)(i * bw + bw / 2);
      uint16_t col = cd.c >= cd.o ? T_UP : T_DOWN;
      tft.drawFastVLine(cx, ypx(cd.h), max(1, ypx(cd.l) - ypx(cd.h)), col);   // wick
      int yo = ypx(cd.o), yc = ypx(cd.c);
      int top = min(yo, yc), bh = max(1, abs(yc - yo));
      int halfw = max(1, (int)(bw / 2) - 1);
      tft.fillRect(cx - halfw, top, halfw * 2, bh, col);                       // body
    }
    // last-price marker line
    int yl = ypx(r.last > 0 ? r.last : g_ch[g_nc - 1].c);
    tft.drawFastHLine(CX, yl, PLW, RGB565(90, 100, 120));
  }

  // headline: symbol  price  +chg%
  char pr[16]; fmtPrice(r.last, pr, sizeof(pr));
  tft.fillRect(CX, CY, PLW, 20, T_BG);                 // clear overlay strip
  tft.setTextColor(C_TEXT, T_BG); tft.setTextDatum(TL_DATUM);
  tft.drawString(r.sym, CX + 2, CY + 2, 2);
  int sx = CX + 4 + tft.textWidth(r.sym, 2) + 6;
  tft.setTextColor(r.ok ? C_TEXT : C_DIM, T_BG);
  tft.drawString(r.ok ? pr : "...", sx, CY + 2, 2);
  if (r.ok) {
    char cb[16]; snprintf(cb, sizeof(cb), "%+.2f%%", r.chg);
    tft.setTextColor(r.chg >= 0 ? T_UP : T_DOWN, T_BG);
    tft.drawString(cb, sx + tft.textWidth(pr, 2) + 8, CY + 2, 2);
  }
}

void drawControls() {
  ui::button(2,   BY, 98, BH, g_crypto ? "CRYPTO" : "STOCKS", g_crypto ? RGB565(40,70,120) : RGB565(90,70,40), C_TEXT, 2);
  ui::button(104, BY, 70, BH, "SWAP",   C_PANEL2, C_TEXT, 1);
  ui::button(178, BY, 70, BH, "RELOAD", C_PANEL2, C_TEXT, 1);
  ui::button(252, BY, 66, BH, "KEY",    C_PANEL2, C_DIM,  1);
}

void drawTable() {
  tft.fillRect(0, TH, 320, 240 - TH, T_BG);
  // header
  tft.setTextColor(C_DIM, T_BG); tft.setTextDatum(TL_DATUM);
  tft.drawString("Symbol", 6, TH, 1);
  tft.setTextDatum(TR_DATUM);
  tft.drawString("Last", 214, TH, 1);
  tft.drawString("Chg%", 312, TH, 1);
  tft.setTextDatum(TL_DATUM);
  tft.drawFastHLine(0, TH + 11, 320, T_GRID);

  int n = g_rows.size();
  if (g_scroll > n - VISROWS) g_scroll = max(0, n - VISROWS);
  if (g_scroll < 0) g_scroll = 0;
  for (int i = 0; i < VISROWS && g_scroll + i < n; ++i) {
    int idx = g_scroll + i, y = ROW0 + i * ROWH;
    Row &r = g_rows[idx];
    if (idx == g_sel) tft.fillRect(0, y - 1, 320, ROWH, T_PANEL);
    tft.setTextColor(idx == g_sel ? C_ACCENT : C_TEXT, idx == g_sel ? T_PANEL : T_BG);
    tft.setTextDatum(TL_DATUM); tft.drawString(r.sym, 6, y, 2);
    char pr[16]; fmtPrice(r.last, pr, sizeof(pr));
    tft.setTextColor(r.ok ? C_TEXT : C_DIM, idx == g_sel ? T_PANEL : T_BG);
    tft.setTextDatum(TR_DATUM); tft.drawString(r.ok ? pr : "-", 214, y, 2);
    if (r.ok) {
      char cb[16]; snprintf(cb, sizeof(cb), "%+.2f", r.chg);
      tft.setTextColor(r.chg >= 0 ? T_UP : T_DOWN, idx == g_sel ? T_PANEL : T_BG);
      tft.drawString(cb, 312, y, 2);
    }
    tft.setTextDatum(TL_DATUM);
  }
  // scrollbar
  if (n > VISROWS) {
    int trh = VISROWS * ROWH, bh = max(10, trh * VISROWS / n);
    int by = ROW0 + (trh - bh) * g_scroll / max(1, n - VISROWS);
    tft.fillRect(316, by, 3, bh, C_PANEL2);
  }
}

}  // namespace

void app_ticker(AppCtx &c) {
  g_rows.clear(); g_sel = 0; g_scroll = 0; g_nc = 0;
  c.header(g_crypto ? "CoinGecko" : "Finnhub");
  ui::clearBody(T_BG);

  auto refresh = [&](bool withChart) {
    loadConfig(c);
    ui::clearBody(T_BG);
    ui::centerText("Connecting WiFi...", 160, 110, C_WARN, T_BG, 2);
    if (!sys::wifiConnect(12000, false)) {
      ui::clearBody(T_BG);
      ui::centerText("WiFi failed", 160, 100, C_ERR, T_BG, 2);
      ui::centerText("set WiFi in Settings", 160, 122, C_DIM, T_BG, 1);
      drawControls(); return;
    }
    ui::clearBody(T_BG);
    ui::centerText("Loading markets...", 160, 110, C_ACCENT, T_BG, 2);
    String err;
    bool ok = loadQuotes(err);
    if (g_sel >= (int)g_rows.size()) g_sel = 0;
    if (ok && withChart) loadChart();
    sys::radiosOff();
    ui::clearBody(T_BG);
    if (!ok) {
      ui::centerText(err.c_str(), 160, 90, C_ERR, T_BG, 2);
      if (!g_crypto && !*finnhubKey())
        ui::centerText("free key at finnhub.io", 160, 112, C_DIM, T_BG, 1);
      drawControls(); drawTable(); return;
    }
    drawChart(); drawControls(); drawTable();
  };

  refresh(true);

  while (c.loop()) {
    Touch &t = *c.t;
    // table scroll by vertical swipe inside the list
    if (t.swipe == 1 && t.sy > TH) { g_scroll++; drawTable(); continue; }
    if (t.swipe == 3 && t.sy > TH) { g_scroll--; drawTable(); continue; }
    if (!t.tap) continue;

    if (ui::inRect(t.sx, t.sy, 2, BY, 98, BH) || ui::inRect(t.sx, t.sy, 104, BY, 70, BH)) {
      g_crypto = !g_crypto; g_sel = 0; g_scroll = 0;
      c.header(g_crypto ? "CoinGecko" : "Finnhub");
      refresh(true); continue;
    }
    if (ui::inRect(t.sx, t.sy, 178, BY, 70, BH)) { refresh(true); continue; }
    if (ui::inRect(t.sx, t.sy, 252, BY, 66, BH)) {
      String k = finnhubKey();
      if (ui::textInput(k, "Finnhub API key (finnhub.io)", 60, false)) {
        sys::cfg["finance"]["finnhub"] = k; sys::saveSettings();
        ui::toast(k.length() ? "key saved" : "key cleared", C_OK);
      }
      c.header(g_crypto ? "CoinGecko" : "Finnhub");
      drawChart(); drawControls(); drawTable();
      continue;
    }
    // tap a watchlist row -> select + load its chart
    if (t.sy >= ROW0 && t.sy < ROW0 + VISROWS * ROWH) {
      int i = g_scroll + (t.sy - ROW0) / ROWH;
      if (i >= 0 && i < (int)g_rows.size() && i != g_sel) {
        g_sel = i;
        drawTable();
        ui::centerText("loading chart...", CX + PLW / 2, CY + CH / 2, C_DIM, T_BG, 2);
        if (sys::wifiConnect(12000, false)) { loadChart(); sys::radiosOff(); }
        drawChart();
      }
    }
  }
}
