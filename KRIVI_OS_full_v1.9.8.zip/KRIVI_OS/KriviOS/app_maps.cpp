// ============================================================================
//  KRIVI OS - Maps                                                    app 86
//
//  OpenStreetMap on the CYD:  map tiles, place search, turn-by-turn routes
//  (car / bike / walk), favourites and "where am I" from your IP address.
//
//  Online services (all free, no API key):
//    map tiles ....... CARTO Voyager (Google-like, default) / CARTO Light / OSM standard
//                      (all from OpenStreetMap data; cached to SD in /maps/tiles/<style>/)
//    search .......... nominatim.openstreetmap.org
//    routing ......... routing.openstreetmap.de (OSRM: routed-car / -bike / -foot)
//    IP location ..... ipwho.is  (fallback ip-api.com)
//
//  Offline: put tiles in  /maps/tiles/<style>/{z}/{x}/{y}.png  (or .jpg)  on the SD card
//  (tools/maps_fetch.py downloads a region for you) and switch MODE to OFFLINE.
//  Tiles fetched while ONLINE are cached in the same folder, so they keep working
//  offline later.
//
//  Self-contained: has its own tiny streaming JSON reader and PNG decoder (no extra
//  libraries - only the TJpg_Decoder the OS already ships, for .jpg tiles).
//  Settings: /sys/maps.txt   Favourites: /data/maps/favorites.txt
//
//  NOTE: IP geolocation is city-level (often several km off). Use MENU > "Set my
//  location here" to pin your exact spot; it is remembered.
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <TJpg_Decoder.h>
#include <math.h>

namespace {

constexpr int VX = 0, VY = 26, VW = 320, VH = 184;     // map viewport
constexpr int BAR_Y = 212;                              // bottom button bar
constexpr int ZB = 20;                                  // stored-coordinate zoom (world = 2^28 px)
constexpr double WORLD = 268435456.0;
constexpr double PIV = 3.14159265358979323846;
constexpr int MAXPTS = 1500, MAXSTEPS = 100, MAXFAV = 40, MAXRES = 8;
constexpr uint16_t G_BLUE = RGB565(66, 133, 244), G_RED = RGB565(234, 67, 53), G_DRED = RGB565(165, 14, 14), G_YEL = RGB565(251, 188, 4), G_GREY = RGB565(95, 99, 104);
constexpr uint16_t MAPBG = RGB565(236, 236, 232);

// ============================================================================
//  projection
// ============================================================================
struct Pt { int32_t x, y; };

double clampd(double v, double lo, double hi) { return v < lo ? lo : v > hi ? hi : v; }

Pt ll2p(double lat, double lon) {
  lat = clampd(lat, -85.0511, 85.0511);
  double s = sin(lat * PIV / 180.0);
  double fx = (lon + 180.0) / 360.0, fy = 0.5 - log((1.0 + s) / (1.0 - s)) / (4.0 * PIV);
  Pt p;
  p.x = (int32_t)clampd(fx * WORLD, 0, WORLD - 1);
  p.y = (int32_t)clampd(fy * WORLD, 0, WORLD - 1);
  return p;
}
void p2ll(Pt p, double &lat, double &lon) {
  double n = PIV * (1.0 - 2.0 * (double)p.y / WORLD);
  lat = atan((exp(n) - exp(-n)) * 0.5) * 180.0 / PIV;
  lon = (double)p.x / WORLD * 360.0 - 180.0;
}
double mPerPx(double lat, int z) { return 156543.03392 * cos(lat * PIV / 180.0) / (double)(1 << z); }

// ============================================================================
//  streaming JSON reader (SAX style, ~no RAM). Calls leaf(path, value) for every
//  scalar.  path = keys joined by '.', array elements by index:
//  "routes.0.legs.0.steps.3.maneuver.type".  Strings are folded to plain ASCII
//  (the display font has no accents).  A string whose path isBig() accepts is
//  streamed char-by-char to bigc() instead (used for the route polyline).
// ============================================================================
const char LAT1[] = "AAAAAAACEEEEIIIIDNOOOOOxOUUUUYTsaaaaaaaceeeeiiiidnooooo/ouuuuyty";   // U+00C0..U+00FF
const char LATA[] = "AaAaAaCcCcCcCcDdDdEeEeEeEeEeGgGgGgGgHhHhIiIiIiIiIiJjJjKkkLlLlLlLlLlNnNnNnnNnOoOoOoOoRrRrRrSsSsSsSsTtTtTtUuUuUuUuUuUuWwYyYZzZzZzs";   // U+0100..U+017F

struct JS {
  typedef void (*LeafFn)(void *u, const char *path, const char *val);
  typedef bool (*BigFn)(void *u, const char *path);
  typedef void (*ChrFn)(void *u, char c);
  LeafFn leaf; BigFn isBig; ChrFn bigc; void *u;
  char path[104]; uint8_t plen;
  struct Fr { char t; uint16_t idx; uint8_t pl; } fr[14];
  int sp;
  uint8_t mode;                     // 0 structure, 1 string, 2 escape, 3 \u, 4 literal
  bool expKey, inKey, big, hiSur;
  char key[32]; uint8_t klen;
  char val[128]; uint8_t vlen;
  uint32_t uni; uint8_t unin;
  uint8_t u8need; uint32_t u8cp;

  void init(LeafFn l, BigFn b, ChrFn c, void *user) {
    leaf = l; isBig = b; bigc = c; u = user;
    path[0] = 0; plen = 0; sp = 0; mode = 0; expKey = false; inKey = false; big = false; hiSur = false;
    klen = vlen = 0; unin = 0; u8need = 0;
  }
  void setPath(uint8_t base, const char *add) {
    plen = base; if (plen && plen < sizeof(path) - 1) path[plen++] = '.';
    for (const char *p = add; *p && plen < sizeof(path) - 1; ++p) path[plen++] = *p;
    path[plen] = 0;
  }
  void setIdx(uint8_t base, unsigned i) { char b[8]; snprintf(b, sizeof(b), "%u", i); setPath(base, b); }
  void emitCh(char c) {
    if (inKey) { if (klen < sizeof(key) - 1) key[klen++] = c; }
    else if (big) { if (bigc) bigc(u, c); }
    else if (vlen < sizeof(val) - 1) val[vlen++] = c;
  }
  void emitCp(uint32_t cp) {
    char c;
    if (cp < 0x80) c = (char)cp;
    else if (cp >= 0xC0 && cp <= 0xFF) c = LAT1[cp - 0xC0];
    else if (cp >= 0x100 && cp <= 0x17F) c = LATA[cp - 0x100];
    else c = '?';
    emitCh(c);
  }
  void endLiteral() { val[vlen] = 0; if (leaf) leaf(u, path, val); mode = 0; vlen = 0; }
  void feed(unsigned char c) {
    switch (mode) {
      case 1:                                              // inside a string
        if (c == '"') {
          mode = 0;
          if (inKey) { key[klen] = 0; inKey = false; Fr &f = fr[sp - 1]; setPath(f.pl, key); }
          else { if (!big && leaf) { val[vlen] = 0; leaf(u, path, val); } big = false; vlen = 0; }
        } else if (c == '\\') mode = 2;
        else if (c >= 0xC0) { u8need = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : 1; u8cp = c & (0x3F >> u8need); }
        else if (c >= 0x80) { if (u8need) { u8cp = (u8cp << 6) | (c & 0x3F); if (--u8need == 0) emitCp(u8cp); } }
        else emitCh((char)c);
        return;
      case 2:
        mode = 1;
        if (c == 'u') { mode = 3; uni = 0; unin = 0; }
        else emitCh(c == 'n' || c == 't' || c == 'r' ? ' ' : c == 'b' || c == 'f' ? ' ' : (char)c);
        return;
      case 3: {
        uni = (uni << 4) | (c <= '9' ? c - '0' : (c | 32) - 'a' + 10);
        if (++unin == 4) {
          mode = 1;
          if (uni >= 0xD800 && uni <= 0xDBFF) { hiSur = true; }
          else if (uni >= 0xDC00 && uni <= 0xDFFF) { if (hiSur) { emitCh('?'); hiSur = false; } }
          else emitCp(uni);
        }
        return; }
      case 4:
        if (c == ',' || c == ']' || c == '}' || c == ' ' || c == '\n' || c == '\r' || c == '\t') { endLiteral(); break; }
        if (vlen < sizeof(val) - 1) val[vlen++] = (char)c;
        return;
    }
    // structure
    switch (c) {
      case '{': if (sp < 14) { fr[sp].t = 'o'; fr[sp].pl = plen; fr[sp].idx = 0; sp++; } expKey = true; break;
      case '[': if (sp < 14) { fr[sp].t = 'a'; fr[sp].pl = plen; fr[sp].idx = 0; sp++; setIdx(plen, 0); } expKey = false; break;
      case '}': case ']':
        if (sp > 0) { --sp; plen = fr[sp].pl; path[plen] = 0; }
        expKey = false; break;
      case ',':
        if (sp > 0) {
          Fr &f = fr[sp - 1];
          if (f.t == 'o') { expKey = true; plen = f.pl; path[plen] = 0; }
          else { f.idx++; setIdx(f.pl, f.idx); }
        }
        break;
      case '"':
        mode = 1; vlen = 0; u8need = 0; hiSur = false;
        if (sp > 0 && fr[sp - 1].t == 'o' && expKey) { inKey = true; klen = 0; expKey = false; }
        else { big = isBig ? isBig(u, path) : false; }
        break;
      case ':': case ' ': case '\n': case '\r': case '\t': break;
      default: mode = 4; vlen = 0; val[vlen++] = (char)c; break;
    }
  }
};

// ============================================================================
//  polyline (OSRM / Google encoded, precision 5), decoded char by char
// ============================================================================
struct Poly {
  int32_t lat, lon, acc; int shift, phase;
  void reset() { lat = lon = acc = 0; shift = 0; phase = 0; }
  // returns true when a full (lat,lon) pair was completed
  bool feed(char c, double &la, double &lo) {
    int b = (uint8_t)c - 63;
    if (b < 0) return false;
    acc |= (b & 31) << shift; shift += 5;
    if (b >= 32) return false;
    int32_t d = (acc & 1) ? ~(acc >> 1) : (acc >> 1);
    acc = 0; shift = 0;
    if (phase == 0) { lat += d; phase = 1; return false; }
    lon += d; phase = 0; la = lat * 1.0e-5; lo = lon * 1.0e-5; return true;
  }
};

// ============================================================================
//  tiny PNG decoder: streaming inflate straight from the SD file, row by row.
//  8-bit RGB / RGBA / gray / palette (1,2,4,8 bit), non-interlaced - what every
//  slippy-map tile server produces.  ~36 KB of RAM, no big output buffer.
// ============================================================================
struct Src {
  File *f; uint8_t buf[512]; int rp, rn; uint32_t chunk; bool idatEnd;
  int raw() {
    if (rp >= rn) { rn = f->read(buf, sizeof(buf)); rp = 0; if (rn <= 0) { rn = 0; return -1; } }
    return buf[rp++];
  }
  uint32_t r32() { uint32_t v = 0; for (int i = 0; i < 4; ++i) { int b = raw(); if (b < 0) return 0; v = (v << 8) | (uint32_t)b; } return v; }
  int idat() {                                    // next byte of the concatenated IDAT stream
    for (;;) {
      if (chunk) { chunk--; return raw(); }
      if (idatEnd) return -1;
      r32();                                      // CRC of the finished chunk
      uint32_t len = r32(), type = r32();
      if (type == 0x49444154u) chunk = len; else idatEnd = true;
    }
  }
};

struct Rows {
  int w, h, depth, ctype, bpp, rowbytes, y; bool needF, done; uint8_t filt; int fill;
  uint8_t *cur, *prev; uint16_t *line; uint16_t pal[256];
  void (*cb)(void *, int, uint16_t *); void *u;
  static inline uint16_t c565(int r, int g, int b) { return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)); }
  void put(uint8_t b) {
    if (done) return;
    if (needF) { filt = b; needF = false; fill = 0; return; }
    cur[fill++] = b;
    if (fill == rowbytes) endRow();
  }
  void endRow() {
    uint8_t *c = cur, *p = prev;
    switch (filt) {
      case 1: for (int i = bpp; i < rowbytes; ++i) c[i] = (uint8_t)(c[i] + c[i - bpp]); break;
      case 2: for (int i = 0; i < rowbytes; ++i) c[i] = (uint8_t)(c[i] + p[i]); break;
      case 3: for (int i = 0; i < rowbytes; ++i) { int a = i >= bpp ? c[i - bpp] : 0; c[i] = (uint8_t)(c[i] + ((a + p[i]) >> 1)); } break;
      case 4: for (int i = 0; i < rowbytes; ++i) {
          int a = i >= bpp ? c[i - bpp] : 0, b = p[i], cc = i >= bpp ? p[i - bpp] : 0;
          int pp = a + b - cc, pa = abs(pp - a), pb = abs(pp - b), pc = abs(pp - cc);
          int pr = (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : cc);
          c[i] = (uint8_t)(c[i] + pr);
        } break;
      default: break;
    }
    if (cb) {
      for (int x = 0; x < w; ++x) {
        uint16_t v;
        if (ctype == 3 || ctype == 0) {
          int idx;
          if (depth == 8) idx = c[x];
          else { int per = 8 / depth, sh = 8 - depth * (x % per + 1); idx = (c[x / per] >> sh) & ((1 << depth) - 1); }
          if (ctype == 3) v = pal[idx]; else { int g = depth == 8 ? idx : idx * 255 / ((1 << depth) - 1); v = c565(g, g, g); }
        } else if (ctype == 2) v = c565(c[3 * x], c[3 * x + 1], c[3 * x + 2]);
        else if (ctype == 4) v = c565(c[2 * x], c[2 * x], c[2 * x]);
        else v = c565(c[4 * x], c[4 * x + 1], c[4 * x + 2]);
        line[x] = v;
      }
      cb(u, y, line);
    }
    uint8_t *t = cur; cur = prev; prev = t;
    needF = true;
    if (++y >= h) done = true;
  }
};

struct Huff { uint16_t count[16]; uint16_t symbol[288]; };

const uint16_t LBASE[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
const uint8_t  LEXT[29]  = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
const uint16_t DBASE[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
const uint8_t  DEXT[30]  = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};
const uint8_t  CLORDER[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};

struct InfTabs { Huff lc, dc, cl; uint16_t lens[320]; };     // ~1.8 KB, kept off the (8 KB) task stack

struct Inf {
  InfTabs *tabs; Src *src; Rows *rows; uint8_t *win; uint32_t wp, bb; int bc; bool err;
  int bits(int need) {
    while (bc < need) { int b = src->idat(); if (b < 0) { err = true; return 0; } bb |= (uint32_t)b << bc; bc += 8; }
    int v = (int)(bb & ((1u << need) - 1)); bb >>= need; bc -= need; return v;
  }
  int decode(const Huff &h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; ++len) {
      code |= bits(1); int count = h.count[len];
      if (code - count < first) return h.symbol[index + (code - first)];
      index += count; first += count; first <<= 1; code <<= 1;
      if (err) return -1;
    }
    return -1;
  }
  static void build(Huff &h, const uint16_t *len, int n) {
    uint16_t offs[16];
    for (int i = 0; i < 16; ++i) h.count[i] = 0;
    for (int i = 0; i < n; ++i) h.count[len[i]]++;
    offs[1] = 0; for (int i = 1; i < 15; ++i) offs[i + 1] = offs[i] + h.count[i];
    for (int i = 0; i < n; ++i) if (len[i]) h.symbol[offs[len[i]]++] = (uint16_t)i;
  }
  inline void out(uint8_t b) { win[wp++ & 32767] = b; rows->put(b); }
  bool codes(const Huff &lc, const Huff &dc) {
    for (;;) {
      if (err || rows->done) return !err;
      int sym = decode(lc);
      if (sym < 0) return false;
      if (sym < 256) out((uint8_t)sym);
      else if (sym == 256) return true;
      else {
        sym -= 257; if (sym >= 29) return false;
        int len = LBASE[sym] + bits(LEXT[sym]);
        int ds = decode(dc); if (ds < 0 || ds >= 30) return false;
        int dist = DBASE[ds] + bits(DEXT[ds]);
        for (int i = 0; i < len; ++i) out(win[(wp - dist) & 32767]);
      }
    }
  }
  bool run() {
    if (src->idat() < 0 || src->idat() < 0) return false;          // zlib header
    int last;
    do {
      last = bits(1); int type = bits(2);
      if (err) return false;
      if (type == 0) {                                              // stored
        bb = 0; bc = 0;
        int a = src->idat(), b = src->idat(), c = src->idat(), d = src->idat();
        if ((a | b | c | d) < 0) return false;
        int len = a | (b << 8);
        for (int i = 0; i < len; ++i) { int v = src->idat(); if (v < 0) return false; out((uint8_t)v); }
      } else if (type == 1 || type == 2) {
        Huff &lc = tabs->lc, &dc = tabs->dc; uint16_t *lens = tabs->lens;
        if (type == 1) {
          int i = 0;
          for (; i < 144; ++i) lens[i] = 8;
          for (; i < 256; ++i) lens[i] = 9;
          for (; i < 280; ++i) lens[i] = 7;
          for (; i < 288; ++i) lens[i] = 8;
          build(lc, lens, 288);
          for (i = 0; i < 30; ++i) lens[i] = 5;
          build(dc, lens, 30);
        } else {
          int nlen = bits(5) + 257, ndist = bits(5) + 1, ncode = bits(4) + 4;
          if (nlen > 286 || ndist > 30) return false;
          for (int i = 0; i < 19; ++i) lens[i] = 0;
          for (int i = 0; i < ncode; ++i) lens[CLORDER[i]] = (uint16_t)bits(3);
          Huff &cl = tabs->cl; build(cl, lens, 19);
          int idx = 0;
          while (idx < nlen + ndist) {
            int sym = decode(cl); if (sym < 0) return false;
            if (sym < 16) lens[idx++] = (uint16_t)sym;
            else {
              int rep, v = 0;
              if (sym == 16) { if (idx == 0) return false; v = lens[idx - 1]; rep = 3 + bits(2); }
              else if (sym == 17) rep = 3 + bits(3); else rep = 11 + bits(7);
              if (idx + rep > nlen + ndist) return false;
              while (rep--) lens[idx++] = (uint16_t)v;
            }
          }
          build(lc, lens, nlen); build(dc, lens + nlen, ndist);
        }
        if (!codes(lc, dc)) return false;
      } else return false;
      if (rows->done) return true;
    } while (!last);
    return rows->done;
  }
};

// Decode the PNG in `f`; every finished row is passed to cb(user, y, rgb565[w]).
// Returns 0 on success, negative on error.
int pngDecode(File &f, void (*cb)(void *, int, uint16_t *), void *user, int *outW, int *outH) {
  Src s; s.f = &f; s.rp = s.rn = 0; s.chunk = 0; s.idatEnd = false;
  uint8_t sig[8]; for (int i = 0; i < 8; ++i) { int b = s.raw(); if (b < 0) return -1; sig[i] = (uint8_t)b; }
  if (sig[0] != 0x89 || sig[1] != 'P' || sig[2] != 'N' || sig[3] != 'G') return -1;
  Rows R; memset(&R, 0, sizeof(R));
  bool haveIhdr = false, haveIdat = false;
  while (!haveIdat) {
    uint32_t len = s.r32(), type = s.r32();
    if (type == 0) return -2;
    if (type == 0x49484452u) {                                             // IHDR
      uint8_t h[13]; for (int i = 0; i < 13; ++i) { int b = s.raw(); h[i] = (uint8_t)(b < 0 ? 0 : b); }
      R.w = (h[0] << 24) | (h[1] << 16) | (h[2] << 8) | h[3];
      R.h = (h[4] << 24) | (h[5] << 16) | (h[6] << 8) | h[7];
      R.depth = h[8]; R.ctype = h[9];
      if (h[12] != 0) return -3;                                           // interlaced
      if (R.w < 1 || R.w > 1024 || R.h < 1 || R.h > 1024) return -3;
      int ch = R.ctype == 0 ? 1 : R.ctype == 2 ? 3 : R.ctype == 3 ? 1 : R.ctype == 4 ? 2 : R.ctype == 6 ? 4 : 0;
      if (!ch) return -3;
      if (R.depth == 16 || (R.depth != 8 && R.ctype != 0 && R.ctype != 3)) return -3;
      R.rowbytes = (R.w * ch * R.depth + 7) / 8; R.bpp = (ch * R.depth + 7) / 8;
      for (uint32_t i = 13; i < len; ++i) s.raw();
      s.r32(); haveIhdr = true;
    } else if (type == 0x504C5445u) {                                      // PLTE
      for (uint32_t i = 0; i < len / 3 && i < 256; ++i) { int r = s.raw(), g = s.raw(), b = s.raw(); R.pal[i] = Rows::c565(r, g, b); }
      for (uint32_t i = (len / 3 > 256 ? 256 : len / 3) * 3; i < len; ++i) s.raw();
      s.r32();
    } else if (type == 0x49444154u) { s.chunk = len; haveIdat = true; }
    else { for (uint32_t i = 0; i < len; ++i) if (s.raw() < 0) return -2; s.r32(); }
  }
  if (!haveIhdr) return -2;
  *outW = R.w; *outH = R.h;
  uint8_t *win = (uint8_t *)malloc(32768 + 2 * R.rowbytes + 2 * R.w + 16 + sizeof(InfTabs));
  if (!win) return -4;
  R.cur = win + 32768; R.prev = R.cur + R.rowbytes; memset(R.prev, 0, R.rowbytes);
  R.line = (uint16_t *)(((uintptr_t)(R.prev + R.rowbytes) + 3) & ~(uintptr_t)3);          // 32-bit aligned (Xtensa faults on misaligned 16/32-bit access)
  R.cb = cb; R.u = user; R.needF = true; R.y = 0;
  Inf inf; inf.tabs = (InfTabs *)(((uintptr_t)(R.line + R.w) + 3) & ~(uintptr_t)3); inf.src = &s; inf.rows = &R; inf.win = win; inf.wp = 0; inf.bb = 0; inf.bc = 0; inf.err = false;
  bool ok = inf.run();
  free(win);
  return ok ? 0 : -5;
}

// ============================================================================
//  routing text
// ============================================================================
enum : uint8_t { T_OTHER, T_DEPART, T_ARRIVE, T_TURN, T_NEWNAME, T_CONTINUE, T_MERGE, T_ONRAMP, T_OFFRAMP, T_FORK, T_ENDROAD, T_RBOUT, T_RTURN, T_RBEXIT };
const char *const TYPES[] = {"", "depart", "arrive", "turn", "new name", "continue", "merge", "on ramp", "off ramp", "fork", "end of road", "roundabout", "rotary", "roundabout turn", "exit roundabout", "exit rotary"};
const char *const MODS[] = {"", "uturn", "sharp right", "right", "slight right", "straight", "slight left", "left", "sharp left"};
const char *const MODTXT[] = {"", "make a U-turn", "turn sharp right", "turn right", "bear right", "continue straight", "bear left", "turn left", "turn sharp left"};

uint8_t typeCode(const char *s) {
  static const uint8_t map[] = {T_OTHER, T_DEPART, T_ARRIVE, T_TURN, T_NEWNAME, T_CONTINUE, T_MERGE, T_ONRAMP, T_OFFRAMP, T_FORK, T_ENDROAD, T_RBOUT, T_RBOUT, T_RTURN, T_RBEXIT, T_RBEXIT};
  for (int i = 1; i < 16; ++i) if (!strcmp(s, TYPES[i])) return map[i];
  return T_OTHER;
}
uint8_t modCode(const char *s) { for (int i = 1; i < 9; ++i) if (!strcmp(s, MODS[i])) return (uint8_t)i; return 0; }

struct Stp { uint32_t dist; uint16_t dur; uint8_t type, mod, ex; char name[28]; Pt p; };

void stepText(const Stp &s, char *o, int n) {
  char on[40] = "";
  if (s.name[0]) snprintf(on, sizeof(on), " onto %s", s.name);
  const char *m = MODTXT[s.mod];
  switch (s.type) {
    case T_DEPART:   if (s.name[0]) snprintf(o, n, "Head out on %s", s.name); else snprintf(o, n, "Start"); break;
    case T_ARRIVE:   snprintf(o, n, "Arrive at destination%s", s.mod == 7 || s.mod == 6 ? " (on the left)" : s.mod == 3 || s.mod == 4 ? " (on the right)" : ""); break;
    case T_TURN:     if (s.mod == 5 || !s.mod) snprintf(o, n, "Continue straight%s", on); else snprintf(o, n, "%s%s", m, on); break;
    case T_NEWNAME:  snprintf(o, n, "Continue%s", on); break;
    case T_CONTINUE: if (s.mod && s.mod != 5) snprintf(o, n, "%s%s", m, on); else snprintf(o, n, "Continue%s", on); break;
    case T_MERGE:    snprintf(o, n, "Merge%s%s", s.mod == 7 || s.mod == 6 ? " left" : s.mod == 3 || s.mod == 4 ? " right" : "", on); break;
    case T_ONRAMP:   snprintf(o, n, "Take the ramp%s%s", s.mod ? " " : "", s.mod ? MODS[s.mod] : ""); if (s.name[0]) { int l = strlen(o); snprintf(o + l, n - l, "%s", on); } break;
    case T_OFFRAMP:  snprintf(o, n, "Take the exit%s%s", s.mod ? " " : "", s.mod ? MODS[s.mod] : ""); if (s.name[0]) { int l = strlen(o); snprintf(o + l, n - l, "%s", on); } break;
    case T_FORK:     snprintf(o, n, "Keep %s%s", s.mod == 7 || s.mod == 6 || s.mod == 8 ? "left" : "right", on); break;
    case T_ENDROAD:  snprintf(o, n, "At the end of the road %s%s", s.mod ? m : "continue", on); break;
    case T_RBOUT:    if (s.ex) snprintf(o, n, "Roundabout: take exit %d%s", s.ex, on); else snprintf(o, n, "Enter the roundabout%s", on); break;
    case T_RTURN:    snprintf(o, n, "At the roundabout %s%s", s.mod ? m : "continue", on); break;
    case T_RBEXIT:   snprintf(o, n, "Exit the roundabout%s", on); break;
    default:         snprintf(o, n, "Continue%s", on); break;
  }
  if (o[0] >= 'a' && o[0] <= 'z') o[0] = (char)(o[0] - 32);
}

// ============================================================================
//  state
// ============================================================================
struct Res { char name[30]; char sub[72]; double lat, lon; };
struct Fav { double lat, lon; char name[26]; };

struct MS {
  Pt c; int z;                                    // view (centre in z20 px, zoom)
  bool online, mi; uint8_t prof, units, style;    // units 0 auto 1 km 2 mi;  style 0 voyager 1 light 2 osm 3 custom
  bool locKnown, locManual, imp; double lat, lon; char locName[40];
  char tile[128], ua[72], rcar[100], rbike[100], rfoot[100];
  bool havePin; double plat, plon; char pname[40];
  bool startCustom; double slat, slon;
  bool haveRoute; uint8_t rprof; double rdist, rdur;
  Pt pts[MAXPTS]; int np, stride, cnt; Pt lastPt;
  Stp steps[MAXSTEPS]; int ns; int hl;
  Res res[MAXRES]; int nres;
  Fav fav[MAXFAV]; int nfav;
  bool netFail; char lastErr[40];
  uint32_t failKey[16]; uint8_t failN;
  bool dirty;
};
MS *M = nullptr;

inline int sx(const Pt &p, int cpx, int sh) { return VX + VW / 2 + (int)((p.x >> sh) - cpx); }
inline int sy(const Pt &p, int cpy, int sh) { return VY + VH / 2 + (int)((p.y >> sh) - cpy); }

// ============================================================================
//  small helpers
// ============================================================================
void fmtDist(char *o, int n, double m) {
  if (M->mi) { double ft = m / 0.3048; if (ft < 1000) snprintf(o, n, "%d ft", (int)(ft / 10 + 0.5) * 10); else snprintf(o, n, "%.1f mi", m / 1609.344); }
  else { if (m < 1000) snprintf(o, n, "%d m", (int)(m / 10 + 0.5) * 10); else snprintf(o, n, "%.1f km", m / 1000.0); }
}
void fmtTime(char *o, int n, double s) {
  int mins = (int)(s / 60.0 + 0.5);
  if (mins < 60) snprintf(o, n, "%d min", mins < 1 ? 1 : mins); else snprintf(o, n, "%d h %02d min", mins / 60, mins % 60);
}
void fitText(char *s, int maxc) { int l = strlen(s); if (l > maxc) { if (maxc > 2) { s[maxc - 2] = '.'; s[maxc - 1] = '.'; } s[maxc] = 0; } }
void urlEnc(const char *in, char *out, int n) {
  int o = 0;
  for (; *in && o < n - 4; ++in) {
    unsigned char c = (unsigned char)*in;
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') out[o++] = (char)c;
    else { snprintf(out + o, 4, "%%%02X", c); o += 3; }
  }
  out[o] = 0;
}
void subst(const char *tmpl, int z, int x, int y, char *out, int n) {
  int o = 0;
  for (const char *p = tmpl; *p && o < n - 12; ) {
    if (p[0] == '{' && p[2] == '}' && (p[1] == 'z' || p[1] == 'x' || p[1] == 'y')) {
      o += snprintf(out + o, n - o, "%d", p[1] == 'z' ? z : p[1] == 'x' ? x : y); p += 3;
    } else out[o++] = *p++;
  }
  out[o] = 0;
}
bool imperialCountry(const char *c) { return !strcmp(c, "United States") || !strcmp(c, "United Kingdom") || !strcmp(c, "Liberia") || !strcmp(c, "Myanmar"); }
void applyUnits() { M->mi = M->units == 2 || (M->units == 0 && M->imp); }

// ============================================================================
//  settings + favourites (plain text, hand-editable)
// ============================================================================
const char *CFG = "/sys/maps.txt";
const char *FAVF = "/data/maps/favorites.txt";
// Plain HTTP (no TLS) Esri tiles are the default: the ESP32's HTTPS stack is
// memory-fragile and some tile hosts also block small devices, so HTTP + Esri's
// robust JPEG tiles are the most reliable on this hardware. OSM (HTTPS) is kept
// as a style you can switch to.
const char *DEF_TILE = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}";
struct Style { const char *id, *name, *url, *attr; };
const Style STY[3] = {
  {"esri", "STREET MAP",     "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", "(c)Esri"},
  {"sat",  "SATELLITE",      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",    "(c)Esri"},
  {"osm",  "OPENSTREETMAP",  "https://tile.openstreetmap.org/{z}/{x}/{y}.png",                                                   "(c)OSM"}};
const char *styleId() { return M->style < 3 ? STY[M->style].id : "custom"; }
const char *styleName() { return M->style < 3 ? STY[M->style].name : "CUSTOM (maps.txt)"; }
const char *tileTmpl() { return M->style < 3 ? STY[M->style].url : M->tile; }
const char *styleAttr() { return M->style < 3 ? STY[M->style].attr : "map data"; }
const char *DEF_CAR = "https://routing.openstreetmap.de/routed-car/route/v1/driving/";
const char *DEF_BIKE = "https://routing.openstreetmap.de/routed-bike/route/v1/driving/";
const char *DEF_FOOT = "https://routing.openstreetmap.de/routed-foot/route/v1/driving/";

void defaults() {
  M->online = true; M->prof = 0; M->units = 0; M->imp = false; M->style = 0;
  strcpy(M->tile, DEF_TILE); strcpy(M->rcar, DEF_CAR); strcpy(M->rbike, DEF_BIKE); strcpy(M->rfoot, DEF_FOOT);
  strcpy(M->ua, "KRIVI-OS-Maps/1.0 (ESP32 hobby device)");
  M->z = 3; M->c = ll2p(20, 0);
}

void loadCfg() {
  defaults();
  File f = SD.open(CFG);
  if (!f) { applyUnits(); return; }
  while (f.available()) {
    String l = f.readStringUntil('\n'); l.trim();
    const char *p = l.c_str();
    if (!*p || *p == '#') continue;
    const char *eq = strchr(p, '='); if (!eq) continue;
    String k = l.substring(0, eq - p); const char *v = eq + 1;
    if (k == "mode") M->online = strcmp(v, "offline") != 0;
    else if (k == "prof") M->prof = (uint8_t)constrain(atoi(v), 0, 2);
    else if (k == "units") M->units = !strcmp(v, "km") ? 1 : !strcmp(v, "mi") ? 2 : 0;
    else if (k == "imp") M->imp = atoi(v) != 0;
    // sat/osm/custom map directly; anything else (incl. legacy voyager/light/topo) -> Esri street (0)
    else if (k == "style") M->style = !strcmp(v, "sat") ? 1 : !strcmp(v, "osm") ? 2 : !strcmp(v, "custom") ? 3 : 0;
    else if (k == "tile") strlcpy(M->tile, v, sizeof(M->tile));
    else if (k == "ua") strlcpy(M->ua, v, sizeof(M->ua));
    else if (k == "route_car") strlcpy(M->rcar, v, sizeof(M->rcar));
    else if (k == "route_bike") strlcpy(M->rbike, v, sizeof(M->rbike));
    else if (k == "route_foot") strlcpy(M->rfoot, v, sizeof(M->rfoot));
    else if (k == "locmanual") M->locManual = atoi(v) != 0;
    else if (k == "loc") {
      double la, lo; char nm[40] = "";
      if (sscanf(v, "%lf,%lf,%39[^\n]", &la, &lo, nm) >= 2) { M->lat = la; M->lon = lo; M->locKnown = true; strlcpy(M->locName, nm, sizeof(M->locName)); }
    } else if (k == "view") {
      double la, lo; int z;
      if (sscanf(v, "%lf,%lf,%d", &la, &lo, &z) == 3) { M->c = ll2p(la, lo); M->z = constrain(z, 2, 18); }
    }
  }
  f.close();
  applyUnits();
}

void saveCfg() {
  SD.mkdir("/sys");
  File f = SD.open(CFG, FILE_WRITE); if (!f) return;
  double la, lo; p2ll(M->c, la, lo);
  f.print("# KRIVI Maps settings (edit freely). mode=online|offline  units=auto|km|mi  prof=0 car,1 bike,2 foot\n");
  f.print("# style=osm | topo | sat | custom (uses tile= below). All are free, no API key. Tiles are cached per style in /maps/tiles/<style>/.\n# tile= any slippy-map template with {z} {x} {y} (used when style=custom). Put your contact info in ua= (OSM tile policy).\n");
  f.printf("mode=%s\nstyle=%s\nunits=%s\nprof=%d\nimp=%d\n", M->online ? "online" : "offline", styleId(), M->units == 1 ? "km" : M->units == 2 ? "mi" : "auto", M->prof, M->imp ? 1 : 0);
  f.printf("tile=%s\nua=%s\nroute_car=%s\nroute_bike=%s\nroute_foot=%s\n", M->tile, M->ua, M->rcar, M->rbike, M->rfoot);
  if (M->locKnown) f.printf("loc=%.6f,%.6f,%s\nlocmanual=%d\n", M->lat, M->lon, M->locName, M->locManual ? 1 : 0);
  f.printf("view=%.6f,%.6f,%d\n", la, lo, M->z);
  f.close();
}

void loadFavs() {
  M->nfav = 0;
  File f = SD.open(FAVF); if (!f) return;
  while (f.available() && M->nfav < MAXFAV) {
    String l = f.readStringUntil('\n'); l.trim();
    Fav &v = M->fav[M->nfav]; double la, lo; char nm[26] = "";
    if (sscanf(l.c_str(), "%lf|%lf|%25[^\n]", &la, &lo, nm) >= 2) { v.lat = la; v.lon = lo; strlcpy(v.name, nm[0] ? nm : "Saved place", sizeof(v.name)); M->nfav++; }
  }
  f.close();
}
void saveFavs() {
  SD.mkdir("/data"); SD.mkdir("/data/maps");
  SD.remove(FAVF);
  File f = SD.open(FAVF, FILE_WRITE); if (!f) return;
  for (int i = 0; i < M->nfav; ++i) f.printf("%.6f|%.6f|%s\n", M->fav[i].lat, M->fav[i].lon, M->fav[i].name);
  f.close();
}

// ============================================================================
//  HTTP (plain or TLS), with chunked-transfer decoding, body pumped to a sink
// ============================================================================
struct Http {
  WiFiClientSecure sec; WiFiClient plain; HTTPClient h; WiFiClient *s; bool open; int code;
  Http() : s(nullptr), open(false), code(0) { sec.setInsecure(); }
  bool get(const char *url, uint16_t timeoutMs = 9000, int depth = 0) {
    if (open) { h.end(); open = false; }
    bool tls = !strncmp(url, "https", 5);
    h.setReuse(false);                            // a fresh connection per tile is more reliable over TLS
    h.setTimeout(timeoutMs);
    h.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    h.setUserAgent(M->ua);
    static const char *hk[] = {"Transfer-Encoding", "Location"};
    h.collectHeaders(hk, 2);
    bool ok = tls ? h.begin(sec, url) : h.begin(plain, url);
    if (!ok) { code = -1; return false; }
    open = true;
    code = h.GET();
    // follow a redirect ourselves when HTTPClient won't (e.g. http -> https)
    if ((code == 301 || code == 302 || code == 307 || code == 308) && depth < 3) {
      String loc = h.header("Location"); h.end(); open = false;
      if (loc.length()) return get(loc.c_str(), timeoutMs, depth + 1);
    }
    if (code != 200) { h.end(); open = false; return false; }
    s = h.getStreamPtr();
    return true;
  }
  void close() { if (open) { h.end(); open = false; } }
  // Feed the whole body to sink(u, data, n). False on timeout / stream error.
  bool pump(void (*sink)(void *, const uint8_t *, int), void *u, uint32_t idleMs = 8000) {
    bool chunked = h.header("Transfer-Encoding").indexOf("chunked") >= 0;
    int32_t left = chunked ? -1 : h.getSize();
    int cs = 0; int32_t cl = 0;                   // chunk state / chunk bytes left
    uint8_t b[256]; uint32_t last = millis();
    for (;;) {
      if (!chunked && left == 0) return true;
      int av = s->available();
      if (av <= 0) {
        if (!s->connected()) return !chunked || cs == 5 ? (left < 0 || left == 0) : false;
        if (millis() - last > idleMs) return false;
        delay(3); continue;
      }
      int want = av < (int)sizeof(b) ? av : (int)sizeof(b);
      if (!chunked && left > 0 && want > left) want = left;
      int n = s->read(b, want); if (n <= 0) { delay(2); continue; }
      last = millis();
      if (!chunked) { sink(u, b, n); if (left > 0) left -= n; continue; }
      int i = 0;
      while (i < n) {
        uint8_t c = b[i];
        switch (cs) {
          case 0: if (c == '\r') cs = 1; else if (isxdigit(c)) cl = cl * 16 + (c <= '9' ? c - '0' : (c | 32) - 'a' + 10); i++; break;
          case 1: i++; cs = cl ? 2 : 5; if (!cl) return true; break;                        // after "\r" -> "\n"
          case 2: { int take = n - i; if (take > cl) take = (int)cl; sink(u, b + i, take); i += take; cl -= take; if (cl == 0) cs = 3; break; }
          case 3: i++; cs = 4; break;                                                       // "\r"
          case 4: i++; cs = 0; cl = 0; break;                                               // "\n"
          default: i = n; break;
        }
      }
    }
  }
};

void jsSink(void *u, const uint8_t *d, int n) { JS *js = (JS *)u; for (int i = 0; i < n; ++i) js->feed(d[i]); }

// ============================================================================
//  JSON handlers
// ============================================================================
// --- search (Nominatim jsonv2) ---
void onSearch(void *, const char *path, const char *val) {
  if (!isdigit((unsigned char)path[0])) return;
  int i = atoi(path); if (i >= MAXRES) return;
  const char *k = strchr(path, '.'); if (!k) return; k++;
  Res &r = M->res[i]; if (i >= M->nres) { memset(&r, 0, sizeof(r)); M->nres = i + 1; }
  if (!strcmp(k, "lat")) r.lat = atof(val);
  else if (!strcmp(k, "lon")) r.lon = atof(val);
  else if (!strcmp(k, "name")) strlcpy(r.name, val, sizeof(r.name));
  else if (!strcmp(k, "display_name")) {
    const char *c = strchr(val, ',');
    if (c && !r.name[0]) { int l = c - val; if (l > 29) l = 29; memcpy(r.name, val, l); r.name[l] = 0; }
    strlcpy(r.sub, c ? c + 2 : val, sizeof(r.sub));
    if (!c && !r.name[0]) strlcpy(r.name, val, sizeof(r.name));
  }
}
// --- reverse geocode ---
struct RevOut { char name[40]; };
void onRev(void *u, const char *path, const char *val) {
  RevOut *o = (RevOut *)u;
  if (!strcmp(path, "display_name")) {
    const char *c = strchr(val, ','); const char *c2 = c ? strchr(c + 1, ',') : nullptr;
    int l = c2 ? (int)(c2 - val) : (int)strlen(val); if (l > 39) l = 39;
    memcpy(o->name, val, l); o->name[l] = 0;
  }
}
// --- IP location (ipwho.is or ip-api.com) ---
struct IpOut { bool ok; double lat, lon; char city[24], region[24], country[32]; bool haveLat, haveLon; };
void onIp(void *u, const char *path, const char *val) {
  IpOut *o = (IpOut *)u;
  if (!strcmp(path, "latitude") || !strcmp(path, "lat")) { o->lat = atof(val); o->haveLat = true; }
  else if (!strcmp(path, "longitude") || !strcmp(path, "lon")) { o->lon = atof(val); o->haveLon = true; }
  else if (!strcmp(path, "city")) strlcpy(o->city, val, sizeof(o->city));
  else if (!strcmp(path, "region") || !strcmp(path, "regionName")) strlcpy(o->region, val, sizeof(o->region));
  else if (!strcmp(path, "country")) strlcpy(o->country, val, sizeof(o->country));
  else if (!strcmp(path, "success")) o->ok = !strcmp(val, "true");
  else if (!strcmp(path, "status")) o->ok = !strcmp(val, "success");
}
// --- route (OSRM v1) ---
struct RouteOut { Poly poly; bool ok; double dist, dur; };
RouteOut *RO = nullptr;
bool routeBig(void *, const char *path) { return !strcmp(path, "routes.0.geometry"); }
void addRoutePt(double la, double lo) {
  Pt p = ll2p(la, lo); M->lastPt = p;
  if (M->cnt++ % M->stride) return;
  if (M->np >= MAXPTS) {
    int j = 0; for (int i = 0; i < M->np; i += 2) M->pts[j++] = M->pts[i];
    M->np = j; M->stride *= 2;
  }
  M->pts[M->np++] = p;
}
void routeChr(void *, char c) { double la, lo; if (RO->poly.feed(c, la, lo)) addRoutePt(la, lo); }
void onRoute(void *, const char *path, const char *val) {
  if (!strcmp(path, "code")) { RO->ok = !strcmp(val, "Ok"); return; }
  if (!strcmp(path, "routes.0.distance")) { RO->dist = atof(val); return; }
  if (!strcmp(path, "routes.0.duration")) { RO->dur = atof(val); return; }
  static const char PRE[] = "routes.0.legs.0.steps.";
  if (strncmp(path, PRE, sizeof(PRE) - 1)) return;
  const char *q = path + sizeof(PRE) - 1; int i = atoi(q);
  if (i < 0 || i >= MAXSTEPS) return;
  const char *k = strchr(q, '.'); if (!k) return; k++;
  Stp &s = M->steps[i]; if (i >= M->ns) { memset(&s, 0, sizeof(s)); M->ns = i + 1; }
  if (!strcmp(k, "distance")) s.dist = (uint32_t)atof(val);
  else if (!strcmp(k, "duration")) s.dur = (uint16_t)constrain((int)atof(val), 0, 65535);
  else if (!strcmp(k, "name")) strlcpy(s.name, val, sizeof(s.name));
  else if (!strcmp(k, "maneuver.type")) s.type = typeCode(val);
  else if (!strcmp(k, "maneuver.modifier")) s.mod = modCode(val);
  else if (!strcmp(k, "maneuver.exit")) s.ex = (uint8_t)atoi(val);
  else if (!strcmp(k, "maneuver.location.0")) s.p.x = (int32_t)(atof(val) * 1000000.0);       // lon (temp, micro-deg)
  else if (!strcmp(k, "maneuver.location.1")) s.p.y = (int32_t)(atof(val) * 1000000.0);       // lat
}

// ============================================================================
//  network flows
// ============================================================================
bool netUp() {
  if (WiFi.status() == WL_CONNECTED) return true;
  return sys::wifiConnect(10000, true);
}
void setErr(const char *e) { strlcpy(M->lastErr, e, sizeof(M->lastErr)); }

bool httpScan(const char *url, JS &js, uint32_t timeout = 12000) {
  Http H;
  if (!H.get(url, 10000)) { char b[24]; snprintf(b, sizeof(b), "HTTP %d", H.code); setErr(b); return false; }
  bool ok = H.pump(jsSink, &js, timeout);
  H.close();
  if (!ok) setErr("connection lost");
  return ok;
}

bool ipLocate() {
  if (!netUp()) { setErr("no WiFi"); return false; }
  static const char *urls[2] = {"https://ipwho.is/", "http://ip-api.com/json/?fields=status,country,regionName,city,lat,lon"};
  for (int i = 0; i < 2; ++i) {
    IpOut o; memset(&o, 0, sizeof(o)); JS js; js.init(onIp, nullptr, nullptr, &o);
    if (!httpScan(urls[i], js, 8000)) continue;
    if (!(o.haveLat && o.haveLon) || (!o.ok && i == 0 && o.lat == 0 && o.lon == 0)) continue;
    M->lat = o.lat; M->lon = o.lon; M->locKnown = true; M->locManual = false;
    snprintf(M->locName, sizeof(M->locName), "%s%s%s (IP)", o.city, o.city[0] && o.region[0] ? ", " : "", o.region);
    M->imp = imperialCountry(o.country); applyUnits();
    return true;
  }
  return false;
}

bool geocode(const char *q) {
  if (!netUp()) { setErr("no WiFi"); return false; }
  double la, lo; p2ll(M->c, la, lo);
  char enc[120], url[360]; urlEnc(q, enc, sizeof(enc));
  snprintf(url, sizeof(url), "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=%d&accept-language=en&q=%s&viewbox=%.4f,%.4f,%.4f,%.4f",
           MAXRES, enc, lo - 0.6, la + 0.6, lo + 0.6, la - 0.6);
  M->nres = 0; JS js; js.init(onSearch, nullptr, nullptr, nullptr);
  if (!httpScan(url, js)) return false;
  return true;
}

bool revGeocode(double la, double lo, char *out, int n) {
  if (!netUp()) { setErr("no WiFi"); return false; }
  char url[200]; snprintf(url, sizeof(url), "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&accept-language=en&lat=%.6f&lon=%.6f", la, lo);
  RevOut o; o.name[0] = 0; JS js; js.init(onRev, nullptr, nullptr, &o);
  if (!httpScan(url, js)) return false;
  if (!o.name[0]) { setErr("nothing found"); return false; }
  strlcpy(out, o.name, n); return true;
}

bool routeFetch(uint8_t prof, double la1, double lo1, double la2, double lo2) {
  if (!netUp()) { setErr("no WiFi"); return false; }
  const char *base = prof == 1 ? M->rbike : prof == 2 ? M->rfoot : M->rcar;
  char url[300];
  snprintf(url, sizeof(url), "%s%.6f,%.6f;%.6f,%.6f?overview=simplified&geometries=polyline&steps=true", base, lo1, la1, lo2, la2);
  RouteOut ro; memset(&ro, 0, sizeof(ro)); ro.poly.reset(); RO = &ro;
  M->np = 0; M->cnt = 0; M->stride = 1; M->ns = 0; M->haveRoute = false;
  JS js; js.init(onRoute, routeBig, routeChr, nullptr);
  bool ok = httpScan(url, js, 15000);
  RO = nullptr;
  if (!ok) return false;
  if (!ro.ok || M->np < 2 || M->ns < 1) { setErr("no route found"); return false; }
  if (M->np < MAXPTS) M->pts[M->np++] = M->lastPt;           // make sure the end point is included
  for (int i = 0; i < M->ns; ++i) {                          // convert temp micro-degrees to map points
    double lo = M->steps[i].p.x / 1.0e6, la = M->steps[i].p.y / 1.0e6; M->steps[i].p = ll2p(la, lo);
  }
  M->rdist = ro.dist; M->rdur = ro.dur; M->rprof = prof; M->haveRoute = true; M->hl = -1;
  return true;
}

// ============================================================================
//  tiles: SD cache + download + decode
// ============================================================================
static int g_tx, g_ty, g_c0, g_c1, g_r0, g_r1;     // tile origin + clip rect (screen)

void tileLine(void *, int y, uint16_t *line) {
  int yy = g_ty + y; if (yy < g_r0 || yy >= g_r1) return;
  int xa = g_tx > g_c0 ? g_tx : g_c0, xb = g_tx + 256 < g_c1 ? g_tx + 256 : g_c1;
  if (xb > xa) tft.pushImage(xa, yy, xb - xa, 1, line + (xa - g_tx));
}
bool jpgOut(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bmp) {
  for (int r = 0; r < h; ++r) {
    int yy = y + r; if (yy < g_r0 || yy >= g_r1) continue;
    int xa = x > g_c0 ? x : g_c0, xb = x + w < g_c1 ? x + w : g_c1;
    if (xb > xa) tft.pushImage(xa, yy, xb - xa, 1, bmp + r * w + (xa - x));
  }
  return true;
}

void tilePath(char *o, int n, int z, int x, int y, const char *ext) { snprintf(o, n, "/maps/tiles/%s/%d/%d/%d.%s", styleId(), z, x, y, ext); }
bool tileExists(int z, int x, int y, char *pathOut, int n, bool &isPng) {
  tilePath(pathOut, n, z, x, y, "png"); if (SD.exists(pathOut)) { isPng = true; return true; }
  tilePath(pathOut, n, z, x, y, "jpg"); if (SD.exists(pathOut)) { isPng = false; return true; }
  return false;
}
uint32_t tkey(int z, int x, int y) { return ((uint32_t)z << 28) ^ ((uint32_t)x << 14) ^ (uint32_t)y ^ 0x5A5A0000u ^ ((uint32_t)M->style << 24); }
bool tileFailed(int z, int x, int y) { uint32_t k = tkey(z, x, y); for (int i = 0; i < 16; ++i) if (M->failKey[i] == k) return true; return false; }
void tileFail(int z, int x, int y) { M->failKey[M->failN++ & 15] = tkey(z, x, y); }

struct FileSink { File f; int total; bool bad; };
void fileSink(void *u, const uint8_t *d, int n) {
  FileSink *s = (FileSink *)u;
  if (s->bad) return;
  if (s->total + n > 250000) { s->bad = true; return; }
  if ((int)s->f.write(d, n) != n) s->bad = true;
  s->total += n;
}

bool mkTileDirs(int z, int x) {
  char p[56];
  SD.mkdir("/maps"); SD.mkdir("/maps/tiles");
  snprintf(p, sizeof(p), "/maps/tiles/%s", styleId()); SD.mkdir(p);
  snprintf(p, sizeof(p), "/maps/tiles/%s/%d", styleId(), z); SD.mkdir(p);
  snprintf(p, sizeof(p), "/maps/tiles/%s/%d/%d", styleId(), z, x); SD.mkdir(p);
  return true;
}

// download one tile into the cache. Returns true if a valid file now exists.
bool downloadTile(Http &H, int z, int x, int y) {
  char url[200]; subst(tileTmpl(), z, x, y, url, sizeof(url));
  mkTileDirs(z, x);
  char tmp[64]; snprintf(tmp, sizeof(tmp), "/maps/tiles/%s/%d/%d/%d.tmp", styleId(), z, x, y);
  if (!H.get(url, 9000)) { char b[24]; snprintf(b, sizeof(b), "tiles: HTTP %d", H.code); setErr(b); return false; }
  FileSink fs; fs.total = 0; fs.bad = false; fs.f = SD.open(tmp, FILE_WRITE);
  if (!fs.f) { setErr("SD write failed"); H.close(); return false; }
  bool ok = H.pump(fileSink, &fs, 8000);
  fs.f.close(); H.close();
  if (fs.bad) { SD.remove(tmp); setErr("SD write error"); return false; }
  if (!ok) { SD.remove(tmp); char e[36]; snprintf(e, sizeof(e), "stream dropped (%d B)", fs.total); setErr(e); return false; }
  if (fs.total < 100) { SD.remove(tmp); char e[36]; snprintf(e, sizeof(e), "empty reply (%d B)", fs.total); setErr(e); return false; }
  File r = SD.open(tmp); uint8_t m[4] = {0, 0, 0, 0}; if (r) { r.read(m, 4); r.close(); }
  const char *ext = (m[0] == 0x89 && m[1] == 'P') ? "png" : (m[0] == 0xFF && m[1] == 0xD8) ? "jpg" : nullptr;
  if (!ext) { SD.remove(tmp); setErr("server sent no image"); return false; }
  char fin[64]; tilePath(fin, sizeof(fin), z, x, y, ext);
  return SD.rename(tmp, fin);
}

bool drawTileFile(const char *path, bool isPng, int dx, int dy) {
  File f = SD.open(path); if (!f) return false;
  g_tx = dx; g_ty = dy;
  bool ok = false;
  if (isPng) {
    int w, h; tft.setSwapBytes(true);
    ok = pngDecode(f, tileLine, nullptr, &w, &h) == 0;
    tft.setSwapBytes(false);
    f.close();
  } else {
    int sz = f.size(); uint8_t *buf = (sz > 0 && sz < 120000) ? (uint8_t *)malloc(sz) : nullptr;
    if (buf && f.read(buf, sz) == sz) {
      f.close();
      TJpgDec.setSwapBytes(true); TJpgDec.setCallback(jpgOut); TJpgDec.setJpgScale(1);
      ok = TJpgDec.drawJpg(dx, dy, buf, sz) == 0;
    } else f.close();
    free(buf);
  }
  return ok;
}

// ============================================================================
//  drawing: overlays
// ============================================================================
bool clipLine(int &x0, int &y0, int &x1, int &y1) {              // Liang-Barsky against the map viewport
  float t0 = 0, t1 = 1, dx = (float)(x1 - x0), dy = (float)(y1 - y0);
  float p[4] = {-dx, dx, -dy, dy}, q[4] = {(float)(x0 - VX), (float)(VX + VW - 1 - x0), (float)(y0 - VY), (float)(VY + VH - 14 - y0)};
  for (int i = 0; i < 4; ++i) {
    if (p[i] == 0) { if (q[i] < 0) return false; }
    else { float t = q[i] / p[i]; if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; } }
  }
  int nx0 = x0 + (int)(t0 * dx), ny0 = y0 + (int)(t0 * dy), nx1 = x0 + (int)(t1 * dx), ny1 = y0 + (int)(t1 * dy);
  x0 = nx0; y0 = ny0; x1 = nx1; y1 = ny1; return true;
}
void thickLine(int x0, int y0, int x1, int y1, uint16_t col) {
  if (!clipLine(x0, y0, x1, y1)) return;
  tft.drawLine(x0, y0, x1, y1, col); tft.drawLine(x0 + 1, y0, x1 + 1, y1, col);
  tft.drawLine(x0, y0 + 1, x1, y1 + 1, col); tft.drawLine(x0 + 1, y0 + 1, x1 + 1, y1 + 1, col);
}
inline bool inMap(int x, int y, int m) { return x >= VX + m && x < VX + VW - m && y >= VY + m + 6 && y < VY + VH - 14 - m / 2; }
void dotMarker(int x, int y, uint16_t col, int r) { if (inMap(x, y, r + 2)) { tft.fillCircle(x, y, r + 1, TFT_WHITE); tft.fillCircle(x, y, r, col); } }
void starMarker(int x, int y, int r, uint16_t col) {
  int vx[10], vy[10];
  for (int i = 0; i < 10; ++i) { float a = -1.5707963f + i * 0.6283185f, rr = (i & 1) ? r * 0.45f : (float)r; vx[i] = x + (int)lroundf(cosf(a) * rr); vy[i] = y + (int)lroundf(sinf(a) * rr); }
  for (int i = 0; i < 10; ++i) tft.fillTriangle(x, y, vx[i], vy[i], vx[(i + 1) % 10], vy[(i + 1) % 10], col);
  for (int i = 0; i < 10; ++i) tft.drawLine(vx[i], vy[i], vx[(i + 1) % 10], vy[(i + 1) % 10], RGB565(190, 130, 0));
}
void pinMarker(int x, int y, uint16_t col) {
  if (!inMap(x, y - 6, 9)) return;
  tft.fillTriangle(x - 4, y - 6, x + 4, y - 6, x, y, col);
  tft.fillCircle(x, y - 9, 6, G_DRED); tft.fillCircle(x, y - 9, 5, col); tft.fillCircle(x, y - 9, 2, G_DRED);
}

// ============================================================================
//  rendering the map
// ============================================================================
void drawOverlays() {
  int sh = ZB - M->z, cpx = M->c.x >> sh, cpy = M->c.y >> sh;
  // route
  if (M->haveRoute) {
    int px = 0, py = 0;
    for (int pass = 0; pass < 2; ++pass) {
      for (int i = 0; i < M->np; ++i) {
        int x = sx(M->pts[i], cpx, sh), y = sy(M->pts[i], cpy, sh);
        if (i > 0) {
          bool off = (x < VX && px < VX) || (x >= VX + VW && px >= VX + VW) || (y < VY && py < VY) || (y >= VY + VH && py >= VY + VH);
          if (!off) {
            if (pass == 0) { thickLine(px - 1, py - 1, x - 1, y - 1, TFT_WHITE); thickLine(px + 1, py + 1, x + 1, y + 1, TFT_WHITE); }
            else thickLine(px, py, x, y, G_BLUE);
          }
        }
        px = x; py = y;
      }
    }
    // start / end markers
    Pt a = M->pts[0], b = M->pts[M->np - 1];
    dotMarker(sx(a, cpx, sh), sy(a, cpy, sh), RGB565(52, 168, 83), 5);
    if (!M->havePin) dotMarker(sx(b, cpx, sh), sy(b, cpy, sh), G_RED, 5);
    if (M->hl >= 0 && M->hl < M->ns) { int x = sx(M->steps[M->hl].p, cpx, sh), y = sy(M->steps[M->hl].p, cpy, sh); if (inMap(x, y, 8)) { tft.drawCircle(x, y, 8, RGB565(255, 120, 0)); tft.drawCircle(x, y, 7, RGB565(255, 120, 0)); } }
  }
  // favourites
  for (int i = 0; i < M->nfav; ++i) { Pt p = ll2p(M->fav[i].lat, M->fav[i].lon); int x = sx(p, cpx, sh), y = sy(p, cpy, sh); if (inMap(x, y, 6)) starMarker(x, y, 6, G_YEL); }
  // my location (IP based): dot + approximate-area ring
  if (M->locKnown) {
    Pt p = ll2p(M->lat, M->lon); int x = sx(p, cpx, sh), y = sy(p, cpy, sh);
    int ring = (int)(M->locManual ? 15.0 / mPerPx(M->lat, M->z) : 4000.0 / mPerPx(M->lat, M->z));
    if (ring > 8 && ring < 90 && inMap(x, y, ring)) { tft.drawCircle(x, y, ring, G_BLUE); tft.drawCircle(x, y, ring - 1, RGB565(168, 199, 250)); }
    if (inMap(x, y, 8)) { tft.fillCircle(x, y, 8, RGB565(168, 199, 250)); tft.fillCircle(x, y, 7, TFT_WHITE); tft.fillCircle(x, y, 5, G_BLUE); }
  }
  // destination pin
  if (M->havePin) { Pt p = ll2p(M->plat, M->plon); pinMarker(sx(p, cpx, sh), sy(p, cpy, sh), G_RED); }
}

void drawChip(const char *msg = nullptr) {
  const int y = VY + VH - 13;
  tft.fillRect(VX, y, VW, 13, TFT_WHITE); tft.drawFastHLine(VX, y, VW, RGB565(218, 220, 224));
  char b[72];
  if (msg) snprintf(b, sizeof(b), "%s", msg);
  else if (M->haveRoute) {
    char d[16], t[20]; fmtDist(d, sizeof(d), M->rdist); fmtTime(t, sizeof(t), M->rdur);
    snprintf(b, sizeof(b), "%s  %s  %s  >%s", M->rprof == 1 ? "BIKE" : M->rprof == 2 ? "WALK" : "CAR", d, t, M->pname);
  } else if (M->havePin) snprintf(b, sizeof(b), "%s  (%.4f, %.4f)", M->pname, M->plat, M->plon);
  else { double la, lo; p2ll(M->c, la, lo); snprintf(b, sizeof(b), "%.4f, %.4f", la, lo); }
  fitText(b, 35);
  tft.setTextColor(RGB565(60, 64, 67)); tft.setTextDatum(TL_DATUM); tft.drawString(b, 3, y + 3, 1);
  tft.setTextColor(M->online ? RGB565(30, 142, 62) : RGB565(227, 116, 0)); tft.drawString(M->online ? "ON" : "OFF", 218, y + 3, 1);
  tft.setTextColor(RGB565(112, 117, 122)); tft.drawString(styleAttr(), 320 - (int)strlen(styleAttr()) * 6 - 3, y + 3, 1);
}

void drawScale() {
  double la, lo; p2ll(M->c, la, lo); double mpp = mPerPx(la, M->z);
  static const double MET[] = {10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000, 2000000, 5000000};
  static const double FT = 0.3048, MI = 1609.344;
  static const double IMP[] = {50 * FT, 100 * FT, 200 * FT, 500 * FT, 1000 * FT, MI, 2 * MI, 5 * MI, 10 * MI, 20 * MI, 50 * MI, 100 * MI, 200 * MI, 500 * MI, 1000 * MI, 2000 * MI, 5000 * MI};
  const double *T = M->mi ? IMP : MET; int n = M->mi ? 17 : 18;
  double m = T[n - 1]; for (int i = 0; i < n; ++i) if (T[i] / mpp >= 30.0) { m = T[i]; break; }
  int w = (int)(m / mpp); if (w > 120) w = 120;
  char b[16];
  if (M->mi) { if (m < MI * 0.99) snprintf(b, sizeof(b), "%d ft", (int)(m / FT + 0.5)); else snprintf(b, sizeof(b), "%d mi", (int)(m / MI + 0.5)); }
  else { if (m < 1000) snprintf(b, sizeof(b), "%d m", (int)m); else snprintf(b, sizeof(b), "%d km", (int)(m / 1000 + 0.5)); }
  int y = VY + VH - 17, x = VX + 6;
  tft.fillRect(x - 3, y - 11, w + 8 > 46 ? w + 8 : 46, 14, RGB565(255, 255, 255));
  tft.drawFastHLine(x, y, w, G_GREY); tft.drawFastVLine(x, y - 3, 4, G_GREY); tft.drawFastVLine(x + w, y - 3, 4, G_GREY);
  tft.setTextColor(G_GREY); tft.setTextDatum(TL_DATUM); tft.drawString(b, x, y - 11, 1);
}

void drawBanner(const char *msg) {
  int w = (int)strlen(msg) * 6 + 8;
  tft.fillRect(VX + 36, VY + 3, w, 11, RGB565(200, 110, 0)); tft.setTextColor(TFT_WHITE); tft.setTextDatum(TL_DATUM); tft.drawString(msg, VX + 40, VY + 5, 1);
}

void drawZoomBtns() {                                          // Google-style white +/- pill
  const int x = VX + VW - 30, y = VY + 6;
  tft.fillRoundRect(x, y, 26, 52, 4, TFT_WHITE); tft.drawRoundRect(x, y, 26, 52, 4, RGB565(190, 193, 198));
  tft.drawFastHLine(x + 3, y + 26, 20, RGB565(218, 220, 224));
  tft.fillRect(x + 7, y + 12, 12, 2, G_GREY); tft.fillRect(x + 12, y + 7, 2, 12, G_GREY);   // +
  tft.fillRect(x + 7, y + 38, 12, 2, G_GREY);                                              // -
  char b[12]; snprintf(b, sizeof(b), "z%d", M->z);
  tft.fillRoundRect(VX + 3, VY + 3, 26, 12, 3, TFT_WHITE); tft.setTextColor(G_GREY); tft.setTextDatum(TL_DATUM); tft.drawString(b, VX + 7, VY + 6, 1);
}

void drawBar() {
  static const char *L[6] = {"FIND", "ROUTE", "STEPS", "SAVED", "ME", "MENU"};
  tft.fillRect(0, BAR_Y - 2, 320, 30, C_BG);
  for (int i = 0; i < 6; ++i) {
    uint16_t bg = (i == 2 && !M->haveRoute) ? C_BG : C_PANEL2;
    ui::button(2 + i * 53, BAR_Y, 51, 26, L[i], bg, (i == 2 && !M->haveRoute) ? C_DIM : C_TEXT, 1);
  }
}

// Draws the tiles + overlays. Online mode downloads missing tiles first (cached to SD).
void renderMap(const char *why = nullptr) {
  int z = M->z, sh = ZB - z, cpx = M->c.x >> sh, cpy = M->c.y >> sh;
  int left = cpx - VW / 2, top = cpy - VH / 2;
  int n = 1 << z;
  int tx0 = left >> 8, tx1 = (left + VW - 1) >> 8, ty0 = top >> 8, ty1 = (top + VH - 1) >> 8;
  tft.fillRect(VX, VY, VW, VH, MAPBG);
  g_c0 = VX; g_c1 = VX + VW; g_r0 = VY; g_r1 = VY + VH;
  struct T { int x, y, d; } t[16]; int nt = 0;
  for (int y = ty0; y <= ty1 && nt < 16; ++y) for (int x = tx0; x <= tx1 && nt < 16; ++x) {
    int cx = x * 256 + 128 - cpx, cy = y * 256 + 128 - cpy; t[nt].x = x; t[nt].y = y; t[nt].d = cx * cx + cy * cy; nt++;
  }
  for (int i = 0; i < nt; ++i) for (int j = i + 1; j < nt; ++j) if (t[j].d < t[i].d) { T a = t[i]; t[i] = t[j]; t[j] = a; }
  Http *H = nullptr; bool triedNet = false;
  int missing = 0; char path[64]; bool isPng;
  for (int i = 0; i < nt; ++i) if (t[i].x >= 0 && t[i].x < n && t[i].y >= 0 && t[i].y < n && !tileExists(z, t[i].x, t[i].y, path, sizeof(path), isPng)) missing++;
  int fetched = 0, offMiss = 0, dlFail = 0;
  for (int i = 0; i < nt; ++i) {
    int tx = t[i].x, ty = t[i].y;
    int dx = VX + VW / 2 + tx * 256 - cpx, dy = VY + VH / 2 + ty * 256 - cpy;
    if (tx < 0 || tx >= n || ty < 0 || ty >= n) continue;
    if (!tileExists(z, tx, ty, path, sizeof(path), isPng)) {
      if (M->online && !M->netFail && !tileFailed(z, tx, ty)) {
        if (!triedNet) { triedNet = true; if (!netUp()) { M->netFail = true; setErr("no WiFi - offline"); } else H = new Http(); }
        if (H) {
          char b[40]; snprintf(b, sizeof(b), "Fetching tiles %d/%d ...", ++fetched, missing); drawChip(b);
          if (!downloadTile(*H, z, tx, ty)) { tileFail(z, tx, ty); dlFail++; }
        }
      }
    }
    if (tileExists(z, tx, ty, path, sizeof(path), isPng)) {
      if (!drawTileFile(path, isPng, dx, dy)) { SD.remove(path); }
    } else {                                                 // placeholder
      if (!M->online) offMiss++;
      int xa = dx < VX ? VX : dx, xb = dx + 256 > VX + VW ? VX + VW : dx + 256, ya = dy < VY ? VY : dy, yb = dy + 256 > VY + VH ? VY + VH : dy + 256;
      if (xb > xa && yb > ya) { tft.fillRect(xa, ya, xb - xa, yb - ya, RGB565(229, 227, 223)); tft.drawRect(xa, ya, xb - xa, yb - ya, RGB565(214, 212, 208)); }
    }
  }
  if (H) { H->close(); delete H; }
  drawOverlays(); drawScale(); drawZoomBtns(); drawChip(why);
  if (offMiss && !M->online) { char b[40]; snprintf(b, sizeof(b), "offline: %d tiles not on SD", offMiss); drawBanner(b); }
  else if (M->netFail && M->online) drawBanner("no WiFi - showing cached tiles");
  else if (dlFail && M->online) drawBanner(M->lastErr);    // show why tiles aren't loading
  ui::clearEvents();
}

// ============================================================================
//  list picker (search results / steps / favourites / menu)
// ============================================================================
typedef void (*RowFn)(void *u, int i, char *l1, int n1, char *l2, int n2);

void waitRelease() { uint32_t t0 = millis(); while (ui::poll().down && millis() - t0 < 3000) delay(4); ui::clearEvents(); }

int pickList(const char *title, int n, RowFn fn, void *u, bool bigFirst, int startAt = 0) {
  waitRelease();
  const int RH = 34, RY = 48, ROWS = 5, RW = 262;
  int top = startAt > 0 ? startAt - (startAt % ROWS) : 0;
  bool redraw = true;
  for (;;) {
    if (redraw) {
      ui::clearBody(C_BG);
      tft.setTextColor(C_ACCENT); tft.setTextDatum(TL_DATUM); tft.drawString(title, 6, 32, 2);
      for (int r = 0; r < ROWS; ++r) {
        int i = top + r; if (i >= n) break;
        char a[64], b[80]; a[0] = b[0] = 0; fn(u, i, a, sizeof(a), b, sizeof(b));
        fitText(a, bigFirst ? 30 : 43); fitText(b, 43);
        tft.fillRoundRect(4, RY + r * RH, RW, RH - 3, 5, C_PANEL2);
        tft.setTextColor(C_TEXT, C_PANEL2); tft.drawString(a, 9, RY + r * RH + (bigFirst ? 2 : 4), bigFirst ? 2 : 1);
        tft.setTextColor(C_DIM, C_PANEL2); tft.drawString(b, 9, RY + r * RH + (bigFirst ? 20 : 17), 1);
      }
      ui::button(270, 48, 46, 38, "UP", C_PANEL2, C_TEXT, 2);
      ui::button(270, 90, 46, 38, "DN", C_PANEL2, C_TEXT, 2);
      char pg[16]; snprintf(pg, sizeof(pg), "%d/%d", n ? top / ROWS + 1 : 0, (n + ROWS - 1) / ROWS);
      tft.setTextColor(C_DIM, C_BG); tft.drawString(pg, 274, 134, 1);
      ui::button(270, 190, 46, 44, "BACK", RGB565(150, 30, 40), C_TEXT, 1);
      redraw = false;
    }
    Touch &t = ui::poll(); delay(4);
    if (ui::exitHit(t)) { ui::clearEvents(); return -1; }
    if (t.swipe == SW_UP && top + ROWS < n) { top += ROWS; redraw = true; }
    else if (t.swipe == SW_DOWN && top >= ROWS) { top -= ROWS; redraw = true; }
    if (t.tap) {
      int x = t.sx, y = t.sy;
      if (ui::inRect(x, y, 270, 190, 46, 44)) { ui::clearEvents(); return -1; }
      if (ui::inRect(x, y, 270, 48, 46, 38)) { if (top >= ROWS) { top -= ROWS; redraw = true; } }
      else if (ui::inRect(x, y, 270, 90, 46, 38)) { if (top + ROWS < n) { top += ROWS; redraw = true; } }
      else if (x < 4 + RW && y >= RY && y < RY + ROWS * RH) { int i = top + (y - RY) / RH; if (i < n) { ui::clearEvents(); return i; } }
    }
    ui::clearEvents();
  }
}

// ---- row callbacks
void rowRes(void *, int i, char *a, int na, char *b, int nb) { snprintf(a, na, "%s", M->res[i].name); snprintf(b, nb, "%s", M->res[i].sub); }
void rowStep(void *, int i, char *a, int na, char *b, int nb) {
  char d[16], t[24]; stepText(M->steps[i], a, na);
  fmtDist(d, sizeof(d), M->steps[i].dist); fmtTime(t, sizeof(t), M->steps[i].dur);
  char num[8]; snprintf(num, sizeof(num), "%d. ", i + 1); char tmp[64]; snprintf(tmp, sizeof(tmp), "%s%s", num, a); snprintf(a, na, "%s", tmp);
  snprintf(b, nb, "%s  -  %s", d, t);
}
struct FavCtx { bool canAdd; };
void rowFav(void *u, int i, char *a, int na, char *b, int nb) {
  FavCtx *c = (FavCtx *)u; int k = i - (c->canAdd ? 1 : 0);
  if (k < 0) { snprintf(a, na, "+ Save current pin"); snprintf(b, nb, "%s", M->pname); return; }
  snprintf(a, na, "%s", M->fav[k].name); snprintf(b, nb, "%.4f, %.4f", M->fav[k].lat, M->fav[k].lon);
}
struct StrList { const char *const *items; };
void rowStr(void *u, int i, char *a, int na, char *b, int nb) { snprintf(a, na, "%s", ((const char *const *)u)[i]); b[0] = 0; (void)nb; }

// ============================================================================
//  actions
// ============================================================================
void zoomTo(Pt p, int z) { M->c = p; M->z = constrain(z, 2, 18); }

void fitBounds() {
  if (M->np < 2) return;
  int32_t x0 = M->pts[0].x, x1 = x0, y0 = M->pts[0].y, y1 = y0;
  for (int i = 1; i < M->np; ++i) { if (M->pts[i].x < x0) x0 = M->pts[i].x; if (M->pts[i].x > x1) x1 = M->pts[i].x; if (M->pts[i].y < y0) y0 = M->pts[i].y; if (M->pts[i].y > y1) y1 = M->pts[i].y; }
  Pt c; c.x = (int32_t)(((int64_t)x0 + x1) / 2); c.y = (int32_t)(((int64_t)y0 + y1) / 2);
  int z = 17;
  for (; z > 3; --z) { int sh = ZB - z; if (((x1 - x0) >> sh) <= VW - 50 && ((y1 - y0) >> sh) <= VH - 50) break; }
  zoomTo(c, z);
}

void setPin(double la, double lo, const char *name) {
  M->havePin = true; M->plat = la; M->plon = lo; strlcpy(M->pname, name, sizeof(M->pname));
  M->haveRoute = false; M->hl = -1;
}

void toastErr(const char *what) { char b[64]; snprintf(b, sizeof(b), "%s: %s", what, M->lastErr); ui::toast(b, C_ERR); }

void doSearch() {
  String q;
  if (!ui::textInput(q, "Search place or address", 60) || !q.length()) return;
  tft.fillRect(0, 100, 320, 40, C_BG); ui::centerText("Searching...", 160, 120, C_WARN, C_BG, 2);
  if (!geocode(q.c_str())) { toastErr("Search failed"); return; }
  if (M->nres == 0) { ui::toast("No results - try a bigger area name", C_WARN); return; }
  int i = pickList("RESULTS - tap one", M->nres, rowRes, nullptr, true);
  if (i < 0) return;
  setPin(M->res[i].lat, M->res[i].lon, M->res[i].name);
  zoomTo(ll2p(M->res[i].lat, M->res[i].lon), 15);
}

void doMyLoc() {
  if (!M->locKnown || !M->locManual) {                       // live position: ask the IP service again
    tft.fillRect(0, 100, 320, 40, C_BG); ui::centerText("Finding you (IP)...", 160, 120, C_WARN, C_BG, 2);
    if (!ipLocate()) { if (!M->locKnown) { toastErr("Locate failed"); return; } ui::toast("Offline - using last known spot", C_WARN); }
    else saveCfg();
  }
  zoomTo(ll2p(M->lat, M->lon), M->z < 12 ? 13 : M->z);
}

void doRoute() {
  if (!M->havePin) { ui::toast("Search or tap the map to pick a destination", C_WARN); return; }
  static const char *P[4] = {"BY CAR", "BY BIKE", "ON FOOT", "CANCEL"};
  int pf = pickList("ROUTE - how are you going?", 4, rowStr, (void *)P, true, M->prof);
  if (pf < 0 || pf > 2) return;
  M->prof = (uint8_t)pf;
  double la1, lo1;
  if (M->startCustom) { la1 = M->slat; lo1 = M->slon; }
  else {
    if (!M->locKnown) { tft.fillRect(0, 100, 320, 40, C_BG); ui::centerText("Finding you (IP)...", 160, 120, C_WARN, C_BG, 2); if (!ipLocate()) { toastErr("No start point"); return; } }
    la1 = M->lat; lo1 = M->lon;
  }
  tft.fillRect(0, 100, 320, 40, C_BG); ui::centerText("Finding route...", 160, 120, C_WARN, C_BG, 2);
  if (!routeFetch(M->prof, la1, lo1, M->plat, M->plon)) { toastErr("Route failed"); return; }
  fitBounds();
}

void doSteps() {
  if (!M->haveRoute) { ui::toast("No route yet - pick a place, then ROUTE", C_WARN); return; }
  char title[40], d[16], t[20]; fmtDist(d, sizeof(d), M->rdist); fmtTime(t, sizeof(t), M->rdur);
  snprintf(title, sizeof(title), "%s  %s", d, t);
  int i = pickList(title, M->ns, rowStep, nullptr, false, M->hl > 0 ? M->hl : 0);
  if (i >= 0) { M->hl = i; zoomTo(M->steps[i].p, 16); }
}

void doFavs() {
  FavCtx fc; fc.canAdd = M->havePin;
  int n = M->nfav + (fc.canAdd ? 1 : 0);
  if (n == 0) { ui::toast("No saved places. Pick a place, then SAVED", C_WARN); return; }
  int i = pickList("SAVED PLACES", n, rowFav, &fc, true);
  if (i < 0) return;
  if (fc.canAdd && i == 0) {
    if (M->nfav >= MAXFAV) { ui::toast("Saved list is full", C_WARN); return; }
    String nm = M->pname;
    if (!ui::textInput(nm, "Name this place", 24) || !nm.length()) return;
    Fav &f = M->fav[M->nfav++]; f.lat = M->plat; f.lon = M->plon; strlcpy(f.name, nm.c_str(), sizeof(f.name));
    saveFavs(); ui::toast("Saved", C_OK); return;
  }
  int k = i - (fc.canAdd ? 1 : 0);
  static const char *A[4] = {"GO TO IT", "ROUTE TO IT", "DELETE", "CANCEL"};
  int a = pickList(M->fav[k].name, 4, rowStr, (void *)A, true);
  if (a == 0 || a == 1) { setPin(M->fav[k].lat, M->fav[k].lon, M->fav[k].name); zoomTo(ll2p(M->fav[k].lat, M->fav[k].lon), 15); if (a == 1) doRoute(); }
  else if (a == 2) { for (int j = k; j < M->nfav - 1; ++j) M->fav[j] = M->fav[j + 1]; M->nfav--; saveFavs(); }
}

void doMenu(AppCtx &c) {
  (void)c;
  for (;;) {
    char l[9][36];
    snprintf(l[0], 36, "Mode: %s", M->online ? "ONLINE (cache to SD)" : "OFFLINE (SD tiles only)");
    snprintf(l[1], 36, "Style: %s", styleName());
    snprintf(l[2], 36, "Units: %s", M->units == 0 ? "AUTO" : M->units == 1 ? "KILOMETERS" : "MILES");
    snprintf(l[3], 36, "Refresh my location (IP)");
    snprintf(l[4], 36, "Set my location = map centre");
    snprintf(l[5], 36, "Start: %s", M->startCustom ? "MAP POINT (tap: ME)" : "MY LOCATION (tap: map)");
    snprintf(l[6], 36, "What is at the pin? (address)");
    snprintf(l[7], 36, "Clear pin and route");
    snprintf(l[8], 36, "About / tile folder");
    const char *items[9]; for (int i = 0; i < 9; ++i) items[i] = l[i];
    int i = pickList("MENU", 9, rowStr, (void *)items, true);
    if (i < 0) return;
    if (i == 0) { M->online = !M->online; M->netFail = false; saveCfg(); }
    else if (i == 1) {
      bool hasCustom = strcmp(M->tile, DEF_TILE) != 0 || M->style == 3;
      M->style = (uint8_t)((M->style + 1) % (hasCustom ? 4 : 3)); M->netFail = false; memset(M->failKey, 0, sizeof(M->failKey)); saveCfg(); return;
    }
    else if (i == 2) { M->units = (M->units + 1) % 3; applyUnits(); saveCfg(); }
    else if (i == 3) { tft.fillRect(0, 100, 320, 40, C_BG); ui::centerText("Finding you (IP)...", 160, 120, C_WARN, C_BG, 2); if (ipLocate()) { saveCfg(); zoomTo(ll2p(M->lat, M->lon), 13); return; } toastErr("Locate failed"); }
    else if (i == 4) { double la, lo; p2ll(M->c, la, lo); M->lat = la; M->lon = lo; M->locKnown = true; M->locManual = true; strcpy(M->locName, "set by you"); saveCfg(); ui::toast("My location set", C_OK); return; }
    else if (i == 5) {
      if (M->startCustom) M->startCustom = false; else { double la, lo; p2ll(M->c, la, lo); M->startCustom = true; M->slat = la; M->slon = lo; }
      ui::toast(M->startCustom ? "Route start = this map point" : "Route start = my location", C_OK); return;
    }
    else if (i == 6) {
      if (!M->havePin) { ui::toast("Drop a pin first (tap the map)", C_WARN); continue; }
      tft.fillRect(0, 100, 320, 40, C_BG); ui::centerText("Looking up...", 160, 120, C_WARN, C_BG, 2);
      char nm[40]; if (revGeocode(M->plat, M->plon, nm, sizeof(nm))) { strlcpy(M->pname, nm, sizeof(M->pname)); ui::msgBox("PIN", nm); return; }
      toastErr("Lookup failed");
    }
    else if (i == 7) { M->havePin = false; M->haveRoute = false; M->hl = -1; M->startCustom = false; return; }
    else if (i == 8) {
      ui::msgBox("MAPS", "Map data (c) OpenStreetMap contributors; CARTO styles (c) CARTO. Tiles are cached per style in /maps/tiles/<style>/z/x/y.png on the SD card - copy tiles there (or run tools/maps_fetch.py) for offline use. IP location is city-level only.");
    }
  }
}

}  // namespace

// ============================================================================
void app_maps(AppCtx &c) {
  if (!sys::sdOk) { ui::msgBox("MAPS", "An SD card is needed for map tiles."); return; }
  M = (MS *)sys::bigAlloc(sizeof(MS));
  if (!M) { ui::msgBox("MAPS", "Not enough RAM"); return; }
  memset(M, 0, sizeof(MS));
  loadCfg(); loadFavs();
  M->hl = -1; strcpy(M->pname, "Dropped pin");
  c.header("OpenStreetMap");
  ui::clearBody(C_BG);
  drawBar();
  bool first = true;

  enum { GN_NONE, GN_MAP, GN_BAR };
  int gest = GN_NONE; bool moved = false; bool need = true; int lastx = 0, lasty = 0;
  uint32_t lastPan = 0;

  for (;;) {
    if (need) {
      if (first && M->online && !M->locManual) { first = false; renderMap("Locating you..."); bool had = M->locKnown; if (ipLocate()) { saveCfg(); if (!had) zoomTo(ll2p(M->lat, M->lon), 13); } }
      first = false;
      renderMap(); drawBar(); need = false;
    }
    Touch &t = ui::poll(); delay(5);
    if (ui::exitHit(t)) { c.exitReq = true; audio::click(); break; }
    bool relayout = false;

    if (t.pressed) {
      moved = false; lastx = t.x; lasty = t.y;
      if (t.y >= BAR_Y - 2 && t.y < 240) {
        gest = GN_BAR;
        int b = (t.x - 2) / 53; if (b > 5) b = 5;
        audio::click();
        switch (b) {
          case 0: doSearch(); break;
          case 1: doRoute(); break;
          case 2: doSteps(); break;
          case 3: doFavs(); break;
          case 4: doMyLoc(); break;
          default: doMenu(c); break;
        }
        relayout = true;
      } else if (t.y >= VY && t.y < VY + VH) {
        gest = GN_MAP;
        if (ui::inRect(t.x, t.y, VX + VW - 32, VY + 4, 30, 28)) { if (M->z < 18) { M->z++; need = true; } gest = GN_NONE; }
        else if (ui::inRect(t.x, t.y, VX + VW - 32, VY + 32, 30, 28)) { if (M->z > 2) { M->z--; need = true; } gest = GN_NONE; }
      } else gest = GN_NONE;
    }
    if (t.down && gest == GN_MAP) {
      if (!moved && (abs(t.x - t.sx) > 8 || abs(t.y - t.sy) > 8)) moved = true;
      if (moved) {
        int sh = ZB - M->z;
        int64_t nx = (int64_t)M->c.x - (int64_t)(t.x - lastx) * (1LL << sh), ny = (int64_t)M->c.y - (int64_t)(t.y - lasty) * (1LL << sh);
        M->c.x = (int32_t)clampd((double)nx, 0, WORLD - 1); M->c.y = (int32_t)clampd((double)ny, 0, WORLD - 1);
        lastPan = millis();
      }
      lastx = t.x; lasty = t.y;
    }
    if (t.released) {
      if (gest == GN_MAP) {
        if (moved) need = true;
        else {                                                  // tap: drop a destination pin
          int sh = ZB - M->z; int cpx = M->c.x >> sh, cpy = M->c.y >> sh;
          Pt p; p.x = (int32_t)clampd((double)(cpx + (t.sx - VX - VW / 2)) * (double)(1LL << sh), 0, WORLD - 1); p.y = (int32_t)clampd((double)(cpy + (t.sy - VY - VH / 2)) * (double)(1LL << sh), 0, WORLD - 1);
          double la, lo; p2ll(p, la, lo);
          bool onChip = t.sy >= VY + VH - 13;
          if (!onChip) { setPin(la, lo, "Dropped pin"); need = true; }
        }
      }
      gest = GN_NONE;
    }
    ui::clearEvents();
    if (relayout) { ui::clearBody(C_BG); drawBar(); need = true; }
    (void)lastPan;
  }
  saveCfg();
  free(M); M = nullptr;
  ui::clearEvents();
}
