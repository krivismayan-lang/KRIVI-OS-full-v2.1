// ============================================================================
//  KRIVI OS - Robot Face  ("Buddy")                                 app 88
//
//  A cute desk companion: two glowing cyan rounded-rectangle eyes that blink,
//  glance around on their own, and react when you tap. No mic or speaker needed
//  - it lives on the screen, touch, and the RGB LED. Goes sleepy at night.
//
//  Eyes are drawn into one small sprite and pushed to each socket, so the
//  animation is flicker-free and costs little RAM.
// ============================================================================
#include "apps_common.h"

namespace {

enum Mood { NEUTRAL, HAPPY, SURPRISED, SLEEPY, LOVE };

const uint16_t EYE   = RGB565(70, 185, 255);
const uint16_t GLINT = RGB565(170, 225, 255);
const uint16_t BG    = RGB565(8, 12, 24);

const int CELLW = 108, CELLH = 150;            // eye sprite cell
const int EYEX  = 46;                           // half-distance between eyes
const int CX = 160, CY = 120;                   // face centre

// draw one eye into the sprite (its own dark background included)
void drawEye(TFT_eSprite &s, Mood m, int lx, int ly, float blink) {
  s.fillSprite(BG);
  int ex = CELLW / 2 + lx, ey = CELLH / 2 + ly;
  int w = 72, h = 112, r = 34;
  if (m == SLEEPY) { ey += 12; }
  if (m == SURPRISED) { w = 84; h = 124; r = 40; }

  if (m == LOVE) {                              // heart eyes
    int hw = 40, hh = 36; uint16_t col = RGB565(255, 90, 140);
    s.fillCircle(ex - hw / 4, ey - hh / 6, hw / 4, col);
    s.fillCircle(ex + hw / 4, ey - hh / 6, hw / 4, col);
    s.fillTriangle(ex - hw / 2, ey - hh / 12, ex + hw / 2, ey - hh / 12, ex, ey + hh / 2, col);
    return;
  }

  int hh = h;
  if (blink > 0) hh = max(6, (int)(h * (1.0f - blink)));
  int rr = min(r, hh / 2);
  s.fillRoundRect(ex - w / 2, ey - hh / 2, w, hh, rr, EYE);
  if (hh > 34) s.fillRoundRect(ex - w / 2 + 9, ey - hh / 2 + 11, w / 2, hh / 4, w / 6, GLINT);  // glint

  if (blink < 0.3f) {
    if (m == HAPPY)  s.fillRoundRect(ex - w / 2 - 3, ey - hh / 2 - (int)(hh * 0.45f), w + 6, hh, r, BG);  // carve a ‿ smile
    if (m == SLEEPY) s.fillRect(ex - w / 2 - 3, ey - hh / 2 - 3, w + 6, (int)(hh * 0.42f), BG);           // droopy lid
  }
}

void ledMood(Mood m) {
  switch (m) {
    case HAPPY:     sys::led(0, 150, 200); break;
    case SURPRISED: sys::led(120, 140, 170); break;
    case SLEEPY:    sys::led(0, 8, 22); break;
    case LOVE:      sys::led(200, 40, 90); break;
    default:        sys::led(0, 45, 90); break;
  }
}

}  // namespace

void app_robot(AppCtx &c) {
  TFT_eSprite eye(&tft); eye.setColorDepth(8);
  bool spr = eye.createSprite(CELLW, CELLH);
  if (!spr) { ui::msgBox("ROBOT FACE", "Not enough RAM"); return; }

  ui::clearBody(BG);
  tft.fillRect(0, 26, 320, 214, BG);

  int hr = 12; struct tm tmv; if (sys::now(tmv)) hr = tmv.tm_hour;
  bool night = hr >= 22 || hr < 7;

  Mood mood = night ? SLEEPY : NEUTRAL;
  float lx = 0, ly = 0, tlx = 0, tly = 0;         // current / target look offset
  float blink = 0; bool blinking = false;
  uint32_t nextBlink = millis() + 2000, nextGlance = millis() + 1500, moodUntil = 0, zT = 0;
  int pets = 0; uint32_t lastPet = 0;
  ledMood(mood);

  auto drawFace = [&]() {
    int ilx = (int)lx, ily = (int)ly;
    drawEye(eye, mood, ilx, ily, blink); eye.pushSprite(CX - EYEX - CELLW / 2, CY - CELLH / 2);
    drawEye(eye, mood, ilx, ily, blink); eye.pushSprite(CX + EYEX - CELLW / 2, CY - CELLH / 2);
  };

  auto zzz = [&]() {                              // floating "z" when sleepy
    static int zy = 0;
    tft.fillRect(236, 40, 60, 46, BG);
    if (mood == SLEEPY) {
      int yy = 80 - (millis() / 40 % 46);
      tft.setTextColor(RGB565(90, 150, 210), BG);
      tft.drawString("z", 250, yy + 14, 2); tft.drawString("Z", 262, yy - 4, 4);
    }
  };

  drawFace();
  tft.setTextColor(RGB565(60, 70, 95), BG); tft.setTextDatum(BC_DATUM);
  tft.drawString("tap me", 160, 236, 1); tft.setTextDatum(TL_DATUM);

  while (c.frame(33)) {
    Touch &t = *c.t;
    uint32_t now = millis();

    // --- tap reaction: look toward the tap, get happy / love
    if (t.tap && t.sy > 30 && t.sy < 210) {
      tlx = constrain((t.x - CX) / 6.0f, -12.0f, 12.0f);
      tly = constrain((t.y - CY) / 8.0f, -10.0f, 10.0f);
      if (now - lastPet < 1500) pets++; else pets = 1;
      lastPet = now;
      mood = (pets >= 3) ? LOVE : HAPPY;
      moodUntil = now + (mood == LOVE ? 1800 : 1200);
      ledMood(mood);
      audio::tone(0, mood == LOVE ? 1200 : 900, 60, audio::SINE, 120, 120);
      nextBlink = now + 900;
    }

    // --- expire temporary mood
    if (moodUntil && now > moodUntil) { moodUntil = 0; mood = night ? SLEEPY : NEUTRAL; ledMood(mood); pets = 0; }

    // --- idle glances (not while sleepy)
    if (now > nextGlance && mood != SLEEPY && !moodUntil) {
      nextGlance = now + 1200 + rnd(2600);
      if (rnd(3) == 0) { tlx = 0; tly = 0; }
      else { tlx = (rnd(25) - 12); tly = (rnd(16) - 8); }
    }
    // ease look toward target
    lx += (tlx - lx) * 0.25f; ly += (tly - ly) * 0.25f;

    // --- blinking
    if (!blinking && now > nextBlink) { blinking = true; }
    if (blinking) {
      blink += 0.22f;
      if (blink >= 1.0f) { blink = 1.0f; }
      if (blink >= 1.0f) { blinking = false; nextBlink = now + (mood == SLEEPY ? 1500 : 2200) + rnd(2800); }
    } else if (blink > 0) blink -= 0.22f;
    if (blink < 0) blink = 0;
    // a sleepy face keeps eyes half-closed
    float drawBlink = blink;
    if (mood == SLEEPY && !blinking && blink < 0.35f) drawBlink = 0.35f;

    // render
    int ilx = (int)lx, ily = (int)ly;
    drawEye(eye, mood, ilx, ily, drawBlink); eye.pushSprite(CX - EYEX - CELLW / 2, CY - CELLH / 2);
    drawEye(eye, mood, ilx, ily, drawBlink); eye.pushSprite(CX + EYEX - CELLW / 2, CY - CELLH / 2);
    zzz();
  }
  sys::led(0, 0, 0);
  eye.deleteSprite();
}
