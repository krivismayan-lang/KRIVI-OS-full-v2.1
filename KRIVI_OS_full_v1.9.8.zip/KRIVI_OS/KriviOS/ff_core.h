// ============================================================================
//  KRIVI OS - FrogFind core (portable C++, no Arduino dependencies)
//
//  Everything the FrogFind browser needs that isn't drawing or networking:
//    * portrait <-> landscape touch mapping
//    * URL building / resolving for frogfind.com
//    * a small streaming HTML tokenizer (UTF-8 + entities -> plain ASCII)
//    * word-wrap layout into compact "segments" for a 240 px wide screen
//    * the phone-style keyboard layout (letters / 123 / #+= layers)
//
//  Kept free of Arduino types so it can be unit-tested on a PC
//  (tools/frogfind_test/).
// ============================================================================
#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cctype>

namespace ffc {

// ---------------------------------------------------------------- rotation
// TFT_eSPI / ILI9341 rotations: 0,2 portrait (240x320), 1,3 landscape (320x240).
// "raw" = rotation-0 coordinates. Rotation 1 is rotation 0 with rows/columns
// swapped (MADCTL MV); rotation 3 is rotation 1 turned 180 degrees.
inline void toRaw(int rot, int x, int y, int &rx, int &ry) {
  switch (rot & 3) {
    case 0:  rx = x;       ry = y;       break;
    case 1:  rx = 239 - y; ry = x;       break;
    case 2:  rx = 239 - x; ry = 319 - y; break;
    default: rx = y;       ry = 319 - x; break;
  }
}
inline void fromRaw(int rot, int rx, int ry, int &x, int &y) {
  switch (rot & 3) {
    case 0:  x = rx;       y = ry;       break;
    case 1:  x = ry;       y = 239 - rx; break;
    case 2:  x = 239 - rx; y = 319 - ry; break;
    default: x = 319 - ry; y = rx;       break;
  }
}
inline void mapPoint(int fromRot, int toRot, int x, int y, int &ox, int &oy) {
  int rx, ry; toRaw(fromRot, x, y, rx, ry); fromRaw(toRot, rx, ry, ox, oy);
}
// portrait rotation that goes with the current landscape one (flip = 180 deg)
inline int portraitFor(int landRot, bool flip) {
  int p = (landRot + 3) & 3;               // 1 -> 0, 3 -> 2
  return flip ? (p + 2) & 3 : p;
}

// ---------------------------------------------------------------- text
inline bool startsNoCase(const std::string &s, const char *p) {
  size_t n = strlen(p);
  if (s.size() < n) return false;
  for (size_t i = 0; i < n; ++i) if (tolower((unsigned char)s[i]) != tolower((unsigned char)p[i])) return false;
  return true;
}
inline std::string lower(std::string s) { for (auto &c : s) c = (char)tolower((unsigned char)c); return s; }
inline std::string trim(const std::string &s) {
  size_t a = 0, b = s.size();
  while (a < b && isspace((unsigned char)s[a])) ++a;
  while (b > a && isspace((unsigned char)s[b - 1])) --b;
  return s.substr(a, b - a);
}

// Unicode code point -> plain ASCII the CYD's built-in font can draw.
inline void asciiFor(uint32_t cp, std::string &out) {
  if (cp < 0x80) { if (cp >= 32 || cp == '\n' || cp == '\t') out += (char)cp; return; }
  if (cp >= 0xC0 && cp <= 0xFF) {
    static const char *L[64] = {
      "A","A","A","A","A","A","AE","C","E","E","E","E","I","I","I","I",
      "D","N","O","O","O","O","O","x","O","U","U","U","U","Y","Th","ss",
      "a","a","a","a","a","a","ae","c","e","e","e","e","i","i","i","i",
      "d","n","o","o","o","o","o","/","o","u","u","u","u","y","th","y"};
    out += L[cp - 0xC0]; return;
  }
  switch (cp) {
    case 0xA0: out += ' '; return;
    case 0xA2: out += 'c'; return;
    case 0xA3: out += "GBP"; return;
    case 0xA5: out += "JPY"; return;
    case 0xA7: out += "S."; return;
    case 0xA9: out += "(c)"; return;
    case 0xAB: case 0xBB: out += '"'; return;
    case 0xAD: return;                                   // soft hyphen
    case 0xAE: out += "(R)"; return;
    case 0xB0: out += '`'; return;                        // font 2 draws ` as a degree sign
    case 0xB1: out += "+/-"; return;
    case 0xB2: out += '2'; return;
    case 0xB3: out += '3'; return;
    case 0xB5: out += 'u'; return;
    case 0xB6: out += "P."; return;
    case 0xB7: out += '*'; return;
    case 0xB9: out += '1'; return;
    case 0xBC: out += "1/4"; return;
    case 0xBD: out += "1/2"; return;
    case 0xBE: out += "3/4"; return;
    case 0xBF: out += '?'; return;
    case 0xA1: out += '!'; return;
    case 0x2010: case 0x2011: case 0x2012: case 0x2013: case 0x2014: case 0x2015: case 0x2212: out += '-'; return;
    case 0x2018: case 0x2019: case 0x201A: case 0x201B: case 0x2032: out += '\''; return;
    case 0x201C: case 0x201D: case 0x201E: case 0x201F: case 0x2033: out += '"'; return;
    case 0x2022: case 0x2023: case 0x2043: case 0x25CF: case 0x25AA: out += '*'; return;
    case 0x2026: out += "..."; return;
    case 0x20AC: out += "EUR"; return;
    case 0x2122: out += "(TM)"; return;
    case 0x2190: out += "<-"; return;
    case 0x2192: out += "->"; return;
    case 0x2191: out += '^'; return;
    case 0x2193: out += 'v'; return;
    case 0x2264: out += "<="; return;
    case 0x2265: out += ">="; return;
    case 0x2260: out += "!="; return;
    case 0x00D7: out += 'x'; return;
    case 0x2009: case 0x200A: case 0x2002: case 0x2003: case 0x202F: case 0x3000: out += ' '; return;
    case 0x200B: case 0x200C: case 0x200D: case 0x2060: case 0xFEFF: case 0x200E: case 0x200F: return;
  }
  if (cp >= 0xFE00 && cp <= 0xFE0F) return;              // variation selectors
  if (cp >= 0x1F000) return;                             // emoji: drop quietly
  if (cp >= 0x2600 && cp <= 0x27BF) return;              // dingbats / symbols
  out += '?';
}

// &name; / &#123; / &#x7B;  -> code point, or -1 if unknown
inline long entityCp(const std::string &e) {
  if (e.empty()) return -1;
  if (e[0] == '#') {
    long v = (e.size() > 1 && (e[1] == 'x' || e[1] == 'X')) ? strtol(e.c_str() + 2, nullptr, 16)
                                                         : strtol(e.c_str() + 1, nullptr, 10);
    return v > 0 && v < 0x110000 ? v : -1;
  }
  static const struct { const char *n; long cp; } T[] = {
    {"amp",38},{"lt",60},{"gt",62},{"quot",34},{"apos",39},{"nbsp",160},{"copy",169},
    {"reg",174},{"trade",8482},{"mdash",8212},{"ndash",8211},{"hellip",8230},{"lsquo",8216},
    {"rsquo",8217},{"sbquo",8218},{"ldquo",8220},{"rdquo",8221},{"bdquo",8222},{"laquo",171},
    {"raquo",187},{"bull",8226},{"middot",183},{"times",215},{"divide",247},{"deg",176},
    {"euro",8364},{"pound",163},{"yen",165},{"cent",162},{"sect",167},{"para",182},
    {"frac12",189},{"frac14",188},{"frac34",190},{"plusmn",177},{"micro",181},{"iexcl",161},
    {"iquest",191},{"shy",173},{"ensp",8194},{"emsp",8195},{"thinsp",8201},{"zwj",8205},
    {"zwnj",8204},{"larr",8592},{"rarr",8594},{"uarr",8593},{"darr",8595},{"le",8804},
    {"ge",8805},{"ne",8800},{"minus",8722},{"prime",8242},{"Prime",8243},{"szlig",223},
    {"aelig",230},{"AElig",198},{"oslash",248},{"Oslash",216},{"thorn",254},{"THORN",222},
    {"eth",240},{"ETH",208},{"sup2",178},{"sup3",179},{"sup1",185},
  };
  for (auto &t : T) if (e == t.n) return t.cp;
  // eacute, Ntilde, ouml, Aring, ccedil ... -> the plain letter
  static const char *SUF[] = {"acute","grave","circ","uml","tilde","ring","cedil","slash","caron"};
  for (auto s : SUF) {
    size_t n = strlen(s);
    if (e.size() == n + 1 && e.compare(1, n, s) == 0 && isalpha((unsigned char)e[0])) return (unsigned char)e[0];
  }
  return -1;
}

inline std::string decodeEntities(const std::string &s) {
  std::string o; o.reserve(s.size());
  for (size_t i = 0; i < s.size(); ++i) {
    if (s[i] == '&') {
      size_t j = s.find(';', i + 1);
      if (j != std::string::npos && j - i <= 10) {
        long cp = entityCp(s.substr(i + 1, j - i - 1));
        if (cp >= 0) {                     // keep exact characters inside URLs
          if (cp < 0x80) o += (char)cp; else asciiFor((uint32_t)cp, o);
          i = j; continue;
        }
      }
    }
    o += s[i];
  }
  return o;
}

// ---------------------------------------------------------------- URLs
static const char *const FF_HOST = "http://frogfind.com";

inline std::string urlEncode(const std::string &s, bool spacePlus) {
  static const char *H = "0123456789ABCDEF";
  std::string o; o.reserve(s.size() * 3);
  for (unsigned char c : s) {
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
    else if (c == ' ' && spacePlus) o += '+';
    else { o += '%'; o += H[c >> 4]; o += H[c & 15]; }
  }
  return o;
}
inline std::string urlDecode(const std::string &s) {
  std::string o; o.reserve(s.size());
  for (size_t i = 0; i < s.size(); ++i) {
    if (s[i] == '+') o += ' ';
    else if (s[i] == '%' && i + 2 < s.size() && isxdigit((unsigned char)s[i + 1]) && isxdigit((unsigned char)s[i + 2])) {
      o += (char)strtol(s.substr(i + 1, 2).c_str(), nullptr, 16); i += 2;
    } else o += s[i];
  }
  return o;
}
inline bool hasHttp(const std::string &u) { return startsNoCase(u, "http://") || startsNoCase(u, "https://"); }
inline bool isFrogFind(const std::string &u) {
  return startsNoCase(u, "http://frogfind.com") || startsNoCase(u, "https://frogfind.com") ||
         startsNoCase(u, "http://www.frogfind.com") || startsNoCase(u, "https://www.frogfind.com");
}
// FrogFind is served over plain http (cheap for the ESP32: no TLS)
inline std::string normalizeFF(const std::string &u) {
  size_t p = u.find("frogfind.com");
  if (p == std::string::npos) return u;
  return std::string(FF_HOST) + u.substr(p + 12);
}
inline std::string searchUrl(const std::string &q) { return std::string(FF_HOST) + "/?q=" + urlEncode(trim(q), true); }
inline std::string readUrl(const std::string &target) { return std::string(FF_HOST) + "/read.php?a=" + urlEncode(target, false); }

// "google.com", "en.wikipedia.org/wiki/x", "http://x.y" -> true;  "esp32 pinout" -> false
inline bool looksLikeUrl(const std::string &raw) {
  std::string s = trim(raw);
  if (s.empty() || s.find(' ') != std::string::npos) return false;
  if (hasHttp(s)) return true;
  if (startsNoCase(s, "www.")) return true;
  size_t slash = s.find('/');
  std::string host = s.substr(0, slash);
  size_t colon = host.find(':'); if (colon != std::string::npos) host = host.substr(0, colon);
  size_t dot = host.rfind('.');
  if (dot == std::string::npos || dot == 0 || dot + 1 >= host.size()) return false;
  std::string tld = host.substr(dot + 1);
  if (tld.size() < 2 || tld.size() > 6) return false;
  for (char c : tld) if (!isalpha((unsigned char)c)) return false;
  return true;
}
// what the user typed in the address bar -> URL to fetch
inline std::string fromTyped(const std::string &raw) {
  std::string s = trim(raw);
  if (s.empty()) return "";
  if (looksLikeUrl(s)) {
    if (!hasHttp(s)) s = "http://" + s;
    if (isFrogFind(s)) return normalizeFF(s);
    return readUrl(s);
  }
  return searchUrl(s);
}
inline std::string origin(const std::string &u) {
  size_t p = u.find("://");
  if (p == std::string::npos) return FF_HOST;
  size_t e = u.find('/', p + 3);
  return e == std::string::npos ? u : u.substr(0, e);
}
inline std::string stripFragment(std::string u) { size_t h = u.find('#'); if (h != std::string::npos) u.erase(h); return u; }
inline std::string spacesTo20(const std::string &u) {
  std::string o; for (char c : u) { if (c == ' ') o += "%20"; else if (c != '\r' && c != '\n' && c != '\t') o += c; } return o;
}
// link href (already entity-decoded) on page `base` -> URL to fetch, "" if not navigable
inline std::string resolve(const std::string &base, const std::string &hrefIn) {
  std::string h = trim(hrefIn);
  if (h.empty() || h[0] == '#') return "";
  if (startsNoCase(h, "javascript:") || startsNoCase(h, "mailto:") || startsNoCase(h, "tel:") ||
      startsNoCase(h, "data:") || startsNoCase(h, "ftp:") || startsNoCase(h, "file:")) return "";
  if (h.compare(0, 2, "//") == 0) h = "http:" + h;
  // a scheme is letters before the first ':' that comes before any / ? #
  size_t colon = h.find(':'), stop = h.find_first_of("/?#");
  bool scheme = colon != std::string::npos && colon > 0 && (stop == std::string::npos || colon < stop);
  for (size_t i = 0; scheme && i < colon; ++i) if (!isalpha((unsigned char)h[i]) && h[i] != '+' && h[i] != '-' && h[i] != '.') scheme = false;
  std::string out;
  if (hasHttp(h)) out = isFrogFind(h) ? normalizeFF(h) : readUrl(stripFragment(h));
  else if (scheme) return "";                                         // ftp:, ws:, intent: ...
  else if (h[0] == '/') out = origin(base) + h;
  else if (h[0] == '?') { std::string b = base.substr(0, base.find('?')); out = b + h; }
  else {
    std::string b = base.substr(0, base.find('?'));
    b = stripFragment(b);
    size_t sl = b.rfind('/');
    size_t hostEnd = b.find("://"); hostEnd = hostEnd == std::string::npos ? 0 : hostEnd + 3;
    if (sl == std::string::npos || sl < hostEnd) b += "/";
    else b = b.substr(0, sl + 1);
    out = b + h;
  }
  out = spacesTo20(stripFragment(out));
  // FrogFind's image viewer page wraps the real JPEG: go straight to the JPEG
  size_t ip = out.find("/image.php?i=");
  if (ip != std::string::npos) out.replace(ip, 13, "/image_compressed.php?i=");
  return out;
}
inline bool isImageUrl(const std::string &u) { return u.find("/image_compressed.php?i=") != std::string::npos; }
// shown in the address bar: the search words or the page being read
inline std::string displayAddress(const std::string &u) {
  size_t p;
  if ((p = u.find("/read.php?a=")) != std::string::npos) {
    std::string t = u.substr(p + 12);
    size_t amp = t.find("&rut="); if (amp != std::string::npos) t.erase(amp);
    return (startsNoCase(t, "http%3a") || startsNoCase(t, "https%3a")) ? urlDecode(t) : t;
  }
  if ((p = u.find("/?q=")) != std::string::npos) return urlDecode(u.substr(p + 4));
  if ((p = u.find("/image_compressed.php?i=")) != std::string::npos) return u.substr(p + 24);
  return u;
}

// ---------------------------------------------------------------- document
enum : uint8_t { F_LINK = 1, F_BOLD = 2, F_HEAD = 4, F_GREEN = 8, F_HR = 16, F_RED = 32, F_ITAL = 64, F_PRE = 128 };

#pragma pack(push, 1)
struct Seg {
  uint16_t line;     // layout line
  uint8_t  x;        // pixel x within the 240 px screen
  uint8_t  flags;    // F_*
  int16_t  link;     // index into Doc::links, -1 none
  uint16_t off;      // into Doc::pool
  uint8_t  len;
};
#pragma pack(pop)

struct Doc {
  char    *pool = nullptr;       // text of all segments (not 0-terminated)
  uint32_t poolCap = 0, poolUsed = 0;
  std::vector<Seg> segs;
  uint32_t segCap = 0;
  std::vector<uint16_t> lineStart;   // first seg of each line, size = lines + 1
  std::vector<std::string> links;
  uint32_t linkBytes = 0, linkByteCap = 0, linkCountCap = 0;
  uint16_t lines = 0;
  bool full = false;               // hit a cap: the rest of the page is a "next part"
  std::string title;
  void reset() {
    poolUsed = 0; segs.clear(); lineStart.clear(); links.clear(); linkBytes = 0;
    lines = 0; full = false; title.clear();
  }
  int segsOnLine(int l, int &first) const {
    if (l < 0 || l >= lines) { first = 0; return 0; }
    first = lineStart[l]; return lineStart[l + 1] - lineStart[l];
  }
};

// Width of `n` chars of `s` in pixels (font 2 on the device).
typedef int (*WidthFn)(const char *s, int n, void *user);

class Layout {
 public:
  Layout(Doc &d, int left, int right, WidthFn w, void *u)
      : D(d), L(left), R(right), wf(w), wu(u) { x = L; lineLeft = L; }
  bool plain = false;              // text/plain: keep newlines
  bool full() const { return D.full; }

  void text(const char *s, size_t n) {
    if (D.full || formDepth) return;
    for (size_t i = 0; i < n; ++i) {
      char c = s[i];
      if (c == '\n' && (plain || preDepth)) { flushWord(); breakLine(); continue; }
      if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
        if (preDepth && c == ' ') { flushWord(); pendingSpace = true; continue; }
        flushWord(); pendingSpace = true; continue;
      }
      word += c;
      if (word.size() >= 200) flushWord();
    }
  }

  void tagOpen(const std::string &name, const std::string &href, const std::string &color) {
    if (D.full) return;
    if (name == "form") { flushWord(); formDepth++; return; }
    if (formDepth) return;
    if (name == "br") { flushWord(); breakLine(); return; }
    if (isPara(name)) { flushWord(); paraBreak(); }
    else if (isBlock(name)) { flushWord(); blockBreak(); }
    if (name == "hr") { flushWord(); paraBreak(); hr(); paraBreak(); return; }
    if (name[0] == 'h' && name.size() == 2 && name[1] >= '1' && name[1] <= '6') { flushWord(); head++; }
    else if (name == "b" || name == "strong") { flushWord(); bold++; }
    else if (name == "i" || name == "em") { flushWord(); ital++; }
    else if (name == "pre") { preDepth++; }
    else if (name == "a") {
      flushWord();
      link = -1;
      if (!href.empty() && D.links.size() < D.linkCountCap && D.linkBytes + href.size() < D.linkByteCap) {
        D.links.push_back(href); D.linkBytes += (uint32_t)href.size();
        link = (int16_t)(D.links.size() - 1);
      }
    }
    else if (name == "font") {
      flushWord();
      if (fontTop < 15) fontStack[++fontTop] = colorFlag(color);
    }
    else if (name == "ul" || name == "ol" || name == "blockquote") { if (indentLevel < 4) indentLevel++; setIndent(); }
    else if (name == "li") { liPrefix(); }
  }

  void tagClose(const std::string &name) {
    if (D.full) return;
    if (name == "form") { flushWord(); if (formDepth) formDepth--; return; }
    if (formDepth) return;
    flushWord();
    if (name[0] == 'h' && name.size() == 2 && name[1] >= '1' && name[1] <= '6') { if (head) head--; }
    else if (name == "b" || name == "strong") { if (bold) bold--; }
    else if (name == "i" || name == "em") { if (ital) ital--; }
    else if (name == "pre") { if (preDepth) preDepth--; }
    else if (name == "a") { link = -1; }
    else if (name == "font") { if (fontTop > 0) fontTop--; }
    else if (name == "ul" || name == "ol" || name == "blockquote") { blockBreak(); if (indentLevel) indentLevel--; setIndent(); }
    if (isPara(name)) paraBreak();
    else if (isBlock(name)) blockBreak();
  }

  void finish() {
    flushWord();
    if (x > lineLeft) breakLine();
    // drop trailing blank lines
    int last = -1;
    for (auto &s : D.segs) if (s.line > last) last = s.line;
    D.lines = (uint16_t)(last + 1);
    D.lineStart.assign(D.lines + 1, 0);
    size_t si = 0;
    for (int l = 0; l <= D.lines; ++l) {
      while (si < D.segs.size() && D.segs[si].line < l) ++si;
      D.lineStart[l] = (uint16_t)si;
    }
  }

 private:
  Doc &D; int L, R; WidthFn wf; void *wu;
  int x, line = 0, lineLeft = 0;
  bool pendingSpace = false, lineBlank = true, prevBlank = true;
  std::string word;
  int bold = 0, ital = 0, head = 0, preDepth = 0, formDepth = 0, indentLevel = 0;
  int16_t link = -1, spaceLink = -1;
  uint8_t fontStack[16] = {0}; int fontTop = 0;
  int indent = 0, hang = 0;

  static bool isPara(const std::string &n) {
    return n == "p" || n == "ul" || n == "ol" || n == "blockquote" || n == "table" || n == "pre" ||
           (n.size() == 2 && n[0] == 'h' && n[1] >= '1' && n[1] <= '6');
  }
  static bool isBlock(const std::string &n) {
    return n == "div" || n == "li" || n == "tr" || n == "dt" || n == "dd" || n == "dl" || n == "center" ||
           n == "section" || n == "article" || n == "header" || n == "footer" || n == "nav" || n == "main" ||
           n == "figure" || n == "figcaption" || n == "address" || n == "aside" || n == "caption";
  }
  static uint8_t colorFlag(const std::string &c) {
    std::string s = lower(trim(c));
    if (s == "green" || s == "darkgreen" || s == "lime") return F_GREEN;
    if (s == "red" || s == "darkred" || s == "crimson") return F_RED;
    if (s.size() >= 6) {
      size_t p = s[0] == '#' ? 1 : 0;
      if (s.size() - p >= 6) {
        long v = strtol(s.substr(p, 6).c_str(), nullptr, 16);
        int r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255;
        if (g > 90 && g > r + 40 && g > b + 40) return F_GREEN;
        if (r > 140 && r > g + 60 && r > b + 60) return F_RED;
      }
    }
    return 0;                                  // other colours: default text (dark ones are unreadable)
  }
  uint8_t flags() const {
    uint8_t f = fontStack[fontTop];
    if (link >= 0) f |= F_LINK;
    if (bold) f |= F_BOLD;
    if (head) f |= F_HEAD;
    if (ital) f |= F_ITAL;
    if (preDepth) f |= F_PRE;
    return f;
  }
  void setIndent() { indent = indentLevel * 12; if (indent > 48) indent = 48; if (lineBlank) { lineLeft = L + indent; x = lineLeft; } }
  int width(const char *s, int n) { return wf(s, n, wu); }

  bool room(size_t n) {
    if (D.poolUsed + n > D.poolCap || D.segs.size() + 1 > D.segCap || line >= 65000) { D.full = true; return false; }
    return true;
  }
  // put text at (x, line) - merges with the previous segment when possible
  void emit(const char *s, int n, int w, uint8_t f) {
    if (n <= 0 || !room(n)) return;
    if (!D.segs.empty()) {
      Seg &p = D.segs.back();
      if (p.line == line && p.flags == f && p.link == link && p.off + p.len == D.poolUsed && p.len + n <= 255 &&
          p.x + width(D.pool + p.off, p.len) == x) {
        memcpy(D.pool + D.poolUsed, s, n); D.poolUsed += n; p.len = (uint8_t)(p.len + n);
        x += w; lineBlank = false; return;
      }
    }
    Seg g; g.line = (uint16_t)line; g.x = (uint8_t)(x > 255 ? 255 : x); g.flags = f; g.link = link;
    g.off = (uint16_t)D.poolUsed; g.len = (uint8_t)n;
    memcpy(D.pool + D.poolUsed, s, n); D.poolUsed += n;
    D.segs.push_back(g);
    x += w; lineBlank = false;
  }
  void breakLine() {
    // never more than one empty line in a row (FrogFind pages stack <br><hr><br>)
    if (lineBlank && prevBlank && !plain && !preDepth && line > 0) { x = lineLeft; pendingSpace = false; return; }
    prevBlank = lineBlank;
    line++; lineLeft = L + indent + hang; x = lineLeft; pendingSpace = false; lineBlank = true;
  }
  void endHang() { hang = 0; if (lineBlank) { lineLeft = L + indent; x = lineLeft; } }
  void blockBreak() { if (!lineBlank) breakLine(); endHang(); }
  void paraBreak() { if (!lineBlank) breakLine(); if (!prevBlank && line > 0) breakLine(); endHang(); }
  void hr() {
    if (!room(0)) return;
    Seg g; g.line = (uint16_t)line; g.x = (uint8_t)L; g.flags = F_HR; g.link = -1; g.off = (uint16_t)D.poolUsed; g.len = 0;
    D.segs.push_back(g); lineBlank = false; breakLine();
  }
  void liPrefix() {
    blockBreak();
    int saved = link; link = -1;
    emit("* ", 2, width("* ", 2), 0);
    link = (int16_t)saved;
    hang = x - (L + indent);               // wrapped lines line up under the text
    lineLeft = x;
    pendingSpace = false;
  }
  void flushWord() {
    if (word.empty()) return;
    uint8_t f = flags();
    const char *s = word.c_str(); int n = (int)word.size();
    int sw = width(" ", 1);
    while (n > 0 && !D.full) {
      int w = width(s, n);
      bool atStart = x <= lineLeft;
      int need = w + ((pendingSpace && !atStart) ? sw : 0);
      if (x + need <= R) {
        if (pendingSpace && !atStart) {    // the gap before a link isn't part of the link
          int16_t sl = link;
          if (spaceLink != link) link = -1;
          emit(" ", 1, sw, link >= 0 ? f : (uint8_t)(f & ~F_LINK));
          link = sl;
        }
        emit(s, n, w, f);
        spaceLink = link;
        n = 0;
      } else if (!atStart) {
        breakLine();                       // try again on a fresh line
      } else {
        // longer than a whole line: hard-split
        int k = n;
        while (k > 1 && x + width(s, k) > R) --k;
        emit(s, k, width(s, k), f);
        s += k; n -= k;
        if (n) breakLine();
      }
    }
    word.clear(); pendingSpace = false;
  }
};

// Streaming HTML tokenizer: feed bytes, it drives a Layout.
class Html {
 public:
  explicit Html(Layout &l) : Lo(l) {}
  bool plain = false;
  uint64_t pos = 0;          // bytes consumed so far
  uint64_t safePos = 0;      // start of the last tag (a good place to resume)
  std::string title;

  // stops consuming as soon as the document is full, so `safePos` / `pos`
  // point at where the next part should start
  void feed(const char *p, size_t n) {
    for (size_t i = 0; i < n; ++i) { if (Lo.full()) return; put(p[i]); ++pos; }
  }
  void finish() { flushText(); Lo.finish(); }

 private:
  Layout &Lo;
  enum St { TEXT, LT, TAG, COMMENT, ENT, SKIPRAW } st = TEXT;
  std::string tag, ent, buf, skipEnd;
  char quote = 0, lastNs = 0;
  size_t skipMatch = 0;
  int c1 = 0, c2 = 0;              // last chars in a comment
  uint32_t cp = 0; int need = 0;   // UTF-8
  bool inTitle = false;

  void out(uint32_t c) {
    if (inTitle) { if (title.size() < 160) asciiFor(c, title); return; }
    asciiFor(c, buf);
    if (buf.size() >= 256) flushText();
  }
  void flushText() { if (!buf.empty()) { Lo.text(buf.data(), buf.size()); buf.clear(); } }

  void put(char ch) {
    unsigned char c = (unsigned char)ch;
    if (plain) { utf8(c); return; }
    switch (st) {
      case TEXT:
        if (c == '<') { st = LT; safePos = pos; return; }
        if (c == '&') { st = ENT; ent.clear(); return; }
        utf8(c); return;
      case LT:
        if (isalpha(c) || c == '/' || c == '!' || c == '?') { tag.assign(1, (char)c); quote = 0; lastNs = 0; st = TAG; return; }
        st = TEXT; out('<'); put(ch); return;
      case TAG:
        if (tag == "!--") { st = COMMENT; c1 = c2 = 0; put(ch); return; }
        if (quote) { if (c == (unsigned char)quote) quote = 0; if (tag.size() < 1024) tag += (char)c; return; }
        if ((c == '"' || c == '\'') && lastNs == '=') { quote = (char)c; if (tag.size() < 1024) tag += (char)c; return; }
        if (c == '>') { st = TEXT; handleTag(); return; }
        if (!isspace(c)) lastNs = (char)c;
        if (tag.size() < 1024) tag += (char)c;
        return;
      case COMMENT:
        if (c == '>' && c1 == '-' && c2 == '-') { st = TEXT; return; }
        c2 = c1; c1 = c; return;
      case ENT:
        if (c == ';') {
          long v = entityCp(ent);
          st = TEXT;
          if (v >= 0) out((uint32_t)v); else { out('&'); for (char e : ent) out((unsigned char)e); out(';'); }
          return;
        }
        if ((isalnum(c) || c == '#') && ent.size() < 10) { ent += (char)c; return; }
        st = TEXT; out('&'); for (char e : ent) out((unsigned char)e); put(ch); return;
      case SKIPRAW:
        if (tolower(c) == (unsigned char)skipEnd[skipMatch]) {
          if (++skipMatch == skipEnd.size()) { st = TAG; tag = skipEnd.substr(1); quote = 0; lastNs = 0; skipMatch = 0; }
        } else skipMatch = (c == '<') ? 1 : 0;
        return;
    }
  }
  void utf8(unsigned char c) {
    if (need) {
      if ((c & 0xC0) == 0x80) { cp = (cp << 6) | (c & 0x3F); if (--need == 0) out(cp); return; }
      need = 0;                                   // broken sequence: fall through
    }
    if (c < 0x80) { out(c); return; }
    if ((c & 0xE0) == 0xC0) { cp = c & 0x1F; need = 1; return; }
    if ((c & 0xF0) == 0xE0) { cp = c & 0x0F; need = 2; return; }
    if ((c & 0xF8) == 0xF0) { cp = c & 0x07; need = 3; return; }
    out(c);                                       // stray byte: treat as Latin-1
  }

  static std::string attr(const std::string &t, const char *name) {
    std::string lt = lower(t);
    size_t n = strlen(name), p = 0;
    while ((p = lt.find(name, p)) != std::string::npos) {
      bool okL = p > 0 && (isspace((unsigned char)lt[p - 1]) || lt[p - 1] == '"' || lt[p - 1] == '\'');
      size_t q = p + n;
      while (q < lt.size() && isspace((unsigned char)lt[q])) ++q;
      if (okL && q < lt.size() && lt[q] == '=') {
        ++q;
        while (q < lt.size() && isspace((unsigned char)lt[q])) ++q;
        if (q >= t.size()) return "";
        char qc = t[q];
        if (qc == '"' || qc == '\'') {
          size_t e = t.find(qc, q + 1);
          return t.substr(q + 1, (e == std::string::npos ? t.size() : e) - q - 1);
        }
        size_t e = q;
        while (e < t.size() && !isspace((unsigned char)t[e]) && t[e] != '>') ++e;
        return t.substr(q, e - q);
      }
      p += n;
    }
    return "";
  }

  void handleTag() {
    std::string t = tag; tag.clear();
    if (t.empty() || t[0] == '!' || t[0] == '?') return;
    bool closing = t[0] == '/';
    size_t i = closing ? 1 : 0;
    std::string name;
    while (i < t.size() && (isalnum((unsigned char)t[i]))) name += (char)tolower((unsigned char)t[i++]);
    if (name.empty()) return;
    if (name == "title") { flushText(); inTitle = !closing; return; }
    if (!closing && (name == "script" || name == "style" || name == "noscript" || name == "template" ||
                     name == "svg" || name == "textarea" || name == "select")) {
      flushText(); st = SKIPRAW; skipEnd = "</" + name; skipMatch = 0; return;
    }
    flushText();
    if (closing) { Lo.tagClose(name); return; }
    std::string href, color;
    if (name == "a") href = decodeEntities(attr(t, "href"));
    else if (name == "font") color = attr(t, "color");
    Lo.tagOpen(name, href, color);
    bool selfClose = !t.empty() && t.back() == '/';
    if (selfClose && name != "br" && name != "hr") Lo.tagClose(name);
  }
};

// ---------------------------------------------------------------- keyboard
enum : uint8_t { K_NONE = 0, K_SHIFT = 1, K_L123 = 2, K_LSYM = 3, K_LABC = 4, K_BS = 8, K_ENTER = 13 };
enum { LAYER_ABC = 0, LAYER_123 = 1, LAYER_SYM = 2 };
struct KKey { int16_t x, y, w, h; uint8_t code; char label[8]; };

const int KB_W = 240, KB_Y0 = 140, KB_ROWH = 45, KB_M = 2, KB_U = KB_W - 2 * KB_M;   // 4 rows: 140..320

inline void kbAdd(KKey *k, int &n, int x, int y, int w, int h, uint8_t code, const char *label) {
  KKey &q = k[n++]; q.x = (int16_t)x; q.y = (int16_t)y; q.w = (int16_t)w; q.h = (int16_t)h; q.code = code;
  strncpy(q.label, label, sizeof(q.label) - 1); q.label[sizeof(q.label) - 1] = 0;
}
// evenly split [x0, x0+w) into `cnt` keys taken from chars
inline void kbRun(KKey *k, int &n, const char *chars, int cnt, double x0, double w, int y, bool upper) {
  for (int i = 0; i < cnt; ++i) {
    int a = (int)(x0 + w * i / cnt + 0.5), b = (int)(x0 + w * (i + 1) / cnt + 0.5);
    char ch = chars[i];
    if (upper && ch >= 'a' && ch <= 'z') ch = (char)(ch - 32);
    char lab[2] = {ch, 0};
    kbAdd(k, n, a, y, b - a, KB_ROWH, (uint8_t)ch, lab);
  }
}
// returns number of keys (<= 40)
inline int kbBuild(int layer, bool upper, KKey *k) {
  int n = 0;
  int y0 = KB_Y0, y1 = KB_Y0 + KB_ROWH, y2 = KB_Y0 + 2 * KB_ROWH, y3 = KB_Y0 + 3 * KB_ROWH;
  const double kw = KB_U / 10.0;
  const int side = 34;                                     // shift / backspace width
  if (layer == LAYER_ABC) {
    kbRun(k, n, "qwertyuiop", 10, KB_M, KB_U, y0, upper);
    kbRun(k, n, "asdfghjkl", 9, KB_M + kw / 2, kw * 9, y1, upper);
    kbAdd(k, n, KB_M, y2, side, KB_ROWH, K_SHIFT, "shift");
    kbRun(k, n, "zxcvbnm", 7, KB_M + side + 2, KB_U - 2 * side - 4, y2, upper);
    kbAdd(k, n, KB_M + KB_U - side, y2, side, KB_ROWH, K_BS, "del");
  } else {
    kbRun(k, n, layer == LAYER_123 ? "1234567890" : "[]{}#%^*+=", 10, KB_M, KB_U, y0, false);
    kbRun(k, n, layer == LAYER_123 ? "-/:;()$&@\"" : "_\\|~<>`&@$", 10, KB_M, KB_U, y1, false);
    kbAdd(k, n, KB_M, y2, side, KB_ROWH, layer == LAYER_123 ? K_LSYM : K_L123, layer == LAYER_123 ? "#+=" : "123");
    kbRun(k, n, ".,?!'", 5, KB_M + side + 2, KB_U - 2 * side - 4, y2, false);
    kbAdd(k, n, KB_M + KB_U - side, y2, side, KB_ROWH, K_BS, "del");
  }
  // bottom row:  [123/ABC] [/] [   space   ] [.] [Enter]
  int w4[5] = {42, 26, 90, 26, 52};
  int x = KB_M;
  kbAdd(k, n, x, y3, w4[0], KB_ROWH, layer == LAYER_ABC ? K_L123 : K_LABC, layer == LAYER_ABC ? "123" : "ABC"); x += w4[0];
  kbAdd(k, n, x, y3, w4[1], KB_ROWH, '/', "/");     x += w4[1];
  kbAdd(k, n, x, y3, w4[2], KB_ROWH, ' ', "space"); x += w4[2];
  kbAdd(k, n, x, y3, w4[3], KB_ROWH, '.', ".");     x += w4[3];
  kbAdd(k, n, x, y3, w4[4], KB_ROWH, K_ENTER, "Enter");
  return n;
}
// key under (x, y); a finger slightly off the edge still counts (resistive screens)
inline int kbHit(const KKey *k, int n, int x, int y) {
  if (y < KB_Y0 - 4) return -1;
  for (int i = 0; i < n; ++i)
    if (x >= k[i].x && x < k[i].x + k[i].w && y >= k[i].y && y < k[i].y + k[i].h) return i;
  int best = -1; long bd = 10 * 10 + 1;
  for (int i = 0; i < n; ++i) {
    int dx = x < k[i].x ? k[i].x - x : (x >= k[i].x + k[i].w ? x - (k[i].x + k[i].w - 1) : 0);
    int dy = y < k[i].y ? k[i].y - y : (y >= k[i].y + k[i].h ? y - (k[i].y + k[i].h - 1) : 0);
    long d = (long)dx * dx + (long)dy * dy;
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

}  // namespace ffc
