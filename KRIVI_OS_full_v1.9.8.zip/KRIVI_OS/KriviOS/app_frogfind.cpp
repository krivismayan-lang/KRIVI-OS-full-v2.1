// ============================================================================
//  KRIVI OS - FrogFind!  (portrait web browser)                     app 91
//
//  Browse the web through frogfind.com - "the search engine for vintage
//  computers". FrogFind fetches DuckDuckGo results and strips any web page
//  down to plain, simple HTML, which is exactly what a 320 KB microcontroller
//  can handle. Pages travel over plain HTTP (no TLS), are saved to the SD card
//  and laid out for a 240 x 320 portrait screen.
//
//    * hold the CYD upright like a phone (FLIP on the home screen turns it 180)
//    * tap the address bar or the search box -> full phone-style keyboard
//      (a-z, Shift/Caps, 123 numbers, #+= symbols, space, delete, Enter)
//    * tap blue links to follow them, drag up/down to scroll,
//      Back / Home / Up / Down / Reload on the bottom bar
//    * FrogFind's picture links open in a JPEG viewer (tap to zoom)
//
//  Needs WiFi (Settings > WI-FI NETWORKS). Recent searches and the flip
//  setting are kept in /sys/settings.json under "frogfind".
// ============================================================================
#include "apps_common.h"
#include "ff_core.h"
#include "ff_ui.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <TJpg_Decoder.h>
#include <vector>

namespace frog {

using namespace ffui;

// ---------------------------------------------------------------- TFT backend
struct TftGfx : Gfx {
  void fillRect(int x, int y, int w, int h, uint16_t c) override { if (w > 0 && h > 0) tft.fillRect(x, y, w, h, c); }
  void fillRoundRect(int x, int y, int w, int h, int r, uint16_t c) override { tft.fillRoundRect(x, y, w, h, r, c); }
  void drawRoundRect(int x, int y, int w, int h, int r, uint16_t c) override { tft.drawRoundRect(x, y, w, h, r, c); }
  void hline(int x, int y, int w, uint16_t c) override { if (w > 0) tft.drawFastHLine(x, y, w, c); }
  void vline(int x, int y, int h, uint16_t c) override { if (h > 0) tft.drawFastVLine(x, y, h, c); }
  void line(int x0, int y0, int x1, int y1, uint16_t c) override { tft.drawLine(x0, y0, x1, y1, c); }
  void circle(int x, int y, int r, uint16_t c) override { tft.drawCircle(x, y, r, c); }
  void fillCircle(int x, int y, int r, uint16_t c) override { tft.fillCircle(x, y, r, c); }
  void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c) override { tft.fillTriangle(x0, y0, x1, y1, x2, y2, c); }
  void text(const char *s, int x, int y, int font, uint16_t fg, uint16_t bg, int datum) override {
    tft.setTextDatum(datum);
    if (fg == bg) tft.setTextColor(fg); else tft.setTextColor(fg, bg);
    tft.drawString(s, x, y, font);
    tft.setTextDatum(TL_DATUM);
  }
  int textWidth(const char *s, int font) override { return tft.textWidth(s, font); }
};
TftGfx G;

// ---------------------------------------------------------------- state
const char *PAGE_FILE = "/sys/cache/ff_page.htm";
const char *IMG_FILE  = "/sys/cache/ff_img.jpg";
const size_t PAGE_SD_MAX = 400UL * 1024;      // bytes kept of one page on SD
const size_t PAGE_RAM_MAX = 26000;            // without an SD card
const size_t IMG_RAM_MAX = 40000;

enum Scr { HOME, PAGE, IMAGE, MSG };
Scr scr = HOME;
ffc::Doc doc;
int landRot = 1, portRot = 0;
bool flip = false;

String curUrl;                // what is on screen
uint32_t curOff = 0;          // byte offset of this part of the page
uint32_t nextOff = 0;         // >0: there is a next part
bool curPlain = false;
int top = 0;                  // first visible line
std::string pageTitle;

struct Hist { String url; uint32_t off; int top; };
std::vector<Hist> hist;
std::vector<std::string> recent;

uint8_t *ram = nullptr;       // body kept in RAM when there is no SD card
size_t ramLen = 0;
bool imgFit = true;
String msgTitle, msgBody; uint16_t msgCol = TEXT;
bool needRedraw = false, wasRinging = false, quit = false;

// ---------------------------------------------------------------- touch (portrait)
struct PT { bool down, pressed, released, tap; int x, y, sx, sy; };
PT poll() {
  ui::clearEvents();
  Touch &t = ui::poll();
  delay(2);
  bool ring = sys::alarm.ringing;
  if (wasRinging && !ring) needRedraw = true;      // the alarm banner drew over us
  wasRinging = ring;
  PT p;
  p.down = t.down; p.pressed = t.pressed; p.released = t.released; p.tap = t.tap;
  ffc::mapPoint(landRot, portRot, t.x, t.y, p.x, p.y);
  ffc::mapPoint(landRot, portRot, t.sx, t.sy, p.sx, p.sy);
  return p;
}

// ---------------------------------------------------------------- helpers
int maxTop() { int t = totalLines(doc, nextOff > 0) - VIS; return t > 0 ? t : 0; }
bool isSearchUrl(const String &u) { return u.indexOf("frogfind.com/?q=") >= 0; }
std::string address() {
  if (scr == HOME || !curUrl.length()) return "Search or type a URL";
  std::string u = curUrl.c_str();
  if (scr == PAGE && !isSearchUrl(curUrl) && !pageTitle.empty() && pageTitle != "FrogFind!") return pageTitle;
  return ffc::displayAddress(u);
}
void saveFrogCfg() {
  JsonArray a = sys::cfg["frogfind"]["recent"].to<JsonArray>();
  for (auto &r : recent) a.add(r.c_str());
  sys::cfg["frogfind"]["flip"] = flip;
  sys::saveSettings();
}
void addRecent(const std::string &q) {
  for (size_t i = 0; i < recent.size(); ++i) if (recent[i] == q) { recent.erase(recent.begin() + i); break; }
  recent.insert(recent.begin(), q);
  if (recent.size() > 5) recent.resize(5);
  saveFrogCfg();
}

bool jpgOut(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bmp) {
  tft.pushImage(x, y, w, h, bmp);
  return true;
}
void drawImage() {
  G.fillRect(0, CY, W, CH, BG);
  uint16_t w = 0, h = 0;
  JRESULT r = ram ? TJpgDec.getJpgSize(&w, &h, ram, ramLen) : TJpgDec.getSdJpgSize(&w, &h, IMG_FILE);
  if (r != JDR_OK || !w || !h) { drawMessage(G, "Can't show this picture", "FrogFind could only send a broken or non-JPEG image.", RED); return; }
  int s = 1;
  if (imgFit) while ((w / s > W - 8 || h / s > CH - 20) && s < 8) s *= 2;
  int dw = w / s, dh = h / s;
  int x = (W - dw) / 2, y = CY + (CH - 14 - dh) / 2;
  TJpgDec.setJpgScale(s);
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(jpgOut);
  tft.setViewport(0, CY, W, CH - 14, false);          // clip, keep screen coordinates
  if (ram) TJpgDec.drawJpg(x, y, ram, ramLen); else TJpgDec.drawSdJpg(x, y, IMG_FILE);
  tft.resetViewport();
  char cap[48];
  snprintf(cap, sizeof(cap), "%ux%u  -  tap to %s", w, h, imgFit ? "zoom 1:1" : "fit screen");
  G.text(cap, W / 2, CY + CH - 7, 1, DIM, BG, DMC);
}

void redrawAll() {
  switch (scr) {
    case HOME:
      drawTopBar(G, address(), true);
      drawHome(G, recent, WiFi.status() == WL_CONNECTED);
      drawToolbar(G, !hist.empty(), false, true);
      break;
    case PAGE:
      if (top > maxTop()) top = maxTop();
      drawTopBar(G, address(), false);
      drawPage(G, doc, top, -1, nextOff > 0);
      drawToolbar(G, !hist.empty(), totalLines(doc, nextOff > 0) > VIS, false);
      break;
    case IMAGE:
      drawTopBar(G, address(), false);
      drawImage();
      drawToolbar(G, !hist.empty(), false, false);
      break;
    case MSG:
      drawTopBar(G, address(), !curUrl.length());
      drawMessage(G, msgTitle.c_str(), msgBody.c_str(), msgCol);
      drawToolbar(G, !hist.empty(), false, false, curUrl.length() > 0);
      break;
  }
}
void showMsg(const char *title, const String &body, uint16_t col) {
  scr = MSG; msgTitle = title; msgBody = body; msgCol = col;
  redrawAll();
}

// ---------------------------------------------------------------- download
size_t g_total = 0; uint32_t g_lastUi = 0;
void progress(size_t n) {
  if (millis() - g_lastUi < 200) return;
  g_lastUi = millis();
  char b[40];
  if (g_total > 0) { snprintf(b, sizeof(b), "%u of %u KB", (unsigned)(n / 1024), (unsigned)(g_total / 1024)); drawProgress(G, (int)(1000ULL * n / g_total)); }
  else { snprintf(b, sizeof(b), "%u KB", (unsigned)(n / 1024)); drawProgress(G, (int)((millis() / 4) % 1000)); }
  G.fillRect(0, CY + 150, W, 14, BG);
  G.text(b, W / 2, CY + 157, 1, DIM, BG, DMC);
}

// Writes the HTTP body to the SD card (or RAM) with a cap and progress.
class Sink : public Stream {
 public:
  File f; uint8_t *buf = nullptr; size_t cap = 0, n = 0; bool over = false;
  size_t write(uint8_t b) override { return write(&b, 1); }
  size_t write(const uint8_t *b, size_t len) override {
    if (over) return 0;
    size_t room = cap > n ? cap - n : 0;
    size_t take = len < room ? len : room;
    if (take) {
      if (buf) memcpy(buf + n, b, take);
      else if (f.write(b, take) != take) { over = true; return 0; }
      n += take;
      progress(n);
    }
    if (take < len) { over = true; return take; }
    return len;
  }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() {}
};

enum Kind { K_HTML, K_TEXT, K_JPEG, K_OTHER, K_FAIL };
struct Got { Kind kind = K_FAIL; String err, ctype; size_t bytes = 0; bool cut = false; };

void freeRam() { if (ram) { free(ram); ram = nullptr; } ramLen = 0; }

Got fetch(const String &urlIn, bool wantImage, int depth = 0) {
  Got g;
  String url = urlIn;
  bool tls = url.startsWith("https://");
  WiFiClient plain;
  WiFiClientSecure *sec = nullptr;
  HTTPClient http;
  http.setReuse(false);
  http.setTimeout(20000);
  http.setConnectTimeout(12000);
  http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  http.setUserAgent("Mozilla/4.0 (compatible; KRIVI-OS FrogFind; ESP32)");
  const char *hk[] = {"Location", "Content-Type"};
  http.collectHeaders(hk, 2);
  bool ok;
  if (tls) { sec = new WiFiClientSecure(); sec->setInsecure(); ok = http.begin(*sec, url); }
  else ok = http.begin(plain, url);
  if (!ok) { g.err = "Bad address"; delete sec; return g; }
  int code = http.GET();
  if ((code == 301 || code == 302 || code == 303 || code == 307 || code == 308) && depth < 4) {
    String loc = http.header("Location");
    http.end(); delete sec;
    if (!loc.length()) { g.err = "Redirect without a target"; return g; }
    std::string to = loc.startsWith("http") ? std::string(loc.c_str())
                     : loc.startsWith("/") ? ffc::origin(url.c_str()) + loc.c_str()
                     : ffc::origin(url.c_str()) + "/" + loc.c_str();
    if (ffc::isFrogFind(to)) to = ffc::normalizeFF(to);
    return fetch(String(to.c_str()), wantImage, depth + 1);
  }
  if (code != 200) {
    g.err = code > 0 ? String("The server answered ") + code : String(HTTPClient::errorToString(code));
    http.end(); delete sec; return g;
  }
  String ct = http.header("Content-Type"); ct.toLowerCase();
  g.ctype = ct;
  if (ct.indexOf("image/jpeg") >= 0 || ct.indexOf("image/jpg") >= 0 || ct.indexOf("image/pjpeg") >= 0) g.kind = K_JPEG;
  else if (ct.indexOf("text/plain") >= 0) g.kind = K_TEXT;
  else if (!ct.length() || ct.indexOf("html") >= 0) g.kind = K_HTML;
  else { g.kind = K_OTHER; http.end(); delete sec; return g; }
  if (wantImage && g.kind != K_JPEG && ct.length()) { g.kind = K_OTHER; http.end(); delete sec; return g; }

  g_total = http.getSize() > 0 ? (size_t)http.getSize() : 0;
  g_lastUi = 0;
  freeRam();
  Sink sink;
  bool isImg = g.kind == K_JPEG;
  if (sys::sdOk) {
    const char *path = isImg ? IMG_FILE : PAGE_FILE;
    SD.remove(path);
    sink.f = SD.open(path, FILE_WRITE);
    if (!sink.f) { g.kind = K_FAIL; g.err = "Can't write to the SD card"; http.end(); delete sec; return g; }
    sink.cap = isImg ? 600UL * 1024 : PAGE_SD_MAX;
  } else {
    size_t cap = isImg ? IMG_RAM_MAX : PAGE_RAM_MAX;
    ram = (uint8_t *)malloc(cap);
    if (!ram) { cap /= 2; ram = (uint8_t *)malloc(cap); }
    if (!ram) { g.kind = K_FAIL; g.err = "Not enough memory"; http.end(); delete sec; return g; }
    sink.buf = ram; sink.cap = cap;
  }
  int r = http.writeToStream(&sink);
  http.end(); delete sec;
  if (sink.f) sink.f.close();
  if (ram) ramLen = sink.n;
  g.bytes = sink.n;
  g.cut = sink.over;
  if (sink.n == 0) { g.kind = K_FAIL; g.err = r < 0 ? String(HTTPClient::errorToString(r)) : String("Empty reply"); }
  return g;
}

// ---------------------------------------------------------------- parse
void parseFrom(uint32_t off) {
  doc.reset();
  ffc::Layout L(doc, PL, PR, width2, nullptr);
  L.plain = curPlain;
  ffc::Html H(L);
  H.plain = curPlain;
  static char buf[1024];
  if (ram) {
    for (size_t i = off; i < ramLen && !doc.full; i += sizeof(buf)) {
      size_t n = ramLen - i < sizeof(buf) ? ramLen - i : sizeof(buf);
      H.feed((const char *)ram + i, n);
    }
  } else {
    File f = SD.open(PAGE_FILE);
    if (f) {
      f.seek(off);
      while (f.available() && !doc.full) {
        int n = f.read((uint8_t *)buf, sizeof(buf));
        if (n <= 0) break;
        H.feed(buf, n);
        yield();
      }
      f.close();
    }
  }
  bool full = doc.full;
  H.finish();
  if (off == 0) pageTitle = ffc::trim(H.title);
  if (full) {
    uint64_t sp = H.safePos ? H.safePos : H.pos;
    nextOff = off + (uint32_t)sp;
    if (nextOff <= off) nextOff = off + (uint32_t)(H.pos ? H.pos : 1);
  } else nextOff = 0;
}

// ---------------------------------------------------------------- navigation
bool ensureWifi() {
  if (WiFi.status() == WL_CONNECTED) return true;
  const char *ssid = sys::cfg["wifi"]["ssid"] | "";
  if (!ssid[0]) return false;
  drawLoading(G, "Joining WiFi...", ssid);
  return sys::wifiConnect(16000, false);
}

void go(const String &url, bool push, uint32_t off = 0, int restoreTop = 0) {
  if (push) {
    if (scr == HOME) hist.push_back({String(""), 0, 0});
    else if (curUrl.length()) hist.push_back({curUrl, curOff, top});
    if (hist.size() > 20) hist.erase(hist.begin());
  }
  curUrl = url; curOff = off; top = 0; nextOff = 0; imgFit = true;
  scr = MSG;                                       // until something loads
  drawTopBar(G, ffc::displayAddress(url.c_str()), false);
  drawToolbar(G, !hist.empty(), false, false, false);
  if (!ensureWifi()) {
    showMsg("No WiFi", "Join a network in Settings > WI-FI NETWORKS, then come back and tap Reload.", RED);
    return;
  }
  bool wantImg = ffc::isImageUrl(url.c_str());
  drawLoading(G, wantImg ? "Fetching picture..." : "Leaping to page...", ffc::displayAddress(url.c_str()));
  Got g = fetch(url, wantImg);
  drawProgress(G, 1000);
  if (g.kind == K_FAIL) { showMsg("Couldn't load the page", g.err + "\nCheck WiFi and tap Reload.", RED); return; }
  if (g.kind == K_OTHER) {
    showMsg("Can't open this file", String("It is \"") + (g.ctype.length() ? g.ctype : String("unknown")) +
            "\". This browser shows web pages and JPEG pictures.", WARN);
    return;
  }
  if (g.kind == K_JPEG) { scr = IMAGE; redrawAll(); return; }
  drawLoading(G, "Laying out page...", String(g.bytes / 1024).c_str() + std::string(" KB"));
  curPlain = g.kind == K_TEXT;
  parseFrom(off);
  if (!doc.lines) {
    showMsg(g.cut ? "Page too big" : "Nothing to show", "FrogFind sent a page with no readable text. Try another result.", WARN);
    return;
  }
  scr = PAGE;
  top = restoreTop;
  redrawAll();
}

void goBack() {
  if (hist.empty()) { scr = HOME; redrawAll(); return; }
  Hist h = hist.back(); hist.pop_back();
  if (!h.url.length()) { scr = HOME; curUrl = ""; redrawAll(); return; }
  if (h.url == curUrl && scr == PAGE && !ram && sys::sdOk) {       // earlier part of the same page: no download
    curOff = h.off; parseFrom(h.off); top = h.top; redrawAll(); return;
  }
  go(h.url, false, h.off, h.top);
}
void goHome() {
  if (scr != HOME && curUrl.length()) { hist.push_back({curUrl, curOff, top}); if (hist.size() > 20) hist.erase(hist.begin()); }
  scr = HOME; redrawAll();
}

// ---------------------------------------------------------------- keyboard
void restoreUnderBubble(Kb &k, int i) {
  int bx, by, bw, bh; bubbleRect(k.keys[i], bx, by, bw, bh);
  if (by < ffc::KB_Y0) drawKbInput(G, k);           // bubble reached up into the text box
  for (int j = 0; j < k.n; ++j) {
    const ffc::KKey &q = k.keys[j];
    if (q.x < bx + bw && q.x + q.w > bx && q.y < by + bh && q.y + q.h > by) drawKey(G, k, j, j == k.pressed);
  }
}
void setPressed(Kb &k, int i) {
  if (i == k.pressed) return;
  int old = k.pressed;
  k.pressed = i;
  if (old >= 0) { drawKey(G, k, old, false); if (keyIsChar(k.keys[old])) restoreUnderBubble(k, old); }
  if (i >= 0) { drawKey(G, k, i, true); drawBubble(G, k, i); }
}

// returns true when Enter was pressed
bool keyboard(const char *prompt, std::string &text) {
  Kb k; k.prompt = prompt; k.text = text;
  if (!k.text.empty() && k.text.size() > 240) k.text.resize(240);
  drawKbScreen(G, k);
  uint32_t delT0 = 0, delLast = 0, lastShift = 0;
  bool delRepeated = false;
  while (true) {
    PT p = poll();
    if (needRedraw) { needRedraw = false; k.pressed = -1; drawKbScreen(G, k); }
    if (p.tap && p.sy < TOPH + 2 && hitCancel(p.sx, p.sy)) return false;
    bool onKeys = p.sy >= ffc::KB_Y0 - 4;
    if (p.down && onKeys) {
      int i = ffc::kbHit(k.keys, k.n, p.x, p.y);
      setPressed(k, i);
      if (i >= 0 && k.keys[i].code == ffc::K_BS) {                      // hold to keep deleting
        uint32_t now = millis();
        if (!delT0) delT0 = now;
        else if (now - delT0 > 450 && now - delLast > 70 && !k.text.empty()) {
          k.text.pop_back(); delLast = now; delRepeated = true; drawKbInput(G, k);
        }
      } else delT0 = 0;
    }
    if (!p.released) continue;
    int i = k.pressed;
    setPressed(k, -1);
    bool repeated = delRepeated;
    delT0 = 0; delRepeated = false;
    if (i < 0 || !onKeys) continue;
    audio::click();
    uint8_t code = k.keys[i].code;
    switch (code) {
      case ffc::K_ENTER: text = k.text; return true;
      case ffc::K_BS: if (!repeated && !k.text.empty()) { k.text.pop_back(); drawKbInput(G, k); } break;
      case ffc::K_SHIFT: {
        uint32_t now = millis();
        if (k.caps) { k.caps = false; k.upper = false; }
        else if (k.upper && now - lastShift < 450) k.caps = true;
        else k.upper = !k.upper;
        lastShift = now;
        drawKeyboard(G, k);
        break;
      }
      case ffc::K_L123: k.layer = ffc::LAYER_123; drawKeyboard(G, k); break;
      case ffc::K_LSYM: k.layer = ffc::LAYER_SYM; drawKeyboard(G, k); break;
      case ffc::K_LABC: k.layer = ffc::LAYER_ABC; drawKeyboard(G, k); break;
      default:
        if (code >= 32 && code < 127 && k.text.size() < 240) {
          k.text += (char)code;
          drawKbInput(G, k);
          bool relayout = false;
          if (k.upper && !k.caps && k.layer == ffc::LAYER_ABC) { k.upper = false; relayout = true; }
          if (code == ' ' && k.layer != ffc::LAYER_ABC) { k.layer = ffc::LAYER_ABC; relayout = true; }
          if (relayout) drawKeyboard(G, k);
        }
    }
  }
}

void askAndGo(const std::string &prefill) {
  std::string t = prefill;
  if (keyboard("FrogFind!", t)) {
    t = ffc::trim(t);
    if (!t.empty()) {
      addRecent(t);
      go(String(ffc::fromTyped(t).c_str()), true);
      return;
    }
  }
  redrawAll();
}

// ---------------------------------------------------------------- taps
void flash(int seg) {                      // show which link was hit
  int r = -1;
  if (seg == -2) r = doc.lines + 1 - top;
  else if (seg >= 0) r = doc.segs[seg].line - top;
  if (r >= 0 && r < VIS) { drawPageRow(G, doc, top, r, seg, nextOff > 0); delay(140); }
}
void onTap(int x, int y) {
  if (hitExit(x, y)) { quit = true; return; }
  if (hitAddress(x, y)) {
    std::string pre = (scr == HOME || !curUrl.length()) ? std::string() : ffc::displayAddress(curUrl.c_str());
    askAndGo(pre);
    return;
  }
  int b = hitToolbar(x, y);
  if (b >= 0) {
    drawToolButton(G, b, true, scr == HOME, true); delay(60);
    switch (b) {
      case TB_BACK: if (!hist.empty()) goBack(); else redrawAll(); return;
      case TB_HOME: goHome(); return;
      case TB_UP: if (scr == PAGE) { top -= VIS - 1; if (top < 0) top = 0; } redrawAll(); return;
      case TB_DOWN: if (scr == PAGE) { top += VIS - 1; if (top > maxTop()) top = maxTop(); } redrawAll(); return;
      default:
        if (scr == HOME) {
          flip = !flip; portRot = ffc::portraitFor(landRot, flip);
          tft.setRotation(portRot); saveFrogCfg(); redrawAll();
        } else if (curUrl.length()) go(curUrl, false, curOff, top);
        else redrawAll();
        return;
    }
  }
  switch (scr) {
    case HOME: {
      if (hitSearchBox(x, y)) { askAndGo(""); return; }
      int i = hitRecent(x, y, (int)recent.size());
      if (i >= 0) { std::string q = recent[i]; addRecent(q); go(String(ffc::fromTyped(q).c_str()), true); }
      return;
    }
    case PAGE: {
      int seg;
      int li = linkAt(doc, top, x, y, nextOff > 0, seg);
      if (li == -2) {                                   // next part of a long page
        flash(-2);
        hist.push_back({curUrl, curOff, top});
        uint32_t o = nextOff;
        drawLoading(G, "Next part...", address());
        curOff = o; parseFrom(o); top = 0; redrawAll();
        return;
      }
      if (li >= 0 && li < (int)doc.links.size()) {
        flash(seg);
        std::string to = ffc::resolve(curUrl.c_str(), doc.links[li]);
        if (to.empty()) { drawTopBar(G, "That link can't open here", true); delay(900); drawTopBar(G, address(), false); return; }
        go(String(to.c_str()), true);
      }
      return;
    }
    case IMAGE:
      if (y >= CY && y < CY + CH) { imgFit = !imgFit; drawImage(); }
      return;
    default: return;
  }
}

}  // namespace frog

void app_frogfind(AppCtx &c) {
  using namespace frog;
  quit = false; needRedraw = false; wasRinging = sys::alarm.ringing;
  landRot = tft.getRotation();
  flip = sys::cfg["frogfind"]["flip"] | false;
  portRot = ffc::portraitFor(landRot, flip);
  recent.clear();
  for (JsonVariant v : sys::cfg["frogfind"]["recent"].as<JsonArray>()) { const char *s = v | ""; if (*s && recent.size() < 5) recent.push_back(s); }

  // page buffers sized to the free heap (WiFi needs ~50 KB of its own)
  uint32_t freeH = ESP.getMaxAllocHeap();
  uint32_t poolCap = freeH > 120000 ? 30000 : freeH > 80000 ? 18000 : 10000;
  uint32_t segCap = poolCap / 11;
  doc.pool = (char *)malloc(poolCap);
  if (!doc.pool) { poolCap = 8000; segCap = 700; doc.pool = (char *)malloc(poolCap); }
  if (!doc.pool) { ui::msgBox("FROGFIND", "Not enough memory to start the browser."); return; }
  doc.poolCap = poolCap; doc.segCap = segCap;
  doc.segs.reserve(segCap);
  doc.linkCountCap = 220; doc.linkByteCap = poolCap / 2;
  doc.reset();
  if (sys::sdOk) SD.mkdir("/sys/cache");

  tft.setRotation(portRot);
  initWidths(G);
  scr = HOME; curUrl = ""; hist.clear(); top = 0; nextOff = 0; pageTitle.clear();
  tft.fillScreen(BG);
  redrawAll();

  bool dragging = false; int top0 = 0;
  while (!quit) {
    PT p = poll();
    if (needRedraw) { needRedraw = false; redrawAll(); }
    if (scr == PAGE && p.down && p.sy > CY && p.sy < BOTY - 2) {          // drag to scroll
      int dy = p.y - p.sy;
      if (!dragging && abs(dy) > 12) { dragging = true; top0 = top; }
      if (dragging) {
        int nt = top0 - (dy > 0 ? (dy + LH / 2) / LH : -((-dy + LH / 2) / LH));
        if (nt < 0) nt = 0;
        if (nt > maxTop()) nt = maxTop();
        if (nt != top) { top = nt; drawPage(G, doc, top, -1, nextOff > 0); }
      }
    }
    if (p.released && dragging) { dragging = false; continue; }
    if (p.tap) onTap(p.sx, p.sy);
  }

  // ---- leave things as the rest of the OS expects them
  tft.setRotation(landRot);
  tft.fillScreen(C_BG);
  freeRam();
  free(doc.pool); doc.pool = nullptr; doc.poolCap = 0;
  std::vector<ffc::Seg>().swap(doc.segs);
  std::vector<uint16_t>().swap(doc.lineStart);
  std::vector<std::string>().swap(doc.links);
  std::vector<Hist>().swap(hist);
  sys::radiosOff();
  ui::clearEvents();
  c.exitReq = true;
}
