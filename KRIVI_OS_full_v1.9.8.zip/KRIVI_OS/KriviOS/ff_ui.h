// ============================================================================
//  KRIVI OS - FrogFind screens (portrait 240 x 320)
//
//  All drawing for the FrogFind browser goes through the tiny Gfx interface
//  below. On the CYD it is backed by TFT_eSPI; on a PC the test harness backs
//  it with a framebuffer using the same fonts, so the preview images are drawn
//  by exactly this code.
// ============================================================================
#pragma once
#include "ff_core.h"
#include <string>
#include <vector>
#include <algorithm>

namespace ffui {

constexpr uint16_t rgb(int r, int g, int b) {
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}
// TFT_eSPI datum values
enum { DTL = 0, DTC = 1, DTR = 2, DML = 3, DMC = 4, DMR = 5 };

const uint16_t BG = rgb(8, 10, 18), BAR = rgb(20, 24, 36), BARLINE = rgb(40, 46, 70), PILL = rgb(38, 44, 64),
               TEXT = rgb(215, 220, 232), WHITE = 0xFFFF, BLACK = 0x0000, DIM = rgb(120, 130, 155),
               LINK = rgb(110, 175, 255), FROG = rgb(70, 200, 90), FROGD = rgb(30, 120, 50),
               HEAD = rgb(140, 235, 160), GREEN = rgb(90, 200, 110), RED = rgb(255, 95, 95),
               SEL = rgb(0, 200, 255), EXITC = rgb(200, 30, 50), KBG = rgb(16, 18, 28), KEY = rgb(48, 54, 78),
               KEY2 = rgb(30, 34, 52), ENTER = rgb(0, 110, 160), SHIFTON = rgb(0, 170, 220), HR = rgb(50, 58, 82),
               BUBBLE = rgb(236, 240, 248), WARN = rgb(255, 190, 0);

struct Gfx {
  virtual void fillRect(int x, int y, int w, int h, uint16_t c) = 0;
  virtual void fillRoundRect(int x, int y, int w, int h, int r, uint16_t c) = 0;
  virtual void drawRoundRect(int x, int y, int w, int h, int r, uint16_t c) = 0;
  virtual void hline(int x, int y, int w, uint16_t c) = 0;
  virtual void vline(int x, int y, int h, uint16_t c) = 0;
  virtual void line(int x0, int y0, int x1, int y1, uint16_t c) = 0;
  virtual void circle(int x, int y, int r, uint16_t c) = 0;
  virtual void fillCircle(int x, int y, int r, uint16_t c) = 0;
  virtual void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c) = 0;
  // fg == bg draws transparent text (TFT_eSPI convention)
  virtual void text(const char *s, int x, int y, int font, uint16_t fg, uint16_t bg, int datum) = 0;
  virtual int  textWidth(const char *s, int font) = 0;
  virtual ~Gfx() {}
};

// ---------------------------------------------------------------- geometry
const int W = 240, H = 320;
const int TOPH = 30;                 // address bar
const int BOTY = 290, BOTH = 30;     // toolbar
const int CY = 31, CH = 256;         // page area
const int LH = 18, VIS = 14;         // line height, visible lines
const int PL = 6, PR = 230;          // text margins

// ---------------------------------------------------------------- font 2 widths
inline uint8_t *w2tab() { static uint8_t t[96]; return t; }
inline void initWidths(Gfx &g) {
  char s[2] = {0, 0};
  for (int i = 0; i < 96; ++i) { s[0] = (char)(32 + i); w2tab()[i] = (uint8_t)g.textWidth(s, 2); }
}
inline int width2(const char *s, int n, void *) {
  int w = 0;
  for (int i = 0; i < n; ++i) { unsigned c = (unsigned char)s[i]; w += w2tab()[(c >= 32 && c < 128) ? c - 32 : 0]; }
  return w;
}
inline int w2(const std::string &s) { return width2(s.data(), (int)s.size(), nullptr); }
inline std::string fitEnd(const std::string &s, int maxW) {
  if (w2(s) <= maxW) return s;
  std::string o = s;
  while (!o.empty() && w2(o + "...") > maxW) o.pop_back();
  return o + "...";
}
// word wrap with font 2 (used for messages / input box)
inline std::vector<std::string> wrap2(const std::string &s, int maxW, bool breakAnywhere) {
  std::vector<std::string> out;
  std::string line;
  size_t i = 0;
  while (i < s.size()) {
    if (s[i] == '\n') { out.push_back(line); line.clear(); ++i; continue; }
    if (breakAnywhere) {
      if (w2(line + s[i]) > maxW) { out.push_back(line); line.clear(); }
      line += s[i++];
      continue;
    }
    size_t j = i; while (j < s.size() && s[j] != ' ' && s[j] != '\n') ++j;
    std::string word = s.substr(i, j - i);
    std::string cand = line.empty() ? word : line + " " + word;
    if (w2(cand) <= maxW) line = cand;
    else {
      if (!line.empty()) out.push_back(line);
      line.clear();
      while (w2(word) > maxW) {                 // very long word
        size_t k = word.size(); while (k > 1 && w2(word.substr(0, k)) > maxW) --k;
        out.push_back(word.substr(0, k)); word = word.substr(k);
      }
      line = word;
    }
    i = j; if (i < s.size() && s[i] == ' ') ++i;
  }
  if (!line.empty() || out.empty()) out.push_back(line);
  return out;
}

// ---------------------------------------------------------------- small icons
inline void iconSearch(Gfx &g, int x, int y, uint16_t c) {        // magnifier centred near (x,y)
  g.circle(x - 2, y - 2, 5, c); g.circle(x - 2, y - 2, 4, c);
  g.line(x + 2, y + 2, x + 6, y + 6, c); g.line(x + 3, y + 2, x + 6, y + 5, c);
}
inline void iconX(Gfx &g, int cx, int cy, int r, uint16_t c) {
  g.line(cx - r, cy - r, cx + r, cy + r, c); g.line(cx - r + 1, cy - r, cx + r, cy + r - 1, c);
  g.line(cx + r, cy - r, cx - r, cy + r, c); g.line(cx + r - 1, cy - r, cx - r, cy + r - 1, c);
}

// ---------------------------------------------------------------- top bar
const int PILLX = 4, PILLY = 4, PILLW = 194, PILLH = 22;
const int EXX = 202, EXW = 34;
inline void drawTopBar(Gfx &g, const std::string &addr, bool placeholder) {
  g.fillRect(0, 0, W, TOPH - 1, BAR);
  g.hline(0, TOPH - 1, W, BARLINE);
  g.fillRoundRect(PILLX, PILLY, PILLW, PILLH, 11, PILL);
  iconSearch(g, 16, 15, DIM);
  g.text(fitEnd(addr, PILLW - 36).c_str(), 28, 15, 2, placeholder ? DIM : TEXT, PILL, DML);
  g.fillRoundRect(EXX, PILLY, EXW, PILLH, 6, EXITC);
  iconX(g, EXX + EXW / 2, 15, 5, WHITE);
}
inline void drawProgress(Gfx &g, int frac1000) {                    // thin bar under the address bar
  int w = W * (frac1000 < 0 ? 0 : frac1000 > 1000 ? 1000 : frac1000) / 1000;
  g.hline(0, TOPH - 1, w, FROG); g.hline(w, TOPH - 1, W - w, BARLINE);
}
inline bool hitAddress(int x, int y) { return y < TOPH + 2 && x < EXX - 2; }
inline bool hitExit(int x, int y) { return y < TOPH + 2 && x >= EXX - 4; }

// ---------------------------------------------------------------- toolbar
enum { TB_BACK = 0, TB_HOME, TB_UP, TB_DOWN, TB_LAST };     // TB_LAST = reload / flip
inline void drawToolButton(Gfx &g, int i, bool enabled, bool lastIsFlip, bool pressed) {
  int x = i * 48, y = BOTY;
  uint16_t bg = pressed ? PILL : BAR, c = enabled ? TEXT : rgb(70, 76, 98);
  g.fillRect(x, y, 48, BOTH, bg);
  int cx = x + 24, cy = y + 11;
  const char *lab = "";
  switch (i) {
    case TB_BACK:
      g.line(cx + 3, cy - 6, cx - 3, cy, c); g.line(cx - 3, cy, cx + 3, cy + 6, c);
      g.line(cx + 4, cy - 6, cx - 2, cy, c); g.line(cx - 2, cy, cx + 4, cy + 6, c);
      lab = "Back"; break;
    case TB_HOME:
      g.fillTriangle(cx - 8, cy - 1, cx, cy - 8, cx + 8, cy - 1, c);
      g.fillRect(cx - 5, cy - 1, 11, 8, c); g.fillRect(cx - 1, cy + 2, 3, 5, bg);
      lab = "Home"; break;
    case TB_UP:
      g.line(cx - 6, cy + 3, cx, cy - 3, c); g.line(cx, cy - 3, cx + 6, cy + 3, c);
      g.line(cx - 6, cy + 4, cx, cy - 2, c); g.line(cx, cy - 2, cx + 6, cy + 4, c);
      lab = "Up"; break;
    case TB_DOWN:
      g.line(cx - 6, cy - 3, cx, cy + 3, c); g.line(cx, cy + 3, cx + 6, cy - 3, c);
      g.line(cx - 6, cy - 2, cx, cy + 4, c); g.line(cx, cy + 4, cx + 6, cy - 2, c);
      lab = "Down"; break;
    default:
      if (lastIsFlip) {                       // two arrows: rotate 180
        g.line(cx - 6, cy - 3, cx + 6, cy - 3, c); g.fillTriangle(cx + 6, cy - 6, cx + 9, cy - 3, cx + 6, cy, c);
        g.line(cx - 6, cy + 4, cx + 6, cy + 4, c); g.fillTriangle(cx - 6, cy + 1, cx - 9, cy + 4, cx - 6, cy + 7, c);
        lab = "Flip";
      } else {                                // reload: circle with an arrow head
        g.circle(cx, cy, 6, c); g.circle(cx, cy, 5, c);
        g.fillRect(cx + 1, cy - 7, 7, 6, bg);
        g.fillTriangle(cx + 1, cy - 9, cx + 6, cy - 5, cx + 1, cy - 1, c);
        lab = "Reload";
      }
  }
  g.text(lab, cx, y + 25, 1, c, bg, DMC);
}
inline void drawToolbar(Gfx &g, bool canBack, bool canScroll, bool lastIsFlip, bool lastEnabled = true) {
  g.hline(0, BOTY - 1, W, BARLINE);
  for (int i = 0; i < 5; ++i)
    drawToolButton(g, i, i == TB_BACK ? canBack : (i == TB_UP || i == TB_DOWN) ? canScroll : i == TB_LAST ? lastEnabled : true,
                   lastIsFlip, false);
}
inline int hitToolbar(int x, int y) { if (y < BOTY - 2) return -1; int i = x / 48; return i < 0 ? 0 : i > 4 ? 4 : i; }

// ---------------------------------------------------------------- page
inline uint16_t segColor(uint8_t f) {
  if (f & ffc::F_LINK) return LINK;
  if (f & ffc::F_HEAD) return HEAD;
  if (f & ffc::F_RED) return RED;
  if (f & ffc::F_GREEN) return GREEN;
  if (f & ffc::F_BOLD) return WHITE;
  return TEXT;
}
inline void drawSeg(Gfx &g, const ffc::Doc &d, int si, int y, bool hl) {
  const ffc::Seg &s = d.segs[si];
  if (s.flags & ffc::F_HR) { g.hline(PL, y + 8, PR - PL, HR); g.hline(PL, y + 9, PR - PL, HR); return; }
  char buf[260];
  memcpy(buf, d.pool + s.off, s.len); buf[s.len] = 0;
  uint16_t fg = segColor(s.flags), bg = BG;
  if (hl) { fg = BLACK; bg = SEL; }
  int w = width2(buf, s.len, nullptr);
  if (hl) g.fillRect(s.x - 1, y, w + 2, LH, SEL);
  g.text(buf, s.x, y + 1, 2, fg, bg, DTL);
  if (s.flags & (ffc::F_BOLD | ffc::F_HEAD)) g.text(buf, s.x + 1, y + 1, 2, fg, fg, DTL);   // faux bold
  if (s.flags & ffc::F_LINK) g.hline(s.x, y + 16, w, hl ? BLACK : rgb(70, 110, 170));
}
inline int totalLines(const ffc::Doc &d, bool nextPart) { return d.lines + (nextPart ? 2 : 0); }
inline void drawPageRow(Gfx &g, const ffc::Doc &d, int top, int r, int hlSeg, bool nextPart) {
  int l = top + r, y = CY + r * LH;
  g.fillRect(0, y, W - 6, LH, BG);
  if (l < d.lines) {
    int f, n = d.segsOnLine(l, f);
    for (int k = 0; k < n; ++k) drawSeg(g, d, f + k, y, f + k == hlSeg);
  } else if (nextPart && l == d.lines + 1) {
    g.fillRoundRect(PL, y + 1, PR - PL, LH - 2, 6, hlSeg == -2 ? SEL : PILL);
    g.text("Long page - tap for the next part >", W / 2 - 3, y + 9, 1, hlSeg == -2 ? BLACK : LINK, hlSeg == -2 ? SEL : PILL, DMC);
  }
}
inline void drawScrollbar(Gfx &g, int top, int total) {
  g.fillRect(W - 6, CY, 6, CH, BG);
  if (total <= VIS) return;
  int th = std::max(18, CH * VIS / total);
  int ty = CY + (CH - th) * top / std::max(1, total - VIS);
  g.fillRoundRect(W - 5, ty, 4, th, 2, rgb(90, 100, 128));
}
inline void drawPage(Gfx &g, const ffc::Doc &d, int top, int hlSeg, bool nextPart) {
  for (int r = 0; r < VIS; ++r) drawPageRow(g, d, top, r, hlSeg, nextPart);
  g.fillRect(0, CY + VIS * LH, W - 6, CH - VIS * LH, BG);
  drawScrollbar(g, top, totalLines(d, nextPart));
}
// link under a tap: returns link index, -2 for "next part", -1 none; seg index in segOut
inline int linkAt(const ffc::Doc &d, int top, int x, int y, bool nextPart, int &segOut) {
  segOut = -1;
  if (y < CY || y >= CY + CH) return -1;
  int r = (y - CY) / LH, within = (y - CY) % LH;
  int cand[3] = {top + r, within < 6 ? top + r - 1 : top + r + 1, -1};
  if (within >= 6 && within < LH - 6) cand[1] = -1;
  for (int ci = 0; ci < 2; ++ci) {
    int l = cand[ci];
    if (l < 0) continue;
    if (nextPart && l == d.lines + 1) { segOut = -2; return -2; }
    if (l >= d.lines) continue;
    int f, n = d.segsOnLine(l, f);
    int best = -1, bestD = 9999;
    for (int k = 0; k < n; ++k) {
      const ffc::Seg &s = d.segs[f + k];
      if (s.link < 0) continue;
      int w = width2(d.pool + s.off, s.len, nullptr);
      int dx = x < s.x ? s.x - x : x > s.x + w ? x - (s.x + w) : 0;
      if (dx <= 8 && dx < bestD) { bestD = dx; best = f + k; }
    }
    if (best >= 0) { segOut = best; return d.segs[best].link; }
  }
  return -1;
}

// ---------------------------------------------------------------- messages
inline void drawMessage(Gfx &g, const std::string &title, const std::string &body, uint16_t col) {
  g.fillRect(0, CY, W, CH, BG);
  g.text(title.c_str(), W / 2, CY + 92, 2, col, BG, DMC);
  auto lines = wrap2(body, 214, false);
  int y = CY + 116;
  for (auto &l : lines) { if (y > CY + CH - 18) break; g.text(l.c_str(), W / 2, y, 2, DIM, BG, DMC); y += 18; }
}
inline void drawLoading(Gfx &g, const std::string &what, const std::string &detail) {
  g.fillRect(0, CY, W, CH, BG);
  // little frog hop
  g.fillCircle(W / 2, CY + 70, 16, FROG);
  g.fillCircle(W / 2 - 9, CY + 56, 7, FROG); g.fillCircle(W / 2 + 9, CY + 56, 7, FROG);
  g.fillCircle(W / 2 - 9, CY + 56, 4, WHITE); g.fillCircle(W / 2 + 9, CY + 56, 4, WHITE);
  g.fillCircle(W / 2 - 8, CY + 57, 2, BLACK); g.fillCircle(W / 2 + 10, CY + 57, 2, BLACK);
  g.text(what.c_str(), W / 2, CY + 110, 2, TEXT, BG, DMC);
  std::string det = detail.size() > 105 ? detail.substr(0, 102) + "..." : detail;
  int y = CY + 134;
  for (size_t i = 0; i < det.size() && y < CY + 160; i += 35) { g.text(det.substr(i, 35).c_str(), W / 2, y, 1, DIM, BG, DMC); y += 12; }
}

// ---------------------------------------------------------------- home
const int SBX = 14, SBY = 140, SBW = 212, SBH = 34;     // search box
const int RECY = 200, RECH = 20;                        // recent rows
inline void drawFrogLogo(Gfx &g, int cx, int cy) {
  g.fillCircle(cx, cy + 6, 22, FROG);
  g.fillCircle(cx - 13, cy - 13, 10, FROG); g.fillCircle(cx + 13, cy - 13, 10, FROG);
  g.fillCircle(cx - 13, cy - 13, 7, WHITE); g.fillCircle(cx + 13, cy - 13, 7, WHITE);
  g.fillCircle(cx - 12, cy - 12, 3, BLACK); g.fillCircle(cx + 14, cy - 12, 3, BLACK);
  g.line(cx - 11, cy + 10, cx - 4, cy + 14, FROGD); g.line(cx - 4, cy + 14, cx + 4, cy + 14, FROGD);
  g.line(cx + 4, cy + 14, cx + 11, cy + 10, FROGD);
  g.fillCircle(cx - 15, cy + 5, 3, rgb(120, 230, 130)); g.fillCircle(cx + 15, cy + 5, 3, rgb(120, 230, 130));
}
inline void drawHome(Gfx &g, const std::vector<std::string> &recent, bool wifiOk) {
  g.fillRect(0, TOPH, W, BOTY - 1 - TOPH, BG);
  drawFrogLogo(g, W / 2, 66);
  int wF = g.textWidth("Frog", 4), wT = wF + g.textWidth("Find!", 4);
  int x0 = W / 2 - wT / 2;
  g.text("Frog", x0, 98, 4, FROG, BG, DTL);
  g.text("Find!", x0 + wF, 98, 4, WHITE, BG, DTL);
  g.text("search engine for vintage computers", W / 2, 129, 1, DIM, BG, DMC);
  g.fillRoundRect(SBX, SBY, SBW, SBH, SBH / 2, PILL);
  iconSearch(g, SBX + 20, SBY + SBH / 2, TEXT);
  g.text("Search or type a URL", SBX + 34, SBY + SBH / 2, 2, DIM, PILL, DML);
  if (!wifiOk) g.text("WiFi joins when you search", W / 2, SBY + SBH + 9, 1, DIM, BG, DMC);
  if (recent.empty()) {
    g.text("Try: esp32 pinout   |   wikipedia.org", W / 2, RECY + 20, 1, DIM, BG, DMC);
    g.text("Tap a result to read it, drag to scroll.", W / 2, RECY + 36, 1, DIM, BG, DMC);
  } else {
    g.text("RECENT", SBX + 4, RECY - 4, 1, DIM, BG, DTL);
    for (size_t i = 0; i < recent.size() && i < 4; ++i) {
      int y = RECY + 6 + (int)i * RECH;
      iconSearch(g, SBX + 10, y + 9, DIM);
      g.text(fitEnd(recent[i], 190).c_str(), SBX + 24, y + 1, 2, TEXT, BG, DTL);
    }
  }
}
inline bool hitSearchBox(int x, int y) { return x >= SBX - 4 && x < SBX + SBW + 4 && y >= SBY - 6 && y < SBY + SBH + 6; }
inline int hitRecent(int x, int y, int n) {
  if (y < RECY + 6 || x < SBX - 4 || x > SBX + SBW + 4) return -1;
  int i = (y - RECY - 6) / RECH;
  return (i >= 0 && i < n && i < 4) ? i : -1;
}

// ---------------------------------------------------------------- keyboard screen
struct Kb {
  int layer = ffc::LAYER_ABC;
  bool upper = false, caps = false;
  int pressed = -1;                       // key index under the finger
  std::string text, prompt;
  ffc::KKey keys[48]; int n = 0;
  void build() { n = ffc::kbBuild(layer, upper, keys); }
};
const int INX = 6, INY = 36, INW = 228, INH = 96;
inline bool hitCancel(int x, int y) { return y < TOPH + 2 && x < 74; }
inline void drawKbHeader(Gfx &g, const Kb &k) {
  g.fillRect(0, 0, W, TOPH - 1, BAR);
  g.hline(0, TOPH - 1, W, BARLINE);
  g.fillRoundRect(4, 4, 66, 22, 11, PILL);
  g.text("Cancel", 37, 15, 2, TEXT, PILL, DMC);
  g.text(fitEnd(k.prompt, 150).c_str(), 155, 15, 2, WHITE, BAR, DMC);
}
inline void drawKbInput(Gfx &g, const Kb &k) {
  g.fillRect(0, TOPH, W, ffc::KB_Y0 - TOPH, BG);
  g.fillRoundRect(INX, INY, INW, INH, 10, PILL);
  const int lh = 18, maxLines = 5, tx = INX + 8, ty = INY + 4;
  if (k.text.empty()) {
    g.vline(tx, ty + 1, 16, SEL); g.vline(tx + 1, ty + 1, 16, SEL);
    g.text("Search words or a web address", tx + 6, ty, 2, DIM, PILL, DTL);
    return;
  }
  auto lines = wrap2(k.text, INW - 22, true);
  size_t first = lines.size() > (size_t)maxLines ? lines.size() - maxLines : 0;
  int y = ty;
  for (size_t i = first; i < lines.size(); ++i) { g.text(lines[i].c_str(), tx, y, 2, WHITE, PILL, DTL); y += lh; }
  int cx = tx + w2(lines.back()) + 1, cy = ty + (int)(lines.size() - 1 - first) * lh;
  g.vline(cx, cy + 1, 16, SEL); g.vline(cx + 1, cy + 1, 16, SEL);
  char cnt[16]; snprintf(cnt, sizeof(cnt), "%d", (int)k.text.size());
  g.text(cnt, INX + INW - 6, INY + INH - 8, 1, DIM, PILL, DMR);
}
inline bool keyIsChar(const ffc::KKey &q) { return q.code >= 33 && q.code < 127; }
inline int keyFont(Gfx &g, const ffc::KKey &q) { return g.textWidth(q.label, 4) <= q.w ? 4 : 2; }
inline void drawKey(Gfx &g, const Kb &k, int i, bool pressed) {
  const ffc::KKey &q = k.keys[i];
  bool special = q.code < 32 || q.code == ' ';
  uint16_t bg = special ? KEY2 : KEY;
  if (q.code == ffc::K_ENTER) bg = ENTER;
  if (q.code == ffc::K_SHIFT && (k.upper || k.caps)) bg = SHIFTON;
  if (pressed) bg = SEL;
  uint16_t fg = pressed ? BLACK : WHITE;
  g.fillRect(q.x, q.y, q.w, q.h, KBG);
  g.fillRoundRect(q.x + 1, q.y + 3, q.w - 2, q.h - 6, 5, bg);
  int cx = q.x + q.w / 2, cy = q.y + q.h / 2;
  if (q.code == ffc::K_SHIFT) {                                 // up arrow
    g.fillTriangle(cx - 7, cy, cx, cy - 8, cx + 7, cy, fg);
    g.fillRect(cx - 3, cy, 7, 6, fg);
    if (k.caps) g.fillRect(cx - 7, cy + 9, 15, 2, fg);           // caps lock bar
  } else if (q.code == ffc::K_BS) {                             // backspace
    g.line(cx - 9, cy, cx - 4, cy - 6, fg); g.line(cx - 9, cy, cx - 4, cy + 6, fg);
    g.hline(cx - 4, cy - 6, 13, fg); g.hline(cx - 4, cy + 6, 13, fg); g.vline(cx + 9, cy - 6, 13, fg);
    g.line(cx - 1, cy - 3, cx + 5, cy + 3, fg); g.line(cx + 5, cy - 3, cx - 1, cy + 3, fg);
  } else if (keyIsChar(q) && strlen(q.label) == 1) {
    // big font when the glyph fits the key (e.g. not '@'); drawn transparent so
    // only the letter's own pixels touch the key
    g.text(q.label, cx, cy + 1, keyFont(g, q), fg, fg, DMC);
  } else {
    g.text(q.label, cx, cy + 1, 2, fg, bg, DMC);
  }
}
inline void drawKeyboard(Gfx &g, Kb &k) {
  k.build();
  g.fillRect(0, ffc::KB_Y0, W, H - ffc::KB_Y0, KBG);
  for (int i = 0; i < k.n; ++i) drawKey(g, k, i, i == k.pressed);
}
// iPhone-style pop-up showing the letter under the finger
inline void bubbleRect(const ffc::KKey &q, int &bx, int &by, int &bw, int &bh) {
  bw = 42; bh = 50;
  bx = q.x + q.w / 2 - bw / 2; if (bx < 1) bx = 1; if (bx + bw > W - 1) bx = W - 1 - bw;
  by = q.y - bh + 2;
}
inline void drawBubble(Gfx &g, const Kb &k, int i) {
  const ffc::KKey &q = k.keys[i];
  if (!keyIsChar(q)) return;
  int bx, by, bw, bh; bubbleRect(q, bx, by, bw, bh);
  g.fillRoundRect(bx, by, bw, bh, 8, BUBBLE);
  g.drawRoundRect(bx, by, bw, bh, 8, SEL);
  g.text(q.label, bx + bw / 2, by + bh / 2, 4, BLACK, BUBBLE, DMC);
}
inline void drawKbScreen(Gfx &g, Kb &k) { drawKbHeader(g, k); drawKbInput(g, k); drawKeyboard(g, k); }

}  // namespace ffui
