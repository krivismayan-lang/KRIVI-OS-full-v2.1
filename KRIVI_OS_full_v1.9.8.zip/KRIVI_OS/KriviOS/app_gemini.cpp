// ============================================================================
//  KRIVI OS - AI Assistant (Google Gemini)                          app 87
//
//  Chat with Gemini over WiFi. Type a question on the on-screen keyboard; the
//  reply scrolls in the transcript. Keeps a short running context so it is a
//  real conversation, not one-shot questions.
//
//  Needs a free Gemini API key (https://aistudio.google.com/apikey). Store it
//  in /sys/settings.json as  "ai": { "key": "AIza...", "model": "gemini-1.5-flash" }
//  or set it in-app with the KEY button. Blank key => the app asks for one.
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <vector>

namespace {

struct Msg { bool user; String text; };
std::vector<Msg> g_log;                        // conversation (user + model turns)
const int MAXTURNS = 12;                        // cap history sent + kept

const int VX = 4, VY = 28, VW = 312, VH = 150;  // transcript viewport
const int CHARW = 6, LINEH = 10, COLS = VW / CHARW;   // font-1 metrics
int g_scroll = 0;                               // line offset from top

// escape a string for embedding in JSON
String jesc(const String &s) {
  String o; o.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); ++i) {
    char c = s[i];
    switch (c) {
      case '"': o += "\\\""; break; case '\\': o += "\\\\"; break;
      case '\n': o += "\\n"; break; case '\r': o += "\\r"; break;
      case '\t': o += "\\t"; break;
      default: if ((uint8_t)c < 0x20) { char b[8]; snprintf(b, sizeof(b), "\\u%04x", c); o += b; } else o += c;
    }
  }
  return o;
}

// word-wrap one message into display lines
void wrapInto(const String &t, std::vector<String> &out) {
  String line;
  int i = 0, n = t.length();
  while (i < n) {
    char c = t[i++];
    if (c == '\n') { out.push_back(line); line = ""; continue; }
    line += c;
    if ((int)line.length() >= COLS) {           // break at last space if possible
      int sp = line.lastIndexOf(' ');
      if (sp > COLS - 14 && sp > 0) { out.push_back(line.substring(0, sp)); line = line.substring(sp + 1); }
      else { out.push_back(line); line = ""; }
    }
  }
  if (line.length()) out.push_back(line);
}

// build the whole transcript as colour-tagged lines
void buildLines(std::vector<String> &lines, std::vector<uint8_t> &who) {
  for (auto &m : g_log) {
    std::vector<String> w; wrapInto(m.text, w);
    for (size_t k = 0; k < w.size(); ++k) { lines.push_back((k == 0 ? (m.user ? "> " : "* ") : "  ") + w[k]); who.push_back(m.user ? 1 : 0); }
    lines.push_back(""); who.push_back(2);
  }
}

const char *apiKey() { return sys::cfg["ai"]["key"] | ""; }
const char *apiModel() { return sys::cfg["ai"]["model"] | "gemini-1.5-flash"; }

// call Gemini; returns the reply text, or an error string prefixed with "!"
String ask(const String &question) {
  WiFiClientSecure cl; cl.setInsecure();
  HTTPClient http; http.setTimeout(20000);
  char url[200];
  snprintf(url, sizeof(url), "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", apiModel(), apiKey());
  if (!http.begin(cl, url)) return "!connection failed";
  http.addHeader("Content-Type", "application/json");

  // body: short rolling history + this question
  String body = "{\"contents\":[";
  int start = (int)g_log.size() - (MAXTURNS - 1); if (start < 0) start = 0;
  // ensure the first sent turn is a user turn (Gemini requires it)
  while (start < (int)g_log.size() && !g_log[start].user) start++;
  bool first = true;
  for (int i = start; i < (int)g_log.size(); ++i) {
    if (!first) body += ","; first = false;
    body += "{\"role\":\""; body += g_log[i].user ? "user" : "model"; body += "\",\"parts\":[{\"text\":\"" + jesc(g_log[i].text) + "\"}]}";
  }
  if (!first) body += ",";
  body += "{\"role\":\"user\",\"parts\":[{\"text\":\"" + jesc(question) + "\"}]}";
  body += "],\"generationConfig\":{\"maxOutputTokens\":500,\"temperature\":0.7}}";

  int code = http.POST(body);
  if (code <= 0) { http.end(); return String("!net error ") + code; }
  String resp = http.getString(); http.end();
  if (code != 200) {
    JsonDocument d; if (!deserializeJson(d, resp)) { const char *m = d["error"]["message"] | ""; if (*m) return String("!") + m; }
    return String("!HTTP ") + code;
  }
  JsonDocument d;
  if (deserializeJson(d, resp)) return "!bad response";
  JsonVariant t = d["candidates"][0]["content"]["parts"][0]["text"];
  if (t.isNull()) { const char *fr = d["candidates"][0]["finishReason"] | "no reply"; return String("!(") + fr + ")"; }
  return t.as<const char *>();
}

}  // namespace

void app_gemini(AppCtx &c) {
  const int BY = 202, BH = 34;

  auto drawTranscript = [&]() {
    tft.fillRect(VX, VY, VW, VH, C_BG);
    std::vector<String> lines; std::vector<uint8_t> who; buildLines(lines, who);
    int total = lines.size(), vis = VH / LINEH;
    if (g_scroll > total - vis) g_scroll = total - vis; if (g_scroll < 0) g_scroll = 0;
    for (int r = 0; r < vis && g_scroll + r < total; ++r) {
      int idx = g_scroll + r; uint16_t col = who[idx] == 1 ? C_ACCENT : who[idx] == 0 ? C_TEXT : C_DIM;
      tft.setTextColor(col, C_BG); tft.drawString(lines[idx], VX + 2, VY + r * LINEH, 1);
    }
    // scrollbar hint
    if (total > vis) { int bh = max(8, VH * vis / total); int by = VY + (VH - bh) * g_scroll / max(1, total - vis); tft.fillRect(VX + VW - 2, VY, 2, VH, C_PANEL); tft.fillRect(VX + VW - 2, by, 2, bh, C_PANEL2); }
  };
  auto status = [&](const char *s, uint16_t col) { tft.fillRect(0, 184, 320, 14, C_BG); tft.setTextColor(col, C_BG); tft.drawString(s, VX, 185, 1); };
  auto bar = [&]() {
    ui::button(2, BY, 150, BH, "ASK", C_OK, TFT_BLACK, 2);
    ui::button(156, BY, 36, BH, "UP", C_PANEL2, C_TEXT, 1);
    ui::button(196, BY, 36, BH, "DN", C_PANEL2, C_TEXT, 1);
    ui::button(236, BY, 40, BH, "KEY", C_PANEL2, C_TEXT, 1);
    ui::button(280, BY, 38, BH, "CLR", C_PANEL2, C_TEXT, 1);
  };
  auto redraw = [&](const char *st = nullptr, uint16_t col = C_DIM) { c.header(apiModel()); drawTranscript(); bar(); status(st ? st : (g_log.empty() ? "Tap ASK to chat with Gemini" : "Ready"), col); };

  // key check
  if (!*apiKey()) { ui::clearBody(); ui::centerText("No Gemini API key set", 160, 70, C_WARN, C_BG, 2); ui::centerText("Get a free key at aistudio.google.com/apikey", 160, 95, C_DIM, C_BG, 1); ui::centerText("then tap KEY to enter it", 160, 115, C_DIM, C_BG, 1); }
  redraw();

  auto setKey = [&]() {
    String k = apiKey();
    if (ui::textInput(k, "Paste your Gemini API key", 60, false)) { sys::cfg["ai"]["key"] = k; sys::saveSettings(); ui::toast(k.length() ? "key saved" : "key cleared", C_OK); }
    c.header(apiModel()); redraw();
  };

  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    int vis = VH / LINEH;
    if (ui::inRect(t.sx, t.sy, 2, BY, 150, BH)) {              // ASK
      if (!*apiKey()) { setKey(); if (!*apiKey()) continue; }
      String q = "";
      if (!ui::textInput(q, "Ask Gemini", 180, false) || !q.length()) { redraw(); continue; }
      g_log.push_back({true, q});
      while ((int)g_log.size() > MAXTURNS) g_log.erase(g_log.begin());
      g_scroll = 99999; redraw("Thinking...", C_WARN);
      if (!sys::wifiConnect(15000, false)) { status("WiFi failed - check Settings", C_ERR); continue; }
      String r = ask(q);
      sys::radiosOff();
      bool err = r.startsWith("!");
      g_log.push_back({false, err ? (String("[error] ") + r.substring(1)) : r});
      while ((int)g_log.size() > MAXTURNS) g_log.erase(g_log.begin());
      g_scroll = 99999; redraw(err ? "Error - see above" : "Ready", err ? C_ERR : C_OK);
    }
    else if (ui::inRect(t.sx, t.sy, 156, BY, 36, BH)) { g_scroll -= vis - 1; if (g_scroll < 0) g_scroll = 0; drawTranscript(); }
    else if (ui::inRect(t.sx, t.sy, 196, BY, 36, BH)) { g_scroll += vis - 1; drawTranscript(); }
    else if (ui::inRect(t.sx, t.sy, 236, BY, 40, BH)) { setKey(); }
    else if (ui::inRect(t.sx, t.sy, 280, BY, 38, BH)) { if (ui::confirm("CLEAR", "Erase this conversation?")) { g_log.clear(); g_scroll = 0; } redraw(); }
  }
}
