// ============================================================================
//  KRIVI OS - OTA Update  (flash new firmware over WiFi, no cable)         app
//
//  Connects to WiFi, runs a tiny web server, and shows its address. Open that
//  address in a browser on the same network, pick a KRIVI .bin (the app image
//  from prebuilt/, i.e. KriviOS.ino.bin - NOT the merged offset-0 image), and
//  upload it. The device flashes it to the spare OTA slot and reboots into it.
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Update.h>
#include <esp_ota_ops.h>

namespace ota {

static WebServer *srv = nullptr;
static volatile int  g_pct = -1;         // upload progress %
static volatile bool g_done = false, g_fail = false;

static const char *PAGE =
  "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
  "<title>KRIVI OS Update</title><style>body{font-family:sans-serif;background:#101418;color:#e6ebf2;"
  "max-width:520px;margin:40px auto;padding:0 16px}h1{color:#00c8ff}input[type=file]{margin:14px 0}"
  "button{background:#00c8ff;border:0;color:#002;padding:12px 20px;border-radius:8px;font-size:16px}"
  ".card{background:#1a2028;padding:20px;border-radius:12px}</style></head><body>"
  "<h1>KRIVI OS &mdash; OTA Update</h1><div class=card>"
  "<p>Select the firmware <b>app image</b> (<code>KriviOS.ino.bin</code>) and upload. "
  "The device will flash it and reboot.</p>"
  "<form method='POST' action='/update' enctype='multipart/form-data'>"
  "<input type='file' name='fw' accept='.bin' required><br><button type='submit'>Flash &amp; reboot</button>"
  "</form></div></body></html>";

static void handleRoot() { srv->send(200, "text/html", PAGE); }

static void handleUpdateDone() {
  bool ok = !Update.hasError() && !g_fail;
  srv->send(200, "text/html", ok ?
    "<html><body style='font-family:sans-serif;background:#101418;color:#9f9'><h2>Flashed OK - rebooting...</h2></body></html>" :
    "<html><body style='font-family:sans-serif;background:#101418;color:#f99'><h2>Update FAILED</h2></body></html>");
  g_done = true; g_fail = !ok;
}

static void handleUpload() {
  HTTPUpload &up = srv->upload();
  if (up.status == UPLOAD_FILE_START) {
    g_pct = 0; g_fail = false;
    if (!Update.begin(UPDATE_SIZE_UNKNOWN)) g_fail = true;
  } else if (up.status == UPLOAD_FILE_WRITE) {
    if (!g_fail && Update.write(up.buf, up.currentSize) != up.currentSize) g_fail = true;
    g_pct = Update.size() ? (int)(Update.progress() * 100 / Update.size()) : 0;
  } else if (up.status == UPLOAD_FILE_END) {
    if (!g_fail && !Update.end(true)) g_fail = true;
    g_pct = 100;
  }
}

}  // namespace ota

void app_ota(AppCtx &c) {
  using namespace ota;
  c.header("OTA Update");
  ui::clearBody();

  // True over-the-air updating needs a spare app (OTA) partition to flash into.
  // On a 4 MB CYD the full KRIVI image (~2.2 MB) is too big to keep two copies,
  // so this build uses a single-app layout and OTA isn't available here. Say so
  // plainly instead of failing mid-upload.
  if (esp_ota_get_next_update_partition(nullptr) == nullptr) {
    ui::msgBox("OTA UPDATE",
      "No OTA partition on this board.\n\n"
      "KRIVI is ~2.2 MB and a 4 MB CYD can't hold two copies, so updates here "
      "are done over USB (or from the SD card). OTA needs an 8/16 MB CYD or a "
      "slimmed build.");
    return;
  }

  ui::centerText("Joining WiFi...", 160, 110, C_WARN, C_BG, 2);
  if (!sys::wifiConnect(15000, false)) {
    c.header("OTA Update");
    ui::msgBox("OTA UPDATE", "WiFi connection failed.\nSet up WiFi in System Settings first.");
    sys::radiosOff(); return;
  }

  srv = new WebServer(80);
  srv->on("/", HTTP_GET, handleRoot);
  srv->on("/update", HTTP_POST, handleUpdateDone, handleUpload);
  srv->begin();

  String ip = WiFi.localIP().toString();
  ui::clearBody();
  ui::centerText("Ready for update", 160, 44, C_OK, C_BG, 2);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(C_DIM, C_BG); tft.drawString("On a browser on the same WiFi, open:", 160, 84, 1);
  tft.setTextColor(C_ACCENT, C_BG); tft.drawString(String("http://") + ip + "/", 160, 112, 4);
  tft.setTextColor(C_DIM, C_BG); tft.drawString("then upload KriviOS.ino.bin", 160, 150, 2);
  tft.drawString("waiting for upload...", 160, 182, 2);
  tft.setTextDatum(TL_DATUM);

  int shown = -1;
  while (c.loop()) {
    srv->handleClient();
    if (g_pct != shown) {
      shown = g_pct;
      if (g_pct >= 0) { tft.fillRect(0, 170, 320, 30, C_BG); ui::bar(30, 176, 260, 14, g_pct / 100.0f, C_ACCENT, C_PANEL);
        tft.setTextDatum(MC_DATUM); tft.setTextColor(C_TEXT, C_BG); char s[16]; snprintf(s, 16, "flashing %d%%", g_pct); tft.drawString(s, 160, 206, 2); tft.setTextDatum(TL_DATUM); }
    }
    if (g_done) {
      srv->stop(); delay(300);
      if (!g_fail) { ui::clearBody(); ui::centerText("Update complete", 160, 100, C_OK, C_BG, 4); ui::centerText("rebooting...", 160, 140, C_DIM, C_BG, 2); delay(1200); ESP.restart(); }
      else { ui::msgBox("OTA UPDATE", "Update failed - firmware unchanged."); break; }
    }
    delay(2);
  }
  if (srv) { srv->stop(); delete srv; srv = nullptr; }
  sys::radiosOff();
}
