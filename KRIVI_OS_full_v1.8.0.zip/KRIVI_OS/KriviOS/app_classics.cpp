// ============================================================================
//  KRIVI OS - Arcade classics (launched from the Arcade hub, app 80)
//    2048 . Connect Four . Checkers . Reversi . Simon . Sudoku .
//    Solitaire (Klondike) . Space Invaders
//  All draw straight to the screen (no frame buffers) so they are RAM-light.
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  2048
// ============================================================================
void g2048(AppCtx &c) {
  int g[4][4]; memset(g, 0, sizeof g);
  long score = 0;
  const int CELL = 54, OX = (320 - 4 * CELL) / 2, OY = 30;
  auto spawn = [&]() { int e[16], n = 0; for (int i = 0; i < 16; i++) if (!g[i / 4][i % 4]) e[n++] = i; if (n) { int p = e[rnd(n)]; g[p / 4][p % 4] = rnd(10) ? 2 : 4; } };
  auto colOf = [&](int v) -> uint16_t { switch (v) { case 2: return RGB565(238,228,218); case 4: return RGB565(237,224,200); case 8: return RGB565(242,177,121); case 16: return RGB565(245,149,99); case 32: return RGB565(246,124,95); case 64: return RGB565(246,94,59); case 128: return RGB565(237,207,114); case 256: return RGB565(237,204,97); case 512: return RGB565(237,200,80); case 1024: return RGB565(237,197,63); default: return RGB565(237,194,46); } };
  auto draw = [&]() {
    c.header("2048"); ui::clearBody();
    tft.fillRoundRect(OX - 5, OY - 5, 4 * CELL + 10, 4 * CELL + 10, 6, RGB565(120,110,100));
    for (int r = 0; r < 4; r++) for (int cc = 0; cc < 4; cc++) {
      int x = OX + cc * CELL, y = OY + r * CELL, v = g[r][cc];
      tft.fillRoundRect(x + 2, y + 2, CELL - 4, CELL - 4, 4, v ? colOf(v) : RGB565(185,173,161));
      if (v) { char s[8]; snprintf(s, 8, "%d", v); tft.setTextColor(v <= 4 ? RGB565(119,110,101) : TFT_WHITE, colOf(v)); tft.setTextDatum(MC_DATUM); tft.drawString(s, x + CELL / 2, y + CELL / 2, v < 128 ? 4 : 2); }
    }
    tft.setTextDatum(TL_DATUM);
    char s[24]; snprintf(s, 24, "Score %ld", score);
    tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 10, OY + 4 * CELL + 10, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("swipe to move", 190, OY + 4 * CELL + 12, 1);
  };
  auto cellRC = [&](int dir, int k, int i, int &r, int &cc) { if (dir == 3) { r = k; cc = i; } else if (dir == 1) { r = k; cc = 3 - i; } else if (dir == 0) { r = i; cc = k; } else { r = 3 - i; cc = k; } };
  auto slide = [&](int dir) -> bool {          // 0 up 1 right 2 down 3 left
    bool moved = false;
    for (int k = 0; k < 4; k++) {
      int line[4], n = 0;
      for (int i = 0; i < 4; i++) { int r, cc; cellRC(dir, k, i, r, cc); if (g[r][cc]) line[n++] = g[r][cc]; }
      int out[4], m = 0;
      for (int i = 0; i < n; i++) { if (i + 1 < n && line[i] == line[i + 1]) { out[m++] = line[i] * 2; score += line[i] * 2; i++; } else out[m++] = line[i]; }
      for (int i = 0; i < 4; i++) { int v = i < m ? out[i] : 0, r, cc; cellRC(dir, k, i, r, cc); if (g[r][cc] != v) { moved = true; g[r][cc] = v; } }
    }
    return moved;
  };
  auto canMove = [&]() -> bool { for (int r = 0; r < 4; r++) for (int cc = 0; cc < 4; cc++) { if (!g[r][cc]) return true; if (cc < 3 && g[r][cc] == g[r][cc + 1]) return true; if (r < 3 && g[r][cc] == g[r + 1][cc]) return true; } return false; };
  spawn(); spawn(); draw();
  while (c.loop()) {
    Touch &t = *c.t; int dir = -1;
    if (t.swipe == SW_UP) dir = 0; else if (t.swipe == SW_RIGHT) dir = 1; else if (t.swipe == SW_DOWN) dir = 2; else if (t.swipe == SW_LEFT) dir = 3;
    if (dir >= 0) { if (slide(dir)) { spawn(); draw(); audio::click(); if (!canMove()) { char m[24]; snprintf(m, 24, "Score %ld", score); banner("GAME OVER", m, C_ERR); waitTap(c); memset(g, 0, sizeof g); score = 0; spawn(); spawn(); draw(); } } }
  }
}

// ============================================================================
//  Connect Four  (2 players, or vs a simple AI)
// ============================================================================
void gc4(AppCtx &c) {
  // ask mode
  c.header("Connect Four"); ui::clearBody();
  ui::centerText("Opponent?", 160, 70, C_TEXT, C_BG, 2);
  ui::button(40, 110, 110, 60, "BOT", C_PANEL2, C_TEXT, 2);
  ui::button(170, 110, 110, 60, "2 PLAYER", C_PANEL2, C_TEXT, 2);
  int vsBot = -1;
  while (c.loop() && vsBot < 0) { Touch &t = *c.t; if (!t.tap) continue; if (ui::inRect(t.sx, t.sy, 40, 110, 110, 60)) vsBot = 1; else if (ui::inRect(t.sx, t.sy, 170, 110, 110, 60)) vsBot = 0; }
  if (vsBot < 0) return;

  const int ROWS = 6, COLS = 7, CS = 30, OX = (320 - COLS * CS) / 2, OY = 36;
  int b[ROWS][COLS]; memset(b, 0, sizeof b);     // 0 empty, 1 red, 2 yellow
  int turn = 1;
  auto col = [&](int v) -> uint16_t { return v == 1 ? RGB565(230,60,60) : v == 2 ? RGB565(240,210,60) : RGB565(20,30,70); };
  auto draw = [&]() {
    c.header("Connect Four"); ui::clearBody();
    tft.fillRoundRect(OX - 4, OY - 4, COLS * CS + 8, ROWS * CS + 8, 6, RGB565(30,60,160));
    for (int r = 0; r < ROWS; r++) for (int cc = 0; cc < COLS; cc++) tft.fillCircle(OX + cc * CS + CS / 2, OY + r * CS + CS / 2, CS / 2 - 3, col(b[r][cc]));
    tft.fillCircle(14, OY + ROWS * CS + 24, 8, col(turn));
    tft.setTextColor(C_TEXT, C_BG); tft.setTextDatum(TL_DATUM);
    tft.drawString(turn == 1 ? "Red's turn - tap a column" : (vsBot ? "Bot thinking..." : "Yellow's turn"), 30, OY + ROWS * CS + 16, 2);
  };
  auto drop = [&](int cc, int who) -> int { for (int r = ROWS - 1; r >= 0; r--) if (!b[r][cc]) { b[r][cc] = who; return r; } return -1; };
  auto wins = [&](int who) -> bool {
    for (int r = 0; r < ROWS; r++) for (int cc = 0; cc < COLS; cc++) {
      if (b[r][cc] != who) continue;
      const int D[4][2] = { {0,1},{1,0},{1,1},{1,-1} };
      for (int d = 0; d < 4; d++) { int k = 1; for (; k < 4; k++) { int nr = r + D[d][0] * k, nc = cc + D[d][1] * k; if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS || b[nr][nc] != who) break; } if (k == 4) return true; }
    }
    return false;
  };
  auto full = [&]() -> bool { for (int cc = 0; cc < COLS; cc++) if (!b[0][cc]) return false; return true; };
  auto botMove = [&]() -> int {
    // win if possible, else block, else center-ish
    for (int who = 2; who >= 1; who--) for (int cc = 0; cc < COLS; cc++) { int r = drop(cc, who); if (r >= 0) { bool w = wins(who); b[r][cc] = 0; if (w) return cc; } }
    int order[7] = {3,2,4,1,5,0,6}; for (int i = 0; i < 7; i++) if (!b[0][order[i]]) return order[i]; return 0;
  };
  draw();
  while (c.loop()) {
    int move = -1;
    if (vsBot && turn == 2) { delay(400); move = botMove(); }
    else { Touch &t = *c.t; if (!t.tap || t.sy < OY || t.sy > OY + ROWS * CS) continue; move = (t.sx - OX) / CS; if (move < 0 || move >= COLS) continue; }
    int r = drop(move, turn); if (r < 0) continue;
    audio::beep(600 + turn * 200, 40); draw();
    if (wins(turn)) { banner(turn == 1 ? "RED WINS" : "YELLOW WINS", "tap to play again", turn == 1 ? C_ERR : C_WARN); waitTap(c); memset(b, 0, sizeof b); turn = 1; draw(); continue; }
    if (full()) { banner("DRAW", "tap to play again", C_DIM); waitTap(c); memset(b, 0, sizeof b); turn = 1; draw(); continue; }
    turn = 3 - turn; draw();
  }
}

// ============================================================================
//  Checkers / Draughts  (2 players, pass-and-play)
// ============================================================================
void gcheckers(AppCtx &c) {
  const int N = 8, CS = 26, OX = (320 - N * CS) / 2, OY = 30;
  // 0 empty, 1 red man, 2 red king, 3 white man, 4 white king
  int b[8][8]; memset(b, 0, sizeof b);
  for (int r = 0; r < 3; r++) for (int cc = 0; cc < 8; cc++) if ((r + cc) & 1) b[r][cc] = 3;     // white top
  for (int r = 5; r < 8; r++) for (int cc = 0; cc < 8; cc++) if ((r + cc) & 1) b[r][cc] = 1;     // red bottom
  int turn = 1;                                   // 1 = red (bottom), moves up
  int sel = -1;                                   // selected square = r*8+cc
  auto isRed = [&](int v) { return v == 1 || v == 2; };
  auto isWhite = [&](int v) { return v == 3 || v == 4; };
  auto mine = [&](int v) { return turn == 1 ? isRed(v) : isWhite(v); };
  auto draw = [&]() {
    c.header("Checkers"); ui::clearBody();
    for (int r = 0; r < 8; r++) for (int cc = 0; cc < 8; cc++) {
      int x = OX + cc * CS, y = OY + r * CS;
      tft.fillRect(x, y, CS, CS, ((r + cc) & 1) ? RGB565(90,60,40) : RGB565(205,175,130));
      int v = b[r][cc];
      if (v) { uint16_t pc = isRed(v) ? RGB565(220,50,50) : RGB565(235,235,235); tft.fillCircle(x + CS / 2, y + CS / 2, CS / 2 - 3, pc); tft.drawCircle(x + CS / 2, y + CS / 2, CS / 2 - 3, TFT_BLACK); if (v == 2 || v == 4) { tft.setTextColor(TFT_BLACK, pc); tft.setTextDatum(MC_DATUM); tft.drawString("K", x + CS / 2, y + CS / 2, 2); } }
      if (sel == r * 8 + cc) tft.drawRect(x + 1, y + 1, CS - 2, CS - 2, C_ACCENT);
    }
    tft.setTextDatum(TL_DATUM); tft.setTextColor(turn == 1 ? RGB565(220,50,50) : TFT_WHITE, C_BG);
    tft.drawString(turn == 1 ? "Red's move" : "White's move", 10, OY + 8 * CS + 6, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("tap piece then target", 150, OY + 8 * CS + 8, 1);
  };
  auto tryMove = [&](int fr, int fc, int tr, int tc) -> bool {
    if (tr < 0 || tr >= 8 || tc < 0 || tc >= 8 || b[tr][tc]) return false;
    int v = b[fr][fc]; int dr = tr - fr, dc = tc - fc;
    bool king = (v == 2 || v == 4);
    int fwd = isRed(v) ? -1 : 1;                  // red moves up (−), white down (+)
    if (abs(dc) == 1 && dr == fwd && !king) { b[tr][tc] = v; b[fr][fc] = 0; return true; }
    if (abs(dc) == 1 && abs(dr) == 1 && king) { b[tr][tc] = v; b[fr][fc] = 0; return true; }
    if (abs(dc) == 2 && abs(dr) == 2 && (king || dr == 2 * fwd)) {       // capture
      int mr = (fr + tr) / 2, mc = (fc + tc) / 2; int mv = b[mr][mc];
      if (mv && mine(v) ? (turn == 1 ? isWhite(mv) : isRed(mv)) : false) { b[tr][tc] = v; b[fr][fc] = 0; b[mr][mc] = 0; return true; }
    }
    return false;
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t; if (!t.tap) continue;
    if (t.sy < OY || t.sy >= OY + 8 * CS) continue;
    int cc = (t.sx - OX) / CS, r = (t.sy - OY) / CS; if (cc < 0 || cc >= 8) continue;
    int sq = r * 8 + cc;
    if (sel < 0) { if (mine(b[r][cc])) { sel = sq; draw(); } }
    else {
      int fr = sel / 8, fc = sel % 8;
      if (sq == sel) { sel = -1; draw(); continue; }
      if (tryMove(fr, fc, r, cc)) {
        if (turn == 1 && r == 0 && b[r][cc] == 1) b[r][cc] = 2;          // king me
        if (turn == 2 && r == 7 && b[r][cc] == 3) b[r][cc] = 4;
        audio::click(); turn = 3 - turn; sel = -1; draw();
      } else if (mine(b[r][cc])) { sel = sq; draw(); }
    }
  }
}

// ============================================================================
//  Reversi / Othello  (vs greedy AI, or 2 players)
// ============================================================================
void greversi(AppCtx &c) {
  c.header("Reversi"); ui::clearBody();
  ui::centerText("Opponent?", 160, 70, C_TEXT, C_BG, 2);
  ui::button(40, 110, 110, 60, "BOT", C_PANEL2, C_TEXT, 2);
  ui::button(170, 110, 110, 60, "2 PLAYER", C_PANEL2, C_TEXT, 2);
  int vsBot = -1;
  while (c.loop() && vsBot < 0) { Touch &t = *c.t; if (!t.tap) continue; if (ui::inRect(t.sx, t.sy, 40, 110, 110, 60)) vsBot = 1; else if (ui::inRect(t.sx, t.sy, 170, 110, 110, 60)) vsBot = 0; }
  if (vsBot < 0) return;

  const int CS = 26, OX = (320 - 8 * CS) / 2, OY = 30;
  int b[8][8]; memset(b, 0, sizeof b);            // 0 empty 1 black 2 white
  b[3][3] = b[4][4] = 2; b[3][4] = b[4][3] = 1;
  int turn = 1;                                   // black (human) first
  const int D[8][2] = { {-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1} };
  auto flips = [&](int r, int cc, int who, bool doit) -> int {
    if (b[r][cc]) return 0; int tot = 0;
    for (int d = 0; d < 8; d++) { int nr = r + D[d][0], nc = cc + D[d][1], cnt = 0;
      while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr][nc] == 3 - who) { nr += D[d][0]; nc += D[d][1]; cnt++; }
      if (cnt && nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr][nc] == who) { tot += cnt; if (doit) { int rr = r + D[d][0], ccc = cc + D[d][1]; for (int k = 0; k < cnt; k++) { b[rr][ccc] = who; rr += D[d][0]; ccc += D[d][1]; } } } }
    return tot;
  };
  auto hasMove = [&](int who) -> bool { for (int r = 0; r < 8; r++) for (int cc = 0; cc < 8; cc++) if (!b[r][cc] && flips(r, cc, who, false)) return true; return false; };
  auto count = [&](int who) -> int { int n = 0; for (int r = 0; r < 8; r++) for (int cc = 0; cc < 8; cc++) if (b[r][cc] == who) n++; return n; };
  auto draw = [&]() {
    c.header("Reversi"); ui::clearBody();
    tft.fillRect(OX - 3, OY - 3, 8 * CS + 6, 8 * CS + 6, RGB565(0,90,40));
    for (int r = 0; r < 8; r++) for (int cc = 0; cc < 8; cc++) { int x = OX + cc * CS, y = OY + r * CS; tft.drawRect(x, y, CS, CS, RGB565(0,60,25)); if (b[r][cc]) tft.fillCircle(x + CS / 2, y + CS / 2, CS / 2 - 3, b[r][cc] == 1 ? TFT_BLACK : TFT_WHITE); else if (flips(r, cc, turn, false)) tft.fillCircle(x + CS / 2, y + CS / 2, 2, RGB565(0,160,70)); }
    char s[28]; snprintf(s, 28, "Black %d   White %d", count(1), count(2));
    tft.setTextDatum(TL_DATUM); tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 10, OY + 8 * CS + 6, 2);
    tft.setTextColor(turn == 1 ? TFT_WHITE : C_DIM, C_BG); tft.drawString(turn == 1 ? "your move" : (vsBot ? "bot..." : "white"), 230, OY + 8 * CS + 6, 2);
  };
  auto over = [&]() { int bl = count(1), wh = count(2); banner(bl > wh ? "BLACK WINS" : wh > bl ? "WHITE WINS" : "DRAW", "tap to exit", C_ACCENT); waitTap(c); };
  draw();
  while (c.loop()) {
    if (!hasMove(1) && !hasMove(2)) { over(); return; }
    if (!hasMove(turn)) { turn = 3 - turn; draw(); continue; }
    if (vsBot && turn == 2) {                      // greedy bot: max flips
      delay(400); int br = -1, bc = -1, best = -1;
      for (int r = 0; r < 8; r++) for (int cc = 0; cc < 8; cc++) { int f = flips(r, cc, 2, false); if (f > best) { best = f; br = r; bc = cc; } }
      if (br >= 0) { flips(br, bc, 2, true); b[br][bc] = 2; audio::click(); turn = 1; draw(); } continue;
    }
    Touch &t = *c.t; if (!t.tap || t.sy < OY || t.sy >= OY + 8 * CS) continue;
    int cc = (t.sx - OX) / CS, r = (t.sy - OY) / CS; if (cc < 0 || cc >= 8) continue;
    if (!b[r][cc] && flips(r, cc, turn, false)) { flips(r, cc, turn, true); b[r][cc] = turn; audio::click(); turn = 3 - turn; draw(); }
  }
}

// ============================================================================
//  Simon  (repeat the growing colour/tone sequence)
// ============================================================================
void gsimon(AppCtx &c) {
  const uint16_t COL[4] = { RGB565(0,200,0), RGB565(220,0,0), RGB565(230,220,0), RGB565(0,80,230) };
  const uint16_t DIM[4] = { RGB565(0,80,0), RGB565(90,0,0), RGB565(95,90,0), RGB565(0,35,100) };
  const int TONE[4] = { 330, 440, 550, 660 };
  const int PX[4] = {30,166,30,166}, PY[4] = {40,40,140,140}, PW = 124, PH = 90;
  uint8_t seq[64]; int len = 0;
  auto drawPad = [&](int i, bool lit) { tft.fillRoundRect(PX[i], PY[i], PW, PH, 10, lit ? COL[i] : DIM[i]); };
  auto drawAll = [&]() { c.header("Simon"); ui::clearBody(); for (int i = 0; i < 4; i++) drawPad(i, false); char s[20]; snprintf(s, 20, "Round %d", len); tft.setTextDatum(TC_DATUM); tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 160, 118, 2); tft.setTextDatum(TL_DATUM); };
  auto flash = [&](int i) { drawPad(i, true); audio::tone(0, TONE[i], 300, audio::SQUARE, 100); delay(330); drawPad(i, false); delay(150); };
  auto padAt = [&](int x, int y) -> int { for (int i = 0; i < 4; i++) if (ui::inRect(x, y, PX[i], PY[i], PW, PH)) return i; return -1; };
  drawAll(); delay(500);
  while (c.loop()) {
    seq[len++] = rnd(4);
    for (int i = 0; i < len; i++) { if (!c.loop()) return; flash(seq[i]); }
    for (int i = 0; i < len; i++) {
      int got = -1;
      while (c.loop() && got < 0) { Touch &t = *c.t; if (t.tap) { got = padAt(t.sx, t.sy); if (got >= 0) { drawPad(got, true); audio::tone(0, TONE[got], 200, audio::SQUARE, 100); delay(180); drawPad(got, false); } } }
      if (got < 0) return;
      if (got != seq[i]) { char m[24]; snprintf(m, 24, "Reached round %d", len); banner("WRONG!", m, C_ERR); waitTap(c); len = 0; drawAll(); delay(400); break; }
    }
    if (len) { delay(500); drawAll(); delay(300); }
  }
}

// ============================================================================
//  Sudoku  (puzzle bank; tap a cell then a number; checks the solution)
// ============================================================================
void gsudoku(AppCtx &c) {
  // a couple of puzzles with solutions ('.' blank). Picked at random.
  static const char *PUZ[2] = {
    "53..7....6..195....98....6.8...6...34..8.3..17...2...6.6....28....419..5....8..79",
    ".2.6.8...58...97......4....37....5..6.......4..8....13....2......98...36...3.6.9."
  };
  static const char *SOL[2] = {
    "534678912672195348198342567859761423426853791713924856961537284287419635345286179",
    "123678945584239761967145328372461589691583274458792613836924157219857436745316892"
  };
  int p = rnd(2);
  int given[81], cur[81];
  for (int i = 0; i < 81; i++) { given[i] = PUZ[p][i] != '.' ? PUZ[p][i] - '0' : 0; cur[i] = given[i]; }
  const int CS = 23, OX = (320 - 9 * CS) / 2, OY = 28;
  int sel = -1;
  auto draw = [&]() {
    c.header("Sudoku"); ui::clearBody();
    for (int i = 0; i < 81; i++) {
      int r = i / 9, cc = i % 9, x = OX + cc * CS, y = OY + r * CS;
      uint16_t bg = (sel == i) ? RGB565(40,70,110) : C_PANEL;
      tft.fillRect(x, y, CS, CS, bg);
      if (cur[i]) { tft.setTextColor(given[i] ? C_TEXT : C_ACCENT, bg); tft.setTextDatum(MC_DATUM); tft.drawString(String(cur[i]), x + CS / 2, y + CS / 2, 2); }
    }
    for (int k = 0; k <= 9; k++) { int w = (k % 3 == 0) ? 2 : 1; uint16_t lc = (k % 3 == 0) ? C_TEXT : RGB565(70,80,100); tft.fillRect(OX + k * CS - w / 2, OY, w, 9 * CS, lc); tft.fillRect(OX, OY + k * CS - w / 2, 9 * CS, w, lc); }
    tft.setTextDatum(MC_DATUM);
    for (int n = 1; n <= 9; n++) { int bx = 6 + (n - 1) * 34, by = OY + 9 * CS + 6; tft.fillRoundRect(bx, by, 30, 30, 4, C_PANEL2); tft.setTextColor(C_TEXT, C_PANEL2); tft.drawString(String(n), bx + 15, by + 15, 2); }
    int ex = 6 + 9 * 34; tft.setTextDatum(TL_DATUM);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("X=erase", 6, OY + 9 * CS + 40, 1);
  };
  auto solved = [&]() -> bool { for (int i = 0; i < 81; i++) if (cur[i] != SOL[p][i] - '0') return false; return true; };
  draw();
  while (c.loop()) {
    Touch &t = *c.t; if (!t.tap) continue;
    if (t.sy >= OY && t.sy < OY + 9 * CS) { int cc = (t.sx - OX) / CS, r = (t.sy - OY) / CS; if (cc >= 0 && cc < 9 && r >= 0 && r < 9) { int i = r * 9 + cc; if (!given[i]) { sel = i; draw(); } } }
    else if (t.sy >= OY + 9 * CS + 6 && t.sy < OY + 9 * CS + 36) {
      int n = (t.sx - 6) / 34 + 1;
      if (sel >= 0 && n >= 1 && n <= 9) { cur[sel] = n; audio::click(); draw(); if (solved()) { banner("SOLVED!", "nice - tap to exit", C_OK); waitTap(c); return; } }
    }
    // tap a given cell twice / long area to erase: tap selected then low-left "X" zone
    if (t.tap && t.sx < 40 && t.sy > OY + 9 * CS + 36 && sel >= 0) { cur[sel] = 0; draw(); }
  }
}

// ============================================================================
//  Solitaire (Klondike, draw-1, tap-to-move)  - simplified but playable
// ============================================================================
namespace sol {
// card: 0..51 ; rank = c%13 (0=A..12=K), suit = c/13 (0,1 red; 2,3 black)
static inline int rankOf(int c) { return c % 13; }
static inline int suitOf(int c) { return c / 13; }
static inline bool red(int c) { return suitOf(c) < 2; }
static const char *RK[13] = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
static const char SU[4] = {'h','d','s','c'};
}
void gsolitaire(AppCtx &c) {
  using namespace sol;
  std::vector<int> stock, waste, found[4], tab[7];
  int deck[52]; for (int i = 0; i < 52; i++) deck[i] = i;
  for (int i = 51; i > 0; i--) { int j = rnd(i + 1); int t = deck[i]; deck[i] = deck[j]; deck[j] = t; }
  int d = 0;
  int faceUp[7];                                  // how many top cards of each tableau are face-up
  for (int i = 0; i < 7; i++) { for (int k = 0; k <= i; k++) tab[i].push_back(deck[d++]); faceUp[i] = 1; }
  while (d < 52) stock.push_back(deck[d++]);
  int selPile = -1, selIdx = -1;                  // selection: pile 0-6 tab, 7 waste ; idx within

  const int TX = 6, TY = 70, TW = 42, TGAP = 2, FAN = 16;
  auto cardFace = [&](int x, int y, int cardv, bool up) {
    tft.fillRoundRect(x, y, TW, 26, 3, up ? TFT_WHITE : RGB565(40,60,140));
    tft.drawRoundRect(x, y, TW, 26, 3, RGB565(120,120,120));
    if (up) { uint16_t col = red(cardv) ? RGB565(210,0,0) : TFT_BLACK; tft.setTextColor(col, TFT_WHITE); tft.setTextDatum(TL_DATUM); char s[6]; snprintf(s, 6, "%s%c", RK[rankOf(cardv)], SU[suitOf(cardv)]); tft.drawString(s, x + 2, y + 2, 2); }
  };
  auto draw = [&]() {
    c.header("Solitaire"); ui::clearBody();
    // stock + waste
    tft.fillRoundRect(6, 30, TW, 26, 3, stock.empty() ? RGB565(30,40,60) : RGB565(40,60,140)); tft.drawRoundRect(6, 30, TW, 26, 3, RGB565(120,120,120));
    if (!waste.empty()) cardFace(54, 30, waste.back(), true); else { tft.drawRoundRect(54, 30, TW, 26, 3, RGB565(60,60,60)); }
    // foundations
    for (int f = 0; f < 4; f++) { int x = 120 + f * (TW + 4); if (!found[f].empty()) cardFace(x, 30, found[f].back(), true); else { tft.drawRoundRect(x, 30, TW, 26, 3, RGB565(60,80,60)); tft.setTextColor(C_DIM, C_BG); tft.setTextDatum(MC_DATUM); char s[2] = {SU[f], 0}; tft.drawString(s, x + TW / 2, 43, 2); } }
    // tableau
    for (int i = 0; i < 7; i++) {
      int x = TX + i * (TW + TGAP);
      if (tab[i].empty()) { tft.drawRoundRect(x, TY, TW, 26, 3, RGB565(60,60,60)); continue; }
      int n = tab[i].size();
      for (int k = 0; k < n; k++) { int y = TY + k * FAN; bool up = (k >= n - faceUp[i]); cardFace(x, y, tab[i][k], up); if (selPile == i && selIdx == k) tft.drawRoundRect(x - 1, y - 1, TW + 2, 28, 3, C_ACCENT); }
    }
    tft.setTextDatum(TL_DATUM); tft.setTextColor(C_DIM, C_BG); tft.drawString("tap stock to deal; tap a card then where to move", 6, 224, 1);
  };
  auto canStack = [&](int moving, int onto) -> bool { return red(moving) != red(onto) && rankOf(moving) == rankOf(onto) - 1; };
  auto canFound = [&](int card, int f) -> bool { if (found[f].empty()) return rankOf(card) == 0 && suitOf(card) == f; return suitOf(card) == f && rankOf(card) == rankOf(found[f].back()) + 1; };
  auto won = [&]() -> bool { int t = 0; for (int f = 0; f < 4; f++) t += found[f].size(); return t == 52; };
  draw();
  while (c.loop()) {
    Touch &t = *c.t; if (!t.tap) continue;
    // stock
    if (ui::inRect(t.sx, t.sy, 6, 30, TW, 26)) {
      if (stock.empty()) { while (!waste.empty()) { stock.push_back(waste.back()); waste.pop_back(); } }
      else { waste.push_back(stock.back()); stock.pop_back(); }
      selPile = -1; audio::click(); draw(); continue;
    }
    // waste select
    if (ui::inRect(t.sx, t.sy, 54, 30, TW, 26) && !waste.empty()) { selPile = 7; selIdx = waste.size() - 1; draw(); continue; }
    // foundations tap (as destination)
    for (int f = 0; f < 4; f++) if (ui::inRect(t.sx, t.sy, 120 + f * (TW + 4), 30, TW, 26)) {
      if (selPile >= 0) { int card = (selPile == 7) ? waste.back() : tab[selPile].back(); bool topOnly = (selPile == 7) || (selIdx == (int)tab[selPile].size() - 1);
        if (topOnly && canFound(card, f)) { found[f].push_back(card); if (selPile == 7) waste.pop_back(); else { tab[selPile].pop_back(); if (faceUp[selPile] > 1) faceUp[selPile]--; else if (!tab[selPile].empty()) faceUp[selPile] = 1; } audio::beep(1200, 40); selPile = -1; draw(); if (won()) { banner("YOU WIN!", "tap to exit", C_OK); waitTap(c); return; } }
      }
      goto done;
    }
    // tableau
    for (int i = 0; i < 7; i++) { int x = TX + i * (TW + TGAP); if (t.sx < x || t.sx >= x + TW) continue;
      if (selPile < 0) { // select: pick the first face-up card under the touch
        if (tab[i].empty()) break; int n = tab[i].size(); int firstUp = n - faceUp[i];
        int k = (t.sy - TY) / FAN; if (k >= n) k = n - 1; if (k < firstUp) k = firstUp; if (k < 0) break;
        selPile = i; selIdx = k; draw();
      } else { // move selection onto tableau i
        int moving = (selPile == 7) ? waste.back() : tab[selPile][selIdx];
        bool ok = tab[i].empty() ? (rankOf(moving) == 12) : canStack(moving, tab[i].back());
        if (ok) {
          if (selPile == 7) { tab[i].push_back(moving); waste.pop_back(); }
          else { for (int k = selIdx; k < (int)tab[selPile].size(); k++) tab[i].push_back(tab[selPile][k]); tab[selPile].resize(selIdx); if (tab[selPile].empty()) faceUp[selPile] = 0; else if (faceUp[selPile] > (int)tab[selPile].size()) faceUp[selPile] = 1; else { int up = tab[selPile].size() - selIdx; (void)up; if (selIdx >= (int)tab[selPile].size()) faceUp[selPile] = 1; } if (!tab[selPile].empty() && faceUp[selPile] == 0) faceUp[selPile] = 1; }
          audio::click(); selPile = -1; draw();
        } else { selPile = -1; draw(); }
      }
      goto done;
    }
    selPile = -1; draw();
    done:;
  }
}

// ============================================================================
//  Space Invaders  (strip-free direct draw; player cannon vs alien waves)
// ============================================================================
void ginvaders(AppCtx &c) {
  const int COLS = 8, ROWS = 4;
  bool alive[ROWS][COLS];
  int ax = 30, ay = 36, adir = 1, adrop = 0;      // alien block origin
  const int AW = 20, AH = 14, AGAPX = 30, AGAPY = 22;
  int px = 150;                                    // player x
  const int PY = 214, PW = 30;
  float bx = -1, by = 0;                           // player bullet
  float ebx = -1, eby = 0;                         // one enemy bullet
  int score = 0, lives = 3, wave = 1;
  auto reset = [&]() { for (int r = 0; r < ROWS; r++) for (int cc = 0; cc < COLS; cc++) alive[r][cc] = true; ax = 30; ay = 36; adir = 1; bx = ebx = -1; };
  auto aliensLeft = [&]() { int n = 0; for (int r = 0; r < ROWS; r++) for (int cc = 0; cc < COLS; cc++) if (alive[r][cc]) n++; return n; };
  auto drawHud = [&]() { tft.fillRect(0, 26, 320, 10, C_BG); char s[28]; snprintf(s, 28, "Score %d  Lives %d  Wave %d", score, lives, wave); tft.setTextColor(C_TEXT, C_BG); tft.setTextDatum(TL_DATUM); tft.drawString(s, 6, 27, 1); };
  reset();
  c.header("Space Invaders"); ui::clearBody(); drawHud();
  uint32_t lastStep = 0; int stepMs = 420;
  while (c.frame(16)) {
    Touch &t = *c.t;
    // player follows finger x (clamped)
    if (t.down) px = constrain(t.x - PW / 2, 2, 318 - PW);
    if (t.tap && bx < 0) { bx = px + PW / 2; by = PY - 4; audio::tone(0, 900, 40, audio::SQUARE, 30); }

    // erase old sprites region cheaply by repainting the play field each frame top area
    tft.fillRect(0, 36, 320, PY - 36 - 2, C_BG);

    // step aliens on a timer (speeds up as they thin out)
    int n = aliensLeft();
    stepMs = 120 + n * 18;
    if (millis() - lastStep > (uint32_t)stepMs) {
      lastStep = millis();
      bool edge = false;
      for (int r = 0; r < ROWS; r++) for (int cc = 0; cc < COLS; cc++) if (alive[r][cc]) { int x = ax + cc * AGAPX + adir * 6; if (x < 2 || x + AW > 318) edge = true; }
      if (edge) { adir = -adir; ay += 12; } else ax += adir * 6;
      // random enemy fire from a live column
      if (ebx < 0) { int cc = rnd(COLS); for (int r = ROWS - 1; r >= 0; r--) if (alive[r][cc]) { ebx = ax + cc * AGAPX + AW / 2; eby = ay + r * AGAPY + AH; break; } }
    }
    // draw aliens
    for (int r = 0; r < ROWS; r++) for (int cc = 0; cc < COLS; cc++) if (alive[r][cc]) { int x = ax + cc * AGAPX, y = ay + r * AGAPY; uint16_t col = r == 0 ? RGB565(240,80,80) : r == 1 ? RGB565(240,200,60) : RGB565(80,220,120); tft.fillRoundRect(x, y, AW, AH, 3, col); tft.fillRect(x + 3, y + 4, 3, 3, C_BG); tft.fillRect(x + AW - 6, y + 4, 3, 3, C_BG); }

    // bullets
    if (bx >= 0) { by -= 7; tft.fillRect((int)bx, (int)by, 2, 8, C_ACCENT); if (by < 36) bx = -1; else { for (int r = 0; r < ROWS && bx >= 0; r++) for (int cc = 0; cc < COLS; cc++) if (alive[r][cc]) { int x = ax + cc * AGAPX, y = ay + r * AGAPY; if (bx >= x && bx <= x + AW && by >= y && by <= y + AH) { alive[r][cc] = false; bx = -1; score += 10; audio::tone(1, 500, 60, audio::NOISE, 200); drawHud(); break; } } } }
    if (ebx >= 0) { eby += 4; tft.fillRect((int)ebx, (int)eby, 2, 8, RGB565(255,120,0)); if (eby > 238) ebx = -1; else if (eby >= PY && ebx >= px && ebx <= px + PW) { ebx = -1; lives--; audio::tone(0, 160, 200, audio::NOISE, 400); drawHud(); if (lives <= 0) { banner("GAME OVER", (String("Score ") + score).c_str(), C_ERR); waitTap(c); score = 0; lives = 3; wave = 1; reset(); drawHud(); } } }

    // player cannon
    tft.fillRect(0, PY - 2, 320, 240 - PY + 2, C_BG);
    tft.fillRect(px, PY, PW, 10, RGB565(80,200,255)); tft.fillRect(px + PW / 2 - 1, PY - 5, 3, 5, RGB565(80,200,255));

    if (aliensLeft() == 0) { wave++; stepMs = max(120, stepMs - 40); reset(); drawHud(); }
    // aliens reached the player
    if (ay + ROWS * AGAPY >= PY) { banner("INVADED!", (String("Score ") + score).c_str(), C_ERR); waitTap(c); score = 0; lives = 3; wave = 1; reset(); drawHud(); }
  }
}
