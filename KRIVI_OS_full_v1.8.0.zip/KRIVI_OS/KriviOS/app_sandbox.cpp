// ============================================================================
//  KRIVI OS - Sandbox  (falling-sand cellular automaton, 33 materials)   app 37
//
//  Full-byte material ids + a per-cell life/aux byte, so there is room for
//  lots of materials and reactions. The picker is organised into category tabs
//  so the toolbar stays tidy. Grid is 160x77 @ 2px cells (three 12 KB arrays,
//  allocated via sys::bigAlloc so a tight-RAM moment degrades instead of
//  crashing).
// ============================================================================
#include "apps_common.h"

namespace sb {

enum {                                           // material ids (0 = empty)
  M_EMPTY = 0,
  M_SAND, M_SALT, M_GUNPOWDER, M_SNOW, M_ASH, M_SOIL,                 // powders
  M_WATER, M_OIL, M_ACID, M_LAVA, M_NITRO, M_MIDAS, M_SAP,              // liquids
  M_STONE, M_WOOD, M_GLASS, M_METAL, M_CLAY, M_WALL, M_GOLD,          // solids
  M_FIRE, M_SMOKE, M_STEAM, M_METHANE,                               // gases
  M_ICE, M_PLANT, M_VIRUS, M_URANIUM, M_CLONER,                      // nature
  M_TNT, M_C4, M_ELECTRIC, M_ANTIMATTER,                            // special
  M_COUNT
};

enum { CL_EMPTY, CL_POWDER, CL_LIQUID, CL_GAS, CL_STATIC };

struct Def { const char *abbr; uint16_t col; uint8_t cls; uint8_t dens; bool flam; };

// abbr, colour, class, density(liquids), flammable
static const Def D[M_COUNT] = {
  /*EMPTY*/ {"", 0, CL_EMPTY, 0, false},
  /*SAND*/  {"SAND", RGB565(224,198,120), CL_POWDER, 6, false},
  /*SALT*/  {"SALT", RGB565(238,238,244), CL_POWDER, 6, false},
  /*GUNP*/  {"GUNP", RGB565(70,70,78),    CL_POWDER, 6, true},
  /*SNOW*/  {"SNOW", RGB565(235,245,255), CL_POWDER, 3, false},
  /*ASH*/   {"ASH",  RGB565(120,116,112), CL_POWDER, 5, false},
  /*SOIL*/  {"SOIL", RGB565(96,66,40),    CL_POWDER, 6, false},
  /*WATER*/ {"WATR", RGB565(40,110,220),  CL_LIQUID, 5, false},
  /*OIL*/   {"OIL",  RGB565(86,70,52),    CL_LIQUID, 3, true},
  /*ACID*/  {"ACID", RGB565(150,255,40),  CL_LIQUID, 5, false},
  /*LAVA*/  {"LAVA", RGB565(255,110,20),  CL_LIQUID, 9, false},
  /*LN2*/   {"LN2",  RGB565(150,220,255), CL_LIQUID, 4, false},
  /*MIDAS*/ {"MIDS", RGB565(255,210,70),  CL_LIQUID, 7, false},
  /*SAP*/   {"SAP",  RGB565(190,140,40),  CL_LIQUID, 6, true},
  /*STONE*/ {"STON", RGB565(122,124,134), CL_STATIC, 0, false},
  /*WOOD*/  {"WOOD", RGB565(120,80,36),   CL_STATIC, 0, true},
  /*GLASS*/ {"GLAS", RGB565(180,220,230), CL_STATIC, 0, false},
  /*METAL*/ {"METL", RGB565(150,160,175), CL_STATIC, 0, false},
  /*CLAY*/  {"CLAY", RGB565(170,110,90),  CL_STATIC, 0, false},
  /*WALL*/  {"WALL", RGB565(70,74,86),    CL_STATIC, 0, false},
  /*GOLD*/  {"GOLD", RGB565(236,196,60),  CL_STATIC, 0, false},
  /*FIRE*/  {"FIRE", RGB565(255,140,20),  CL_GAS,    0, false},
  /*SMOKE*/ {"SMOK", RGB565(120,120,126), CL_GAS,    0, false},
  /*STEAM*/ {"STEM", RGB565(200,210,220), CL_GAS,    0, false},
  /*METH*/  {"METH", RGB565(120,200,150), CL_GAS,    0, true},
  /*ICE*/   {"ICE",  RGB565(170,210,255), CL_STATIC, 0, false},
  /*PLANT*/ {"PLNT", RGB565(60,190,60),   CL_STATIC, 0, true},
  /*VIRUS*/ {"VIRS", RGB565(200,40,200),  CL_STATIC, 0, false},
  /*URAN*/  {"URAN", RGB565(120,230,80),  CL_STATIC, 0, false},
  /*CLONE*/ {"CLNE", RGB565(230,120,180), CL_STATIC, 0, false},
  /*TNT*/   {"TNT",  RGB565(220,50,40),   CL_STATIC, 0, true},
  /*C4*/    {"C4",   RGB565(230,210,120), CL_STATIC, 0, true},
  /*ELEC*/  {"ELEC", RGB565(255,255,120), CL_GAS,    0, false},
  /*ANTI*/  {"ANTI", RGB565(255,0,160),   CL_STATIC, 0, false},
};

// category tabs -> member material lists
struct Cat { const char *name; uint8_t n; uint8_t m[7]; };
static const Cat CATS[6] = {
  {"POWDER", 6, {M_SAND, M_SALT, M_GUNPOWDER, M_SNOW, M_ASH, M_SOIL}},
  {"LIQUID", 7, {M_WATER, M_OIL, M_ACID, M_LAVA, M_NITRO, M_MIDAS, M_SAP}},
  {"SOLID",  7, {M_STONE, M_WOOD, M_GLASS, M_METAL, M_CLAY, M_WALL, M_GOLD}},
  {"GAS",    4, {M_FIRE, M_SMOKE, M_STEAM, M_METHANE}},
  {"NATURE", 5, {M_ICE, M_PLANT, M_VIRUS, M_URANIUM, M_CLONER}},
  {"SPECL",  4, {M_TNT, M_C4, M_ELECTRIC, M_ANTIMATTER}},
};

static inline bool flammable(uint8_t m) { return D[m].flam; }

}  // namespace sb

void app_sand(AppCtx &c) {
  using namespace sb;
  const int GW = 160, GH = 77, CS = 2, OY = 26;    // grid 26..180
  const int TAB_Y = 182, MAT_Y = 200, TOOL_Y = 220;
  uint8_t *g  = (uint8_t *)sys::bigAlloc(GW * GH);
  uint8_t *lf = (uint8_t *)sys::bigAlloc(GW * GH);  // per-cell life / aux
  uint8_t *pr = (uint8_t *)sys::bigAlloc(GW * GH);  // processed-this-frame guard
  if (!g || !lf || !pr) { free(g); free(lf); free(pr); ui::msgBox("SANDBOX", "Not enough RAM"); return; }
  memset(g, 0, GW * GH); memset(lf, 0, GW * GH);

  int cat = 0, tool = M_SAND, brush = 3;

  auto shade = [&](uint16_t base, int x, int y) -> uint16_t {        // tiny static texture
    int n = ((x * 7 + y * 13) & 7) - 3;
    int r = ((base >> 11) & 31) + n, gg = ((base >> 5) & 63) + n, b = (base & 31) + n;
    r = constrain(r, 0, 31); gg = constrain(gg, 0, 63); b = constrain(b, 0, 31);
    return (r << 11) | (gg << 5) | b;
  };
  auto colOf = [&](int x, int y) -> uint16_t {
    uint8_t m = g[y * GW + x]; if (!m) return TFT_BLACK;
    if (m == M_FIRE) { uint8_t l = lf[y * GW + x]; return l > 10 ? RGB565(255,240,120) : l > 5 ? RGB565(255,150,20) : RGB565(220,50,10); }
    if (m == M_SAND || m == M_STONE || m == M_SOIL || m == M_ASH || m == M_WOOD) return shade(D[m].col, x, y);
    return D[m].col;
  };
  auto draw1 = [&](int x, int y) { tft.fillRect(x * CS, OY + y * CS, CS, CS, colOf(x, y)); };
  auto put = [&](int x, int y, uint8_t m, uint8_t life = 0) { int i = y * GW + x; g[i] = m; lf[i] = life; draw1(x, y); };
  auto at = [&](int x, int y) -> int { return (x < 0 || y < 0 || x >= GW || y >= GH) ? -2 : g[y * GW + x]; };

  // ------------------------------------------------------------- toolbar
  auto drawTabs = [&]() {
    for (int i = 0; i < 6; i++) { int x = i * 53 + 1; bool s = cat == i; tft.fillRoundRect(x, TAB_Y, 51, 15, 2, s ? C_ACCENT : C_PANEL); tft.setTextColor(s ? TFT_BLACK : C_TEXT, s ? C_ACCENT : C_PANEL); tft.setTextDatum(MC_DATUM); tft.drawString(CATS[i].name, x + 25, TAB_Y + 7, 1); }
  };
  auto drawMats = [&]() {
    tft.fillRect(0, MAT_Y - 1, 320, 18, C_BG);
    const Cat &ca = CATS[cat];
    for (int i = 0; i < ca.n; i++) { int m = ca.m[i], x = i * 45 + 2; bool s = tool == m; tft.fillRoundRect(x, MAT_Y, 43, 16, 3, s ? D[m].col : C_PANEL); tft.setTextColor(s ? TFT_BLACK : D[m].col, s ? D[m].col : C_PANEL); tft.setTextDatum(MC_DATUM); tft.drawString(D[m].abbr, x + 21, MAT_Y + 8, 1); }
    tft.setTextDatum(TL_DATUM);
  };
  auto drawTools = [&]() {
    ui::button(2, TOOL_Y, 60, 18, tool == M_EMPTY ? "ERASING" : "ERASE", tool == M_EMPTY ? C_ACCENT : C_PANEL2, tool == M_EMPTY ? TFT_BLACK : C_TEXT, 1);
    ui::button(66, TOOL_Y, 56, 18, "CLEAR", C_PANEL2, C_TEXT, 1);
    char b[16]; snprintf(b, sizeof(b), "brush %d", brush);
    ui::button(126, TOOL_Y, 56, 18, b, C_PANEL2, C_TEXT, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("tap a tab, then a material", 188, TOOL_Y + 5, 1);
  };
  auto drawBar = [&]() { drawTabs(); drawMats(); drawTools(); };
  ui::clearBody(TFT_BLACK); drawBar();

  bool flip = false;
  while (c.frame(24)) {
    Touch &t = *c.t;
    // ---- toolbar input
    if (t.tap && t.sy >= TAB_Y) {
      if (t.sy < TAB_Y + 15) { int i = t.sx / 53; if (i < 6) { cat = i; drawTabs(); drawMats(); } }
      else if (t.sy >= MAT_Y && t.sy < MAT_Y + 16) { int i = t.sx / 45; if (i < CATS[cat].n) { tool = CATS[cat].m[i]; drawMats(); drawTools(); } }
      else if (t.sy >= TOOL_Y) {
        if (ui::inRect(t.sx, t.sy, 2, TOOL_Y, 60, 18)) { tool = M_EMPTY; drawMats(); drawTools(); }
        else if (ui::inRect(t.sx, t.sy, 66, TOOL_Y, 56, 18)) { memset(g, 0, GW * GH); memset(lf, 0, GW * GH); tft.fillRect(0, OY, 320, GH * CS, TFT_BLACK); }
        else if (ui::inRect(t.sx, t.sy, 126, TOOL_Y, 56, 18)) { brush = brush >= 5 ? 1 : brush + 1; drawTools(); }
      }
      continue;
    }
    // ---- painting
    if (t.down && t.y >= OY && t.y < OY + GH * CS) {
      int gx = t.x / CS, gy = (t.y - OY) / CS, r = brush;
      bool stat = (tool == M_EMPTY) || (D[tool].cls == CL_STATIC);
      for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) {
        int x = gx + dx, y = gy + dy; if (x < 0 || y < 0 || x >= GW || y >= GH || dx * dx + dy * dy > r * r) continue;
        if (tool == M_EMPTY) { if (g[y * GW + x]) put(x, y, 0); }
        else if (!g[y * GW + x] && (stat || rnd(2) == 0)) {
          uint8_t life = tool == M_FIRE ? 10 + rnd(6) : (tool == M_SMOKE || tool == M_STEAM) ? 40 + rnd(30) : tool == M_ELECTRIC ? 3 : 0;
          put(x, y, tool, life);
        }
      }
    }

    // ---- simulation (bottom-up, L/R alternating, processed-guard)
    memset(pr, 0, GW * GH); flip = !flip;
    for (int y = GH - 1; y >= 0; y--) {
      for (int ii = 0; ii < GW; ii++) {
        int x = flip ? ii : GW - 1 - ii, idx = y * GW + x;
        if (pr[idx]) continue;
        uint8_t m = g[idx]; if (m == M_EMPTY) continue;
        uint8_t cls = D[m].cls;
        int d = rnd(2) ? 1 : -1;
        auto move = [&](int nx, int ny) { int ni = ny * GW + nx; uint8_t om = g[ni]; uint8_t ol = lf[ni]; g[ni] = m; lf[ni] = lf[idx]; g[idx] = om; lf[idx] = ol; draw1(nx, ny); draw1(x, y); pr[ni] = 1; pr[idx] = 1; };
        auto conv = [&](int nx, int ny, uint8_t nm, uint8_t nl = 0) { int ni = ny * GW + nx; g[ni] = nm; lf[ni] = nl; draw1(nx, ny); pr[ni] = 1; };
        auto hotNbr = [&]() { return at(x,y-1)==M_FIRE||at(x,y+1)==M_FIRE||at(x-1,y)==M_FIRE||at(x+1,y)==M_FIRE||at(x,y-1)==M_LAVA||at(x,y+1)==M_LAVA||at(x-1,y)==M_LAVA||at(x+1,y)==M_LAVA; };
        const int NB[4][2] = {{0,-1},{0,1},{-1,0},{1,0}};

        // ===================== reactions by material =====================
        if (m == M_FIRE) {
          int life = lf[idx];
          for (auto &n : NB) { int a = at(x+n[0], y+n[1]);
            if (a>=0 && flammable(a) && rnd(a==M_GUNPOWDER||a==M_METHANE||a==M_SAP?2:5)==0) conv(x+n[0], y+n[1], M_FIRE, 10+rnd(5));
            else if (a==M_WATER) { conv(x+n[0], y+n[1], M_STEAM, 50); life=0; }
            else if (a==M_ICE||a==M_SNOW) conv(x+n[0], y+n[1], M_WATER);
            else if (a==M_TNT||a==M_C4) conv(x+n[0], y+n[1], a==M_C4?M_C4:M_TNT, 1);   // arm (life=1 triggers below)
            else if (a==M_URANIUM) conv(x+n[0], y+n[1], M_LAVA); }
          if (life<=1) { put(x, y, rnd(3)?M_SMOKE:M_EMPTY, 30); continue; }
          lf[idx] = life - 1; g[idx] = M_FIRE;
          if (at(x,y-1)==M_EMPTY) move(x, y-1); else if (at(x+d,y-1)==M_EMPTY) move(x+d, y-1); else pr[idx]=1;
          draw1(x, y); continue;
        }
        if (m == M_TNT || m == M_C4) {                   // explode when armed (lf==1) or touched by fire
          if (lf[idx] == 1 || hotNbr()) { int R = (m==M_C4)?9:6; for (int yy=-R; yy<=R; yy++) for (int xx=-R; xx<=R; xx++){ int nx=x+xx, ny=y+yy; if(nx<0||ny<0||nx>=GW||ny>=GH||xx*xx+yy*yy>R*R) continue; int a=g[ny*GW+nx]; if(a!=M_WALL) conv(nx, ny, rnd(3)?M_FIRE:M_SMOKE, 8+rnd(6)); } audio::tone(0,120,160,audio::NOISE,500,500); continue; }
          continue;                                       // otherwise static
        }
        if (m == M_LAVA) {
          for (auto &n : NB) { int a = at(x+n[0], y+n[1]);
            if (a==M_WATER) { conv(x+n[0], y+n[1], M_STEAM, 50); conv(x, y, M_STONE); goto doneCell; }
            else if (a>=0 && flammable(a) && rnd(3)==0) conv(x+n[0], y+n[1], M_FIRE, 10);
            else if (a==M_ICE||a==M_SNOW) conv(x+n[0], y+n[1], M_WATER);
            else if (a==M_SAND && rnd(4)==0) conv(x+n[0], y+n[1], M_GLASS); }
          if (rnd(400)==0) { conv(x, y, M_STONE); goto doneCell; }        // slowly cools
        }
        else if (m == M_WATER) {
          for (auto &n : NB) { int a = at(x+n[0], y+n[1]); if (a==M_FIRE||a==M_LAVA) { conv(x, y, M_STEAM, 50); goto doneCell; } if ((a==M_ICE||a==M_NITRO) && rnd(18)==0) { conv(x, y, M_ICE); goto doneCell; } }
        }
        else if (m == M_ICE) {
          if (hotNbr()) { conv(x, y, M_WATER); goto doneCell; }
          for (auto &n : NB) { int a = at(x+n[0], y+n[1]); if (a==M_SALT && rnd(6)==0) { conv(x, y, M_WATER); goto doneCell; } if (a==M_WATER && rnd(50)==0) conv(x+n[0], y+n[1], M_ICE); }
          continue;                                        // static
        }
        else if (m == M_SNOW) { if (hotNbr() && rnd(2)) { conv(x, y, M_WATER); goto doneCell; } }
        else if (m == M_NITRO) { for (auto &n : NB){ int a=at(x+n[0],y+n[1]); if(a==M_WATER) conv(x+n[0],y+n[1],M_ICE); } if (rnd(120)==0){ conv(x,y,M_EMPTY); goto doneCell; } }
        else if (m == M_SALT) { for (auto &n : NB){ int a=at(x+n[0],y+n[1]); if(a==M_ICE||a==M_SNOW){ if(rnd(5)==0) conv(x+n[0],y+n[1],M_WATER);} if(a==M_WATER && rnd(60)==0){ conv(x,y,M_EMPTY); goto doneCell; } } }
        else if (m == M_ACID) {
          int b = at(x, y+1);
          auto eat = [&](int a){ return a==M_SAND||a==M_WOOD||a==M_STONE||a==M_METAL||a==M_PLANT||a==M_CLAY||a==M_GOLD||a==M_SALT||a==M_SOIL||a==M_ASH||a==M_VIRUS; };
          if (eat(b)) { conv(x, y+1, M_EMPTY); if (rnd(4)==0) { conv(x, y, M_EMPTY); goto doneCell; } }
          for (auto &n : NB){ int a=at(x+n[0],y+n[1]); if(eat(a)&&rnd(3)==0) conv(x+n[0],y+n[1],M_EMPTY); }
        }
        else if (m == M_MIDAS) { for (auto &n : NB){ int a=at(x+n[0],y+n[1]); if(a>=M_SAND && a!=M_GOLD && a!=M_WALL && a!=M_ANTIMATTER && a!=M_MIDAS && D[a].cls!=CL_GAS && D[a].cls!=CL_LIQUID && rnd(3)==0) conv(x+n[0],y+n[1],M_GOLD); } }
        else if (m == M_PLANT) {
          if (hotNbr() && rnd(3)==0) { conv(x, y, M_FIRE, 10); goto doneCell; }
          int wx=-2; if(at(x,y-1)==M_WATER)wx=0; else if(at(x-1,y)==M_WATER)wx=-1; else if(at(x+1,y)==M_WATER)wx=1;
          if (wx!=-2 && rnd(30)==0) { if(at(x,y-1)==M_EMPTY) conv(x,y-1,M_PLANT); int wy=at(x,y-1)==M_WATER?y-1:y; if(at(x+wx,wy)==M_WATER) conv(x+wx,wy,M_EMPTY); }
          continue;
        }
        else if (m == M_WOOD || m == M_SAP) { if (hotNbr() && rnd(m==M_SAP?3:8)==0) { conv(x, y, M_FIRE, 10); goto doneCell; } }
        else if (m == M_GUNPOWDER) { if (hotNbr()) { conv(x, y, M_FIRE, 6); goto doneCell; } }
        else if (m == M_OIL) { if (hotNbr() && rnd(2)) { conv(x, y, M_FIRE, 8); goto doneCell; } }
        else if (m == M_METHANE) { if (hotNbr()) { conv(x, y, M_FIRE, 8); goto doneCell; } }
        else if (m == M_VIRUS) {
          if (hotNbr()) { conv(x, y, M_FIRE, 6); goto doneCell; }
          for (auto &n : NB){ int a=at(x+n[0],y+n[1]); if((a==M_WOOD||a==M_PLANT||a==M_SAND||a==M_SOIL||a==M_SAP)&&rnd(6)==0) conv(x+n[0],y+n[1],M_VIRUS); if(a==M_ACID){ conv(x,y,M_EMPTY); goto doneCell; } }
          continue;
        }
        else if (m == M_URANIUM) { if (rnd(60)==0){ for(auto &n:NB){ int a=at(x+n[0],y+n[1]); if(a==M_EMPTY && rnd(3)==0){ conv(x+n[0],y+n[1], rnd(2)?M_ELECTRIC:M_FIRE, rnd(2)?3:8); break; } } } continue; }
        else if (m == M_CLONER) { int src=M_EMPTY; for(auto &n:NB){ int a=at(x+n[0],y+n[1]); if(a>0 && a!=M_CLONER && a!=M_WALL){ src=a; break; } } if(src){ for(auto &n:NB){ if(at(x+n[0],y+n[1])==M_EMPTY && rnd(2)) conv(x+n[0],y+n[1],src); } } continue; }
        else if (m == M_ELECTRIC) {
          int life = lf[idx];
          for (auto &n : NB){ int a=at(x+n[0],y+n[1]); if((a==M_METAL||a==M_WATER)&&rnd(2)) conv(x+n[0],y+n[1],M_ELECTRIC,2); else if(a==M_GUNPOWDER||a==M_METHANE||a==M_OIL||a==M_SAP) conv(x+n[0],y+n[1],M_FIRE,8); }
          if (life<=1) { conv(x, y, M_EMPTY); goto doneCell; } lf[idx]=life-1; continue;
        }
        else if (m == M_ANTIMATTER) {
          bool hit=false; for(auto &n:NB){ int a=at(x+n[0],y+n[1]); if(a>0 && a!=M_WALL && a!=M_ANTIMATTER){ conv(x+n[0],y+n[1],M_EMPTY); hit=true; } }
          if (hit && rnd(2)) { conv(x, y, M_EMPTY); goto doneCell; }
          continue;
        }
        else if (m == M_SMOKE || m == M_STEAM) {
          int life = lf[idx]; if (life==0 || (m==M_STEAM && rnd(200)==0)) { conv(x, y, m==M_STEAM?M_WATER:M_EMPTY); goto doneCell; }
          lf[idx]=life-1;
          if (at(x,y-1)==M_EMPTY) move(x,y-1); else if (at(x+d,y-1)==M_EMPTY) move(x+d,y-1); else if (at(x+d,y)==M_EMPTY && rnd(2)) move(x+d,y); else pr[idx]=1;
          continue;
        }

        // ===================== movement by class =====================
        if (cls == CL_STATIC) { pr[idx] = 1; continue; }
        if (cls == CL_GAS) {                               // generic gas rises (METHANE)
          if (at(x,y-1)==M_EMPTY) move(x,y-1); else if (at(x+d,y-1)==M_EMPTY) move(x+d,y-1); else if (at(x+d,y)==M_EMPTY && rnd(2)) move(x+d,y); else pr[idx]=1;
          continue;
        }
        // powders & liquids fall
        {
          bool powder = (cls == CL_POWDER);
          auto into = [&](int a) -> bool {                 // can this cell move into neighbour 'a'?
            if (a == M_EMPTY) return true;
            if (a < 0) return false;
            if (D[a].cls == CL_LIQUID && D[a].dens < D[m].dens) return true;   // denser sinks
            if (powder && D[a].cls == CL_LIQUID) return true;                   // powders sink in liquid
            return false;
          };
          if (into(at(x, y+1))) { move(x, y+1); continue; }
          if (into(at(x+d, y+1))) { move(x+d, y+1); continue; }
          if (into(at(x-d, y+1))) { move(x-d, y+1); continue; }
          if (!powder) {                                   // liquids also spread sideways
            if (at(x+d, y) == M_EMPTY) { move(x+d, y); continue; }
            if (at(x-d, y) == M_EMPTY) { move(x-d, y); continue; }
          }
          pr[idx] = 1;
        }
        doneCell:;
      }
    }
  }
  free(g); free(lf); free(pr);
}
