// ============================================================================
//  KRIVI OS - Built-in sensor apps (the CYD's light-dependent resistor, LDR)
//    Light Meter . Auto-Brightness . Night Light
//  The LDR sits on PIN_LDR (GPIO34, ADC1, input-only). Reading rises with
//  ambient light on this board; everything here is relative (0-100 %).
// ============================================================================
#include "apps_common.h"

static int ldrPercent() {
  // average a few samples for a steady reading; map 12-bit ADC to 0-100 %
  long s = 0; for (int i = 0; i < 8; i++) { s += analogRead(PIN_LDR); delayMicroseconds(200); }
  int raw = s / 8;                                  // 0..4095
  return constrain(map(raw, 150, 3600, 0, 100), 0, 100);
}

// ----------------------------------------------------------------------------
//  Light Meter - live ambient-light reading with a rolling graph
// ----------------------------------------------------------------------------
void app_lightmeter(AppCtx &c) {
  analogReadResolution(12);
  const int GX = 10, GY = 150, GW = 300, GH = 70;
  uint8_t hist[300]; int hn = 0; memset(hist, 0, sizeof hist);
  c.header("Light Meter");
  ui::clearBody();
  tft.drawRect(GX - 1, GY - 1, GW + 2, GH + 2, C_PANEL2);
  uint32_t last = 0;
  while (c.loop()) {
    if (millis() - last < 120) continue;
    last = millis();
    int pct = ldrPercent();
    // big number + descriptor
    tft.fillRect(0, 32, 320, 110, C_BG);
    char s[8]; snprintf(s, sizeof(s), "%d%%", pct);
    tft.setTextDatum(MC_DATUM); tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 160, 70, 7);
    const char *word = pct > 75 ? "bright" : pct > 45 ? "indoor light" : pct > 18 ? "dim" : "dark";
    tft.setTextColor(C_DIM, C_BG); tft.drawString(word, 160, 118, 2);
    tft.setTextDatum(TL_DATUM);
    ui::bar(10, 132, 300, 10, pct / 100.0f, C_ACCENT, C_PANEL);
    // rolling graph
    hist[hn % GW] = pct; hn++;
    tft.fillRect(GX, GY, GW, GH, C_BG);
    for (int x = 0; x < GW && x < hn; x++) { int idx = (hn - GW + x); if (idx < 0) continue; int v = hist[idx % GW]; int h = v * GH / 100; tft.drawFastVLine(GX + x, GY + GH - h, h, RGB565(0,160,120)); }
  }
}

// ----------------------------------------------------------------------------
//  Auto-Brightness - match the screen backlight to the room, until you exit
// ----------------------------------------------------------------------------
void app_autobright(AppCtx &c) {
  analogReadResolution(12);
  ledcSetup(7, 5000, 8); ledcAttachPin(TFT_BL, 7);
  int lo = 25, hi = 100;                             // min/max backlight %
  c.header("Auto-Brightness");
  auto draw = [&](int pct, int bl) {
    ui::clearBody();
    ui::centerText("Screen follows the room light", 160, 40, C_TEXT, C_BG, 2);
    char s[40]; snprintf(s, sizeof(s), "ambient %d%%   backlight %d%%", pct, bl);
    tft.setTextDatum(TC_DATUM); tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 160, 70, 2); tft.setTextDatum(TL_DATUM);
    tft.setTextColor(C_TEXT, C_BG); tft.drawString("min", 10, 104, 2); ui::bar(60, 106, 250, 10, lo / 100.0f, C_WARN, C_PANEL);
    tft.drawString("max", 10, 134, 2); ui::bar(60, 136, 250, 10, hi / 100.0f, C_OK, C_PANEL);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("drag the bars to set the limits", 10, 170, 1);
  };
  int pct = ldrPercent(); draw(pct, hi);
  uint32_t last = 0;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.down && ui::inRect(t.x, t.y, 60, 100, 250, 20)) { lo = constrain((t.x - 60) * 100 / 250, 5, hi - 5); draw(pct, 0); }
    else if (t.down && ui::inRect(t.x, t.y, 60, 130, 250, 20)) { hi = constrain((t.x - 60) * 100 / 250, lo + 5, 100); draw(pct, 0); }
    if (millis() - last > 200) {
      last = millis();
      pct = (pct * 3 + ldrPercent()) / 4;              // smooth
      int bl = lo + (hi - lo) * pct / 100;
      ledcWrite(7, map(bl, 0, 100, 0, 255));
      tft.fillRect(0, 60, 320, 20, C_BG);
      char s[40]; snprintf(s, sizeof(s), "ambient %d%%   backlight %d%%", pct, bl);
      tft.setTextDatum(TC_DATUM); tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 160, 70, 2); tft.setTextDatum(TL_DATUM);
    }
  }
  // restore the saved brightness on exit
  int sb = sys::cfg["display"]["brightness"] | 100;
  ledcWrite(7, map(constrain(sb, 10, 100), 0, 100, 0, 255));
}

// ----------------------------------------------------------------------------
//  Night Light - RGB LED glows when the room goes dark
// ----------------------------------------------------------------------------
void app_nightlight(AppCtx &c) {
  analogReadResolution(12);
  int thresh = 25;                                   // turn on below this %
  bool on = false;
  c.header("Night Light");
  auto draw = [&](int pct) {
    ui::clearBody();
    tft.fillCircle(160, 96, 46, on ? RGB565(255,240,180) : RGB565(40,44,54));
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(on ? TFT_BLACK : C_DIM, on ? RGB565(255,240,180) : C_BG); tft.drawString(on ? "ON" : "off", 160, 86, 4);
    char s[32]; snprintf(s, sizeof(s), "ambient %d%%", pct);
    tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 160, 158, 2);
    char th[32]; snprintf(th, sizeof(th), "turns on below %d%%", thresh);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(th, 160, 180, 1); tft.setTextDatum(TL_DATUM);
    ui::button(40, 198, 110, 34, "- dimmer trip", C_PANEL2, C_TEXT, 1);
    ui::button(170, 198, 110, 34, "+ brighter trip", C_PANEL2, C_TEXT, 1);
  };
  int pct = ldrPercent(); draw(pct);
  uint32_t last = 0;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && ui::inRect(t.sx, t.sy, 40, 198, 110, 34)) { thresh = max(5, thresh - 5); draw(pct); }
    else if (t.tap && ui::inRect(t.sx, t.sy, 170, 198, 110, 34)) { thresh = min(90, thresh + 5); draw(pct); }
    if (millis() - last > 250) {
      last = millis();
      pct = (pct * 2 + ldrPercent()) / 3;
      bool want = pct < thresh;
      if (want != on) { on = want; sys::led(on ? 255 : 0, on ? 240 : 0, on ? 170 : 0); draw(pct); }
      else { tft.fillRect(60, 150, 200, 16, C_BG); tft.setTextDatum(TC_DATUM); char s[32]; snprintf(s, sizeof(s), "ambient %d%%", pct); tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 160, 158, 2); tft.setTextDatum(TL_DATUM); }
    }
  }
  sys::led(0, 0, 0);
}
