// ============================================================================
//  Page 5: Benchmarks, simulations & graphic design
//  35 Sketchpad 36 Rainbow warp 37 Falling sand 38 Game of Life
//  39 Mandelbrot (40 Video/MP4 player lives in app_media.cpp) 41 Virtual pet 42 Touch diagnostics
//  43 System manual
// ============================================================================
#include "apps_common.h"
#include <time.h>
#include <WiFi.h>

// ============================================================================
//  35  SKETCHPAD CANVAS PAINT  (4-bit canvas in RAM, saved as 16-colour BMP)
// ============================================================================
static const uint16_t PAINT_PAL[16] = {
  TFT_BLACK, TFT_WHITE, RGB565(230, 40, 40), RGB565(255, 140, 0), RGB565(255, 230, 0), RGB565(40, 200, 60),
  RGB565(0, 200, 220), RGB565(30, 80, 230), RGB565(140, 60, 220), RGB565(255, 110, 180), RGB565(130, 80, 40),
  RGB565(128, 128, 128), RGB565(60, 60, 60), RGB565(160, 240, 140), RGB565(10, 20, 90), RGB565(240, 200, 160)};

void app_paint(AppCtx &c) {
  const int CW = 320, CH = 170, CY = 26;
  uint8_t *cv = (uint8_t *)sys::bigAlloc(CW * CH / 2);
  if (!cv) { ui::msgBox("SKETCHPAD", "Not enough RAM"); return; }
  memset(cv, 0x11, CW * CH / 2);                          // white
  int color = 0, size = 1;
  static const uint8_t SIZES[4] = {1, 3, 6, 10};
  auto setPx = [&](int x, int y, int ci) {
    if (x < 0 || y < 0 || x >= CW || y >= CH) return;
    uint8_t &b = cv[(y * CW + x) >> 1];
    b = (x & 1) ? (b & 0xF0) | ci : (b & 0x0F) | (ci << 4);
  };
  auto stamp = [&](int x, int y) {
    int r = SIZES[size];
    for (int dy = -r; dy <= r; ++dy) for (int dx = -r; dx <= r; ++dx) if (dx * dx + dy * dy <= r * r) setPx(x + dx, y + dy, color);
    if (r <= 1) tft.fillRect(x - 1, CY + y - 1, 3, 3, PAINT_PAL[color]); else tft.fillCircle(x, CY + y, r, PAINT_PAL[color]);
  };
  auto redrawCanvas = [&]() {
    uint16_t line[CW];
    for (int y = 0; y < CH; ++y) {
      for (int x = 0; x < CW; ++x) { uint8_t b = cv[(y * CW + x) >> 1]; line[x] = PAINT_PAL[(x & 1) ? (b & 0x0F) : (b >> 4)]; }
      tft.setSwapBytes(true); tft.pushImage(0, CY + y, CW, 1, line); tft.setSwapBytes(false);
    }
  };
  auto toolbar = [&]() {
    for (int i = 0; i < 16; ++i) {
      tft.fillRect(i * 20, 197, 20, 20, PAINT_PAL[i]);
      if (i == color) { tft.drawRect(i * 20, 197, 20, 20, C_ACCENT); tft.drawRect(i * 20 + 1, 198, 18, 18, TFT_BLACK); }
    }
    char s[12]; snprintf(s, 12, "SIZE %d", SIZES[size]);
    ui::button(0, 218, 64, 22, s, C_PANEL2, C_TEXT, 1); ui::button(64, 218, 64, 22, "CLEAR", C_PANEL2, C_TEXT, 1);
    ui::button(128, 218, 64, 22, "FILL BG", C_PANEL2, C_TEXT, 1);
    ui::button(192, 218, 64, 22, "SAVE", RGB565(0, 110, 60), C_TEXT, 1); ui::button(256, 218, 64, 22, "LOAD", C_PANEL2, C_TEXT, 1);
  };
  auto saveBmp = [&]() -> String {
    char path[40];
    for (int n = 1; n < 1000; ++n) { snprintf(path, 40, "/data/paint/sketch_%03d.bmp", n); if (!SD.exists(path)) break; }
    File f = SD.open(path, FILE_WRITE);
    if (!f) return "";
    uint32_t rowB = CW / 2, img = rowB * CH, off = 14 + 40 + 64, fsz = off + img;
    uint8_t h[54] = {'B', 'M'};
    auto w32 = [&](int o, uint32_t v) { h[o] = v; h[o + 1] = v >> 8; h[o + 2] = v >> 16; h[o + 3] = v >> 24; };
    w32(2, fsz); w32(10, off); w32(14, 40); w32(18, CW); w32(22, CH); h[26] = 1; h[28] = 4; w32(34, img); w32(46, 16);
    f.write(h, 54);
    for (int i = 0; i < 16; ++i) { uint16_t c565 = PAINT_PAL[i];
      uint8_t q[4] = {(uint8_t)((c565 & 0x1F) << 3), (uint8_t)(((c565 >> 5) & 0x3F) << 2), (uint8_t)((c565 >> 11) << 3), 0}; f.write(q, 4); }
    for (int y = CH - 1; y >= 0; --y) f.write(cv + y * rowB, rowB);
    f.close();
    return path;
  };
  auto loadBmp = [&](const String &p) -> bool {
    File f = SD.open(p); if (!f) return false;
    uint8_t h[54]; f.read(h, 54);
    auto r32 = [&](int o) { return (uint32_t)h[o] | (h[o + 1] << 8) | (h[o + 2] << 16) | ((uint32_t)h[o + 3] << 24); };
    if (h[0] != 'B' || r32(18) != (uint32_t)CW || r32(22) != (uint32_t)CH || h[28] != 4) { f.close(); return false; }
    f.seek(r32(10));
    for (int y = CH - 1; y >= 0; --y) f.read(cv + y * (CW / 2), CW / 2);
    f.close(); return true;
  };
  redrawCanvas(); toolbar();
  int lx = -1, ly = -1, settle = 0;
  const int JUMP = 52;        // resistive panels throw the odd wild sample; a
                              // leap bigger than this starts a fresh dab rather
                              // than streaking a line clear across the canvas
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.down && t.sy >= CY && t.sy < CY + CH && t.y >= CY) {
      int x = constrain((int)t.x, 0, CW - 1), y = constrain((int)t.y - CY, 0, CH - 1);
      if (lx < 0) { if (++settle >= 2) { stamp(x, y); lx = x; ly = y; } }   // ignore the first noisy sample of a stroke
      else {
        int dx = x - lx, dy = y - ly;
        if (abs(dx) > JUMP || abs(dy) > JUMP) stamp(x, y);                  // jump = noise: dab, don't connect
        else { int steps = max(abs(dx), abs(dy)) / max(1, SIZES[size] / 2) + 1;
          for (int i = 1; i <= steps; ++i) stamp(lx + dx * i / steps, ly + dy * i / steps); }
        lx = x; ly = y;
      }
    } else { lx = -1; settle = 0; }
    if (!t.tap || t.sy < CY + CH) continue;
    if (t.sy >= 197 && t.sy < 217) { color = constrain(t.sx / 20, 0, 15); toolbar(); }
    else if (ui::inRect(t.sx, t.sy, 0, 218, 64, 22)) { size = (size + 1) % 4; toolbar(); }
    else if (ui::inRect(t.sx, t.sy, 64, 218, 64, 22)) { memset(cv, 0x11, CW * CH / 2); redrawCanvas(); }
    else if (ui::inRect(t.sx, t.sy, 128, 218, 64, 22)) { memset(cv, color * 0x11, CW * CH / 2); redrawCanvas(); }
    else if (ui::inRect(t.sx, t.sy, 192, 218, 64, 22)) {
      String p = saveBmp();
      ui::toast(p.length() ? ("saved " + p.substring(12)).c_str() : "save failed (SD?)", p.length() ? C_OK : C_ERR);
      delay(900); redrawCanvas(); toolbar();
    } else if (ui::inRect(t.sx, t.sy, 256, 218, 64, 22)) {
      String p = ui::pickFile("/data/paint", ".bmp", "LOAD sketch (.bmp)");
      bool ok = p.length() && loadBmp(p);
      c.header(); ui::clearBody(); redrawCanvas(); toolbar();
      if (p.length() && !ok) { ui::toast("only 320x170 16-colour sketches", C_ERR); delay(1200); toolbar(); }
    }
  }
  free(cv);
}

// ============================================================================
//  36  3D RAINBOW WARP ENGINE
// ============================================================================
void app_warp(AppCtx &c) {
  // All-integer star tunnel: positions and depth are ints (depth in tenths),
  // projection is one integer divide per star (no float math), so the CPU
  // never times out computing the deep-projection scales.
  const int N = 220, TOP = 26;
  struct Star { int16_t x, y, z, sx, sy; uint8_t sz; };
  Star *s = (Star *)malloc(sizeof(Star) * N);
  if (!s) return;
  auto spawn = [&](Star &st, bool far) { st.x = (int)rnd(200) - 100; st.y = (int)rnd(200) - 100; st.z = far ? 640 : 10 + (int)rnd(630); st.sx = -1; };
  for (int i = 0; i < N; ++i) spawn(s[i], false);
  int speed = 8;                    // depth units (tenths) per frame
  int cx = 160, cy = 133, tcx = 160, tcy = 133;
  uint16_t hueBase = 0; uint32_t fpsT = millis(); int frames = 0;
  ui::clearBody(TFT_BLACK);
  while (c.frame(16)) {
    Touch &t = *c.t;
    if (t.down) { tcx = t.x; tcy = constrain((int)t.y, TOP + 10, 230); } else { tcx = 160; tcy = 133; }
    if (t.swipe == SW_UP) speed = min(30, speed + 4);
    if (t.swipe == SW_DOWN) speed = max(2, speed - 4);
    cx += (tcx - cx) / 6; cy += (tcy - cy) / 6;
    hueBase += 2;
    for (int i = 0; i < N; ++i) {
      Star &st = s[i];
      if (st.sx >= 0) tft.fillRect(st.sx, st.sy, st.sz, st.sz, TFT_BLACK);
      st.z -= speed;
      if (st.z <= 5) { spawn(st, true); continue; }
      int sx = cx + (st.x * 1280) / st.z;      // 128.0/z with z in tenths -> 1280/z
      int sy = cy + (st.y * 1280) / st.z;
      if (sx < 0 || sx >= 318 || sy < TOP || sy >= 238) { spawn(st, true); continue; }
      uint8_t sz = st.z < 80 ? 3 : (st.z < 240 ? 2 : 1);
      uint8_t v = (uint8_t)constrain(255 - st.z * 3 / 10, 60, 255);
      tft.fillRect(sx, sy, sz, sz, ui::hsv((hueBase + st.z * 6 / 10) % 360, 255, v));
      st.sx = sx; st.sy = sy; st.sz = sz;
    }
    tft.drawPixel(cx, cy, TFT_WHITE);
    if (++frames && millis() - fpsT > 1000) { hudf("%d fps x%d", frames, speed); frames = 0; fpsT = millis(); }
  }
  free(s);
}

// ============================================================================
//  37  FALLING SAND PHYSICS SIMULATOR
// ============================================================================

// ============================================================================
//  38  CONWAY'S GAME OF LIFE
// ============================================================================
// ============================================================================
//  39  INFINITE MANDELBROT FRACTAL BENCHMARK
// ============================================================================
void app_mandel(AppCtx &c) {
  const int W = 320, H = 190, OY = 26;
  double cxr = -0.6, cyi = 0.0, scale = 3.2 / W;
  int iters = c.pInt("iterations", 64);
  uint16_t pal[256];
  auto mkPal = [&]() { for (int i = 0; i < 256; ++i) pal[i] = ui::hsv((i * 360 / 48 + 200) % 360, 230, i == 255 ? 0 : 255); };
  mkPal();
  auto toolbar = [&](const char *msg) {
    ui::button(0, 218, 64, 22, "ZOOM -", C_PANEL2, C_TEXT, 1);
    char s[16]; snprintf(s, 16, "ITER %d", iters); ui::button(64, 218, 64, 22, s, C_PANEL2, C_TEXT, 1);
    ui::button(128, 218, 64, 22, "RESET", C_PANEL2, C_TEXT, 1);
    tft.fillRect(194, 218, 126, 22, C_BG); tft.setTextColor(C_DIM, C_BG); tft.drawString(msg, 196, 225, 1);
  };
  bool redraw = true;
  uint16_t line[W];
  while (true) {
    if (redraw) {
      redraw = false;
      toolbar("rendering...");
      uint32_t t0 = micros();
      bool aborted = false;
      for (int y = 0; y < H && !aborted; ++y) {
        float ci = (float)(cyi + (y - H / 2) * scale);
        for (int x = 0; x < W; ++x) {
          float cr = (float)(cxr + (x - W / 2) * scale);
          float zr = 0, zi = 0, zr2 = 0, zi2 = 0; int i = 0;
          // cardioid / bulb test skips most interior points
          float q = (cr - 0.25f) * (cr - 0.25f) + ci * ci;
          if (q * (q + (cr - 0.25f)) < 0.25f * ci * ci || (cr + 1) * (cr + 1) + ci * ci < 0.0625f) i = iters;
          while (i < iters && zr2 + zi2 < 4.0f) { zi = 2 * zr * zi + ci; zr = zr2 - zi2 + cr; zr2 = zr * zr; zi2 = zi * zi; i++; }
          line[x] = i >= iters ? TFT_BLACK : pal[i & 0xFF];
        }
        tft.setSwapBytes(true); tft.pushImage(0, OY + y, W, 1, line); tft.setSwapBytes(false);
        if ((y & 7) == 0) { ui::clearEvents(); Touch &t = ui::poll(); if (ui::exitHit(t)) return; }
      }
      float secs = (micros() - t0) / 1e6f;
      char s[40]; snprintf(s, 40, "%.2fs %.0fkpx/s x%.0f", secs, W * H / secs / 1000, 3.2 / W / scale);
      toolbar(s);
      sys::log("mandel: %dx%d iter %d in %.3f s", W, H, iters, secs);
    }
    if (!c.loop()) return;
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (t.sy >= OY && t.sy < OY + H) {
      cxr += (t.sx - W / 2) * scale; cyi += (t.sy - OY - H / 2) * scale; scale /= 2;
      if (scale < 1e-7) scale = 1e-7;      // float precision limit
      redraw = true;
    } else if (ui::inRect(t.sx, t.sy, 0, 218, 64, 22)) { scale *= 2; redraw = true; }
    else if (ui::inRect(t.sx, t.sy, 64, 218, 64, 22)) { iters = iters >= 512 ? 32 : iters * 2; redraw = true; }
    else if (ui::inRect(t.sx, t.sy, 128, 218, 64, 22)) { cxr = -0.6; cyi = 0; scale = 3.2 / W; iters = 64; redraw = true; }
  }
}

// ============================================================================
//  41  ANIMATED VIRTUAL PET
// ============================================================================
void app_pet(AppCtx &c) {
  // ---- persistent state
  struct Pet {
    float hunger = 85, happy = 85, energy = 85, clean = 85, health = 100;
    uint32_t age = 0;      // minutes
    bool asleep = false, sick = false, dead = false;
    uint8_t poop = 0;      // 0..4 piles on the ground
    char name[16] = "Krivi";
  } p;
  time_t savedAt = 0;
  auto load = [&]() {
    if (!sys::sdOk) return;
    File f = SD.open("/sys/pet.json"); if (!f) return;
    JsonDocument d;
    if (!deserializeJson(d, f)) {
      p.hunger = d["hunger"] | 85.f; p.happy = d["happy"] | 85.f; p.energy = d["energy"] | 85.f;
      p.clean = d["clean"] | 85.f; p.health = d["health"] | 100.f; p.age = d["age"] | 0;
      p.asleep = d["asleep"] | false; p.sick = d["sick"] | false; p.dead = d["dead"] | false;
      p.poop = d["poop"] | 0; strlcpy(p.name, d["name"] | "Krivi", sizeof(p.name));
      savedAt = d["saved"] | 0;
    }
    f.close();
  };
  auto save = [&]() {
    if (!sys::sdOk) return;
    JsonDocument d; d["hunger"] = p.hunger; d["happy"] = p.happy; d["energy"] = p.energy;
    d["clean"] = p.clean; d["health"] = p.health; d["age"] = p.age; d["asleep"] = p.asleep;
    d["sick"] = p.sick; d["dead"] = p.dead; d["poop"] = p.poop; d["name"] = p.name;
    d["saved"] = sys::timeValid() ? (long)time(nullptr) : 0;
    File f = SD.open("/sys/pet.json", FILE_WRITE); if (f) { serializeJson(d, f); f.close(); }
  };
  load();
  // offline decay
  if (savedAt && sys::timeValid()) {
    float m = min(4320.0f, (time(nullptr) - savedAt) / 60.0f);   // cap 3 days
    if (m > 0 && !p.dead) {
      p.hunger -= m * 0.5f; p.happy -= m * 0.35f; p.clean -= m * 0.4f;
      p.energy += p.asleep ? m * 1.2f : -m * 0.3f;
      if (p.hunger < 15 || p.clean < 15) p.health -= m * 0.3f;
      if ((int)m / 90 > 0) p.poop = min(4, p.poop + (int)(m / 90));
      p.age += (uint32_t)m;
    }
  }
  auto clamp = [&]() {
    p.hunger = constrain(p.hunger, 0.f, 100.f); p.happy = constrain(p.happy, 0.f, 100.f);
    p.energy = constrain(p.energy, 0.f, 100.f); p.clean = constrain(p.clean, 0.f, 100.f);
    p.health = constrain(p.health, 0.f, 100.f);
  };
  clamp();
  if (p.health <= 0) p.dead = true;

  enum { EGG, BABY, TEEN, ADULT };
  auto stage = [&]() { return p.dead ? -1 : p.age < 2 ? EGG : p.age < 20 ? BABY : p.age < 90 ? TEEN : ADULT; };
  static const char *STN[4] = {"Egg", "Baby", "Teen", "Adult"};

  TFT_eSprite spr(&tft); spr.setColorDepth(8);
  bool haveSpr = spr.createSprite(184, 158);

  auto statRow = [&](int i, const char *l, float v) {
    int y = 32 + i * 24;
    tft.setTextColor(C_DIM, C_BG); tft.drawString(l, 192, y, 1);
    uint16_t col = v > 50 ? C_OK : v > 20 ? C_WARN : C_ERR;
    ui::bar(192, y + 9, 122, 9, v / 100, col, C_PANEL);
  };
  auto stats = [&]() {
    const char *L[5] = {"FOOD", "FUN", "ENERGY", "HYGIENE", "HEALTH"};
    float V[5] = {p.hunger, p.happy, p.energy, p.clean, p.health};
    for (int i = 0; i < 5; ++i) statRow(i, L[i], V[i]);
  };
  auto info = [&]() {
    tft.fillRect(0, 26, 190, 14, C_BG);
    char s[40];
    int st = stage();
    if (p.dead) snprintf(s, 40, "%s  (RIP)", p.name);
    else snprintf(s, 40, "%s  %s  %lud%luh", p.name, STN[st], (unsigned long)(p.age / 1440), (unsigned long)(p.age / 60 % 24));
    tft.setTextColor(p.sick ? C_WARN : C_TEXT, C_BG); tft.drawString(s, 6, 28, 1);
    if (p.sick && !p.dead) { tft.setTextColor(C_WARN, C_BG); tft.drawString("SICK - give MEDS", 120, 28, 1); }
  };
  auto buttons = [&]() {
    const char *L[5] = {"FEED", "PLAY", p.asleep ? "WAKE" : "SLEEP", "CLEAN", "MEDS"};
    uint16_t C[5] = {RGB565(200, 120, 0), RGB565(0, 150, 90), RGB565(70, 70, 160), RGB565(0, 140, 150), RGB565(190, 40, 90)};
    for (int i = 0; i < 5; ++i) ui::button(2 + i * 63, 198, 61, 38, L[i], C[i], TFT_WHITE, 2);
  };
  ui::clearBody(); info(); stats(); buttons();

  uint32_t lastDecay = millis(), lastSave = millis(), minT = millis(), anim = 0;
  int action = 0; uint32_t actionT = 0; float ballX = 0;
  bool redrawUi = false;

  // ground poop spots
  static const int PX[4] = {20, 150, 70, 120};

  while (c.frame(60)) {
    Touch &t = *c.t;
    anim++;
    int st = stage();
    if (t.tap) {
      if (p.dead) {
        if (ui::inRect(t.sx, t.sy, 2, 198, 320, 38)) {           // tap buttons area to hatch a new egg
          p = Pet(); strcpy(p.name, "Krivi"); savedAt = 0; redrawUi = true;
        }
      } else if (ui::inRect(t.sx, t.sy, 2, 198, 61, 38)) {        // FEED
        if (!p.asleep) { p.hunger += 28; p.happy += 3; action = 1; actionT = millis();
          audio::tone(0, 660, 70, audio::TRIANGLE, 110, 110); if (rnd(3) == 0 && p.poop < 4) p.poop++; redrawUi = true; }
      } else if (ui::inRect(t.sx, t.sy, 65, 198, 61, 38)) {       // PLAY
        if (!p.asleep && p.energy > 12) { p.happy += 22; p.energy -= 10; p.hunger -= 4; action = 2; actionT = millis(); ballX = 0; audio::tone(0, 990, 70, audio::SQUARE, 70); redrawUi = true; }
        else audio::beep(220, 120);
      } else if (ui::inRect(t.sx, t.sy, 128, 198, 61, 38)) {      // SLEEP
        p.asleep = !p.asleep; redrawUi = true;
      } else if (ui::inRect(t.sx, t.sy, 191, 198, 61, 38)) {      // CLEAN
        p.clean = 100; p.poop = 0; action = 3; actionT = millis(); audio::tone(0, 1400, 60, audio::SINE, 120, 120); redrawUi = true;
      } else if (ui::inRect(t.sx, t.sy, 254, 198, 61, 38)) {      // MEDS
        if (p.sick) { p.sick = false; p.health += 35; action = 4; actionT = millis(); audio::tone(1, 523, 90, audio::SINE, 200, 200); }
        else audio::beep(300, 80);
        redrawUi = true;
      } else if (ui::inRect(t.sx, t.sy, 0, 26, 120, 16)) {        // rename
        String nn = p.name;
        if (ui::textInput(nn, "Name your pet", 14) && nn.length()) { strlcpy(p.name, nn.c_str(), sizeof(p.name)); }
        c.header(); ui::clearBody(); redrawUi = true;
      } else if (!p.asleep && ui::inRect(t.sx, t.sy, 6, 42, 184, 150)) {   // pet it
        p.happy += 4; action = 3; actionT = millis(); audio::beep(1600, 25); redrawUi = true;
      }
      clamp();
    }

    if (millis() - lastDecay > 8000 && !p.dead) {                 // live decay every 8 s
      lastDecay = millis();
      p.hunger -= 0.6f; p.happy -= 0.4f; p.clean -= 0.3f - (p.poop ? -0.5f : 0);
      p.energy += p.asleep ? 1.4f : -0.25f;
      if (p.asleep && p.energy >= 100) p.asleep = false;
      // health model
      bool ok = p.hunger > 25 && p.clean > 25 && p.happy > 15 && !p.sick;
      p.health += ok ? 0.5f : (p.sick ? -1.4f : -0.6f);
      if (!p.sick && (p.clean < 18 || p.hunger < 10 || p.health < 30) && rnd(3) == 0) p.sick = true;
      if (!p.asleep && p.poop < 4 && rnd(6) == 0) p.poop++;
      clamp();
      if (p.health <= 0) { p.dead = true; audio::tone(0, 180, 110, audio::TRIANGLE, 700, 700); }
      redrawUi = true;
    }
    if (millis() - minT > 60000) { minT = millis(); if (!p.dead) p.age++; redrawUi = true; }
    if (millis() - lastSave > 20000) { lastSave = millis(); save(); }
    if (action && millis() - actionT > 1400) action = 0;
    if (redrawUi) { info(); stats(); buttons(); redrawUi = false; }

    if (!haveSpr) continue;
    // ---------------- draw pet (polished graphics) ----------------
    int hr = 12; struct tm tmv; if (sys::now(tmv)) hr = tmv.tm_hour;
    bool night = hr < 6 || hr >= 20;
    bool dusk  = (hr >= 18 && hr < 20) || (hr >= 6 && hr < 8);
    // --- gradient sky
    uint16_t skyTop = night ? RGB565(12,14,40)  : dusk ? RGB565(250,140,90)  : RGB565(70,150,240);
    uint16_t skyBot = night ? RGB565(44,34,78)  : dusk ? RGB565(255,205,130) : RGB565(175,215,250);
    for (int y = 0; y < 128; y++) {
      int rr = map(y,0,127,(skyTop>>11)&31,(skyBot>>11)&31);
      int gg = map(y,0,127,(skyTop>>5)&63,(skyBot>>5)&63);
      int bb = map(y,0,127, skyTop&31, skyBot&31);
      spr.drawFastHLine(0, y, 184, (rr<<11)|(gg<<5)|bb);
    }
    // --- sun / moon with glow + stars
    int lx = 150, ly = 24;
    if (night) {
      for (int i = 0; i < 16; i++) { int sx=(i*41+5)%184, sy=(i*27)%84; spr.fillCircle(sx,sy,(i%4)?1:2, TFT_WHITE); }
      spr.fillCircle(lx,ly,12, RGB565(230,230,245)); spr.fillCircle(lx+5,ly-3,9, skyTop);
    } else {
      for (int g = 17; g > 9; g--) { uint16_t gc = RGB565(255,235,120); spr.fillCircle(lx,ly,g, ((g&1)?gc:RGB565(255,245,160))); }
      spr.fillCircle(lx,ly,9, RGB565(255,250,190));
    }
    // --- drifting clouds
    uint16_t cloud = night ? RGB565(70,70,100) : RGB565(245,250,255);
    for (int cC = 0; cC < 2; cC++) {
      int base = (cC==0) ? (anim/3) : (anim/5 + 90);
      int cxo = (base % 230) - 24, cyo = cC==0 ? 30 : 52;
      spr.fillEllipse(cxo,cyo,15,8,cloud); spr.fillEllipse(cxo+13,cyo-4,12,8,cloud); spr.fillEllipse(cxo+25,cyo+2,14,7,cloud);
    }
    // --- grass foreground with blades + flowers
    spr.fillRect(0,126,184,32, RGB565(66,158,66));
    spr.fillRect(0,126,184,3,  RGB565(92,188,92));
    for (int i = 0; i < 26; i++) { int gx=(i*17+6)%184, h=4+((i*13)%6); spr.drawFastVLine(gx,126-h,h, RGB565(56,146,56)); }
    for (int i = 0; i < 3; i++) { int fx=28+i*62; uint16_t fc = i==0?RGB565(255,120,160):i==1?TFT_WHITE:RGB565(185,140,255);
      spr.fillCircle(fx-3,123,2,fc); spr.fillCircle(fx+3,123,2,fc); spr.fillCircle(fx,120,2,fc); spr.fillCircle(fx,126,2,fc); spr.fillCircle(fx,123,2,RGB565(255,210,80)); }
    // --- poop piles
    for (int i = 0; i < p.poop; ++i) { int x = PX[i]; spr.fillEllipse(x,143,6,4,RGB565(96,62,22)); spr.fillEllipse(x,139,4,3,RGB565(108,70,26)); spr.fillEllipse(x,136,2,2,RGB565(118,76,30)); }

    if (p.dead) {
      spr.fillRoundRect(74,88,36,48,6, RGB565(150,150,160)); spr.fillRect(66,102,52,34, RGB565(150,150,160));
      spr.setTextColor(RGB565(70,70,80)); spr.setTextDatum(MC_DATUM); spr.drawString("RIP",92,110,2); spr.setTextDatum(TL_DATUM);
      spr.pushSprite(6,42);
      static bool once=false; if(!once){once=true; ui::toast("tap the buttons to hatch a new egg", C_DIM);} 
      continue;
    }

    float mood = (p.hunger + p.happy + p.health) / 300.0f;
    uint16_t body  = p.sick ? RGB565(150,185,130) : mood>0.55f ? RGB565(120,200,255) : mood>0.3f ? RGB565(150,170,205) : RGB565(185,155,155);
    int _br = ((body>>11)&31)*255/31, _bg = ((body>>5)&63)*255/63, _bb = (body&31)*255/31;
    uint16_t dark  = RGB565(_br*7/10, _bg*7/10, _bb*7/10);
    uint16_t light = RGB565(min(255,_br+48), min(255,_bg+48), min(255,_bb+48));
    int cx = 92, bob = p.asleep ? (int)(sinf(anim*0.08f)*1) : (int)(sinf(anim*0.18f)*4);
    int cy = 98 + bob;

    if (st == EGG) {
      bool hatch = p.age >= 1; int w = hatch ? (int)(sinf(anim*0.6f)*3) : 0;
      spr.fillEllipse(cx+w,cy+30,20,5,RGB565(40,110,40));
      spr.fillEllipse(cx+w,cy+4,24,30,RGB565(248,238,214)); spr.fillEllipse(cx+w-7,cy-2,8,12,RGB565(255,250,235));
      spr.drawEllipse(cx+w,cy+4,24,30,RGB565(205,190,165));
      for (int i=-2;i<=2;i++) spr.fillCircle(cx+w+i*8,cy+6,3,RGB565(222,186,150));
      if (hatch) { spr.drawLine(cx+w-11,cy-6,cx+w,cy+2,RGB565(160,140,110)); spr.drawLine(cx+w,cy+2,cx+w+11,cy-6,RGB565(160,140,110));
        spr.setTextColor(night?TFT_WHITE:TFT_BLACK); spr.setTextDatum(MC_DATUM); spr.drawString("...hatching!",cx,152,1); spr.setTextDatum(TL_DATUM); }
    } else {
      int r = st==BABY ? 27 : st==TEEN ? 34 : 42;
      // shadow
      spr.fillEllipse(cx, cy+r-4, r+4, 6, RGB565(46,120,46));
      // tail (wags)
      int tw = p.asleep ? 0 : (int)(sinf(anim*0.3f)*8);
      spr.fillEllipse(cx+r-4, cy+6+tw, 7, 5, dark);
      // feet
      spr.fillEllipse(cx-r/2, cy+r-6, 9, 6, dark); spr.fillEllipse(cx+r/2, cy+r-6, 9, 6, dark);
      // ears (grow from TEEN) with inner pink
      if (st >= TEEN) { int er = st==ADULT ? 12 : 9; int ewig = p.asleep?0:(int)(sinf(anim*0.22f)*2);
        spr.fillCircle(cx-r+7, cy-r+8-ewig, er, body); spr.fillCircle(cx+r-7, cy-r+8+ewig, er, body);
        spr.fillCircle(cx-r+7, cy-r+8-ewig, er/2, RGB565(255,160,185)); spr.fillCircle(cx+r-7, cy-r+8+ewig, er/2, RGB565(255,160,185)); }
      // body with shading
      spr.fillEllipse(cx, cy, r, r-3, body);
      spr.fillEllipse(cx, cy+4, r-4, r-8, light);              // belly patch
      spr.drawEllipse(cx, cy, r, r-3, dark);
      spr.fillEllipse(cx-r/2, cy-r/2+4, r/4, r/5, RGB565(255,255,255)); // top sheen
      // head tuft
      if (!p.asleep) { int hh=(int)(sinf(anim*0.25f)*2); spr.drawLine(cx,cy-r+2,cx-3,cy-r-8+hh,dark); spr.fillCircle(cx-3,cy-r-9+hh,3,body); }
      // eyes
      int ey = cy - 6, es = st==BABY ? 8 : 10;
      if (p.asleep) { spr.drawFastHLine(cx-16,ey,10,TFT_BLACK); spr.drawFastHLine(cx-15,ey+1,8,TFT_BLACK); spr.drawFastHLine(cx+6,ey,10,TFT_BLACK); spr.drawFastHLine(cx+7,ey+1,8,TFT_BLACK); }
      else {
        bool blink = (anim % 60) < 3;
        if (blink) { spr.fillRect(cx-11-es/2,ey,es,2,TFT_BLACK); spr.fillRect(cx+11-es/2,ey,es,2,TFT_BLACK); }
        else {
          spr.fillCircle(cx-11,ey,es,TFT_WHITE); spr.fillCircle(cx+11,ey,es,TFT_WHITE);
          int lookx = action ? 2 : 0;
          spr.fillCircle(cx-11+lookx,ey+1,es-3,TFT_BLACK); spr.fillCircle(cx+11+lookx,ey+1,es-3,TFT_BLACK);
          spr.fillCircle(cx-13+lookx,ey-2,2,TFT_WHITE); spr.fillCircle(cx+9+lookx,ey-2,2,TFT_WHITE);   // glints
        }
        // eyebrows hint mood
        if (mood <= 0.3f && !p.sick) { spr.drawLine(cx-16,ey-9,cx-7,ey-6,dark); spr.drawLine(cx+7,ey-6,cx+16,ey-9,dark); }
      }
      // rosy cheeks
      if (!p.sick && !p.asleep) { spr.fillCircle(cx-r+9, cy+6, 4, RGB565(255,150,175)); spr.fillCircle(cx+r-9, cy+6, 4, RGB565(255,150,175)); }
      if (p.sick) { spr.setTextColor(RGB565(120,200,90)); spr.setTextDatum(MC_DATUM); spr.drawString("~",cx+r-4,cy-r+2,2); spr.setTextDatum(TL_DATUM); }
      // mouth by mood
      int my = cy + 11;
      if (!p.asleep) {
        if (p.sick) spr.drawLine(cx-7,my,cx+7,my-4,RGB565(120,70,70));
        else if (mood>0.55f || action) { spr.fillCircle(cx,my,7,TFT_BLACK); spr.fillRect(cx-8,my-7,16,7,body); spr.fillCircle(cx,my+2,3,RGB565(255,120,140)); }
        else if (mood>0.3f) spr.drawFastHLine(cx-6,my+2,12,TFT_BLACK);
        else spr.drawCircle(cx,my+7,6,TFT_BLACK); spr.fillRect(cx-7,my+7,14,7,body);
      }
      if (p.asleep) { spr.setTextColor(night?TFT_WHITE:RGB565(40,40,80)); spr.drawString("z",cx+r,cy-r+(anim%16),2); spr.drawString("Z",cx+r+8,cy-r-6+(anim%24)/2,4); }
    }
    // --- action props
    if (action == 1) { spr.fillEllipse(150,78,12,5,RGB565(210,180,120)); spr.fillCircle(150,72,9,RGB565(230,70,70)); spr.fillRect(149,60,2,6,RGB565(90,60,20)); spr.fillCircle(153,69,2,RGB565(255,160,160)); }
    if (action == 2) { ballX += 7; int bxp=16+((int)ballX%150), byp=120-(int)fabsf(sinf(ballX/18)*42); spr.fillCircle(bxp,byp,7,C_WARN); spr.drawLine(bxp-5,byp,bxp+5,byp,RGB565(180,100,0)); spr.drawLine(bxp,byp-5,bxp,byp+5,RGB565(180,100,0)); }
    if (action == 3) { for (int i=0;i<4;i++){ int a=(anim*6+i*40)%150; int hx=cx+(i-2)*20+10, hy=96-a/5; spr.fillCircle(hx-2,hy,3,RGB565(255,90,140)); spr.fillCircle(hx+2,hy,3,RGB565(255,90,140)); spr.fillTriangle(hx-4,hy+1,hx+4,hy+1,hx,hy+6,RGB565(255,90,140)); } }
    if (action == 4) { spr.fillRoundRect(148,60,12,18,2,TFT_WHITE); spr.fillRect(150,56,8,8,RGB565(210,50,100)); spr.fillRect(152,58,4,4,TFT_WHITE); }
    spr.pushSprite(6, 42);
  }
  save();
  if (haveSpr) spr.deleteSprite();
}

// ============================================================================
//  42  ONBOARD TOUCH DIAGNOSTICS
// ============================================================================
void app_touchdiag(AppCtx &c) {
  int mode = 0;   // 0 grid, 1 targets, 2 draw
  static const char *MODES[3] = {"GRID", "TARGETS", "DRAW"};
  static const int TG[5][2] = {{20, 46}, {300, 46}, {160, 133}, {20, 220}, {300, 220}};
  int tgi = 0; float errSum = 0; int errMax = 0;
  auto grid = [&]() {
    ui::clearBody(TFT_BLACK);
    for (int x = 0; x < 320; x += 40) tft.drawFastVLine(x, 26, 214, RGB565(25, 40, 60));
    for (int y = 40; y < 240; y += 40) tft.drawFastHLine(0, y, 320, RGB565(25, 40, 60));
    tft.drawRect(0, 26, 320, 214, C_PANEL2);
    tft.setTextColor(C_DIM, TFT_BLACK); tft.drawString("tap the title bar to change mode", 6, 228, 1);
    hud(MODES[mode], C_ACCENT);
  };
  auto target = [&]() {
    grid();
    if (tgi < 5) {
      int x = TG[tgi][0], y = TG[tgi][1];
      tft.drawCircle(x, y, 10, C_ERR); tft.drawFastHLine(x - 14, y, 29, C_ERR); tft.drawFastVLine(x, y - 14, 29, C_ERR);
      char s[32]; snprintf(s, 32, "tap target %d of 5", tgi + 1); ui::centerText(s, 160, 100, C_TEXT, TFT_BLACK, 2);
    } else {
      char s[48]; snprintf(s, 48, "avg error %.1f px, max %d px", errSum / 5, errMax);
      ui::centerText(s, 160, 110, errMax < 8 ? C_OK : C_WARN, TFT_BLACK, 2);
      ui::centerText(errMax < 8 ? "calibration OK" : "consider touch.invertX/Y or map limits", 160, 132, C_DIM, TFT_BLACK, 1);
      ui::centerText("tap to repeat", 160, 150, C_DIM, TFT_BLACK, 1);
    }
  };
  grid();
  int px = -1, py = -1, lx = -1, ly = -1;
  uint32_t lastTxt = 0;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && t.sy < 26) { mode = (mode + 1) % 3; tgi = 0; errSum = 0; errMax = 0; if (mode == 1) target(); else grid(); continue; }
    int16_t rx, ry, rz;
    bool raw = touch::readRaw(rx, ry, rz);
    if (millis() - lastTxt > 100) {
      lastTxt = millis();
      char s[64];
      if (raw) snprintf(s, 64, "raw x%4d y%4d z%4d -> %3d,%3d ", rx, ry, rz, t.x, t.y);
      else snprintf(s, 64, "raw ---- (no touch)  z%4d           ", rz);
      tft.setTextColor(C_ACCENT, TFT_BLACK); tft.drawString(s, 6, 30, 1);
    }
    if (mode == 0 && t.down) {
      if (px >= 0) { tft.drawFastHLine(0, py, 320, TFT_BLACK); tft.drawFastVLine(px, 40, 200, TFT_BLACK);
        if ((py - 40) % 40 == 0) tft.drawFastHLine(0, py, 320, RGB565(25, 40, 60)); if (px % 40 == 0) tft.drawFastVLine(px, 40, 200, RGB565(25, 40, 60)); }
      px = t.x; py = max((int)t.y, 40);
      tft.drawFastHLine(0, py, 320, C_OK); tft.drawFastVLine(px, 40, 200, C_OK); tft.fillCircle(px, py, 3, C_ERR);
    }
    if (mode == 1 && t.tap) {
      if (tgi >= 5) { tgi = 0; errSum = 0; errMax = 0; target(); continue; }
      int e = (int)sqrtf(sq(t.sx - TG[tgi][0]) + sq(t.sy - TG[tgi][1]));
      errSum += e; errMax = max(errMax, e);
      tft.fillCircle(t.sx, t.sy, 3, C_WARN);
      sys::log("touchdiag: target %d err %d px (at %d,%d)", tgi, e, t.sx, t.sy);
      delay(250); tgi++; target();
    }
    if (mode == 2) {
      if (t.down && t.y > 40) { if (lx >= 0) tft.drawLine(lx, ly, t.x, t.y, ui::hsv(millis() / 10 % 360, 255, 255)); lx = t.x; ly = t.y; }
      else lx = -1;
    }
  }
}

// ============================================================================
//  43  SYSTEM MANUAL & DIRECTORY  (+ e-book reader + system info)
// ============================================================================
static void manualReader(AppCtx &c, const String &path) {
  File f = SD.open(path);
  if (!f) return;
  std::vector<uint32_t> pages; pages.push_back(0);
  int pg = 0; const int X0 = 6, Y0 = 30, W = 308, LH = 16, LINES = 11;
  auto render = [&]() -> uint32_t {               // returns next page offset
    tft.fillRect(0, 26, 320, 190, RGB565(245, 240, 225));
    f.seek(pages[pg]);
    String line, word; int ln = 0; uint32_t pos = pages[pg], lineStart = pos;
    tft.setTextColor(RGB565(30, 30, 40), RGB565(245, 240, 225));
    while (ln < LINES) {
      int ch = f.read();
      if (ch < 0) { if (word.length() || line.length()) tft.drawString(line + (line.length() ? " " : "") + word, X0, Y0 + ln * LH, 2); return f.size(); }
      pos++;
      if (ch == '\r') continue;
      if (ch == ' ' || ch == '\n' || ch == '\t') {
        String cand = line.length() ? line + " " + word : word;
        if (tft.textWidth(cand, 2) > W) { tft.drawString(line, X0, Y0 + ln * LH, 2); ln++; line = word; lineStart = pos - word.length() - 1; }
        else line = cand;
        word = "";
        if (ch == '\n') { if (ln < LINES) { tft.drawString(line, X0, Y0 + ln * LH, 2); ln++; } line = ""; lineStart = pos; }
      } else word += (char)ch;
      if (ln >= LINES) return lineStart;
    }
    return pos;
  };
  String nm = path.substring(path.lastIndexOf('/') + 1);
  while (true) {
    uint32_t next = render();
    tft.fillRect(0, 216, 320, 24, C_BG);
    ui::button(4, 216, 70, 22, "< PREV", C_PANEL2, C_TEXT, 1); ui::button(246, 216, 70, 22, "NEXT >", C_PANEL2, C_TEXT, 1);
    char s[48]; snprintf(s, 48, "%s  p%d  %d%%", nm.substring(0, 18).c_str(), pg + 1, (int)(100.0 * next / max((size_t)1, f.size())));
    ui::centerText(s, 160, 227, C_DIM, C_BG, 1);
    while (true) {
      if (!c.loop()) { f.close(); return; }
      Touch &t = *c.t;
      bool nx = t.swipe == SW_LEFT || (t.tap && (ui::inRect(t.sx, t.sy, 246, 216, 70, 22) || (t.sy < 216 && t.sx > 160)));
      bool pv = t.swipe == SW_RIGHT || (t.tap && (ui::inRect(t.sx, t.sy, 4, 216, 70, 22) || (t.sy < 216 && t.sx <= 160)));
      if (nx && next < f.size()) { if (pg + 1 >= (int)pages.size()) pages.push_back(next); pg++; break; }
      if (pv && pg > 0) { pg--; break; }
    }
  }
}

void app_manual(AppCtx &c) {
  int tab = 0, listTop = 0;
  auto tabs = [&]() {
    static const char *T[3] = {"APPS", "BOOKS", "SYSTEM"};
    for (int i = 0; i < 3; ++i) ui::button(4 + i * 106, 28, 102, 24, T[i], i == tab ? C_ACCENT : C_PANEL2, i == tab ? TFT_BLACK : C_TEXT, 2);
  };
  auto appsList = [&]() {
    tft.fillRect(0, 54, 320, 186, C_BG);
    for (int i = 0; i < 9 && listTop + i < launcher::APP_COUNT; ++i) {
      const AppDef &a = launcher::APPS[listTop + i];
      int y = 56 + i * 20;
      tft.fillRect(4, y + 2, 12, 12, a.color);
      char s[64]; snprintf(s, 64, "%02d  %-24s p%d", a.id, a.name, a.page + 1);
      tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 22, y + 2, 2);
    }
    ui::button(4, 216, 100, 22, "< UP", C_PANEL2, C_TEXT, 1); ui::button(216, 216, 100, 22, "DOWN >", C_PANEL2, C_TEXT, 1);
    char s[24]; snprintf(s, 24, "%d-%d of %d", listTop + 1, min(listTop + 9, launcher::APP_COUNT), launcher::APP_COUNT);
    ui::centerText(s, 160, 227, C_DIM, C_BG, 1);
  };
  auto sysInfo = [&]() {
    tft.fillRect(0, 54, 320, 186, C_BG);
    struct tm tm; bool tv = sys::now(tm);
    char rows[13][64];
    snprintf(rows[0], 64, "KRIVI OS %s  (%s panel)", KRIVI_VERSION, KRIVI_PANEL_NAME);
    snprintf(rows[1], 64, "Chip %s rev%d @ %lu MHz", ESP.getChipModel(), ESP.getChipRevision(), (unsigned long)ESP.getCpuFreqMHz());
    snprintf(rows[2], 64, "Heap free %u KB, largest block %u KB", ESP.getFreeHeap() / 1024, ESP.getMaxAllocHeap() / 1024);
    snprintf(rows[3], 64, "Flash %u MB, firmware %u KB", ESP.getFlashChipSize() / 1048576, ESP.getSketchSize() / 1024);
    snprintf(rows[4], 64, "SD: %s %llu MB", sys::sdOk ? "mounted" : "NOT mounted", sys::sdSizeMB);
    snprintf(rows[5], 64, "Uptime %lu min   Clock: %s", millis() / 60000, sys::ntpState());
    if (tv) snprintf(rows[6], 64, "Time %04d-%02d-%02d %02d:%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min);
    else snprintf(rows[6], 64, "Time not set (WiFi NTP or Alarm app)");
    snprintf(rows[7], 64, "Settings: /sys/settings.json  Logs: /sys/boot/");
    snprintf(rows[8], 64, "TFT HSPI 14/13/12 CS15 DC2 BL21  SD VSPI CS5");
    snprintf(rows[9], 64, "Touch soft-SPI 25/32/39 CS33 IRQ36");
    snprintf(rows[10], 64, "Speaker GPIO26  Mic IO35  LDR IO34  Relay IO22");
    snprintf(rows[11], 64, "RGB LED 4/16/17 (active low)  MAC %s", WiFi.macAddress().c_str());
    snprintf(rows[12], 64, "Exit box: X %d-%d, Y %d-%d", EXIT_X0, EXIT_X1, EXIT_Y0, EXIT_Y1);
    for (int i = 0; i < 13; ++i) { tft.setTextColor(i ? C_TEXT : C_ACCENT, C_BG); tft.drawString(rows[i], 6, 58 + i * 14, 1); }
  };
  auto books = [&]() {
    tft.fillRect(0, 54, 320, 186, C_BG);
    ui::centerText("Read .txt manuals, logs and e-books", 160, 90, C_TEXT, C_BG, 2);
    ui::centerText("from /data/reader", 160, 110, C_DIM, C_BG, 2);
    ui::button(60, 140, 200, 40, "OPEN LIBRARY", C_ACCENT, TFT_BLACK);
    ui::button(60, 186, 200, 30, "BOOT LOG", C_PANEL2);
  };
  auto showTab = [&]() { tabs(); if (tab == 0) appsList(); else if (tab == 1) books(); else sysInfo(); };
  ui::clearBody(); showTab();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && t.sy >= 28 && t.sy < 52) { tab = constrain((t.sx - 4) / 106, 0, 2); showTab(); continue; }
    if (tab == 0) {
      if (t.swipe == SW_UP || (t.tap && ui::inRect(t.sx, t.sy, 216, 216, 100, 22))) { if (listTop + 9 < launcher::APP_COUNT) { listTop += 9; appsList(); } }
      else if (t.swipe == SW_DOWN || (t.tap && ui::inRect(t.sx, t.sy, 4, 216, 100, 22))) { if (listTop > 0) { listTop = max(0, listTop - 9); appsList(); } }
      else if (t.tap && t.sy >= 56 && t.sy < 56 + 9 * 20) {
        int i = listTop + (t.sy - 56) / 20;
        if (i < launcher::APP_COUNT) {
          const AppDef &a = launcher::APPS[i];
          ui::clearBody();
          tft.fillRoundRect(6, 30, 40, 40, 8, a.color);
          char s[8]; snprintf(s, 8, "%02d", a.id); ui::centerText(s, 26, 50, TFT_WHITE, a.color, 4);
          tft.setTextColor(C_TEXT, C_BG); tft.drawString(a.name, 54, 32, 4);
          tft.setTextColor(C_DIM, C_BG); tft.drawString(launcher::PAGE_TITLES[a.page], 54, 56, 1);
          tft.setTextColor(C_WARN, C_BG); tft.drawString("REQUIRES", 6, 80, 1);
          // wrap helper
          auto wrap = [&](const char *txt, int y, uint16_t col) {
            String line, word; tft.setTextColor(col, C_BG);
            for (const char *p = txt;; ++p) {
              if (*p == ' ' || *p == '\n' || !*p) {
                String cand = line.length() ? line + " " + word : word;
                if (tft.textWidth(cand, 2) > 306 && line.length()) { tft.drawString(line, 6, y, 2); y += 16; line = word; } else line = cand;
                word = "";
                if (*p == '\n') { tft.drawString(line, 6, y, 2); y += 16; line = ""; }
                if (!*p) { if (line.length()) { tft.drawString(line, 6, y, 2); y += 16; } break; }
              } else word += *p;
            }
            return y;
          };
          int y = wrap(a.needs, 92, C_TEXT);
          tft.setTextColor(C_ACCENT, C_BG); tft.drawString("HOW IT WORKS", 6, y + 4, 1);
          wrap(a.help, y + 16, C_TEXT);
          ui::button(216, 30, 100, 26, "BACK", C_PANEL2);
          while (c.loop()) if (c.t->tap) break;
          if (c.exitReq) return;
          ui::clearBody(); showTab();
        }
      }
    } else if (tab == 1 && t.tap) {
      if (ui::inRect(t.sx, t.sy, 60, 140, 200, 40)) {
        String p = ui::pickFile("/data/reader", ".txt", "LIBRARY /data/reader");
        c.header(); ui::clearBody();
        if (p.length()) { manualReader(c, p); if (c.exitReq) return; }
        c.header(); ui::clearBody(); showTab();
      } else if (ui::inRect(t.sx, t.sy, 60, 186, 200, 30)) {
        ui::clearBody(); manualReader(c, "/sys/boot/boot_last.log"); if (c.exitReq) return;
        ui::clearBody(); showTab();
      }
    } else if (tab == 2 && t.tap) sysInfo();
  }
}
