// ============================================================================
//  KRIVI OS - 5-page desktop launcher + 43-app registry
// ============================================================================
#include "krivi.h"

namespace launcher {

#define P1 RGB565(230, 60, 90)
#define P2 RGB565(150, 80, 240)
#define P3 RGB565(0, 180, 170)
#define P4 RGB565(40, 160, 255)
#define P5 RGB565(255, 150, 30)
#define P6 RGB565(0, 210, 120)

#define NUM_PAGES 6
const char *PAGE_TITLES[NUM_PAGES] = {"GAMING & EMULATION", "MEDIA & SENSORS",
                              "UTILITIES & TIME", "PI LINK & RADIO",
                              "GRAPHICS & SANDBOX", "WIRELESS LAB & SYSTEM"};

const AppDef APPS[] = {
// ---------------------------------------------------------------- page 1
{1, 0, "NES Emulator", "NES Emulator", "NES", P1, app_nes,
 "microSD /roms/*.nes (mappers 0/1/2/3/4 that fit in RAM; no PSRAM so big games like SMB3 are too large)",
 "Pick a ROM. Left half is the D-pad; right panel has A, B, JUMP-RIGHT "
 "(A+Right), START, SELECT. Supports NROM/MMC1/UxROM/CNROM/MMC3 (incl. the "
 "MMC3 scanline-IRQ status-bar split). The whole ROM loads into RAM, so with "
 "no PSRAM only games up to ~180 KB fit. Audio muted for speed."},
{80, 0, "Arcade", "Arcade", "ARC", P1, app_arcade, "Touchscreen",
 "A single menu of 10 classics - Flappy Bird, Snake, Tetris, Pong, Breakout, "
 "Minesweeper, Chess, 3D Dice, Ludo and Snakes & Ladders. Tap a game to play; "
 "tap EXIT to come back to the list (each game frees its RAM on exit). Ludo "
 "and Snakes & Ladders are 2-4 player pass-and-play."},
// Snake, Tetris, Pong, Flappy, Minesweeper, Breakout and Chess now live inside
// the Arcade hub (app 80) so they are not duplicated here on the home grid.
// ---------------------------------------------------------------- page 2 (MEDIA & SENSORS)
{79, 1, "Bluetooth + MP3", "BT + MP3", "BT", P2, app_btaudio, "Bluetooth headphones + SD /music",
 "Three tabs: BLUETOOTH pairs headphones/speakers (A2DP, auto-reconnects); "
 "PLAYER streams the .mp3 files in /music to them (play/pause, prev/next, "
 "shuffle, volume); FTP SERVER uploads music over WiFi (user krivi / pass krivi). "
 "Bluetooth and WiFi run one at a time."},
{81, 1, "Internet Radio", "Radio", "RAD", P2, app_radio, "WiFi",
 "Streams an MP3 radio station over WiFi and plays it on the speaker. Pick a "
 "preset or add your own in /sys/radio.txt as Name|http://host/stream. MP3 "
 "(Icecast/SHOUTcast) streams only."},
{82, 1, "Light Meter", "Light Meter", "LUX", P2, app_lightmeter, "Built-in LDR",
 "Live ambient-light reading (0-100%) from the CYD's built-in light sensor, with "
 "a rolling graph. bright / indoor / dim / dark."},
{83, 1, "Auto-Brightness", "Auto-Bright", "ABR", P2, app_autobright, "Built-in LDR",
 "Matches the screen backlight to the room light using the LDR. Drag the bars "
 "to set the min and max brightness. Runs until you exit."},
{85, 1, "Night Light", "Night Light", "NTL", P2, app_nightlight, "Built-in LDR + RGB LED",
 "Turns the on-board RGB LED into a warm night light that switches on when the "
 "room gets dark. Tap +/- to set how dark it has to be."},
// ---------------------------------------------------------------- page 3
{18, 2, "Stopwatch", "Stopwatch", "STW", P3, app_stopwatch, "None",
 "START/STOP, LAP and RESET. Millisecond resolution, up to 6 laps shown."},
{19, 2, "Pomodoro Timer", "Pomodoro", "POM", P3, app_pomodoro, "On-board speaker",
 "25 min work (red) / 5 min break (green), long break every 4 rounds. "
 "Chimes and LED colour change at every transition."},
{20, 2, "Calculator", "Calculator", "CAL", P3, app_calc, "None",
 "Full expression parser: + - * / ^ ( ) and sin cos tan sqrt log ln, pi, "
 "e and ANS. Trig in degrees."},
{21, 2, "Calendar", "Calendar", "DAY", P3, app_calendar, "Clock (NTP over WiFi or set in Alarm app)",
 "Month grid with today highlighted. Swipe or tap arrows to change month; "
 "leap years computed with the Gregorian rule."},
{22, 2, "Text Editor", "Text Editor", "TXT", P3, app_editor, "microSD /data/reader/",
 "Multi-line editor with on-screen keyboard. OPEN/NEW/SAVE files in "
 "/data/reader. Cursor arrows move through text."},
{23, 2, "Hex Viewer", "Hex Viewer", "HEX", P3, app_hexview, "microSD",
 "Browse any folder, open any file and page through it as offset / hex / "
 "ASCII. Swipe up/down to scroll, tap +4K/-4K to jump."},
// 3D Dice now lives inside the Arcade hub (app 80), not duplicated here.
{26, 2, "Alarm Clock", "Alarm Clock", "ALM", P3, app_alarm, "Clock (NTP or manual set)",
 "Set the alarm with the +/- buttons and toggle it ON. It rings anywhere in "
 "the OS; tap the red banner to stop. SET CLOCK if there is no WiFi."},
// ---------------------------------------------------------------- page 4
{27, 3, "Pi Performance Monitor", "Pi Monitor", "PIM", P4, app_pimon,
 "USB cable to Raspberry Pi running tools/pi/krivi_bridge.py",
 "Shows CPU %, temperature, RAM, disk, load and uptime streamed once per "
 "second by the bridge daemon, with a 60 s CPU/temp graph."},
{28, 3, "Pi Bash Console", "Pi Console", "SH", P4, app_piconsole,
 "USB to Pi + krivi_bridge.py, scripts in ~/krivi_scripts/",
 "Lists whitelisted scripts on the Pi. Tap one to run it; its output "
 "streams back live. Only scripts in that folder can run."},
{29, 3, "Pi Remote Trackpad", "Pi Trackpad", "PAD", P4, app_pitrackpad,
 "USB to Pi + krivi_bridge.py (python3-evdev, uinput)",
 "Drag to move the Pi's mouse, tap to left-click, bottom buttons for "
 "L/R click and scroll. SPEED changes sensitivity."},
{30, 3, "Bluetooth Macro Pad", "BLE Macro Pad", "BLE", P4, app_blemacro,
 "Bluetooth LE host (PC/phone/tablet)",
 "Pair with 'KRIVI Macro'. 9 pads send hotkeys or text; edit them in "
 "/sys/apps/app_30.json (e.g. \"CTRL+ALT+T\", \"text:hello\")."},
{31, 3, "BLE Keyboard", "BLE Keyboard", "KB", P4, app_blekbd,
 "Bluetooth LE host (Raspberry Pi / PC / phone / tablet)",
 "A full on-screen Bluetooth keyboard. Pair with 'KRIVI Keyboard' and type "
 "LIVE into a Raspberry Pi or any device - letters, numbers, symbols, arrows, "
 "Enter/Tab/Esc, plus sticky CTRL/ALT/GUI for shortcuts like CTRL+ALT+T."},
{32, 3, "WiFi Analyzer", "WiFi Analyzer", "WFA", P4, app_wifiscan, "None",
 "Scans 2.4 GHz networks and draws signal parabolas per channel 1-13. "
 "Tap LIST for SSID/RSSI/security table."},
{33, 3, "Ping Monitor", "Ping Monitor", "PNG", P4, app_ping,
 "WiFi credentials in /sys/settings.json",
 "ICMP-pings the gateway and a cloud host (default 1.1.1.1, editable) "
 "every second; plots latency and packet loss."},
{34, 3, "ESP-NOW Radio", "ESP-NOW Chat", "NOW", P4, app_espnow,
 "Another ESP32 running KRIVI OS (or any ESP-NOW sender)",
 "Broadcast short messages to nearby boards on channel 1, no router "
 "needed. Quick-reply buttons or type with the keyboard."},
{51, 4, "Weather", "Weather", "WX", P5, app_weather,
 "WiFi + condition icons in /icons/weather on the SD card",
 "Current conditions and a 5-day forecast from Open-Meteo (free, no API key). "
 "Set your city (or lat/lon) and units in sys/apps/app_51.json. The weather "
 "icons are loaded from /icons/weather on the SD card, so you can restyle them "
 "without reflashing. Tap to refresh."},
// ---------------------------------------------------------------- page 5
{35, 4, "Sketchpad", "Sketchpad", "ART", P5, app_paint, "microSD /data/paint/",
 "Draw with 16 colours and 4 brush sizes. SAVE writes a .bmp to "
 "/data/paint, LOAD opens one, CLR wipes the canvas."},
{36, 4, "3D Rainbow Warp", "Rainbow Warp", "WRP", P5, app_warp, "None",
 "Perspective star tunnel: 3D points projected with depth scaling and hue "
 "by depth. Touch to steer, swipe up/down to change speed."},
{37, 4, "Sandbox", "Sandbox", "SBX", P5, app_sand, "None",
 "Cellular automaton: sand, water, wall and erase. Drag to pour. "
 "160x107 cells, updated bottom-up each frame."},
{39, 4, "Mandelbrot", "Mandelbrot", "FRC", P5, app_mandel, "None",
 "Renders every pixel in float and reports the time (benchmark). Tap to "
 "zoom x2 at that point, ZOOM- to back out, ITER to raise depth."},
{40, 4, "Video & MP4 Player", "Video / MP4", "VID", P5, app_video,
 "microSD /data/movies/*.avi (MP4s converted by tools/convert_media.py) or /data/video/*.mjpeg",
 "The ESP32 cannot decode H.264, so MP4s are converted on your computer to "
 "AVI (Motion-JPEG 320x240 + 22 kHz audio) and play with sound. Raw .mjpeg "
 "clips such as Bad Apple play silently. Tap to pause, swipe down for the "
 "list."},
{41, 4, "Virtual Pet", "Virtual Pet", "PET", P5, app_pet, "microSD /sys/pet.json",
 "Feed, play and put your pet to sleep. Hunger, happiness and energy decay "
 "over time, even while the app is closed (saved to SD)."},
{42, 4, "Touch Diagnostics", "Touch Diag", "TCH", P5, app_touchdiag, "Touchscreen",
 "Crosshair grid with live raw ADC and mapped coordinates; hit the 5 "
 "targets to measure error. Draw mode traces raw paths."},
{43, 4, "System Manual", "System Manual", "MAN", P5, app_manual, "None",
 "This directory. Also reads .txt books in /data/reader and shows "
 "system info."},
{58, 4, "Demoscene FX", "Demo FX", "FX", P5, app_demofx, "None",
 "A full-screen floating-point pixel pusher cycling plasma, a classic fire "
 "effect and metaballs - rendered at 160x100 and line-doubled to fill the "
 "screen. A benchmark that also just looks great."},
// ---------------------------------------------------------------- added: page 2 slot 9
// ---------------------------------------------------------------- page 6: Wireless Lab
// Passive / defensive radio diagnostics (original KRIVI implementations).
{45, 5, "Channel Congestion", "Ch. Congestion", "CH", P6, app_chanmon,
 "None (2.4 GHz radio)",
 "Hops across Wi-Fi channels 1-13 in monitor mode and graphs how busy each "
 "one is by counting frames only (never their contents or addresses). Use it "
 "to pick the clearest channel for your own router."},
{46, 5, "BLE Scanner", "BLE Scanner", "BLE", P6, app_blescan,
 "None (Bluetooth LE radio)",
 "Passively lists nearby Bluetooth LE devices from the public advertisements "
 "they broadcast: name, signal, address type and appearance. Handy for "
 "finding your own beacons, trackers and wearables."},
{47, 5, "Signal Mapper", "Signal Mapper", "MAP", P6, app_sigmap,
 "None (2.4 GHz radio)",
 "Pick one of your own access points, then walk around: a live RSSI meter and "
 "rolling graph reveal dead spots. SAMPLE records a labelled reading so you "
 "can compare rooms."},
{48, 5, "LAN Discovery", "LAN Devices", "LAN", P6, app_landisc,
 "Your Wi-Fi network (credentials in settings.json)",
 "Joins your own network and pings every address on the subnet to list the "
 "devices that are online, with response time and the gateway flagged. A "
 "mini network inventory for your LAN."},
{49, 5, "Net Health", "Net Health", "NET", P6, app_nethealth,
 "Your Wi-Fi network",
 "Times DNS lookups and measures latency, jitter and packet loss to your "
 "gateway and a host you choose, with a rolling sparkline. Tells you whether "
 "a bad connection is your Wi-Fi, your router or the internet."},
{52, 5, "3D ISS Globe Radar", "ISS Globe", "ISS", P6, app_iss,
 "WiFi (tracks the live ISS position from wheretheiss.at, no API key)",
 "A raycast, spinning 3D Earth that tracks the International Space Station in "
 "real time. Pulsing red blip + crosshair, fading orbit trail, live lat/lon/"
 "alt/velocity HUD. Drag the globe to spin and tilt it. Refreshes every 3 s."},

// ---------------------------------------------------------------- planned apps (4x3 roadmap)
// Working placeholders - each shows its planned feature and is filled in over
// coming updates. They keep the 4x3 grid complete and launchable today.
{59, 0, "CHIP-8 Virtual Machine", "CHIP-8", "CH8", P1, app_chip8, "microSD /roms/*.ch8",
 "Interpreter for classic CHIP-8 games (Pong, Brix, Tetris...) loaded from the SD card."},
{65, 2, "World Clock", "World Clock", "WLD", P3, app_worldclock, "Clock (NTP)",
 "Shows the current time across several world time zones at once."},
{66, 2, "Currency Converter", "Currency", "CUR", P3, app_currency, "microSD rates json (or WiFi)",
 "Converts between currencies using stored or fetched exchange rates."},
{67, 2, "Unit Converter", "Units", "UNT", P3, app_units, "None",
 "Length, mass, temperature, speed and data-size conversions."},
{68, 3, "Pi Shell Keyboard", "Pi Shell", "PSH", P4, app_pishell, "USB to Pi + krivi_bridge.py",
 "Full on-screen terminal: type commands to the Pi and read the output."},
{71, 3, "Pi Safe Shutdown", "Pi Power", "PWR", P4, app_pishutdown, "USB to Pi + krivi_bridge.py",
 "Sends a graceful shutdown/reboot command to the connected Pi."},
{72, 4, "Matrix Digital Rain", "Matrix Rain", "MTX", P5, app_matrix, "None",
 "Cascading green glyph streams - the classic terminal screensaver."},
{73, 4, "Starfield Screensaver", "Starfield", "STR", P5, app_starfield, "None",
 "Full-screen monochrome cosmic cruise through a particle starfield."},
{74, 5, "System Settings", "Settings", "SET", P6, app_settings, "None",
 "Screen brightness (PWM), Wi-Fi profiles, volume, theme and calibration from the touchscreen."},
{84, 5, "OTA Update", "OTA Update", "OTA", P6, app_ota, "WiFi",
 "Flash new firmware over WiFi: joins your network, shows a web address, and you "
 "upload a KRIVI app image (KriviOS.ino.bin) from a browser. Needs an OTA "
 "partition - a 4 MB CYD can't keep two ~2.2 MB copies, so it will say so on "
 "those boards (use USB/SD updates there)."},
{75, 5, "NVS Flash Editor", "NVS Editor", "NVS", P6, app_nvsedit, "None",
 "Browse and edit raw non-volatile system variables stored in flash."},
{76, 5, "Desk Clock", "Desk Clock", "CLK", P6, app_deskclock, "Clock (NTP or manual)",
 "Minimal full-screen HH:MM:SS clock for standby/desk display."},
{77, 5, "Noise Floor Log", "Noise Log", "NSE", P6, app_noiselog, "Mic on IO35",
 "Measures and logs ambient room volume over time to the SD card."},
};
const int APP_COUNT = sizeof(APPS) / sizeof(APPS[0]);

const AppDef *find(uint8_t id) {
  for (int i = 0; i < APP_COUNT; ++i) if (APPS[i].id == id) return &APPS[i];
  return nullptr;
}

// ---------------------------------------------------------------- layout
// 4x3 high-density grid: 12 cells per page
static const int CELL_W = 76, CELL_H = 56;
static const int GRID_X[4] = {3, 82, 161, 240};
static const int GRID_Y[3] = {30, 90, 150};
static const int NAV_Y = 208;
static const int CELLS = 12;

static int s_page = 0;
static uint16_t *s_icons[CELLS] = {nullptr};  // icon page cache (from SD)
static int s_iconPage = -1;

static void freeIcons() {
  for (auto &p : s_icons) { if (p) { free(p); p = nullptr; } }
  s_iconPage = -1;
}

// Dynamic paging: only the 12 icons of the visible page live in RAM
// (12 x 3200 B). They are dropped before any app launches.
static void loadIcons(int page) {
  if (s_iconPage == page) return;
  freeIcons();
  if (!sys::sdOk) return;
  int slot = 0;
  for (int i = 0; i < APP_COUNT && slot < CELLS; ++i) {
    if (APPS[i].page != page) continue;
    char path[32];
    snprintf(path, sizeof(path), "/icons/app_%02d.raw", APPS[i].id);
    File f = SD.open(path);
    if (f && f.size() == 40 * 40 * 2) {
      s_icons[slot] = (uint16_t *)malloc(40 * 40 * 2);
      if (s_icons[slot]) f.read((uint8_t *)s_icons[slot], 40 * 40 * 2);
    }
    if (f) f.close();
    slot++;
  }
  s_iconPage = page;
}

static void fallbackIcon(int x, int y, const AppDef &a) {
  uint16_t c = a.color;
  tft.fillRoundRect(x, y, 40, 40, 9, c);
  tft.fillRoundRect(x + 4, y + 3, 32, 13, 6, tft.alphaBlend(60, TFT_WHITE, c));
  tft.drawRoundRect(x, y, 40, 40, 9, tft.alphaBlend(120, TFT_WHITE, c));
  tft.setTextColor(TFT_WHITE, c);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(a.abbr, x + 20, y + 21, 2);
  tft.setTextDatum(TL_DATUM);
}

static void drawCell(int slot, const AppDef &a, bool hl) {
  int x = GRID_X[slot % 4], y = GRID_Y[slot / 4];
  uint16_t bg = hl ? C_PANEL2 : C_BG;
  tft.fillRoundRect(x, y, CELL_W, CELL_H, 6, bg);
  if (hl) tft.drawRoundRect(x, y, CELL_W, CELL_H, 6, a.color);
  int ix = x + (CELL_W - 40) / 2, iy = y + 1;
  if (s_icons[slot]) {
    tft.setSwapBytes(true);
    tft.pushImage(ix, iy, 40, 40, s_icons[slot]);
    tft.setSwapBytes(false);
  } else {
    fallbackIcon(ix, iy, a);
  }
  tft.setTextColor(C_TEXT, bg);
  tft.setTextDatum(TC_DATUM);
  tft.drawString(a.label, x + CELL_W / 2, y + 43, 1);
  tft.setTextDatum(TL_DATUM);
}

static void drawStatus() {
  tft.fillRect(0, 0, SCR_W, 26, C_PANEL);
  tft.fillRect(0, 24, SCR_W, 2, ui::hsv(s_page * 60 + 190, 200, 255));
  tft.setTextColor(C_ACCENT, C_PANEL);
  tft.drawString("KRIVI", 6, 5, 2);
  char t[24];
  snprintf(t, sizeof(t), "%d/%d %s", s_page + 1, NUM_PAGES, PAGE_TITLES[s_page]);
  tft.setTextColor(C_TEXT, C_PANEL);
  tft.drawString(t, 52, 5, 2);
  struct tm tm;
  if (sys::now(tm)) snprintf(t, sizeof(t), "%02d:%02d", tm.tm_hour, tm.tm_min);
  else strcpy(t, "--:--");
  tft.setTextColor(sys::alarm.enabled ? C_WARN : C_DIM, C_PANEL);
  tft.setTextDatum(TR_DATUM);
  tft.drawString(t, 314, 5, 2);
  tft.setTextDatum(TL_DATUM);
  if (sys::clapBackground) tft.fillCircle(270, 13, 3, sys::clapLatch ? C_OK : C_WARN);
}

static void drawNav() {
  tft.fillRect(0, NAV_Y - 2, SCR_W, SCR_H - NAV_Y + 2, C_BG);
  tft.drawFastHLine(10, NAV_Y - 2, 300, C_PANEL2);
  ui::button(4, NAV_Y + 3, 64, 28, "<", s_page > 0 ? C_PANEL2 : C_PANEL, s_page > 0 ? C_TEXT : C_DIM, 4);
  ui::button(252, NAV_Y + 3, 64, 28, ">", s_page < NUM_PAGES - 1 ? C_PANEL2 : C_PANEL, s_page < NUM_PAGES - 1 ? C_TEXT : C_DIM, 4);
  for (int i = 0; i < NUM_PAGES; ++i) {
    int cx = 112 + i * 16, cy = NAV_Y + 17;
    if (i == s_page) tft.fillCircle(cx, cy, 5, C_ACCENT);
    else tft.drawCircle(cx, cy, 4, C_DIM);
  }
}

static void drawPage() {
  loadIcons(s_page);
  tft.fillRect(0, 26, SCR_W, NAV_Y - 28, C_BG);
  drawStatus();
  int slot = 0;
  for (int i = 0; i < APP_COUNT; ++i) {
    if (APPS[i].page != s_page) continue;
    drawCell(slot++, APPS[i], false);
  }
  drawNav();
}

static const AppDef *slotApp(int page, int slot, int *idxOut = nullptr) {
  int s = 0;
  for (int i = 0; i < APP_COUNT; ++i) {
    if (APPS[i].page != page) continue;
    if (s == slot) { if (idxOut) *idxOut = i; return &APPS[i]; }
    s++;
  }
  return nullptr;
}

static int slotAt(int x, int y) {
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c)
      if (ui::inRect(x, y, GRID_X[c], GRID_Y[r], CELL_W, CELL_H)) return r * 4 + c;
  return -1;
}

static void infoCard(const AppDef &a) {
  char t[64];
  snprintf(t, sizeof(t), "APP %02d - %s", a.id, a.name);
  String msg = String("Needs: ") + a.needs + "\n" + a.help;
  if (msg.length() > 330) msg = msg.substring(0, 327) + "...";
  ui::msgBox(t, msg.c_str());
}

void begin() { s_page = sys::cfg["launcher"]["page"] | 0; s_page = constrain(s_page, 0, NUM_PAGES - 1); }

void run() {
  drawPage();
  uint32_t lastClock = 0;
  int pressedSlot = -1;
  bool longShown = false;
  for (;;) {
    ui::clearEvents();
    Touch &t = ui::poll();
    delay(4);
    if (millis() - lastClock > 1000) { lastClock = millis(); drawStatus(); }

    if (t.pressed) {
      pressedSlot = slotAt(t.x, t.y);
      longShown = false;
      if (pressedSlot >= 0) {
        const AppDef *a = slotApp(s_page, pressedSlot);
        if (a) drawCell(pressedSlot, *a, true); else pressedSlot = -1;
      }
    }
    // long press -> app info card
    if (t.down && pressedSlot >= 0 && !longShown && t.held() > 650 &&
        abs(t.x - t.sx) < 18 && abs(t.y - t.sy) < 18) {
      longShown = true;
      const AppDef *a = slotApp(s_page, pressedSlot);
      if (a) { audio::beep(1200, 30); infoCard(*a); drawPage(); }
      pressedSlot = -1;
    }
    if (t.released) {
      int ps = pressedSlot; pressedSlot = -1;
      if (ps >= 0) {
        const AppDef *a = slotApp(s_page, ps);
        if (a) drawCell(ps, *a, false);
      }
      if (t.swipe == SW_LEFT && s_page < NUM_PAGES - 1) { s_page++; audio::click(); drawPage(); continue; }
      if (t.swipe == SW_RIGHT && s_page > 0) { s_page--; audio::click(); drawPage(); continue; }
      if (t.tap) {
        if (ui::inRect(t.sx, t.sy, 0, NAV_Y, 76, 34) && s_page > 0) { s_page--; audio::click(); drawPage(); continue; }
        if (ui::inRect(t.sx, t.sy, 244, NAV_Y, 76, 34) && s_page < NUM_PAGES - 1) { s_page++; audio::click(); drawPage(); continue; }
        if (ps >= 0 && !longShown && slotAt(t.sx, t.sy) == ps) {
          const AppDef *a = slotApp(s_page, ps);
          if (a) {
            audio::click();
            freeIcons();                     // hand the RAM to the app
            loader::launch(*a);
            ui::header(nullptr, 0);          // detach header ownership
            drawPage();
          }
        }
      }
    }
  }
}
}  // namespace launcher
