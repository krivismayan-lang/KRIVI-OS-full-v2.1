// ============================================================================
//  KRIVI OS - Internet Radio  (stream an MP3 station over WiFi)            app
//
//  Picks a station (built-in presets, plus any added in /sys/radio.txt as
//  "Name|http://host/path" lines), connects over WiFi, and decodes the MP3
//  stream with the in-tree Helix decoder straight into the audio engine, so it
//  plays on the speaker (and through Bluetooth headphones if the BT app has a
//  headset connected and left the tap running).
//
//  MP3 (Icecast/SHOUTcast) streams only - AAC/OGG stations won't play.
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include "src/helix/mp3dec.h"
#include <vector>

namespace radio {

struct Station { String name, url; };

static std::vector<Station> load() {
  std::vector<Station> v;
  // built-in defaults (public MP3 Icecast streams; edit /sys/radio.txt to change)
  v.push_back({"SomaFM Groove Salad", "http://ice1.somafm.com/groovesalad-128-mp3"});
  v.push_back({"SomaFM Drone Zone",   "http://ice1.somafm.com/dronezone-128-mp3"});
  v.push_back({"SomaFM Lush",         "http://ice1.somafm.com/lush-128-mp3"});
  v.push_back({"SomaFM Indie Pop",    "http://ice1.somafm.com/indiepop-128-mp3"});
  if (sys::sdOk) {
    File f = SD.open("/sys/radio.txt");
    if (f) {
      v.clear();                                  // user list replaces the defaults
      while (f.available()) {
        String line = f.readStringUntil('\n'); line.trim();
        int bar = line.indexOf('|');
        if (bar > 0 && line.startsWith("http") == false) { v.push_back({line.substring(0, bar), line.substring(bar + 1)}); }
        else if (bar > 0) v.push_back({line.substring(0, bar), line.substring(bar + 1)});
      }
      f.close();
    }
  }
  return v;
}

}  // namespace radio

void app_radio(AppCtx &c) {
  using namespace radio;
  std::vector<Station> st = load();
  if (st.empty()) { ui::msgBox("INTERNET RADIO", "No stations. Add some to /sys/radio.txt as\nName|http://host/stream"); return; }

  int sel = 0, top = 0; const int RH = 30, Y0 = 32, ROWS = 5;
  auto drawList = [&]() {
    c.header("Internet Radio"); ui::clearBody();
    for (int i = 0; i < ROWS && top + i < (int)st.size(); i++) {
      int idx = top + i, y = Y0 + i * RH;
      tft.fillRoundRect(6, y, 308, RH - 4, 5, idx == sel ? RGB565(30,60,110) : C_PANEL);
      tft.setTextColor(C_TEXT, idx == sel ? RGB565(30,60,110) : C_PANEL); tft.drawString(st[idx].name.substring(0, 30), 14, y + 5, 2);
    }
    ui::button(6, 198, 150, 34, "UP/DOWN", C_PANEL2, C_TEXT, 1);
    ui::button(164, 198, 150, 34, "PLAY", C_OK, TFT_BLACK, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("stations: edit /sys/radio.txt", 8, 182, 1);
  };
  // ---- station picker
  bool play = false;
  drawList();
  while (c.loop() && !play) {
    Touch &t = *c.t; if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 6, 198, 150, 34)) { sel = (sel + 1) % st.size(); if (sel < top || sel >= top + ROWS) top = (sel / ROWS) * ROWS; drawList(); }
    else if (ui::inRect(t.sx, t.sy, 164, 198, 150, 34)) play = true;
    else if (t.sy >= Y0 && t.sy < Y0 + ROWS * RH) { int idx = top + (t.sy - Y0) / RH; if (idx < (int)st.size()) { sel = idx; drawList(); } }
  }
  if (!play) return;

  // ---- connect
  c.header("Internet Radio"); ui::clearBody();
  ui::centerText("Joining WiFi...", 160, 110, C_WARN, C_BG, 2);
  if (!sys::wifiConnect(15000, false)) { c.header("Internet Radio"); ui::msgBox("RADIO", "WiFi connection failed.\nSet up WiFi in System Settings."); sys::radiosOff(); return; }

  // ---- decoder + audio
  HMP3Decoder dec = MP3InitDecoder();
  const int INBUF = 2 * MAINBUF_SIZE;
  uint8_t *inbuf = (uint8_t *)sys::bigAlloc(INBUF);
  int16_t *pcm = (int16_t *)sys::bigAlloc(MAX_NSAMP * MAX_NCHAN * MAX_NGRAN * 2);
  if (!dec || !inbuf || !pcm || !audio::streamBegin(44100, 12288)) {
    if (dec) MP3FreeDecoder(dec); free(inbuf); free(pcm); sys::radiosOff();
    c.header("Internet Radio"); ui::msgBox("RADIO", "Not enough RAM for the decoder."); return;
  }
  int vol = c.pInt("volume", 210); audio::streamVolume(vol);

  auto drawNow = [&](const char *status, uint16_t col) {
    c.header("Internet Radio"); ui::clearBody();
    tft.setTextColor(C_TEXT, C_BG); tft.setTextDatum(TC_DATUM);
    tft.drawString(st[sel].name.substring(0, 28), 160, 60, 4);
    tft.setTextColor(col, C_BG); tft.drawString(status, 160, 100, 2); tft.setTextDatum(TL_DATUM);
    ui::button(10, 198, 70, 34, "STOP", RGB565(150,40,40), TFT_WHITE, 1);
    ui::button(150, 198, 70, 34, "VOL-", C_PANEL2, C_TEXT, 1);
    ui::button(240, 198, 70, 34, "VOL+", C_PANEL2, C_TEXT, 1);
  };
  drawNow("connecting...", C_WARN);

  HTTPClient http; WiFiClient *stream = nullptr;
  http.begin(st[sel].url);
  http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
  int code = http.GET();
  if (code != HTTP_CODE_OK && code != 200) {
    drawNow((String("stream error ") + code).c_str(), C_ERR);
    delay(1500);
    MP3FreeDecoder(dec); free(inbuf); free(pcm); audio::streamEnd(); http.end(); sys::radiosOff();
    waitTap(c); return;
  }
  stream = http.getStreamPtr();
  drawNow("buffering...", C_WARN);

  int bytesLeft = 0; uint8_t *rp = inbuf; bool rateSet = false; int srate = 44100;
  uint32_t lastUi = 0, lastData = millis(); int peak = 0; bool playing = true;

  while (c.loop() && playing) {
    // ---- keep the input buffer fed from the network
    if (bytesLeft < MAINBUF_SIZE) {
      memmove(inbuf, rp, bytesLeft); rp = inbuf;
      int want = INBUF - bytesLeft;
      int avail = stream->available();
      if (avail > 0) { int n = stream->read(inbuf + bytesLeft, min(want, avail)); if (n > 0) { bytesLeft += n; lastData = millis(); } }
      if (!http.connected() && stream->available() == 0) { drawNow("reconnecting...", C_WARN); break; }
      if (millis() - lastData > 8000) { drawNow("stream stalled", C_ERR); break; }
    }
    // ---- decode while the ring has room
    if (bytesLeft >= MAINBUF_SIZE && audio::streamSpace() > 1200) {
      int off = MP3FindSyncWord(rp, bytesLeft);
      if (off < 0) { bytesLeft = 0; }
      else {
        rp += off; bytesLeft -= off;
        int err = MP3Decode(dec, &rp, &bytesLeft, pcm, 0);
        if (err == 0) {
          MP3FrameInfo fi; MP3GetLastFrameInfo(dec, &fi);
          if (!rateSet || fi.samprate != srate) { srate = fi.samprate; audio::streamSetRate(srate); rateSet = true; }
          int frames = fi.outputSamps / max(1, fi.nChans);
          if (fi.nChans == 2) for (int i = 0; i < frames; i++) pcm[i] = (pcm[2 * i] + pcm[2 * i + 1]) / 2;
          for (int i = 0; i < frames; i += 16) peak = max(peak, abs((int)pcm[i]));
          audio::streamWrite(pcm, frames);
        } else if (err == ERR_MP3_INDATA_UNDERFLOW || err == ERR_MP3_MAINDATA_UNDERFLOW) {
          // need more data
        } else { if (bytesLeft > 0) { rp++; bytesLeft--; } }
      }
    }
    // ---- UI: a simple level meter + "live" tag once audio is flowing
    if (millis() - lastUi > 120) {
      lastUi = millis();
      if (rateSet) { tft.fillRect(0, 96, 320, 20, C_BG); tft.setTextDatum(TC_DATUM); tft.setTextColor(C_OK, C_BG); tft.drawString("LIVE", 160, 100, 2); tft.setTextDatum(TL_DATUM); }
      int lvl = constrain(peak / 320, 0, 100); peak = peak * 3 / 4;
      ui::bar(30, 150, 260, 14, lvl / 100.0f, C_ACCENT, C_PANEL);
    }
    // ---- touch
    Touch &t = *c.t;
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 10, 198, 70, 34)) playing = false;
      else if (ui::inRect(t.sx, t.sy, 150, 198, 70, 34)) { vol = max(20, vol - 30); audio::streamVolume(vol); }
      else if (ui::inRect(t.sx, t.sy, 240, 198, 70, 34)) { vol = min(255, vol + 30); audio::streamVolume(vol); }
    }
  }

  MP3FreeDecoder(dec); free(inbuf); free(pcm);
  audio::streamEnd(); http.end(); sys::radiosOff();
}
