// ============================================================================
//  KRIVI OS - Arcade  (a single "list of games" hub)              app 80
//
//  One scrollable menu that launches 16 classics. Each sub-game is a normal
//  app function; the hub runs one at a time, and when a game's EXIT button is
//  tapped control returns here (its RAM is already freed on return). The new
//  classics live in app_classics.cpp; the rest are the stock KRIVI games.
// ============================================================================
#include "apps_common.h"

// classics implemented in app_classics.cpp
void g2048(AppCtx &); void gc4(AppCtx &); void gcheckers(AppCtx &); void greversi(AppCtx &);
void gsimon(AppCtx &); void gsudoku(AppCtx &); void gsolitaire(AppCtx &); void ginvaders(AppCtx &);

namespace arcade {

struct GameEntry { const char *name; const char *desc; void (*fn)(AppCtx &); };

static const GameEntry GAMES[] = {
  {"Flappy Bird",      "tap to flap through the pipes",   app_flappy},
  {"Snake",            "eat, grow, don't bite yourself",  app_snake},
  {"Tetris",           "stack and clear the lines",       app_tetris},
  {"Pong",             "classic paddle bat-and-ball",     app_pong},
  {"Breakout",         "bounce the ball, break bricks",   app_breakout},
  {"Minesweeper",      "flag the mines, clear the grid",  app_mines},
  {"Chess / Tic-Tac",  "two-player board games",          app_board},
  {"3D Dice",          "roll two tumbling dice",          app_dice},
  {"2048",             "swipe to merge the tiles",        g2048},
  {"Connect Four",     "drop four in a row to win",       gc4},
  {"Checkers",         "two-player draughts",             gcheckers},
  {"Reversi",          "flip discs, hold the board",      greversi},
  {"Simon",            "repeat the colour sequence",      gsimon},
  {"Sudoku",           "fill the 9x9 grid",               gsudoku},
  {"Solitaire",        "Klondike patience",               gsolitaire},
  {"Space Invaders",   "blast the alien waves",           ginvaders},
};
static const int NGAMES = sizeof(GAMES) / sizeof(GAMES[0]);

// Run one sub-game, then swallow the EXIT tap that ended it so this hub does
// not immediately exit too.
static void runSub(AppCtx &c, void (*fn)(AppCtx &)) {
  c.exitReq = false;
  tft.fillScreen(C_BG);
  fn(c);
  c.exitReq = false;
  uint32_t t0 = millis();
  while (ui::state().down && millis() - t0 < 1500) { ui::poll(); delay(5); }
  ui::clearEvents();
}

}  // namespace arcade

void app_arcade(AppCtx &c) {
  using namespace arcade;
  // Screen body is y 26..240. Fit 4 rows of 40px, the nav bar and a counter.
  const int RH = 40, Y0 = 30, ROWS = 4;
  const int BY = 194, BH = 32;
  int top = 0;

  auto draw = [&]() {
    c.header("16 classics");
    ui::clearBody();
    for (int i = 0; i < ROWS && top + i < NGAMES; ++i) {
      int idx = top + i, y = Y0 + i * RH;
      tft.fillRoundRect(6, y, 308, RH - 4, 6, C_PANEL);
      tft.setTextColor(C_TEXT, C_PANEL); tft.drawString(GAMES[idx].name, 14, y + 4, 2);
      tft.setTextColor(C_DIM, C_PANEL);  tft.drawString(GAMES[idx].desc, 14, y + 22, 1);
      tft.fillTriangle(296, y + 12, 296, y + 24, 305, y + 18, C_ACCENT);
    }
    ui::button(6, BY, 150, BH, "UP", top > 0 ? C_PANEL2 : C_PANEL, C_TEXT, 2);
    ui::button(164, BY, 150, BH, "DOWN", top + ROWS < NGAMES ? C_PANEL2 : C_PANEL, C_TEXT, 2);
    char cnt[28]; snprintf(cnt, sizeof(cnt), "games %d-%d of %d", top + 1, min(top + ROWS, NGAMES), NGAMES);
    tft.fillRect(0, 228, 320, 11, C_BG);
    tft.setTextColor(C_DIM, C_BG); tft.setTextDatum(TC_DATUM); tft.drawString(cnt, 160, 229, 1); tft.setTextDatum(TL_DATUM);
  };
  draw();

  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 6, BY, 150, BH)) { if (top > 0) { top = max(0, top - ROWS); draw(); } }
    else if (ui::inRect(t.sx, t.sy, 164, BY, 150, BH)) { if (top + ROWS < NGAMES) { top += ROWS; draw(); } }
    else if (t.sy >= Y0 && t.sy < Y0 + ROWS * RH) {
      int idx = top + (t.sy - Y0) / RH;
      if (idx < NGAMES) { audio::click(); runSub(c, GAMES[idx].fn); draw(); }
    }
  }
}
