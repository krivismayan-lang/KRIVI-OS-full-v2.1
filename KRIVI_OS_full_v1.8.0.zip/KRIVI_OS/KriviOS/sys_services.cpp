// ============================================================================
//  KRIVI OS - system services: settings, log, clock/NTP, alarm, clap latch,
//  LED, radios, file helpers
// ============================================================================
#include "krivi.h"
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_wpa2.h>
#include <time.h>
#include <sys/time.h>
#include <stdarg.h>
#include <string.h>

namespace sys {

// Join the configured network. Three cases, chosen from /sys/settings.json:
//   open         : "wifi":{"ssid":"Cafe"}                 (no "pass", or "pass":"")
//   WPA2-PSK     : "wifi":{"ssid":"Home","pass":"secret"}
//   WPA2-Enterprise (school/eduroam): add "user":"you@school.edu"  (+ optional
//                  "identity" and "pass"); the username turns on enterprise mode.
static void wifiStart() {
  const char *ssid  = cfg["wifi"]["ssid"] | "";
  const char *pass  = cfg["wifi"]["pass"] | "";
  const char *user  = cfg["wifi"]["user"] | "";
  const char *ident = cfg["wifi"]["identity"] | "";
  WiFi.mode(WIFI_STA);
  if (user[0]) {                                   // WPA2-Enterprise (PEAP/TTLS)
    const char *id = ident[0] ? ident : user;
    esp_wifi_sta_wpa2_ent_set_identity((const uint8_t *)id, strlen(id));
    esp_wifi_sta_wpa2_ent_set_username((const uint8_t *)user, strlen(user));
    esp_wifi_sta_wpa2_ent_set_password((const uint8_t *)pass, strlen(pass));
    esp_wifi_sta_wpa2_ent_enable();
    WiFi.begin(ssid);
  } else {
    esp_wifi_sta_wpa2_ent_disable();               // clear any prior enterprise state
    WiFi.begin(ssid, pass);                        // empty pass => open network
  }
}
JsonDocument cfg;
bool sdOk = false;
uint64_t sdSizeMB = 0;
Alarm alarm = {false, 7, 0, false, 255};
volatile bool clapLatch = false;
bool clapBackground = false;
int  clapThreshold = 900;

static bool s_manualTime = false;

// ---------------------------------------------------------------- settings
static void applyDefaults() {
  if (!cfg["theme"].is<JsonObject>()) {
    cfg["theme"]["accent"] = "#00C8FF";
  }
  if (!cfg["sound"].is<JsonObject>()) {
    cfg["sound"]["volume"] = 140;
    cfg["sound"]["clicks"] = true;
  }
  if (!cfg["time"].is<JsonObject>()) {
    cfg["time"]["tz"] = "EST5EDT,M3.2.0,M11.1.0";
    cfg["time"]["ntp"] = "pool.ntp.org";
  }
  if (!cfg["wifi"].is<JsonObject>()) {
    cfg["wifi"]["ssid"] = "";
    cfg["wifi"]["pass"] = "";
  }
}

bool loadSettings() {
  cfg.clear();
  bool ok = false;
  if (sdOk) {
    File f = SD.open("/sys/settings.json");
    if (f) {
      DeserializationError e = deserializeJson(cfg, f);
      f.close();
      ok = !e;
      if (e) cfg.clear();
    }
  }
  applyDefaults();
  audio::setMaster(cfg["sound"]["volume"] | 140);
  alarm.enabled = cfg["alarm"]["enabled"] | false;
  alarm.h = cfg["alarm"]["h"] | 7;
  alarm.m = cfg["alarm"]["m"] | 0;
  clapThreshold = cfg["clap"]["threshold"] | 900;
  return ok;
}

bool saveSettings() {
  if (!sdOk) return false;
  cfg["alarm"]["enabled"] = alarm.enabled;
  cfg["alarm"]["h"] = alarm.h;
  cfg["alarm"]["m"] = alarm.m;
  cfg["clap"]["threshold"] = clapThreshold;
  cfg["sound"]["volume"] = audio::master();
  SD.mkdir("/sys");
  File f = SD.open("/sys/settings.json", FILE_WRITE);
  if (!f) return false;
  serializeJsonPretty(cfg, f);
  f.close();
  return true;
}

// ---------------------------------------------------------------- logging
void log(const char *fmt, ...) {
  char buf[200];
  va_list ap; va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  Serial.printf("[%10.3f] %s\n", millis() / 1000.0f, buf);
  if (!sdOk) return;
  File f = SD.open("/sys/boot/session.log", FILE_APPEND);
  if (!f) return;
  if (f.size() > 64 * 1024) {               // rotate
    f.close();
    SD.remove("/sys/boot/session.old");
    SD.rename("/sys/boot/session.log", "/sys/boot/session.old");
    f = SD.open("/sys/boot/session.log", FILE_APPEND);
    if (!f) return;
  }
  f.printf("[%10.3f] %s\n", millis() / 1000.0f, buf);
  f.close();
}

// ---------------------------------------------------------------- clock
bool timeValid() { time_t n = time(nullptr); return n > 1700000000; }
bool now(struct tm &t) {
  time_t n = time(nullptr);
  localtime_r(&n, &t);
  return n > 1700000000;
}
void setClock(int y, int mo, int d, int h, int mi, int s) {
  const char *tz = cfg["time"]["tz"] | "EST5EDT,M3.2.0,M11.1.0";
  setenv("TZ", tz, 1); tzset();
  struct tm t = {};
  t.tm_year = y - 1900; t.tm_mon = mo - 1; t.tm_mday = d;
  t.tm_hour = h; t.tm_min = mi; t.tm_sec = s; t.tm_isdst = -1;
  time_t e = mktime(&t);
  struct timeval tv = {e, 0};
  settimeofday(&tv, nullptr);
  s_manualTime = true;
}

// NTP state machine (non-blocking, driven by tick())
enum NtpSt { NTP_IDLE, NTP_CONNECT, NTP_SYNC, NTP_OK, NTP_FAIL, NTP_NOCFG };
static NtpSt s_ntp = NTP_IDLE;
static uint32_t s_ntpT0 = 0;
const char *ntpState() {
  switch (s_ntp) {
    case NTP_CONNECT: return "wifi...";
    case NTP_SYNC:    return "ntp...";
    case NTP_OK:      return "synced";
    case NTP_FAIL:    return "failed";
    case NTP_NOCFG:   return "no wifi cfg";
    default:          return s_manualTime ? "manual" : "idle";
  }
}
void startNtp() {
  const char *ssid = cfg["wifi"]["ssid"] | "";
  const char *tz = cfg["time"]["tz"] | "EST5EDT,M3.2.0,M11.1.0";
  setenv("TZ", tz, 1); tzset();
  if (!ssid[0]) { s_ntp = NTP_NOCFG; return; }
  wifiStart();
  s_ntp = NTP_CONNECT; s_ntpT0 = millis();
}
static void ntpTick() {
  if (s_ntp == NTP_CONNECT) {
    if (WiFi.status() == WL_CONNECTED) {
      configTzTime(cfg["time"]["tz"] | "EST5EDT,M3.2.0,M11.1.0",
                   cfg["time"]["ntp"] | "pool.ntp.org", "time.nist.gov");
      s_ntp = NTP_SYNC;
    } else if (millis() - s_ntpT0 > 15000) { s_ntp = NTP_FAIL; WiFi.disconnect(true); WiFi.mode(WIFI_OFF); }
  } else if (s_ntp == NTP_SYNC) {
    if (timeValid()) { s_ntp = NTP_OK; log("ntp: clock synchronised"); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); }
    else if (millis() - s_ntpT0 > 25000) { s_ntp = NTP_FAIL; WiFi.disconnect(true); WiFi.mode(WIFI_OFF); }
  }
}

void radiosOff() {
  if (s_ntp == NTP_CONNECT || s_ntp == NTP_SYNC) s_ntp = NTP_FAIL;
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
}

// Lock screen shown at boot when a password is set. Loops until it matches, so
// there is no way past it without the password. Blank password = no lock.
void checkLock() {
  String pw = cfg["security"]["pass"] | "";
  if (!pw.length()) return;
  while (true) {
    tft.fillScreen(C_BG);
    ui::centerText("KRIVI OS", 160, 70, C_ACCENT, C_BG, 4);
    ui::centerText("device locked", 160, 104, C_DIM, C_BG, 2);
    String in = "";
    if (ui::textInput(in, "Enter password", 32, true) && in == pw) {
      tft.fillScreen(C_BG); ui::centerText("unlocked", 160, 110, C_OK, C_BG, 2); delay(500); return;
    }
    tft.fillScreen(C_BG); ui::centerText("wrong password", 160, 110, C_ERR, C_BG, 2); delay(1000);
  }
}

bool wifiConnect(uint32_t timeoutMs, bool showUi) {
  if (WiFi.status() == WL_CONNECTED) return true;
  const char *ssid = cfg["wifi"]["ssid"] | "";
  if (!ssid[0]) {
    if (showUi) ui::msgBox("NO WIFI CONFIG",
      "Add your network to /sys/settings.json:\n\"wifi\": {\"ssid\":\"..\",\"pass\":\"..\"}");
    return false;
  }
  wifiStart();
  uint32_t t0 = millis();
  int dots = 0;
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < timeoutMs) {
    if (showUi) {
      char b[48]; snprintf(b, sizeof(b), "Joining %s%.*s   ", ssid, (dots++ % 4), "...");
      tft.setTextColor(C_WARN, C_BG); tft.drawString(b, 10, 120, 2);
    }
    delay(250);
  }
  return WiFi.status() == WL_CONNECTED;
}

// ---------------------------------------------------------------- LED / latch
void led(uint8_t r, uint8_t g, uint8_t b) {
  // active-low; use LEDC-free digital for on/off, analogWrite for levels
  analogWrite(PIN_LED_R, 255 - r);
  analogWrite(PIN_LED_G, 255 - g);
  analogWrite(PIN_LED_B, 255 - b);
}
void setLatch(bool on) {
  clapLatch = on;
  digitalWrite(PIN_RELAY, on ? HIGH : LOW);
  led(on ? 0 : 0, on ? 40 : 0, 0);
}

static int micPeakToPeak(int samples) {
  int lo = 4095, hi = 0;
  for (int i = 0; i < samples; ++i) {
    int v = analogRead(PIN_MIC);
    if (v < lo) lo = v; if (v > hi) hi = v;
  }
  return hi - lo;
}

// ---------------------------------------------------------------- tick
static uint32_t s_lastSlow = 0, s_lastClap = 0, s_lastAlarmBeep = 0, s_ringT0 = 0;

void tick() {
  uint32_t n = millis();
  // background clap detector (cheap: 24 ADC reads ~ 0.25 ms)
  if (clapBackground) {
    int pp = micPeakToPeak(24);
    if (pp > clapThreshold && n - s_lastClap > 450) {
      s_lastClap = n;
      setLatch(!clapLatch);
      log("clap: latch -> %d (pp=%d)", clapLatch, pp);
    }
  }
  if (n - s_lastSlow < 250) {
    if (alarm.ringing && n - s_lastAlarmBeep > 500) {
      s_lastAlarmBeep = n;
      static bool ph = false; ph = !ph;
      audio::tone(6, ph ? 1760 : 1320, 110, audio::SQUARE, 220);
      led(ph ? 255 : 0, 0, 0);
    }
    return;
  }
  s_lastSlow = n;
  ntpTick();
  if (alarm.enabled && !alarm.ringing && timeValid()) {
    struct tm t; now(t);
    if (t.tm_hour == alarm.h && t.tm_min == alarm.m && alarm.lastDay != (uint8_t)(t.tm_yday & 0xFF)) {
      alarm.lastDay = t.tm_yday & 0xFF;
      alarm.ringing = true; s_ringT0 = n;
      log("alarm: ringing %02d:%02d", alarm.h, alarm.m);
    }
  }
  if (alarm.ringing && n - s_ringT0 > 60000) { alarm.ringing = false; led(0, 0, 0); }
}

// ---------------------------------------------------------------- files
std::vector<String> listDir(const char *dir, const char *ext, bool dirsToo) {
  std::vector<String> out;
  if (!sdOk) return out;
  File d = SD.open(dir);
  if (!d || !d.isDirectory()) return out;
  File f;
  while ((f = d.openNextFile())) {
    String nm = f.name();
    int sl = nm.lastIndexOf('/');
    if (sl >= 0) nm = nm.substring(sl + 1);
    if (nm.startsWith(".")) { f.close(); continue; }
    if (f.isDirectory()) {
      if (dirsToo) out.push_back(nm + "/");
    } else {
      // ext may list several extensions: ".avi|.mjpeg"
      String lower = nm; lower.toLowerCase();
      bool ok = !ext;
      if (ext) {
        String e = ext; int st = 0;
        while (!ok && st <= (int)e.length()) {
          int bar = e.indexOf('|', st); if (bar < 0) bar = e.length();
          String one = e.substring(st, bar);
          if (one.length() && lower.endsWith(one)) ok = true;
          st = bar + 1;
        }
      }
      if (ok) out.push_back(nm);
    }
    f.close();
    if (out.size() > 200) break;
  }
  d.close();
  std::sort(out.begin(), out.end(), [](const String &a, const String &b) {
    bool da = a.endsWith("/"), db = b.endsWith("/");
    if (da != db) return da;
    return a.compareTo(b) < 0;
  });
  return out;
}

String humanSize(uint64_t b) {
  char s[24];
  if (b < 1024) snprintf(s, sizeof(s), "%u B", (unsigned)b);
  else if (b < 1024ULL * 1024) snprintf(s, sizeof(s), "%.1f KB", b / 1024.0);
  else if (b < 1024ULL * 1024 * 1024) snprintf(s, sizeof(s), "%.1f MB", b / 1048576.0);
  else snprintf(s, sizeof(s), "%.2f GB", b / 1073741824.0);
  return String(s);
}

// --------------------------------------------------------------------------
//  SD card as a RAM helper
// --------------------------------------------------------------------------
void *bigAlloc(uint32_t bytes) {
  void *p = malloc(bytes);
  if (!p) { delay(3); p = malloc(bytes); }      // let a transient blip clear
  return p;
}

bool SwapBuf::open(uint32_t bytes, const char *name) {
  close();
  if (!sdOk) return false;
  SD.remove(name);
  // 1) create and pre-extend the file to `bytes` so put/get can seek anywhere
  File w = SD.open(name, FILE_WRITE);
  if (!w) return false;
  static uint8_t z[512];
  memset(z, 0, sizeof(z));
  uint32_t left = bytes;
  while (left) { uint32_t n = left < sizeof(z) ? left : sizeof(z); if (w.write(z, n) != n) { w.close(); SD.remove(name); return false; } left -= n; }
  w.close();
  // 2) reopen for random read+write
  f = SD.open(name, "r+");
  if (!f) { SD.remove(name); return false; }
  size = bytes; ok = true;
  return true;
}
void SwapBuf::put(uint32_t off, const void *src, uint32_t n) {
  if (!ok || off + n > size) return;
  f.seek(off); f.write((const uint8_t *)src, n);
}
void SwapBuf::get(uint32_t off, void *dst, uint32_t n) {
  if (!ok || off + n > size) { memset(dst, 0, n); return; }
  f.seek(off); f.read((uint8_t *)dst, n);
}
void SwapBuf::close() {
  if (f) { f.close(); SD.remove("/sys/swap.bin"); }
  ok = false; size = 0;
}
}  // namespace sys
