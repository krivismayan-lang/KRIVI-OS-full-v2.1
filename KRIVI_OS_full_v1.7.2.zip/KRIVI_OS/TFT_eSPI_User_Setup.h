// ============================================================================
//  TFT_eSPI User_Setup.h for the Cheap Yellow Display  ESP32-2432S028
//  (KRIVI OS)
//
//  INSTALL: copy this file over
//     <Arduino>/libraries/TFT_eSPI/User_Setup.h
//  (Windows: Documents\Arduino\libraries\TFT_eSPI\User_Setup.h
//   macOS/Linux: ~/Documents/Arduino/libraries/TFT_eSPI/User_Setup.h)
//  Keep a backup of the original if you use TFT_eSPI with other boards.
// ============================================================================
#define USER_SETUP_INFO "KRIVI_CYD_2432S028"

// ---- Panel driver ----------------------------------------------------------
// Most ESP32-2432S028 boards (incl. many dual-USB / USB-C revisions):
#define ILI9341_2_DRIVER
// If your screen shows wrong colours, mirrored or garbled output, comment the
// line above and enable this one instead (some dual-USB boards use ST7789):
// #define ST7789_DRIVER
// #define TFT_RGB_ORDER TFT_RGB
// #define TFT_INVERSION_OFF

#define TFT_WIDTH  240
#define TFT_HEIGHT 320

// ---- Display SPI (HSPI) ----------------------------------------------------
#define TFT_MISO 12
#define TFT_MOSI 13
#define TFT_SCLK 14
#define TFT_CS   15
#define TFT_DC    2
#define TFT_RST  -1
#define TFT_BL   21
#define TFT_BACKLIGHT_ON HIGH
#define USE_HSPI_PORT        // leaves VSPI free for the microSD card

// ---- Fonts -----------------------------------------------------------------
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_FONT6
#define LOAD_FONT7
#define LOAD_FONT8
#define LOAD_GFXFF
#define SMOOTH_FONT

// ---- Clocks ----------------------------------------------------------------
#define SPI_FREQUENCY       55000000
#define SPI_READ_FREQUENCY  20000000
#define SPI_TOUCH_FREQUENCY  2500000   // unused: KRIVI bit-bangs the XPT2046
