// ============================================================================
//  Page 4: Raspberry Pi interface & wireless radio
//  27 Pi monitor 28 Pi console 29 Pi trackpad 30 BLE macro pad
//  31 BLE presenter 32 WiFi analyzer 33 Ping monitor 34 ESP-NOW chat
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_now.h>
#include <NimBLEDevice.h>
#include <NimBLEHIDDevice.h>
#include "ping/ping_sock.h"
#include <stdarg.h>

// ============================================================================
//  USB-serial link to tools/pi/krivi_bridge.py
// ============================================================================
namespace pilink {
static char s_buf[256]; static int s_len = 0;
void send(const char *fmt, ...) {
  char b[200];
  va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof(b), fmt, ap); va_end(ap);
  Serial.print('@'); Serial.println(b);
}
bool readLine(String &out) {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\r') continue;
    if (ch == '\n') { s_buf[s_len] = 0; out = s_buf; s_len = 0; return true; }
    if (s_len < (int)sizeof(s_buf) - 1) s_buf[s_len++] = ch;
  }
  return false;
}
}

static float kv(const String &l, const char *key, float d = NAN) {
  String k = String(key) + "=";
  int i = l.indexOf(k);
  if (i < 0) return d;
  return l.substring(i + k.length()).toFloat();
}
static String kvs(const String &l, const char *key) {
  String k = String(key) + "=";
  int i = l.indexOf(k);
  if (i < 0) return "";
  int e = l.indexOf(' ', i);
  return l.substring(i + k.length(), e < 0 ? l.length() : e);
}

// ============================================================================
//  27  PI PERFORMANCE MONITOR
// ============================================================================
void app_pimon(AppCtx &c) {
  uint8_t cpuH[60], tmpH[60]; memset(cpuH, 0, 60); memset(tmpH, 0, 60);
  int hp = 0; uint32_t lastRx = 0, lastHello = 0; bool online = false;
  ui::clearBody();
  auto tile = [&](int x, int y, const char *k, const String &v, uint16_t col) {
    tft.fillRoundRect(x, y, 100, 42, 6, C_PANEL);
    tft.setTextColor(C_DIM, C_PANEL); tft.drawString(k, x + 6, y + 4, 1);
    tft.setTextColor(col, C_PANEL); tft.drawString(v, x + 6, y + 16, 4);
  };
  auto graph = [&]() {
    const int GX = 4, GY = 124, GW = 312, GH = 86;
    tft.fillRect(GX, GY, GW, GH, TFT_BLACK);
    tft.drawRect(GX, GY, GW, GH, C_PANEL2);
    for (int i = 1; i < 60; ++i) {
      int a = (hp + i - 1) % 60, b = (hp + i) % 60;
      int x0 = GX + (i - 1) * GW / 60, x1 = GX + i * GW / 60;
      tft.drawLine(x0, GY + GH - 1 - cpuH[a] * (GH - 2) / 100, x1, GY + GH - 1 - cpuH[b] * (GH - 2) / 100, C_ACCENT);
      tft.drawLine(x0, GY + GH - 1 - tmpH[a] * (GH - 2) / 100, x1, GY + GH - 1 - tmpH[b] * (GH - 2) / 100, C_WARN);
    }
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString("CPU %", 6, 214, 1);
    tft.setTextColor(C_WARN, C_BG); tft.drawString("TEMP C (0-100)  last 60 s", 50, 214, 1);
  };
  tile(4, 30, "CPU", "--", C_ACCENT); tile(110, 30, "TEMP", "--", C_WARN); tile(216, 30, "RAM", "--", C_OK);
  tile(4, 76, "DISK", "--", C_TEXT); tile(110, 76, "LOAD 1m", "--", C_TEXT); tile(216, 76, "UPTIME", "--", C_TEXT);
  graph();
  hud("waiting...", C_WARN);
  while (c.loop()) {
    if (millis() - lastHello > 3000) { lastHello = millis(); pilink::send("STATS 1"); }
    String l;
    while (pilink::readLine(l)) {
      if (!l.startsWith("@STAT ")) continue;
      lastRx = millis();
      if (!online) { online = true; hud(kvs(l, "host").substring(0, 14).c_str(), C_OK); }
      float cpu = kv(l, "cpu", 0), temp = kv(l, "temp", 0), ram = kv(l, "ram", 0), disk = kv(l, "disk", 0), load = kv(l, "load", 0);
      long up = (long)kv(l, "up", 0);
      char b[24];
      snprintf(b, 24, "%.0f%%", cpu); tile(4, 30, "CPU", b, cpu > 80 ? C_ERR : C_ACCENT);
      snprintf(b, 24, "%.1fC", temp); tile(110, 30, "TEMP", b, temp > 70 ? C_ERR : C_WARN);
      snprintf(b, 24, "%.0f%%", ram); tile(216, 30, "RAM", b, C_OK);
      snprintf(b, 24, "%.0f%%", disk); tile(4, 76, "DISK", b, C_TEXT);
      snprintf(b, 24, "%.2f", load); tile(110, 76, "LOAD 1m", b, C_TEXT);
      if (up >= 86400) snprintf(b, 24, "%ldd%ldh", up / 86400, up % 86400 / 3600); else snprintf(b, 24, "%ldh%02ldm", up / 3600, up % 3600 / 60);
      tile(216, 76, "UPTIME", b, C_TEXT);
      cpuH[hp] = constrain((int)cpu, 0, 100); tmpH[hp] = constrain((int)temp, 0, 100); hp = (hp + 1) % 60;
      graph();
    }
    if (online && millis() - lastRx > 4000) { online = false; hud("link lost", C_ERR); }
  }
  pilink::send("STATS 0");
}

// ============================================================================
//  28  PI BASH DEPLOYMENT CONSOLE
// ============================================================================
void app_piconsole(AppCtx &c) {
  std::vector<String> scripts;
  std::vector<String> term;
  bool running = false; int page = 0;
  const int TY = 108, TL = 11;
  auto drawTerm = [&]() {
    tft.fillRect(0, TY, 320, 132, TFT_BLACK);
    int first = max(0, (int)term.size() - TL);
    for (int i = first; i < (int)term.size(); ++i) {
      const String &s = term[i];
      tft.setTextColor(s.startsWith("$") ? C_ACCENT : (s.startsWith("!") ? C_ERR : RGB565(170, 255, 190)), TFT_BLACK);
      tft.drawString(s.substring(0, 53), 2, TY + 2 + (i - first) * 12, 1);
    }
  };
  auto addLine = [&](const String &s) { term.push_back(s); if (term.size() > 60) term.erase(term.begin()); drawTerm(); };
  auto drawButtons = [&]() {
    tft.fillRect(0, 28, 320, 78, C_BG);
    for (int i = 0; i < 4; ++i) {
      int idx = page * 4 + i;
      if (idx < (int)scripts.size()) ui::button(4 + (i % 2) * 130, 30 + (i / 2) * 38, 126, 34, scripts[idx].substring(0, 16).c_str(), RGB565(0, 80, 130), TFT_WHITE, 2);
    }
    ui::button(264, 30, 52, 34, running ? "KILL" : "LIST", running ? C_ERR : C_PANEL2, C_TEXT, 2);
    ui::button(264, 68, 52, 34, "MORE", C_PANEL2, C_TEXT, 2);
  };
  ui::clearBody();
  drawButtons(); drawTerm();
  addLine("Requesting script list from Pi...");
  pilink::send("LIST");
  uint32_t asked = millis();
  bool gotList = false;
  while (c.loop()) {
    String l;
    while (pilink::readLine(l)) {
      if (l.startsWith("@SCRIPT ")) { scripts.push_back(l.substring(8)); gotList = true; }
      else if (l == "@END") { addLine(String("") + scripts.size() + " scripts available"); drawButtons(); }
      else if (l.startsWith("@OUT ")) addLine(l.substring(5));
      else if (l.startsWith("@EXIT ")) { running = false; addLine("! exit code " + l.substring(6)); drawButtons(); audio::beep(l.substring(6).toInt() ? 400 : 1200, 80); }
      else if (l.startsWith("@ERR ")) { running = false; addLine("! " + l.substring(5)); drawButtons(); }
    }
    if (!gotList && asked && millis() - asked > 3000) { asked = 0; addLine("! no reply - is krivi_bridge.py running on the Pi?"); }
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 264, 30, 52, 34)) {
      if (running) { pilink::send("KILL"); addLine("$ kill"); }
      else { scripts.clear(); pilink::send("LIST"); asked = millis(); gotList = false; addLine("$ list"); }
    } else if (ui::inRect(t.sx, t.sy, 264, 68, 52, 34)) {
      if (scripts.size() > 4) { page = (page + 1) % ((scripts.size() + 3) / 4); drawButtons(); }
    } else if (!running) {
      for (int i = 0; i < 4; ++i) {
        int idx = page * 4 + i;
        if (idx < (int)scripts.size() && ui::inRect(t.sx, t.sy, 4 + (i % 2) * 130, 30 + (i / 2) * 38, 126, 34)) {
          if (!ui::confirm("RUN ON PI", (String("Run ~/krivi_scripts/") + scripts[idx] + " ?").c_str())) { c.header(); ui::clearBody(); drawButtons(); drawTerm(); break; }
          c.header(); ui::clearBody();
          running = true; pilink::send("RUN %s", scripts[idx].c_str());
          addLine("$ " + scripts[idx]); drawButtons(); drawTerm();
        }
      }
    }
  }
  if (running) pilink::send("KILL");
}

// ============================================================================
//  29  PI REMOTE TRACKPAD
// ============================================================================
void app_pitrackpad(AppCtx &c) {
  const int PY = 28, PH = 168;
  float speed = c.pFloat("speed", 2.0f);
  auto draw = [&]() {
    tft.fillRoundRect(4, PY, 312, PH, 10, RGB565(30, 34, 48));
    tft.drawRoundRect(4, PY, 312, PH, 10, C_PANEL2);
    ui::centerText("drag = move   tap = click", 160, PY + PH / 2, C_DIM, RGB565(30, 34, 48), 2);
    ui::button(4, 200, 74, 36, "LEFT", C_PANEL2); ui::button(82, 200, 74, 36, "RIGHT", C_PANEL2);
    ui::button(160, 200, 50, 36, "SCR^", C_PANEL2, C_TEXT, 1); ui::button(214, 200, 50, 36, "SCRv", C_PANEL2, C_TEXT, 1);
    char s[12]; snprintf(s, 12, "x%.1f", speed); ui::button(268, 200, 48, 36, s, RGB565(90, 50, 160), C_TEXT, 1);
  };
  ui::clearBody(); draw();
  int lx = 0, ly = 0; float ax = 0, ay = 0; uint32_t lastSend = 0; bool moved = false;
  int dotX = -1, dotY = -1;
  while (c.loop()) {
    Touch &t = *c.t;
    bool inPad = ui::inRect(t.sx, t.sy, 4, PY, 312, PH);
    if (t.pressed && inPad) { lx = t.x; ly = t.y; moved = false; }
    if (t.down && inPad) {
      ax += (t.x - lx) * speed; ay += (t.y - ly) * speed; lx = t.x; ly = t.y;
      if (fabsf(ax) + fabsf(ay) > 6) moved = true;
      if (millis() - lastSend > 20 && ((int)ax || (int)ay)) {
        pilink::send("MOVE %d %d", (int)ax, (int)ay); ax -= (int)ax; ay -= (int)ay; lastSend = millis();
      }
      if (dotX >= 0) tft.fillCircle(dotX, dotY, 6, RGB565(30, 34, 48));
      dotX = constrain((int)t.x, 12, 308); dotY = constrain((int)t.y, PY + 8, PY + PH - 8);
      tft.fillCircle(dotX, dotY, 6, C_ACCENT);
    }
    if (t.released && dotX >= 0) { tft.fillCircle(dotX, dotY, 6, RGB565(30, 34, 48)); dotX = -1; }
    if (t.tap && inPad && !moved) { pilink::send("CLICK L"); audio::click(); }
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 4, 200, 74, 36)) { pilink::send("CLICK L"); audio::click(); }
      else if (ui::inRect(t.sx, t.sy, 82, 200, 74, 36)) { pilink::send("CLICK R"); audio::click(); }
      else if (ui::inRect(t.sx, t.sy, 160, 200, 50, 36)) pilink::send("SCROLL 3");
      else if (ui::inRect(t.sx, t.sy, 214, 200, 50, 36)) pilink::send("SCROLL -3");
      else if (ui::inRect(t.sx, t.sy, 268, 200, 48, 36)) { speed = speed >= 4 ? 1 : speed + 0.5f; draw(); }
    }
  }
}

// ============================================================================
//  BLE HID keyboard (NimBLE) - shared by apps 30 and 31
// ============================================================================
namespace blehid {
static NimBLEServer *srv = nullptr;
static NimBLEHIDDevice *hid = nullptr;
static NimBLECharacteristic *inKb = nullptr, *inCons = nullptr;
static volatile bool s_conn = false;
static bool s_on = false;

static const uint8_t REPORT_MAP[] = {
  0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,             // Keyboard, report 1
  0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
  0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
  0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
  0xC0,
  0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x02,             // Consumer, report 2
  0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
  0xC0};

class SrvCB : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer *) override { s_conn = true; }
  void onDisconnect(NimBLEServer *) override { s_conn = false; NimBLEDevice::startAdvertising(); }
};

bool begin(const char *name) {
  if (s_on) return true;
  NimBLEDevice::init(name);
  NimBLEDevice::setSecurityAuth(true, false, true);
  srv = NimBLEDevice::createServer();
  srv->setCallbacks(new SrvCB());
  hid = new NimBLEHIDDevice(srv);
  inKb = hid->inputReport(1);
  inCons = hid->inputReport(2);
  hid->manufacturer()->setValue("KRIVI OS");
  hid->pnp(0x02, 0xE502, 0xA111, 0x0210);
  hid->hidInfo(0x00, 0x01);
  hid->reportMap((uint8_t *)REPORT_MAP, sizeof(REPORT_MAP));
  hid->startServices();
  hid->setBatteryLevel(100);
  NimBLEAdvertising *adv = srv->getAdvertising();
  adv->setAppearance(0x03C1);                     // HID keyboard
  adv->addServiceUUID(hid->hidService()->getUUID());
  adv->setScanResponse(true);
  adv->start();
  s_on = true;
  sys::log("ble: advertising as '%s'", name);
  return true;
}
void end() {
  if (!s_on) return;
  NimBLEDevice::deinit(true);
  delete hid; hid = nullptr; srv = nullptr; inKb = inCons = nullptr;
  s_on = false; s_conn = false;
}
bool connected() { return s_conn; }

static void sendKb(uint8_t mod, uint8_t key) {
  if (!s_conn || !inKb) return;
  uint8_t r[8] = {mod, 0, key, 0, 0, 0, 0, 0};
  inKb->setValue(r, 8); inKb->notify();
  delay(12);
  uint8_t z[8] = {0};
  inKb->setValue(z, 8); inKb->notify();
  delay(8);
}
void press(uint8_t mod, uint8_t key) { sendKb(mod, key); }
void consumer(uint16_t usage) {
  if (!s_conn || !inCons) return;
  uint8_t r[2] = {(uint8_t)(usage & 0xFF), (uint8_t)(usage >> 8)};
  inCons->setValue(r, 2); inCons->notify(); delay(12);
  uint8_t z[2] = {0, 0}; inCons->setValue(z, 2); inCons->notify(); delay(8);
}
// ASCII -> (shift, usage)
static bool asciiKey(char ch, uint8_t &mod, uint8_t &key) {
  mod = 0;
  if (ch >= 'a' && ch <= 'z') { key = 4 + ch - 'a'; return true; }
  if (ch >= 'A' && ch <= 'Z') { mod = 2; key = 4 + ch - 'A'; return true; }
  if (ch >= '1' && ch <= '9') { key = 30 + ch - '1'; return true; }
  if (ch == '0') { key = 39; return true; }
  static const char *plain = " -=[]\\;'`,./\n\t";
  static const uint8_t pk[] = {44, 45, 46, 47, 48, 49, 51, 52, 53, 54, 55, 56, 40, 43};
  for (int i = 0; plain[i]; ++i) if (plain[i] == ch) { key = pk[i]; return true; }
  static const char *shifted = "!@#$%^&*()_+{}|:\"~<>?";
  static const uint8_t sk[] = {30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 45, 46, 47, 48, 49, 51, 52, 53, 54, 55, 56};
  for (int i = 0; shifted[i]; ++i) if (shifted[i] == ch) { mod = 2; key = sk[i]; return true; }
  return false;
}
void typeText(const char *s) { for (; *s; ++s) { uint8_t m, k; if (asciiKey(*s, m, k)) sendKb(m, k); } }

bool sendCombo(const char *combo) {
  String c = combo;
  if (c.startsWith("text:")) { typeText(c.c_str() + 5); return true; }
  if (c.startsWith("media:")) {
    String m = c.substring(6); m.toUpperCase();
    uint16_t u = m == "PLAY" ? 0xCD : m == "VOLUP" ? 0xE9 : m == "VOLDN" ? 0xEA : m == "MUTE" ? 0xE2 :
                 m == "NEXT" ? 0xB5 : m == "PREV" ? 0xB6 : 0;
    if (u) consumer(u);
    return u != 0;
  }
  uint8_t mod = 0, key = 0;
  int start = 0;
  while (start <= (int)c.length()) {
    int e = c.indexOf('+', start); if (e < 0) e = c.length();
    String tok = c.substring(start, e); start = e + 1;
    String T = tok; T.toUpperCase();
    if (T == "CTRL") mod |= 0x01; else if (T == "SHIFT") mod |= 0x02; else if (T == "ALT") mod |= 0x04;
    else if (T == "GUI" || T == "WIN" || T == "CMD") mod |= 0x08;
    else if (T.length() >= 2 && T[0] == 'F' && isdigit((unsigned char)T[1])) key = 57 + T.substring(1).toInt();
    else if (T == "ENTER") key = 40; else if (T == "ESC") key = 41; else if (T == "BKSP") key = 42; else if (T == "TAB") key = 43;
    else if (T == "SPACE") key = 44; else if (T == "RIGHT") key = 79; else if (T == "LEFT") key = 80; else if (T == "DOWN") key = 81;
    else if (T == "UP") key = 82; else if (T == "PGUP") key = 75; else if (T == "PGDN") key = 78; else if (T == "HOME") key = 74;
    else if (T == "END") key = 77; else if (T == "DEL") key = 76; else if (T == "PRTSC") key = 70;
    else if (tok.length() == 1) { uint8_t m2; asciiKey(tolower(tok[0]), m2, key); mod |= m2; }
  }
  sendKb(mod, key);
  return key != 0 || mod != 0;
}
}  // namespace blehid

static void bleStatus(bool conn, const char *name) {
  tft.fillRect(0, 26, 320, 18, C_BG);
  tft.fillCircle(10, 35, 5, conn ? C_OK : C_WARN);
  tft.setTextColor(conn ? C_OK : C_WARN, C_BG);
  tft.drawString(conn ? "connected" : (String("pair with '") + name + "'").c_str(), 20, 30, 2);
}

// ============================================================================
//  30  BLUETOOTH MACRO HID PAD
// ============================================================================
void app_blemacro(AppCtx &c) {
  struct M { String label, keys; } m[9];
  static const char *DL[9] = {"Copy", "Paste", "Undo", "Save", "Terminal", "Lock", "Vol -", "Play", "Vol +"};
  static const char *DK[9] = {"CTRL+C", "CTRL+V", "CTRL+Z", "CTRL+S", "CTRL+ALT+T", "GUI+L", "media:VOLDN", "media:PLAY", "media:VOLUP"};
  JsonArray arr = c.params["macros"].as<JsonArray>();
  for (int i = 0; i < 9; ++i) {
    if (!arr.isNull() && i < (int)arr.size()) { m[i].label = arr[i]["label"] | DL[i]; m[i].keys = arr[i]["keys"] | DK[i]; }
    else { m[i].label = DL[i]; m[i].keys = DK[i]; }
  }
  sys::radiosOff();
  ui::clearBody();
  ui::centerText("Starting Bluetooth...", 160, 120, C_DIM, C_BG, 2);
  blehid::begin("KRIVI Macro");
  ui::clearBody();
  const int PW = 102, PH = 62, OX = 6, OY = 46;
  auto pad = [&](int i, bool lit) {
    int x = OX + (i % 3) * (PW + 2), y = OY + (i / 3) * (PH + 2);
    uint16_t col = lit ? C_ACCENT : ui::hsv(200 + i * 15, 160, 120);
    tft.fillRoundRect(x, y, PW, PH, 8, col);
    ui::centerText(m[i].label.c_str(), x + PW / 2, y + 24, TFT_WHITE, col, 2);
    ui::centerText(m[i].keys.substring(0, 16).c_str(), x + PW / 2, y + 46, lit ? TFT_BLACK : C_DIM, col, 1);
  };
  for (int i = 0; i < 9; ++i) pad(i, false);
  bool lastConn = !blehid::connected();
  while (c.loop()) {
    if (blehid::connected() != lastConn) { lastConn = blehid::connected(); bleStatus(lastConn, "KRIVI Macro"); }
    Touch &t = *c.t;
    if (!t.pressed) continue;
    int col = (t.x - OX) / (PW + 2), row = (t.y - OY) / (PH + 2);
    if (t.y < OY || col > 2 || row > 2) continue;
    int i = row * 3 + col;
    pad(i, true);
    if (blehid::connected()) { blehid::sendCombo(m[i].keys.c_str()); audio::click(); }
    else audio::beep(300, 60);
    delay(60); pad(i, false);
  }
  blehid::end();
}

// ============================================================================
//  31  BLE SLIDESHOW PRESENTER
// ============================================================================
void app_blekbd(AppCtx &c) {
  // Full on-screen Bluetooth keyboard. Pairs as "KRIVI Keyboard" and types
  // LIVE into a Raspberry Pi, PC, phone or tablet over Bluetooth LE HID.
  sys::radiosOff();
  ui::clearBody();
  ui::centerText("Starting Bluetooth...", 160, 120, C_DIM, C_BG, 2);
  blehid::begin("KRIVI Keyboard");
  ui::clearBody();
  ui::Keyboard kb; kb.y0 = 108;
  uint8_t mod = 0;                  // sticky CTRL/ALT/GUI for the next key
  String sent;                      // little echo of what we sent
  auto modRow = [&]() {
    tft.fillRect(0, 54, 320, 50, C_BG);
    struct B { const char *l; uint8_t bit; int x, w; };
    static const B BB[] = {{"ESC", 0, 2, 40}, {"TAB", 0, 44, 40}, {"CTRL", 1, 86, 48},
      {"ALT", 4, 136, 44}, {"GUI", 8, 182, 44}, {"UP", 0, 228, 42}, {"DN", 0, 272, 44}};
    for (auto &b : BB) {
      bool on = b.bit && (mod & b.bit);
      ui::button(b.x, 56, b.w, 42, b.l, on ? C_ACCENT : C_PANEL2, on ? TFT_BLACK : C_TEXT, 2);
    }
  };
  auto topInfo = [&]() {
    tft.fillRect(0, 26, 320, 28, C_BG);
    bool cn = blehid::connected();
    tft.fillCircle(10, 38, 5, cn ? C_OK : C_WARN);
    tft.setTextColor(cn ? C_OK : C_WARN, C_BG);
    tft.drawString(cn ? "connected" : "pair with 'KRIVI Keyboard'", 20, 32, 2);
    tft.setTextColor(C_DIM, C_BG); tft.setTextDatum(TR_DATUM);
    tft.drawString(sent.substring(0, 22), 314, 32, 2); tft.setTextDatum(TL_DATUM);
  };
  kb.draw(); modRow(); topInfo();
  bool lastConn = !blehid::connected();
  auto echo = [&](const String &s) { sent = s + " " + sent; if (sent.length() > 40) sent = sent.substring(0, 40); topInfo(); };
  while (c.loop()) {
    if (blehid::connected() != lastConn) { lastConn = blehid::connected(); topInfo(); }
    Touch &t = *c.t;
    if (!t.pressed) continue;
    // special / modifier row
    if (t.y >= 56 && t.y < 104) {
      if (ui::inRect(t.x, t.y, 2, 56, 40, 42)) { blehid::sendCombo("ESC"); echo("Esc"); }
      else if (ui::inRect(t.x, t.y, 44, 56, 40, 42)) { blehid::sendCombo("TAB"); echo("Tab"); }
      else if (ui::inRect(t.x, t.y, 86, 56, 48, 42)) { mod ^= 1; modRow(); }
      else if (ui::inRect(t.x, t.y, 136, 56, 44, 42)) { mod ^= 4; modRow(); }
      else if (ui::inRect(t.x, t.y, 182, 56, 44, 42)) { mod ^= 8; modRow(); }
      else if (ui::inRect(t.x, t.y, 228, 56, 42, 42)) { blehid::press(0, 82); echo("Up"); }
      else if (ui::inRect(t.x, t.y, 272, 56, 44, 42)) { blehid::press(0, 81); echo("Dn"); }
      audio::click();
      continue;
    }
    if (t.y < kb.y0) continue;
    int k = kb.hit(t.x, t.y);
    if (!k) continue;
    if (k == ui::Keyboard::K_ENTER) { blehid::sendCombo("ENTER"); echo("Enter"); }
    else if (k == ui::Keyboard::K_BKSP) { blehid::sendCombo("BKSP"); echo("Bksp"); }
    else if (k == ui::Keyboard::K_LEFT) { blehid::press(0, 80); echo("Left"); }
    else if (k == ui::Keyboard::K_RIGHT) { blehid::press(0, 79); echo("Right"); }
    else if (k >= 32) {
      if (mod) {
        char combo[24]; const char *mm = "";
        // build "CTRL+ALT+GUI+x"
        String cs;
        if (mod & 1) cs += "CTRL+";
        if (mod & 4) cs += "ALT+";
        if (mod & 8) cs += "GUI+";
        cs += (char)k;
        blehid::sendCombo(cs.c_str());
        echo(cs); mod = 0; modRow();
      } else {
        char s[2] = {(char)k, 0}; blehid::typeText(s);
        char e[8]; snprintf(e, 8, "%c", (char)k); echo(e);
      }
    }
  }
  blehid::end();
}

// ============================================================================
//  32  LOCAL WIFI ANTENNA ANALYZER
// ============================================================================
void app_wifiscan(AppCtx &c) {
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  bool list = false; int n = 0;
  const int GX = 30, GY = 32, GW = 284, GH = 160;
  auto chX = [&](float ch) { return GX + (int)((ch + 1) * GW / 16.0f); };
  auto rssiY = [&](int r) { return GY + GH - (int)((constrain(r, -100, -20) + 100) * GH / 80.0f); };
  auto drawGraph = [&]() {
    ui::clearBody();
    tft.drawRect(GX, GY, GW, GH, C_PANEL2);
    for (int r = -90; r <= -30; r += 20) { int y = rssiY(r); tft.drawFastHLine(GX, y, GW, RGB565(25, 30, 45));
      char s[6]; snprintf(s, 6, "%d", r); tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 2, y - 4, 1); }
    for (int ch = 1; ch <= 13; ++ch) { char s[4]; snprintf(s, 4, "%d", ch); ui::centerText(s, chX(ch), GY + GH + 8, C_DIM, C_BG, 1); }
    for (int i = 0; i < n; ++i) {
      int ch = WiFi.channel(i), r = WiFi.RSSI(i);
      uint16_t col = ui::hsv((i * 47) % 360, 220, 255);
      int px = -1, py = -1;
      for (float d = -2.0f; d <= 2.0f; d += 0.1f) {
        float amp = 1 - (d * d) / 4.0f;
        int y = rssiY(-100 + (int)((r + 100) * amp));
        int x = chX(ch + d);
        if (px >= 0) tft.drawLine(px, py, x, y, col);
        px = x; py = y;
      }
      String ss = WiFi.SSID(i); if (!ss.length()) ss = "(hidden)";
      tft.setTextColor(col, C_BG); tft.drawString(ss.substring(0, 10), chX(ch) - 20, rssiY(r) - 10, 1);
    }
  };
  auto drawList = [&]() {
    ui::clearBody();
    tft.setTextColor(C_DIM, C_BG); tft.drawString("SSID                  CH  RSSI  SEC", 4, 30, 1);
    int idx[40]; int m = min(n, 40); for (int i = 0; i < m; ++i) idx[i] = i;
    std::sort(idx, idx + m, [](int a, int b) { return WiFi.RSSI(a) > WiFi.RSSI(b); });
    for (int k = 0; k < min(m, 13); ++k) {
      int i = idx[k]; char s[64]; String ss = WiFi.SSID(i); if (!ss.length()) ss = "(hidden)";
      wifi_auth_mode_t a = WiFi.encryptionType(i);
      snprintf(s, 64, "%-21s %2d  %4d  %s", ss.substring(0, 21).c_str(), WiFi.channel(i), WiFi.RSSI(i),
               a == WIFI_AUTH_OPEN ? "open" : (a == WIFI_AUTH_WEP ? "WEP" : (a == WIFI_AUTH_WPA3_PSK ? "WPA3" : "WPA2")));
      tft.setTextColor(WiFi.RSSI(i) > -60 ? C_OK : (WiFi.RSSI(i) > -75 ? C_WARN : C_ERR), C_BG);
      tft.drawString(s, 4, 44 + k * 13, 1);
    }
  };
  auto buttons = [&]() {
    ui::button(4, 210, 100, 28, "RESCAN"); ui::button(110, 210, 100, 28, list ? "GRAPH" : "LIST");
    char s[16]; snprintf(s, 16, "%d nets", n); tft.fillRect(216, 210, 104, 28, C_BG); ui::centerText(s, 266, 224, C_TEXT, C_BG, 2);
  };
  auto scan = [&]() {
    ui::clearBody(); ui::centerText("Scanning 2.4 GHz...", 160, 120, C_WARN, C_BG, 2);
    n = WiFi.scanNetworks(false, true);
    if (n < 0) n = 0;
    list ? drawList() : drawGraph(); buttons();
  };
  scan();
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 4, 210, 100, 28)) scan();
    else if (ui::inRect(t.sx, t.sy, 110, 210, 100, 28)) { list = !list; list ? drawList() : drawGraph(); buttons(); }
  }
  WiFi.scanDelete();
}

// ============================================================================
//  33  PING LATENCY NETWORK MONITOR  (ICMP via lwIP esp_ping)
// ============================================================================
namespace pingmon {
struct Tgt { esp_ping_handle_t h; volatile int last; volatile uint32_t sent, recv; float sum; int16_t hist[100]; volatile int hp; IPAddress ip; String name; };
static void onOk(esp_ping_handle_t h, void *a) {
  Tgt *t = (Tgt *)a; uint32_t ms; esp_ping_get_profile(h, ESP_PING_PROF_TIMEGAP, &ms, sizeof(ms));
  t->last = ms; t->recv++; t->sent++; t->sum += ms; t->hist[t->hp] = ms; t->hp = (t->hp + 1) % 100;
}
static void onTo(esp_ping_handle_t h, void *a) {
  Tgt *t = (Tgt *)a; t->last = -1; t->sent++; t->hist[t->hp] = -1; t->hp = (t->hp + 1) % 100;
}
static bool start(Tgt &t) {
  esp_ping_config_t cfg = ESP_PING_DEFAULT_CONFIG();
  ip_addr_t a; IP_ADDR4(&a, t.ip[0], t.ip[1], t.ip[2], t.ip[3]);
  cfg.target_addr = a; cfg.count = ESP_PING_COUNT_INFINITE; cfg.interval_ms = 1000; cfg.timeout_ms = 900;
  esp_ping_callbacks_t cb = {}; cb.cb_args = &t; cb.on_ping_success = onOk; cb.on_ping_timeout = onTo;
  if (esp_ping_new_session(&cfg, &cb, &t.h) != ESP_OK) return false;
  return esp_ping_start(t.h) == ESP_OK;
}
}

void app_ping(AppCtx &c) {
  ui::clearBody();
  if (!sys::wifiConnect(10000, true)) { if (!c.exitReq) ui::msgBox("PING", "WiFi connection failed."); return; }
  String host = c.pStr("host", "1.1.1.1");
  pingmon::Tgt *T = new pingmon::Tgt[2]();
  T[0].name = "gateway"; T[0].ip = WiFi.gatewayIP();
  T[1].name = host;
  if (!WiFi.hostByName(host.c_str(), T[1].ip)) T[1].ip = IPAddress(1, 1, 1, 1);
  for (int i = 0; i < 2; ++i) { memset(T[i].hist, 0xFF, sizeof(T[i].hist)); T[i].hist[0] = -2; for (auto &h : T[i].hist) h = -2; pingmon::start(T[i]); }
  ui::clearBody();
  const int GX = 4, GY = 92, GW = 312, GH = 120;
  static const uint16_t COL[2] = {C_OK, C_ACCENT};
  while (c.frame(500)) {
    int maxMs = 50;
    for (int i = 0; i < 2; ++i) for (int k = 0; k < 100; ++k) maxMs = max(maxMs, (int)T[i].hist[k]);
    maxMs = ((maxMs + 49) / 50) * 50;
    for (int i = 0; i < 2; ++i) {
      pingmon::Tgt &t = T[i];
      int y = 30 + i * 30;
      tft.fillRect(0, y, 320, 28, C_BG);
      tft.fillCircle(10, y + 10, 5, COL[i]);
      char s[80];
      float loss = t.sent ? 100.0f * (t.sent - t.recv) / t.sent : 0;
      snprintf(s, 80, "%-10s %-15s", t.name.substring(0, 10).c_str(), t.ip.toString().c_str());
      tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 20, y + 2, 1);
      if (t.last >= 0) snprintf(s, 80, "%4d ms  avg %5.1f  loss %4.1f%%", t.last, t.recv ? t.sum / t.recv : 0, loss);
      else snprintf(s, 80, "timeout  avg %5.1f  loss %4.1f%%", t.recv ? t.sum / t.recv : 0, loss);
      tft.setTextColor(t.last >= 0 ? COL[i] : C_ERR, C_BG); tft.drawString(s, 20, y + 14, 1);
    }
    tft.fillRect(GX, GY, GW, GH, TFT_BLACK); tft.drawRect(GX, GY, GW, GH, C_PANEL2);
    char s[16]; snprintf(s, 16, "%d ms", maxMs); tft.setTextColor(C_DIM, TFT_BLACK); tft.drawString(s, GX + 4, GY + 3, 1);
    for (int i = 0; i < 2; ++i) {
      pingmon::Tgt &t = T[i]; int px = -1, py = 0;
      for (int k = 0; k < 100; ++k) {
        int v = t.hist[(t.hp + k) % 100]; int x = GX + k * GW / 100;
        if (v == -2) { px = -1; continue; }
        if (v < 0) { tft.drawFastVLine(x, GY + 1, GH - 2, RGB565(90, 20, 20)); px = -1; continue; }
        int y = GY + GH - 2 - v * (GH - 4) / maxMs;
        if (px >= 0) tft.drawLine(px, py, x, y, COL[i]);
        px = x; py = y;
      }
    }
    tft.setTextColor(C_DIM, C_BG); tft.drawString("last 100 s (red = timeout). Host editable in app_33.json", 4, 218, 1);
  }
  for (int i = 0; i < 2; ++i) { if (T[i].h) { esp_ping_stop(T[i].h); esp_ping_delete_session(T[i].h); } }
  delete[] T;
}

// ============================================================================
//  34  ESP-NOW PEER RADIO TRANSCEIVER
// ============================================================================
namespace espnowchat {
struct Msg { char magic[4]; char nick[12]; char text[180]; };
static volatile int s_inHead = 0; static Msg s_in[6]; static volatile int s_inCount = 0;
static void onRecv(const uint8_t *mac, const uint8_t *data, int len) {
  if (len < 16 || memcmp(data, "KRV1", 4)) return;
  Msg &m = s_in[s_inHead % 6];
  memset(&m, 0, sizeof(m)); memcpy(&m, data, min(len, (int)sizeof(Msg))); m.text[179] = 0; m.nick[11] = 0;
  s_inHead++; s_inCount++;
}
}

void app_espnow(AppCtx &c) {
  using namespace espnowchat;
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_channel(c.pInt("channel", 1), WIFI_SECOND_CHAN_NONE);
  if (esp_now_init() != ESP_OK) { ui::msgBox("ESP-NOW", "init failed"); return; }
  esp_now_register_recv_cb(onRecv);
  esp_now_peer_info_t peer = {}; memset(peer.peer_addr, 0xFF, 6); peer.channel = 0; peer.encrypt = false;
  esp_now_add_peer(&peer);
  String nick = c.pStr("nick", "");
  if (!nick.length()) { uint8_t mac[6]; WiFi.macAddress(mac); char b[12]; snprintf(b, 12, "CYD-%02X%02X", mac[4], mac[5]); nick = b; }
  std::vector<String> log;
  int seen = s_inHead;
  auto drawLog = [&]() {
    tft.fillRect(0, 28, 320, 140, TFT_BLACK);
    int first = max(0, (int)log.size() - 11);
    for (int i = first; i < (int)log.size(); ++i) {
      const String &l = log[i];
      tft.setTextColor(l.startsWith(">") ? C_ACCENT : RGB565(170, 255, 190), TFT_BLACK);
      tft.drawString(l.substring(0, 53), 2, 30 + (i - first) * 12, 1);
    }
  };
  auto buttons = [&]() {
    static const char *Q[4] = {"Hi!", "OK", "PING", "On my way"};
    for (int i = 0; i < 4; ++i) ui::button(2 + i * 80, 172, 76, 30, Q[i], C_PANEL2, C_TEXT, 2);
    ui::button(2, 206, 156, 30, "TYPE MESSAGE", RGB565(0, 110, 160));
    ui::button(162, 206, 156, 30, (String("NICK: ") + nick).c_str(), C_PANEL2, C_TEXT, 1);
  };
  auto sendMsg = [&](const String &txt) {
    Msg m = {}; memcpy(m.magic, "KRV1", 4); strncpy(m.nick, nick.c_str(), 11); strncpy(m.text, txt.c_str(), 179);
    esp_err_t e = esp_now_send(peer.peer_addr, (uint8_t *)&m, 16 + strlen(m.text) + 1);
    log.push_back("> " + txt + (e == ESP_OK ? "" : " (fail)"));
    if (log.size() > 40) log.erase(log.begin());
    drawLog(); audio::beep(1500, 25);
  };
  ui::clearBody();
  log.push_back(String("ESP-NOW ch ") + c.pInt("channel", 1) + "  MAC " + WiFi.macAddress());
  log.push_back("Broadcasting to all KRIVI boards in range.");
  drawLog(); buttons();
  while (c.loop()) {
    while (seen != s_inHead) {
      Msg &m = s_in[seen % 6]; seen++;
      log.push_back(String(m.nick) + ": " + m.text);
      if (log.size() > 40) log.erase(log.begin());
      drawLog(); audio::tone(0, 880, 80, audio::SINE, 120, 120);
      if (!strcmp(m.text, "PING")) sendMsg("PONG from " + nick);
    }
    Touch &t = *c.t;
    if (!t.tap) continue;
    static const char *Q[4] = {"Hi!", "OK", "PING", "On my way"};
    for (int i = 0; i < 4; ++i) if (ui::inRect(t.sx, t.sy, 2 + i * 80, 172, 76, 30)) sendMsg(Q[i]);
    if (ui::inRect(t.sx, t.sy, 2, 206, 156, 30)) {
      String msg;
      bool ok = ui::textInput(msg, "Message", 120);
      c.header(); ui::clearBody(); drawLog(); buttons();
      if (ok && msg.length()) sendMsg(msg);
    } else if (ui::inRect(t.sx, t.sy, 162, 206, 156, 30)) {
      String nn = nick;
      if (ui::textInput(nn, "Nickname", 11) && nn.length()) nick = nn;
      c.header(); ui::clearBody(); drawLog(); buttons();
    }
  }
  esp_now_unregister_recv_cb();
  esp_now_deinit();
}
