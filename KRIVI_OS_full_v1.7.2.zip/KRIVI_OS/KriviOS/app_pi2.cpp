// ============================================================================
//  Raspberry Pi apps (need tools/pi/krivi_bridge.py on the Pi)
//   68 Pi Shell Keyboard   69 SSH Action Shortcuts   70 htop Monitor   71 Pi Safe Shutdown
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  68  PI SHELL KEYBOARD  - type a command, stream the output back
// ============================================================================
void app_pishell(AppCtx &c) {
  std::vector<String> term;
  ui::Keyboard kb; kb.y0 = 150;
  String cmdline;
  bool running = false;
  const int TY = 44, TL = 8;
  auto drawTerm = [&]() {
    tft.fillRect(0, TY, 320, 100, TFT_BLACK);
    int first = max(0, (int)term.size() - TL);
    for (int i = first; i < (int)term.size(); ++i) {
      const String &s = term[i];
      tft.setTextColor(s.startsWith("$") ? C_ACCENT : s.startsWith("!") ? C_ERR : RGB565(170, 255, 190), TFT_BLACK);
      tft.drawString(s.substring(0, 53), 2, TY + 2 + (i - first) * 12, 1);
    }
  };
  auto prompt = [&]() { tft.fillRect(0, 28, 320, 15, C_PANEL); tft.setTextColor(C_TEXT, C_PANEL);
    tft.drawString(("$ " + cmdline).substring(0, 52), 4, 30, 2); };
  auto addLine = [&](const String &s) { term.push_back(s); if (term.size() > 60) term.erase(term.begin()); drawTerm(); };
  ui::clearBody(); kb.draw(); prompt();
  addLine("Type a command and press ENTER. Runs on the Pi via krivi_bridge.py.");
  while (c.loop()) {
    String l;
    while (pilink::readLine(l)) {
      if (l.startsWith("@OUT ")) addLine(l.substring(5));
      else if (l.startsWith("@EXIT ")) { running = false; addLine("! exit " + l.substring(6)); }
      else if (l.startsWith("@ERR ")) { running = false; addLine("! " + l.substring(5)); }
    }
    Touch &t = *c.t;
    if (!t.pressed) continue;
    if (t.y < kb.y0) continue;
    int k = kb.hit(t.x, t.y);
    if (!k) continue;
    if (k == ui::Keyboard::K_ENTER) {
      if (cmdline.length() && !running) { addLine("$ " + cmdline); pilink::send("CMD %s", cmdline.c_str()); running = true; cmdline = ""; prompt(); }
    } else if (k == ui::Keyboard::K_BKSP) { if (cmdline.length()) { cmdline.remove(cmdline.length() - 1); prompt(); } }
    else if (k >= 32) { if (cmdline.length() < 80) { cmdline += (char)k; prompt(); } }
  }
  if (running) pilink::send("KILL");
}

// ============================================================================
//  69  SSH ACTION SHORTCUTS  - one-tap remote commands
// ============================================================================
// ============================================================================
//  70  HTOP LIVE MONITOR
// ============================================================================
// ============================================================================
//  71  PI SAFE SHUTDOWN
// ============================================================================
void app_pishutdown(AppCtx &c) {
  ui::clearBody();
  ui::centerText("Raspberry Pi Power", 160, 44, C_DIM, C_BG, 2);
  ui::button(40, 70, 240, 54, "SHUT DOWN PI", RGB565(180, 40, 40), TFT_WHITE, 4);
  ui::button(40, 134, 240, 48, "REBOOT PI", RGB565(180, 120, 0), TFT_WHITE, 4);
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString("Sends a graceful command over USB (needs sudo in", 10, 196, 1);
  tft.drawString("the Pi's sudoers; see krivi_bridge notes).", 10, 208, 1);
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 40, 70, 240, 54)) {
      if (ui::confirm("SHUT DOWN", "Gracefully power off the connected Pi now?")) {
        pilink::send("POWER shutdown"); c.header(); ui::clearBody(); ui::toast("shutdown command sent", C_OK); delay(1500);
      } else { c.header(); ui::clearBody(); ui::centerText("Raspberry Pi Power", 160, 44, C_DIM, C_BG, 2);
        ui::button(40, 70, 240, 54, "SHUT DOWN PI", RGB565(180, 40, 40), TFT_WHITE, 4); ui::button(40, 134, 240, 48, "REBOOT PI", RGB565(180, 120, 0), TFT_WHITE, 4); }
    } else if (ui::inRect(t.sx, t.sy, 40, 134, 240, 48)) {
      if (ui::confirm("REBOOT", "Reboot the connected Pi now?")) { pilink::send("POWER reboot"); c.header(); ui::clearBody(); ui::toast("reboot command sent", C_OK); delay(1500); }
      else { c.header(); ui::clearBody(); ui::centerText("Raspberry Pi Power", 160, 44, C_DIM, C_BG, 2);
        ui::button(40, 70, 240, 54, "SHUT DOWN PI", RGB565(180, 40, 40), TFT_WHITE, 4); ui::button(40, 134, 240, 48, "REBOOT PI", RGB565(180, 120, 0), TFT_WHITE, 4); }
    }
  }
}
