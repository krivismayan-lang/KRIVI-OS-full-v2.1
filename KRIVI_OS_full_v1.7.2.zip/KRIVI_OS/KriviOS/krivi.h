// ============================================================================
//  KRIVI OS - shared kernel API
//  Every app includes this single header.
// ============================================================================
#pragma once
#include <Arduino.h>
#include <TFT_eSPI.h>
#include <SD.h>
#include <FS.h>
#include <ArduinoJson.h>
#include <vector>

#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
#error "KRIVI OS needs the esp32 Arduino core 2.0.x (Boards Manager -> esp32 by Espressif -> 2.0.17). Core 3.x removed the built-in-DAC I2S audio mode."
#endif

#ifndef KRIVI_PANEL_NAME
#if defined(ST7789_DRIVER)
#define KRIVI_PANEL_NAME "ST7789"
#else
#define KRIVI_PANEL_NAME "ILI9341"
#endif
#endif
#define KRIVI_VERSION "1.7.2-arcade"

// ----------------------------------------------------------------------------
//  CYD (ESP32-2432S028) pin map
// ----------------------------------------------------------------------------
#define PIN_SD_CS    5
#define PIN_SD_SCK   18
#define PIN_SD_MISO  19
#define PIN_SD_MOSI  23

#define PIN_TP_CLK   25
#define PIN_TP_MOSI  32
#define PIN_TP_MISO  39
#define PIN_TP_CS    33
#define PIN_TP_IRQ   36

#define PIN_SPEAKER  26   // DAC2 -> on-board SC8002B amp (SPEAK connector)
#define PIN_MIC      35   // P3 connector, ADC1_CH7 (input only)
#define PIN_LDR      34
#define PIN_RELAY    22   // CN1 / P3 - used as latch / relay output
#define PIN_LED_R    4    // RGB LED, active LOW
#define PIN_LED_G    16
#define PIN_LED_B    17

// ----------------------------------------------------------------------------
//  Screen geometry (landscape, locked)
// ----------------------------------------------------------------------------
#define SCR_W   320
#define SCR_H   240
#define HDR_H   26          // app header bar height
#define EXIT_X0 260         // global exit box  (spec: X 260..315, Y 4..22)
#define EXIT_X1 315
#define EXIT_Y0 4
#define EXIT_Y1 22

// Palette helpers
#define RGB565(r,g,b) ((uint16_t)((((r)&0xF8)<<8)|(((g)&0xFC)<<3)|((b)>>3)))
#define C_BG        RGB565(8,10,18)
#define C_PANEL     RGB565(24,28,44)
#define C_PANEL2    RGB565(40,46,70)
#define C_TEXT      RGB565(230,235,245)
#define C_DIM       RGB565(120,130,155)
#define C_ACCENT    RGB565(0,200,255)
#define C_OK        RGB565(40,220,110)
#define C_WARN      RGB565(255,190,0)
#define C_ERR       RGB565(255,60,60)
#define C_EXIT      RGB565(200,30,50)

extern TFT_eSPI tft;

// ----------------------------------------------------------------------------
//  Touch input  (bit-banged XPT2046 so the SD card keeps the VSPI bus)
// ----------------------------------------------------------------------------
struct Touch {
  bool     down = false;      // finger currently on glass
  bool     pressed = false;   // went down since last frame
  bool     released = false;  // went up since last frame
  bool     tap = false;       // released with small travel & short time
  int8_t   swipe = 0;         // on release: 0 none, 1 up, 2 right, 3 down, 4 left
  int16_t  x = 0, y = 0;      // current / last position (screen px)
  int16_t  sx = 0, sy = 0;    // gesture start
  uint32_t t0 = 0;            // gesture start ms
  int16_t  rawX = 0, rawY = 0, rawZ = 0;
  uint32_t held() const { return down ? millis() - t0 : 0; }
};
enum { SW_NONE = 0, SW_UP, SW_RIGHT, SW_DOWN, SW_LEFT };

namespace touch {
  void begin();
  bool readRaw(int16_t &x, int16_t &y, int16_t &z);   // raw 12-bit values
  bool read(int16_t &sx, int16_t &sy);                // calibrated screen coords
  bool present();                                     // controller answered
}

// ----------------------------------------------------------------------------
//  Audio engine  (I2S0 -> built-in DAC2 / GPIO26, DMA, 8 voices + hook)
// ----------------------------------------------------------------------------
namespace audio {
  enum Wave : uint8_t { SQUARE = 0, SINE, TRIANGLE, SAW, NOISE };
  constexpr uint32_t RATE = 22050;
  constexpr uint8_t  VOICES = 8;
  bool begin();
  void tone(uint8_t v, float hz, uint8_t vol = 90, Wave w = SQUARE,
            uint32_t ms = 0, uint16_t decayMs = 0);
  void setFreq(uint8_t v, float hz);
  void sample(uint8_t v, const int8_t *data, uint32_t len, uint32_t rate,
              uint8_t vol = 110, bool loop = false);
  void stop(uint8_t v);
  void stopAll();
  bool active(uint8_t v);
  void beep(float hz = 1800, uint32_t ms = 40, uint8_t vol = 70);
  void click();
  void setMaster(uint8_t vol);     // 0..255
  uint8_t master();
  // Optional extra source mixed into the bus (used by the .mod tracker).
  // fn fills `n` signed samples in range about -128..127 * 4.
  typedef void (*Hook)(int32_t *buf, int n, void *user);
  void setHook(Hook fn, void *user);
  bool ok();
  // PCM stream for the MP3 / movie players: mono int16 at any source rate,
  // resampled to the 22.05 kHz bus. streamWrite blocks while the ring is full.
  bool     streamBegin(uint32_t sourceRate, uint32_t ringSamples = 8192);
  void     streamSetRate(uint32_t sourceRate);
  size_t   streamWrite(const int16_t *samples, size_t n);
  size_t   streamSpace();
  size_t   streamQueued();
  uint32_t streamPlayed();        // source samples consumed since begin
  void     streamPause(bool p);
  void     streamFlush();
  void     streamVolume(uint8_t v);
  void     streamEnd();
}

// ----------------------------------------------------------------------------
//  System services
// ----------------------------------------------------------------------------
namespace sys {
  extern JsonDocument cfg;        // /sys/settings.json
  extern bool sdOk;
  extern uint64_t sdSizeMB;
  bool loadSettings();
  bool saveSettings();
  void log(const char *fmt, ...);
  void tick();                    // background services (alarm, NTP, clap)
  // time
  bool timeValid();
  bool now(struct tm &t);
  void setClock(int y, int mo, int d, int h, int mi, int s);
  void startNtp();                // non-blocking
  const char *ntpState();
  // alarm (owned by app 26, rings anywhere)
  struct Alarm { bool enabled; uint8_t h, m; bool ringing; uint8_t lastDay; };
  extern Alarm alarm;
  // clap latch (owned by app 14, can run in background)
  extern volatile bool clapLatch;
  extern bool clapBackground;
  extern int  clapThreshold;
  void setLatch(bool on);
  // rgb led helpers (active low)
  void led(uint8_t r, uint8_t g, uint8_t b);
  // radio housekeeping
  void radiosOff();
  bool wifiConnect(uint32_t timeoutMs = 8000, bool showUi = true);
  // file helpers
  std::vector<String> listDir(const char *dir, const char *ext = nullptr,
                              bool dirsToo = false);
  String humanSize(uint64_t b);

  // --- SD card as a RAM helper -------------------------------------------
  // A large block of bytes kept in a temp file on the SD card instead of in
  // RAM, with random-access get/put. Costs almost no heap. Worth it only for
  // data an app touches in blocks (a staged frame, a captured buffer), not for
  // something read per-pixel every frame - the SD card is far slower than RAM.
  struct SwapBuf {
    File     f;
    uint32_t size = 0;
    bool     ok   = false;
    bool open(uint32_t bytes, const char *name = "/sys/swap.bin");
    void put(uint32_t off, const void *src, uint32_t n);
    void get(uint32_t off, void *dst, uint32_t n);
    void close();
  };
  // malloc that retries once after a short yield, so a passing fragmentation
  // blip does not turn into a spurious "Not enough RAM". nullptr only if the
  // request genuinely cannot be met.
  void *bigAlloc(uint32_t bytes);
}

// ----------------------------------------------------------------------------
//  UI toolkit
// ----------------------------------------------------------------------------
namespace ui {
  Touch &poll();                        // read touch, update events, run sys::tick
  Touch &state();
  void   clearEvents();
  bool   inRect(int x, int y, int rx, int ry, int rw, int rh);
  bool   hit(const Touch &t, int rx, int ry, int rw, int rh);   // pressed inside
  bool   tapIn(const Touch &t, int rx, int ry, int rw, int rh); // tap inside
  bool   exitHit(const Touch &t);
  void   header(const char *title, uint16_t accent, const char *sub = nullptr);
  void   redrawHeader();
  void   exitBox();
  void   button(int x, int y, int w, int h, const char *label,
                uint16_t bg = C_PANEL2, uint16_t fg = C_TEXT, uint8_t font = 2);
  void   centerText(const char *s, int cx, int cy, uint16_t fg, uint16_t bg,
                    uint8_t font = 2);
  void   bar(int x, int y, int w, int h, float frac, uint16_t fg, uint16_t bg);
  void   toast(const char *msg, uint16_t color = C_ACCENT);
  void   msgBox(const char *title, const char *msg);  // blocking until tap
  bool   confirm(const char *title, const char *msg);
  String pickFile(const char *dir, const char *ext, const char *title,
                  bool allowDirs = false);            // "" on exit
  bool   textInput(String &text, const char *prompt, int maxLen = 64,
                   bool password = false);            // full screen keyboard
  uint16_t hsv(uint16_t h, uint8_t s, uint8_t v);     // h 0..359
  void   clearBody(uint16_t c = C_BG);

  // Reusable on-screen keyboard (4 rows) - used by editor/textInput/ESP-NOW
  struct Keyboard {
    int y0 = 128;          // top of keyboard
    bool shift = false, sym = false;
    void draw();
    // returns char, or codes below, or 0 if nothing hit
    int  hit(int x, int y);
    static constexpr int K_BKSP = 8, K_ENTER = 13, K_SHIFT = 1, K_SYM = 2,
                         K_LEFT = 3, K_RIGHT = 4, K_DONE = 5;
  };
}

// ----------------------------------------------------------------------------
//  App framework
// ----------------------------------------------------------------------------
struct AppCtx;
typedef void (*AppFn)(AppCtx &);

struct AppDef {
  uint8_t     id;          // 1..43
  uint8_t     page;        // 0..4
  const char *name;        // full name
  const char *label;       // icon caption (<= 15 chars)
  const char *abbr;        // fallback glyph text
  uint16_t    color;       // tile colour
  AppFn       fn;
  const char *needs;       // required hardware / files
  const char *help;        // how to use (shown by the manual)
};

struct AppCtx {
  const AppDef *def = nullptr;
  JsonObject    params;           // "params" from /sys/apps/app_NN.json
  Touch        *t = nullptr;
  bool          exitReq = false;
  // poll once; false when the global exit box was hit
  bool loop();
  // poll repeatedly until `ms` since the previous frame elapsed;
  // touch events are latched across the wait. false on exit.
  bool frame(uint32_t ms);
  void header(const char *sub = nullptr);
  uint32_t lastFrame = 0;
  // parameter helpers (fall back to defaults when the SD manifest lacks them)
  int    pInt(const char *k, int d) const;
  float  pFloat(const char *k, float d) const;
  String pStr(const char *k, const char *d) const;
};

namespace launcher {
  extern const AppDef APPS[];
  extern const int APP_COUNT;
  extern const char *PAGE_TITLES[6];
  void begin();
  void run();               // never returns
  const AppDef *find(uint8_t id);
}

namespace loader {
  // Pages an app's manifest + assets in from SD, budgets heap, runs it,
  // then reclaims memory. Returns false if the launch was aborted.
  bool launch(const AppDef &a);
  bool flashBinary(const char *path);   // external .bin -> ota_1, reboot
}

void boot_sequence();

// ----------------------------------------------------------------------------
//  App entry points
// ----------------------------------------------------------------------------
// Page 1
void app_arcade(AppCtx &);
void app_nes(AppCtx &);      void app_snake(AppCtx &);   void app_tetris(AppCtx &);
void app_pong(AppCtx &);         void app_flappy(AppCtx &);
void app_mines(AppCtx &);    void app_breakout(AppCtx &);void app_board(AppCtx &);
// Page 2
void app_piano(AppCtx &);    void app_scope(AppCtx &);   void app_vu(AppCtx &);
      
void app_drumpad(AppCtx &);
// Page 3
void app_stopwatch(AppCtx &);void app_pomodoro(AppCtx &);void app_calc(AppCtx &);
void app_calendar(AppCtx &); void app_editor(AppCtx &);  void app_hexview(AppCtx &);
void app_dice(AppCtx &);        void app_alarm(AppCtx &);
// Page 4
void app_pimon(AppCtx &);    void app_piconsole(AppCtx &);void app_pitrackpad(AppCtx &);
void app_blemacro(AppCtx &); void app_blekbd(AppCtx &);  void app_wifiscan(AppCtx &);
void app_ping(AppCtx &);     void app_espnow(AppCtx &);
// Page 5
void app_paint(AppCtx &);    void app_warp(AppCtx &);    void app_sand(AppCtx &);
     void app_mandel(AppCtx &);  void app_video(AppCtx &);
void app_pet(AppCtx &);      void app_touchdiag(AppCtx &);void app_manual(AppCtx &);
// Media (added)
void app_mp3(AppCtx &);
// Page 6: Wireless Lab (passive diagnostics)
void app_chanmon(AppCtx &);  void app_blescan(AppCtx &);  void app_sigmap(AppCtx &);
void app_landisc(AppCtx &);  void app_nethealth(AppCtx &);
void app_weather(AppCtx &);
void app_iss(AppCtx &);
// New apps (push the CYD)
 
void app_spectrum(AppCtx &);   
void app_demofx(AppCtx &);
void app_chip8(AppCtx &);


void app_morse(AppCtx &);
void app_pitch(AppCtx &);
void app_ultrasonic(AppCtx &);
void app_worldclock(AppCtx &);
void app_currency(AppCtx &);
void app_units(AppCtx &);
void app_pishell(AppCtx &);


void app_pishutdown(AppCtx &);
void app_matrix(AppCtx &);
void app_starfield(AppCtx &);
void app_settings(AppCtx &);
void app_nvsedit(AppCtx &);
void app_deskclock(AppCtx &);
void app_noiselog(AppCtx &);

// Shared helpers between apps
namespace pilink {           // USB-serial protocol to the Raspberry Pi bridge
  void send(const char *fmt, ...);
  bool readLine(String &out);   // non-blocking, complete line available
}
namespace blehid {           // NimBLE HID keyboard (apps 30, 31)
  bool begin(const char *name);
  void end();
  bool connected();
  void press(uint8_t mod, uint8_t key);   // press+release
  void typeText(const char *s);
  void consumer(uint16_t usage);          // media keys
  bool sendCombo(const char *combo);      // "CTRL+ALT+T", "F5", "text:hello"
}
