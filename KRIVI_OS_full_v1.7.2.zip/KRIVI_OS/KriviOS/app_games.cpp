// ============================================================================
//  Page 1 games: Snake, Tetris, Pong, Maze, Flappy, Minesweeper, Breakout
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  02  RETRO SNAKE  - continuous swipe tracking
// ============================================================================
void app_snake(AppCtx &c) {
  const int CS = 10, COLS = 32, ROWS = 21, OY = 28;
  const int MAXL = COLS * ROWS;
  int16_t *sx = (int16_t *)malloc(MAXL * 2), *sy = (int16_t *)malloc(MAXL * 2);
  if (!sx || !sy) { free(sx); free(sy); return; }
  int best = 0;
restart:
  ui::clearBody(RGB565(6, 14, 8));
  for (int x = 0; x < COLS; ++x) for (int y = 0; y < ROWS; ++y)
    if ((x + y) & 1) tft.fillRect(x * CS, OY + y * CS, CS, CS, RGB565(9, 20, 11));
  auto bgAt = [&](int x, int y) { return ((x + y) & 1) ? RGB565(9, 20, 11) : RGB565(6, 14, 8); };
  int len = 4, head = 3, dir = 1, nextDir = 1, score = 0;
  for (int i = 0; i < len; ++i) { sx[i] = 5 + i; sy[i] = 10; }
  int fx = 0, fy = 0;
  auto occupied = [&](int x, int y) {
    for (int i = 0; i < len; ++i) { int k = (head - i + MAXL) % MAXL; if (sx[k] == x && sy[k] == y) return true; }
    return false;
  };
  auto placeFood = [&]() {
    do { fx = rnd(COLS); fy = rnd(ROWS); } while (occupied(fx, fy));
    tft.fillRoundRect(fx * CS + 1, OY + fy * CS + 1, CS - 2, CS - 2, 3, C_ERR);
  };
  for (int i = 0; i < len; ++i) tft.fillRoundRect(sx[i] * CS, OY + sy[i] * CS, CS, CS, 2, C_OK);
  placeFood();
  hudf("SCORE %d", score);
  int ax = 0, ay = 0;
  uint32_t step = 140;
  const int DX[4] = {0, 1, 0, -1}, DY[4] = {-1, 0, 1, 0};
  while (true) {
    // swipe tracking on the fly: every 18 px of drag sets a new heading
    uint32_t t0 = millis();
    while (millis() - t0 < step) {
      if (!c.loop()) goto done;
      Touch &t = *c.t;
      if (t.pressed) { ax = t.x; ay = t.y; }
      if (t.down) {
        int dx = t.x - ax, dy = t.y - ay;
        if (max(abs(dx), abs(dy)) > 18) {
          int nd = abs(dx) > abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
          if ((nd + 2) % 4 != dir) nextDir = nd;
          ax = t.x; ay = t.y;
        }
      }
    }
    dir = nextDir;
    int nx = sx[head] + DX[dir], ny = sy[head] + DY[dir];
    bool grow = (nx == fx && ny == fy);
    if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS || (occupied(nx, ny) &&
        !(sx[(head - len + 1 + MAXL) % MAXL] == nx && sy[(head - len + 1 + MAXL) % MAXL] == ny && !grow))) {
      audio::tone(0, 140, 110, audio::SAW, 400, 400);
      best = max(best, score);
      char s[32]; snprintf(s, sizeof(s), "score %d  best %d", score, best);
      banner("GAME OVER", s, C_ERR);
      if (!waitTap(c)) goto done;
      goto restart;
    }
    if (!grow) {
      int tail = (head - len + 1 + MAXL) % MAXL;
      tft.fillRect(sx[tail] * CS, OY + sy[tail] * CS, CS, CS, bgAt(sx[tail], sy[tail]));
    }
    tft.fillRoundRect(sx[head] * CS, OY + sy[head] * CS, CS, CS, 2, C_OK);
    head = (head + 1) % MAXL;
    sx[head] = nx; sy[head] = ny;
    tft.fillRoundRect(nx * CS, OY + ny * CS, CS, CS, 2, RGB565(170, 255, 120));
    if (grow) {
      len++; score++;
      audio::tone(0, 880 + score * 20, 80, audio::SQUARE, 40);
      hudf("SCORE %d", score);
      if (score % 5 == 0 && step > 60) step -= 12;
      placeFood();
    }
  }
done:
  free(sx); free(sy);
}

// ============================================================================
//  03  TETRIS MATRIX
// ============================================================================
static const uint16_t TET_SHAPES[7][4] = {   // 4x4 bitmasks per rotation
  {0x0F00, 0x2222, 0x00F0, 0x4444},  // I
  {0x8E00, 0x6440, 0x0E20, 0x44C0},  // J
  {0x2E00, 0x4460, 0x0E80, 0xC440},  // L
  {0x6600, 0x6600, 0x6600, 0x6600},  // O
  {0x6C00, 0x4620, 0x06C0, 0x8C40},  // S
  {0x4E00, 0x4640, 0x0E40, 0x4C40},  // T
  {0xC600, 0x2640, 0x0C60, 0x4C80},  // Z
};
static const uint16_t TET_COL[8] = {C_BG, RGB565(0, 230, 255), RGB565(40, 90, 255), RGB565(255, 150, 0),
                                    RGB565(255, 230, 0), RGB565(40, 230, 60), RGB565(190, 60, 255), RGB565(255, 40, 60)};

void app_tetris(AppCtx &c) {
  const int W = 10, H = 20, CS = 10, BX = 108, BY = 30;
  uint8_t board[H][W], shown[H][W];
  int best = 0;
restart:
  memset(board, 0, sizeof(board));
  memset(shown, 0xFF, sizeof(shown));
  ui::clearBody();
  tft.drawRect(BX - 2, BY - 2, W * CS + 4, H * CS + 4, C_DIM);
  // controls
  ui::button(222, 30, 94, 38, "ROTATE", C_PANEL2);
  ui::button(222, 74, 45, 44, "<", C_PANEL2, C_TEXT, 4);
  ui::button(271, 74, 45, 44, ">", C_PANEL2, C_TEXT, 4);
  ui::button(222, 124, 94, 44, "DOWN", C_PANEL2);
  ui::button(222, 174, 94, 58, "DROP", RGB565(120, 30, 60));
  int score = 0, lines = 0, level = 1;
  int cur = rnd(7), nxt = rnd(7), rot = 0, px = 3, py = 0;
  auto cell = [&](int p, int r, int i, int j) { return (TET_SHAPES[p][r] >> (15 - (i * 4 + j))) & 1; };
  auto fits = [&](int p, int r, int x, int y) {
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (cell(p, r, i, j)) {
      int bx = x + j, by = y + i;
      if (bx < 0 || bx >= W || by >= H) return false;
      if (by >= 0 && board[by][bx]) return false;
    }
    return true;
  };
  auto drawSide = [&]() {
    tft.fillRect(4, 30, 98, 200, C_BG);
    tft.setTextColor(C_DIM, C_BG);
    tft.drawString("NEXT", 8, 32, 2);
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j)
      if (cell(nxt, 0, i, j)) tft.fillRect(18 + j * 12, 54 + i * 12, 11, 11, TET_COL[nxt + 1]);
    char b[24];
    tft.setTextColor(C_DIM, C_BG); tft.drawString("SCORE", 8, 110, 2);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%d", score); tft.drawString(b, 8, 126, 4);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("LINES", 8, 156, 2);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%d", lines); tft.drawString(b, 8, 172, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("LEVEL", 8, 194, 2);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%d", level); tft.drawString(b, 8, 210, 2);
  };
  auto render = [&]() {
    uint8_t frame[H][W];
    memcpy(frame, board, sizeof(frame));
    int gy = py; while (fits(cur, rot, px, gy + 1)) gy++;          // ghost
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (cell(cur, rot, i, j)) {
      if (gy + i >= 0 && !frame[gy + i][px + j]) frame[gy + i][px + j] = 9;
    }
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (cell(cur, rot, i, j) && py + i >= 0)
      frame[py + i][px + j] = cur + 1;
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) if (frame[y][x] != shown[y][x]) {
      uint8_t v = frame[y][x];
      int X = BX + x * CS, Y = BY + y * CS;
      if (v == 0) tft.fillRect(X, Y, CS, CS, C_BG);
      else if (v == 9) { tft.fillRect(X, Y, CS, CS, C_BG); tft.drawRect(X + 1, Y + 1, CS - 2, CS - 2, C_PANEL2); }
      else { tft.fillRect(X, Y, CS - 1, CS - 1, TET_COL[v]); tft.drawFastHLine(X, Y, CS - 1, TFT_WHITE); }
      shown[y][x] = v;
    }
  };
  drawSide();
  uint32_t lastFall = millis(), repT = 0;
  int heldBtn = -1;
  while (true) {
    if (!c.frame(16)) return;
    Touch &t = *c.t;
    int btn = -1;
    if (t.down) {
      if (ui::inRect(t.x, t.y, 222, 30, 94, 38)) btn = 0;
      else if (ui::inRect(t.x, t.y, 222, 74, 45, 44)) btn = 1;
      else if (ui::inRect(t.x, t.y, 271, 74, 45, 44)) btn = 2;
      else if (ui::inRect(t.x, t.y, 222, 124, 94, 44)) btn = 3;
      else if (ui::inRect(t.x, t.y, 222, 174, 94, 58)) btn = 4;
      else if (t.x < 222) btn = 0;               // tap the board to rotate too
    }
    bool fire = false;
    if (btn != heldBtn) { heldBtn = btn; fire = btn >= 0; repT = millis() + 220; }
    else if (btn >= 1 && btn <= 3 && millis() > repT) { fire = true; repT = millis() + 70; }
    if (fire) {
      if (btn == 0) {
        int nr = (rot + 1) % 4;
        if (fits(cur, nr, px, py)) rot = nr; else if (fits(cur, nr, px - 1, py)) { rot = nr; px--; }
        else if (fits(cur, nr, px + 1, py)) { rot = nr; px++; }
        audio::tone(0, 660, 50, audio::SQUARE, 20);
      } else if (btn == 1 && fits(cur, rot, px - 1, py)) px--;
      else if (btn == 2 && fits(cur, rot, px + 1, py)) px++;
      else if (btn == 3 && fits(cur, rot, px, py + 1)) { py++; score++; }
      else if (btn == 4) { while (fits(cur, rot, px, py + 1)) { py++; score += 2; } lastFall = 0; }
    }
    uint32_t fallMs = max(80, 700 - (level - 1) * 60);
    if (millis() - lastFall > fallMs) {
      lastFall = millis();
      if (fits(cur, rot, px, py + 1)) py++;
      else {
        bool over = false;
        for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (cell(cur, rot, i, j)) {
          if (py + i < 0) over = true; else board[py + i][px + j] = cur + 1;
        }
        int cleared = 0;
        for (int y = H - 1; y >= 0; --y) {
          bool full = true; for (int x = 0; x < W; ++x) if (!board[y][x]) full = false;
          if (full) { cleared++; for (int yy = y; yy > 0; --yy) memcpy(board[yy], board[yy - 1], W); memset(board[0], 0, W); y++; }
        }
        static const int pts[5] = {0, 100, 300, 500, 800};
        if (cleared) {
          score += pts[cleared] * level; lines += cleared; level = 1 + lines / 10;
          audio::tone(1, 523 * cleared, 90, audio::TRIANGLE, 160, 160);
        } else audio::tone(1, 200, 60, audio::SQUARE, 25);
        cur = nxt; nxt = rnd(7); rot = 0; px = 3; py = -1;
        drawSide();
        if (over || !fits(cur, rot, px, py)) {
          render();
          best = max(best, score);
          char s[32]; snprintf(s, sizeof(s), "score %d  best %d", score, best);
          audio::tone(0, 110, 110, audio::SAW, 600, 600);
          banner("GAME OVER", s, C_ERR);
          if (!waitTap(c)) return;
          goto restart;
        }
      }
    }
    render();
  }
}

// ============================================================================
//  04  PONG vs AI
// ============================================================================
void app_pong(AppCtx &c) {
  const int TOP = 28, BOT = 238, PH = 40, PW = 6;
  float bx, by, vx, vy;
  float py = 110, ay = 110;
  int ps = 0, as = 0;
  int obx = -10, oby = -10, opy = -100, oay = -100;
  ui::clearBody();
  auto net = [&]() { for (int y = TOP; y < BOT; y += 12) tft.fillRect(159, y, 2, 6, C_PANEL2); };
  auto serve = [&](int dirn) {
    bx = 160; by = 130; float a = (rnd(60) - 30) * PI / 180.0f;
    vx = dirn * 3.2f * cosf(a); vy = 3.2f * sinf(a);
  };
  net(); serve(1);
  hudf("%d : %d", ps, as);
  uint32_t aiReact = 0; float aiTarget = 110;
  while (c.frame(16)) {
    Touch &t = *c.t;
    if (t.down && t.x < 200) py = constrain(t.y - PH / 2, TOP, BOT - PH);
    // AI: re-targets every 120 ms, limited speed
    if (millis() > aiReact) { aiReact = millis() + 120; aiTarget = vx > 0 ? by + rnd(30) - 15 : 130; }
    float d = aiTarget - (ay + PH / 2);
    ay += constrain(d, -2.6f, 2.6f);
    ay = constrain(ay, TOP, BOT - PH);
    bx += vx; by += vy;
    if (by < TOP + 2) { by = TOP + 2; vy = -vy; audio::beep(500, 15, 50); }
    if (by > BOT - 6) { by = BOT - 6; vy = -vy; audio::beep(500, 15, 50); }
    if (vx < 0 && bx <= 14 && bx >= 6 && by + 4 >= py && by <= py + PH) {
      float rel = ((by + 2) - (py + PH / 2)) / (PH / 2);
      float sp = min(7.5f, sqrtf(vx * vx + vy * vy) * 1.05f);
      vx = sp * cosf(rel * 1.0f); vy = sp * sinf(rel * 1.0f); bx = 15;
      audio::beep(880, 20, 70);
    }
    if (vx > 0 && bx >= 302 && bx <= 310 && by + 4 >= ay && by <= ay + PH) {
      float rel = ((by + 2) - (ay + PH / 2)) / (PH / 2);
      float sp = min(7.5f, sqrtf(vx * vx + vy * vy) * 1.05f);
      vx = -sp * cosf(rel * 1.0f); vy = sp * sinf(rel * 1.0f); bx = 301;
      audio::beep(660, 20, 70);
    }
    if (bx < -6 || bx > 326) {
      if (bx < 0) as++; else ps++;
      audio::tone(0, bx < 0 ? 200 : 1000, 90, audio::TRIANGLE, 250, 250);
      hudf("%d : %d", ps, as);
      tft.fillRect(obx, oby, 5, 5, C_BG);
      if (ps >= 7 || as >= 7) {
        banner(ps > as ? "YOU WIN" : "AI WINS", "tap to play again", ps > as ? C_OK : C_ERR);
        if (!waitTap(c)) return;
        ps = as = 0; ui::clearBody(); net(); hudf("%d : %d", ps, as); opy = oay = -100;
      }
      serve(bx < 0 ? 1 : -1);
      obx = oby = -10;
    }
    int ipy = (int)py, iay = (int)ay, ibx = (int)bx, iby = (int)by;
    if (ipy != opy) { tft.fillRect(8, TOP, PW, BOT - TOP, C_BG); tft.fillRoundRect(8, ipy, PW, PH, 2, C_ACCENT); opy = ipy; }
    if (iay != oay) { tft.fillRect(306, TOP, PW, BOT - TOP, C_BG); tft.fillRoundRect(306, iay, PW, PH, 2, C_ERR); oay = iay; }
    tft.fillRect(obx, oby, 5, 5, C_BG);
    if (abs(obx - 159) < 6) net();
    tft.fillRect(ibx, iby, 5, 5, TFT_WHITE);
    obx = ibx; oby = iby;
  }
}

// ============================================================================
//  05  MAZE RUNNER - randomized Prim's algorithm
// ============================================================================
// ============================================================================
//  06  FLAPPY PHYSICS SANDBOX  (8-bit sprite double buffer)
// ============================================================================
void app_flappy(AppCtx &c) {
  const int W = 320, H = 212, OY = 27, STRIP = 53, NS = H / STRIP;  // 4 strips of 320x53 (~17 KB)
  TFT_eSprite spr(&tft);
  spr.setColorDepth(8);
  if (!spr.createSprite(W, STRIP)) { ui::msgBox("FLAPPY", "Not enough RAM for frame buffer"); return; }
  int best = 0;
  while (true) {
    float y = 90, v = 0;
    const float G = 0.32f, THRUST = -5.2f;
    float pipeX[3]; int gapY[3]; bool scored[3];
    for (int i = 0; i < 3; ++i) { pipeX[i] = 340 + i * 120; gapY[i] = 40 + rnd(100); scored[i] = false; }
    int score = 0; bool started = false, dead = false;
    while (!dead) {
      if (!c.frame(20)) { spr.deleteSprite(); return; }
      if (c.t->pressed) { v = THRUST; started = true; audio::tone(0, 900, 50, audio::SQUARE, 40, 40); }
      if (started) {
        v += G; y += v;
        for (int i = 0; i < 3; ++i) {
          pipeX[i] -= 2.2f;
          if (pipeX[i] < -34) { pipeX[i] += 360; gapY[i] = 30 + rnd(110); scored[i] = false; }
          if (!scored[i] && pipeX[i] + 30 < 70) { scored[i] = true; score++; audio::tone(1, 1320, 60, audio::SQUARE, 60); }
          if (pipeX[i] < 80 && pipeX[i] + 30 > 60 && (y - 7 < gapY[i] || y + 7 > gapY[i] + 70)) dead = true;
        }
        if (y > H - 22 || y < 0) dead = true;
      } else y = 90 + 6 * sinf(millis() / 200.0f);
      int iy = (int)y;
      for (int sp = 0; sp < NS; ++sp) {
        int y0 = sp * STRIP;                              // first row of this strip (in play-area coords)
        spr.fillSprite(RGB565(80, 170, 230));
        for (int i = 0; i < 4; ++i) spr.fillCircle((int)(i * 100 - (millis() / 40) % 100), (H - 30) - y0, 30, RGB565(140, 210, 140));
        for (int i = 0; i < 3; ++i) {
          int px = (int)pipeX[i];
          spr.fillRect(px, 0 - y0, 30, gapY[i], RGB565(40, 180, 60));
          spr.fillRect(px - 3, gapY[i] - 10 - y0, 36, 10, RGB565(30, 150, 50));
          spr.fillRect(px, gapY[i] + 70 - y0, 30, H - gapY[i] - 70, RGB565(40, 180, 60));
          spr.fillRect(px - 3, gapY[i] + 70 - y0, 36, 10, RGB565(30, 150, 50));
        }
        spr.fillRect(0, (H - 16) - y0, W, 16, RGB565(210, 180, 100));
        spr.fillCircle(70, iy - y0, 8, RGB565(255, 220, 0));
        spr.fillCircle(74, iy - 3 - y0, 3, TFT_WHITE); spr.fillCircle(75, iy - 3 - y0, 1, TFT_BLACK);
        spr.fillTriangle(77, iy - y0, 84, iy + 2 - y0, 77, iy + 4 - y0, RGB565(255, 120, 0));
        spr.setTextColor(TFT_WHITE);
        spr.setTextDatum(TC_DATUM);
        spr.drawNumber(score, W / 2, 6 - y0, 4);
        if (!started) spr.drawString("TAP TO FLAP", W / 2, 140 - y0, 2);
        spr.setTextDatum(TL_DATUM);
        spr.pushSprite(0, OY + y0);
      }
    }
    audio::tone(0, 160, 110, audio::NOISE, 300, 300);
    best = max(best, score);
    char s[32]; snprintf(s, sizeof(s), "score %d  best %d", score, best);
    banner("CRASHED", s, C_ERR);
    delay(400);
    if (!waitTap(c)) { spr.deleteSprite(); return; }
  }
}

// ============================================================================
//  07  MINEFIELD SWEEPER
// ============================================================================
void app_mines(AppCtx &c) {
  const int GW = 16, GH = 10, CS = 19, OX = 8, OY = 29, MINES = 22;
  uint8_t mine[GH][GW], state[GH][GW], num[GH][GW];   // state: 0 hidden,1 open,2 flag
restart:
  memset(mine, 0, sizeof(mine)); memset(state, 0, sizeof(state));
  bool placed = false, flagMode = false, over = false;
  int opened = 0, flags = 0;
  uint32_t t0 = 0;
  static const uint16_t NC[9] = {C_TEXT, RGB565(80, 160, 255), RGB565(60, 200, 80), RGB565(255, 80, 80),
                                 RGB565(160, 80, 255), RGB565(200, 60, 40), RGB565(0, 200, 200), TFT_WHITE, C_DIM};
  ui::clearBody();
  auto drawCell = [&](int x, int y) {
    int X = OX + x * CS, Y = OY + y * CS;
    if (state[y][x] == 1) {
      tft.fillRect(X, Y, CS - 1, CS - 1, mine[y][x] ? C_ERR : RGB565(30, 34, 50));
      if (mine[y][x]) tft.fillCircle(X + 9, Y + 9, 5, TFT_BLACK);
      else if (num[y][x]) { tft.setTextColor(NC[num[y][x]], RGB565(30, 34, 50)); tft.setTextDatum(MC_DATUM);
        tft.drawNumber(num[y][x], X + 9, Y + 10, 2); tft.setTextDatum(TL_DATUM); }
    } else {
      tft.fillRect(X, Y, CS - 1, CS - 1, RGB565(70, 80, 110));
      tft.drawFastHLine(X, Y, CS - 1, RGB565(120, 130, 170)); tft.drawFastVLine(X, Y, CS - 1, RGB565(120, 130, 170));
      if (state[y][x] == 2) { tft.fillTriangle(X + 6, Y + 4, X + 14, Y + 8, X + 6, Y + 12, C_ERR); tft.drawFastVLine(X + 6, Y + 4, 11, TFT_WHITE); }
    }
  };
  auto bar = [&]() {
    ui::button(8, 222, 120, 17, flagMode ? "MODE: FLAG" : "MODE: DIG", flagMode ? RGB565(150, 40, 40) : C_PANEL2, C_TEXT, 1);
    ui::button(236, 222, 76, 17, "NEW", C_PANEL2, C_TEXT, 1);
    char s[24]; snprintf(s, sizeof(s), "MINES %d", MINES - flags);
    tft.fillRect(130, 222, 104, 17, C_BG); ui::centerText(s, 182, 231, C_WARN, C_BG, 1);
  };
  for (int y = 0; y < GH; ++y) for (int x = 0; x < GW; ++x) drawCell(x, y);
  bar();
  auto place = [&](int sx, int sy) {
    int n = 0;
    while (n < MINES) { int x = rnd(GW), y = rnd(GH);
      if (mine[y][x] || (abs(x - sx) <= 1 && abs(y - sy) <= 1)) continue; mine[y][x] = 1; n++; }
    for (int y = 0; y < GH; ++y) for (int x = 0; x < GW; ++x) {
      int k = 0; for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) {
        int nx = x + dx, ny = y + dy; if (nx >= 0 && ny >= 0 && nx < GW && ny < GH) k += mine[ny][nx]; }
      num[y][x] = k; }
    placed = true; t0 = millis();
  };
  auto reveal = [&](int sx, int sy) {
    int16_t stack[GW * GH]; int sp = 0; stack[sp++] = sy * GW + sx;
    while (sp) { int i = stack[--sp]; int x = i % GW, y = i / GW;
      if (state[y][x] != 0) continue; state[y][x] = 1; opened++; drawCell(x, y);
      if (num[y][x] == 0 && !mine[y][x]) for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) {
        int nx = x + dx, ny = y + dy; if (nx >= 0 && ny >= 0 && nx < GW && ny < GH && state[ny][nx] == 0 && sp < GW * GH) stack[sp++] = ny * GW + nx; } }
  };
  bool longDone = false;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.pressed) longDone = false;
    int gx = (t.x - OX) / CS, gy = (t.y - OY) / CS;
    bool inGrid = t.x >= OX && t.y >= OY && gx < GW && gy < GH;
    if (!over && t.down && !longDone && t.held() > 500 && inGrid && abs(t.x - t.sx) < 8 && abs(t.y - t.sy) < 8) {
      longDone = true;
      if (state[gy][gx] != 1) { state[gy][gx] = state[gy][gx] == 2 ? 0 : 2; flags += state[gy][gx] == 2 ? 1 : -1;
        drawCell(gx, gy); bar(); audio::beep(1500, 30); }
    }
    if (t.tap && !longDone) {
      if (ui::inRect(t.sx, t.sy, 8, 222, 120, 17)) { flagMode = !flagMode; bar(); continue; }
      if (ui::inRect(t.sx, t.sy, 236, 222, 76, 17)) goto restart;
      if (over) goto restart;
      gx = (t.sx - OX) / CS; gy = (t.sy - OY) / CS;
      if (t.sx < OX || t.sy < OY || gx >= GW || gy >= GH) continue;
      if (flagMode) {
        if (state[gy][gx] != 1) { state[gy][gx] = state[gy][gx] == 2 ? 0 : 2; flags += state[gy][gx] == 2 ? 1 : -1; drawCell(gx, gy); bar(); }
        continue;
      }
      if (state[gy][gx] != 0) continue;
      if (!placed) place(gx, gy);
      if (mine[gy][gx]) {
        for (int y = 0; y < GH; ++y) for (int x = 0; x < GW; ++x) if (mine[y][x]) { state[y][x] = 1; drawCell(x, y); }
        audio::tone(0, 90, 120, audio::NOISE, 600, 600);
        over = true; hud("BOOM!", C_ERR);
      } else {
        reveal(gx, gy); audio::click();
        if (opened == GW * GH - MINES) {
          over = true; audio::tone(0, 1046, 90, audio::TRIANGLE, 400, 400);
          char s[32]; snprintf(s, sizeof(s), "cleared in %lus", (millis() - t0) / 1000);
          banner("YOU WIN", s, C_OK);
        }
      }
    }
    static uint32_t lastT = 0;
    if (placed && !over && millis() - lastT > 1000) { lastT = millis(); hudf("%d s", (millis() - t0) / 1000); }
  }
}

// ============================================================================
//  08  BREAKOUT VECTOR
// ============================================================================
void app_breakout(AppCtx &c) {
  const int COLS = 10, ROWS = 6, BW = 30, BH = 10, BX0 = 6, BY0 = 40;
  const int PY = 224, PW = 52;
  uint8_t br[ROWS][COLS];
  int lives, score, level = 1;
  auto drawBrick = [&](int r, int k) {
    int x = BX0 + k * (BW + 1), y = BY0 + r * (BH + 2);
    if (br[r][k]) { uint16_t col = ui::hsv(r * 50, 220, 255); tft.fillRect(x, y, BW, BH, col); tft.drawFastHLine(x, y, BW, TFT_WHITE); }
    else tft.fillRect(x, y, BW, BH, C_BG);
  };
newGame:
  lives = 3; score = 0; level = 1;
newLevel:
  memset(br, 1, sizeof(br));
  ui::clearBody();
  for (int r = 0; r < ROWS; ++r) for (int k = 0; k < COLS; ++k) drawBrick(r, k);
  {
    float px = 134, bx = 160, by = PY - 6, vx = 0, vy = 0;
    bool launched = false; int left = ROWS * COLS;
    int opx = -100, obx = -10, oby = -10;
    char s[32]; snprintf(s, sizeof(s), "%d  L%d  \x03%d", score, level, lives); hud(s);
    while (c.frame(16)) {
      Touch &t = *c.t;
      if (t.down) px = constrain(t.x - PW / 2, 0, 320 - PW);
      if (!launched) { bx = px + PW / 2; by = PY - 6; if (t.tap) { launched = true; float a = (-60 - rnd(60)) * PI / 180; float sp = 3.6f + level * 0.3f; vx = sp * cosf(a); vy = sp * sinf(a); } }
      else {
        // sub-steps for robust collisions
        for (int s2 = 0; s2 < 2; ++s2) {
          bx += vx / 2; by += vy / 2;
          if (bx < 0) { bx = 0; vx = -vx; } if (bx > 316) { bx = 316; vx = -vx; }
          if (by < 28) { by = 28; vy = -vy; }
          int k = ((int)bx + 2 - BX0) / (BW + 1), r = ((int)by + 2 - BY0) / (BH + 2);
          if (by + 2 >= BY0 && r >= 0 && r < ROWS && k >= 0 && k < COLS && br[r][k]) {
            br[r][k] = 0; drawBrick(r, k); left--; score += 10 * (ROWS - r);
            vy = -vy; audio::tone(0, 400 + (ROWS - r) * 120, 70, audio::SQUARE, 30);
            snprintf(s, sizeof(s), "%d  L%d  \x03%d", score, level, lives); hud(s);
          }
          if (vy > 0 && by + 4 >= PY && by + 4 <= PY + 6 && bx + 4 >= px && bx <= px + PW) {
            float rel = ((bx + 2) - (px + PW / 2)) / (PW / 2);
            float sp = sqrtf(vx * vx + vy * vy);
            float a = -PI / 2 + rel * 1.1f;
            vx = sp * cosf(a); vy = sp * sinf(a); by = PY - 5;
            audio::beep(700, 15, 60);
          }
        }
        if (by > 240) {
          lives--; launched = false; audio::tone(0, 150, 110, audio::SAW, 300, 300);
          snprintf(s, sizeof(s), "%d  L%d  \x03%d", score, level, lives); hud(s);
          if (lives <= 0) { banner("GAME OVER", "tap to restart", C_ERR); if (!waitTap(c)) return; goto newGame; }
        }
        if (left == 0) { level++; banner("LEVEL CLEAR", "tap for next level", C_OK); if (!waitTap(c)) return; goto newLevel; }
      }
      int ipx = (int)px;
      if (ipx != opx) { tft.fillRect(0, PY, 320, 6, C_BG); tft.fillRoundRect(ipx, PY, PW, 6, 3, C_ACCENT); opx = ipx; }
      tft.fillRect(obx, oby, 5, 5, C_BG);
      obx = (int)bx; oby = (int)by;
      if (oby < PY - 4 || oby > PY + 6) tft.fillRect(obx, oby, 5, 5, TFT_WHITE);
      else { tft.fillRoundRect(ipx, PY, PW, 6, 3, C_ACCENT); tft.fillRect(obx, oby, 5, 5, TFT_WHITE); }
    }
  }
}
