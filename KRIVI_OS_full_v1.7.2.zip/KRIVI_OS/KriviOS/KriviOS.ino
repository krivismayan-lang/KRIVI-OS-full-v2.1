// ============================================================================
//  KRIVI OS - entry point
// ============================================================================
#include "krivi.h"

void setup() {
  Serial.begin(115200);
  pinMode(PIN_RELAY, OUTPUT);
  digitalWrite(PIN_RELAY, LOW);
  pinMode(PIN_LED_R, OUTPUT); pinMode(PIN_LED_G, OUTPUT); pinMode(PIN_LED_B, OUTPUT);
  digitalWrite(PIN_LED_R, HIGH); digitalWrite(PIN_LED_G, HIGH); digitalWrite(PIN_LED_B, HIGH);

  tft.init();
  tft.setRotation(1);                 // landscape 320x240, locked
  tft.fillScreen(TFT_BLACK);
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);

  randomSeed(esp_random());
  boot_sequence();
  launcher::begin();
}

void loop() {
  launcher::run();                    // never returns
}
                