// Small helpers shared by app files
#pragma once
#include "krivi.h"

// Text in the header bar between title and EXIT box (right-aligned at x=254)
inline void hud(const char *s, uint16_t c = C_TEXT) {
  tft.fillRect(150, 3, 106, 19, C_PANEL);
  tft.setTextColor(c, C_PANEL);
  tft.setTextDatum(MR_DATUM);
  tft.drawString(s, 254, 13, 2);
  tft.setTextDatum(TL_DATUM);
}
inline void hudf(const char *fmt, int a, int b = 0) {
  char s[32]; snprintf(s, sizeof(s), fmt, a, b); hud(s);
}
// Centred banner over the play-field ("GAME OVER - tap to retry")
inline void banner(const char *big, const char *small, uint16_t c = C_WARN) {
  tft.fillRoundRect(40, 90, 240, 70, 8, C_PANEL);
  tft.drawRoundRect(40, 90, 240, 70, 8, c);
  ui::centerText(big, 160, 112, c, C_PANEL, 4);
  ui::centerText(small, 160, 142, C_TEXT, C_PANEL, 2);
}
// Block until tap (true) or exit (false)
inline bool waitTap(AppCtx &c) {
  while (c.loop()) if (c.t->tap) return true;
  return false;
}
inline uint32_t rnd(uint32_t n) { return esp_random() % n; }
