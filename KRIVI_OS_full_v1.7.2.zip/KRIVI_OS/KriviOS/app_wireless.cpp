// ============================================================================
//  Page 6: WIRELESS LAB  - passive / defensive radio diagnostics
//  Original KRIVI implementations. These tools only LISTEN (to public Wi-Fi
//  management traffic and BLE advertisements) or probe the user's OWN network.
//  Nothing here transmits attack frames, injects packets, captures payloads,
//  logs the addresses of other people's devices, or impersonates a network.
//
//   45 Channel Congestion   monitor-mode frame COUNTS per channel (no contents)
//   46 BLE Scanner          lists public BLE advertisements nearby
//   47 Signal Mapper        live RSSI of one of YOUR APs, to find dead spots
//   48 LAN Discovery        pings YOUR subnet to inventory your own devices
//   49 Net Health           DNS / latency / jitter / loss to gateway + a host
//   50 Airtime Monitor      frames-per-second over time on one channel (counts)
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <esp_wifi.h>
#include <NimBLEDevice.h>
#include "ping/ping_sock.h"

// ============================================================================
//  Shared monitor-mode plumbing. The callback reads ONLY the radio metadata
//  (channel, signal strength) and the top-level frame category. It never looks
//  at addresses or payload, and keeps nothing but per-category counters.
// ============================================================================
namespace wmon {
static volatile uint32_t total, mgmt, data, ctrl;
static volatile uint32_t chCount[14];
static volatile int8_t   chRssi[14];
static volatile uint8_t  curCh = 1;
static bool running = false;

static void cb(void *buf, wifi_promiscuous_pkt_type_t type) {
  const wifi_promiscuous_pkt_t *p = (const wifi_promiscuous_pkt_t *)buf;
  int ch = p->rx_ctrl.channel;
  if (ch < 1 || ch > 13) ch = curCh;
  chCount[ch]++;
  int8_t r = p->rx_ctrl.rssi;
  if (r > chRssi[ch]) chRssi[ch] = r;
  total++;
  if (type == WIFI_PKT_MGMT) mgmt++;
  else if (type == WIFI_PKT_DATA) data++;
  else ctrl++;
}
static void begin() {
  memset((void *)chCount, 0, sizeof(chCount));
  for (auto &r : chRssi) r = -127;
  total = mgmt = data = ctrl = 0;
  WiFi.mode(WIFI_STA);                       // starts the driver (does not connect)
  esp_wifi_set_promiscuous(false);
  wifi_promiscuous_filter_t f = {};
  f.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA | WIFI_PROMIS_FILTER_MASK_CTRL;
  esp_wifi_set_promiscuous_filter(&f);
  esp_wifi_set_promiscuous_rx_cb(cb);
  esp_wifi_set_promiscuous(true);
  running = true;
}
static void channel(uint8_t ch) { curCh = ch; esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE); }
static void end() {
  if (!running) return;
  esp_wifi_set_promiscuous(false);
  esp_wifi_set_promiscuous_rx_cb(nullptr);
  running = false;
  sys::radiosOff();
}
}  // namespace wmon

// ============================================================================
//  Shared single-shot ICMP ping (used by LAN Discovery and Net Health)
// ============================================================================
namespace wping {
static volatile bool done;
static volatile int rtt;
static void okCb(esp_ping_handle_t h, void *) { uint32_t t; esp_ping_get_profile(h, ESP_PING_PROF_TIMEGAP, &t, sizeof(t)); rtt = (int)t; }
static void toCb(esp_ping_handle_t, void *) { rtt = -1; }
static void endCb(esp_ping_handle_t, void *) { done = true; }
static bool once(IPAddress ip, uint32_t timeoutMs, int &outRtt) {
  done = false; rtt = -1;
  esp_ping_config_t c = ESP_PING_DEFAULT_CONFIG();
  ip_addr_t a; IP_ADDR4(&a, ip[0], ip[1], ip[2], ip[3]);
  c.target_addr = a; c.count = 1; c.timeout_ms = timeoutMs; c.interval_ms = 10; c.data_size = 32;
  esp_ping_handle_t h;
  esp_ping_callbacks_t cb = {}; cb.on_ping_success = okCb; cb.on_ping_timeout = toCb; cb.on_ping_end = endCb;
  if (esp_ping_new_session(&c, &cb, &h) != ESP_OK) return false;
  esp_ping_start(h);
  uint32_t t0 = millis();
  while (!done && millis() - t0 < timeoutMs + 200) delay(4);
  esp_ping_stop(h); esp_ping_delete_session(h);
  outRtt = rtt;
  return rtt >= 0;
}
}  // namespace wping

// ============================================================================
//  45  CHANNEL CONGESTION  - hops 1..13, bar chart of frame counts per channel
// ============================================================================
void app_chanmon(AppCtx &c) {
  wmon::begin();
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString("Frames seen per channel (counts only, no contents). Lower = clearer.", 4, 214, 1);
  tft.drawString("2.4 GHz  -  hopping 1..13", 4, 226, 1);
  const int GX = 18, GY = 32, GW = 296, GH = 168, BW = GW / 13;
  uint32_t snap[14]; memset(snap, 0, sizeof(snap));
  int dwell = 140;
  while (true) {
    for (int ch = 1; ch <= 13; ++ch) {
      wmon::chCount[ch] = 0; wmon::chRssi[ch] = -127;
      wmon::channel(ch);
      uint32_t t0 = millis();
      while (millis() - t0 < (uint32_t)dwell) {
        if (!c.loop()) { wmon::end(); return; }
      }
      snap[ch] = wmon::chCount[ch];
      // redraw full chart after each hop
      uint32_t mx = 1; for (int i = 1; i <= 13; ++i) mx = max(mx, snap[i]);
      tft.fillRect(0, GY - 2, SCR_W, GH + 4, C_BG);
      for (int i = 1; i <= 13; ++i) {
        int x = GX + (i - 1) * BW;
        int h = (int)((uint64_t)snap[i] * (GH - 14) / mx);
        uint16_t col = i == ch ? C_WARN : ui::hsv(140 - snap[i] * 140 / mx, 220, 255);
        tft.fillRect(x + 2, GY + GH - h, BW - 4, h, col);
        tft.setTextColor(i == ch ? C_WARN : C_DIM, C_BG);
        tft.setTextDatum(TC_DATUM); tft.drawNumber(i, x + BW / 2, GY + GH + 2, 1);
        if (snap[i]) { char b[8]; snprintf(b, 8, "%lu", (unsigned long)snap[i]); tft.drawString(b, x + BW / 2, GY + GH - h - 10, 1); }
        tft.setTextDatum(TL_DATUM);
      }
      hudf("CH %d", ch);
    }
  }
}

// ============================================================================
//  46  BLE SCANNER  - passive list of nearby advertisements
// ============================================================================
namespace blesc {
struct Dev { String addr, name; int rssi; uint8_t type; uint16_t appear; uint32_t seen; };
static std::vector<Dev> devs;
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
class CB : public NimBLEAdvertisedDeviceCallbacks {
  void onResult(NimBLEAdvertisedDevice *d) override {
    String a = d->getAddress().toString().c_str();
    portENTER_CRITICAL(&mux);
    for (auto &e : devs) if (e.addr == a) {
      e.rssi = d->getRSSI(); e.seen = millis();
      if (e.name.length() == 0 && d->haveName()) e.name = d->getName().c_str();
      portEXIT_CRITICAL(&mux); return;
    }
    if (devs.size() < 40) {
      Dev e; e.addr = a; e.name = d->haveName() ? d->getName().c_str() : String("");
      e.rssi = d->getRSSI(); e.type = d->getAddressType();
      e.appear = d->haveAppearance() ? d->getAppearance() : 0; e.seen = millis();
      devs.push_back(e);
    }
    portEXIT_CRITICAL(&mux);
  }
};
static const char *appearName(uint16_t a) {
  switch (a >> 6) {                          // category (upper bits of the 16-bit appearance)
    case 1: return "phone"; case 2: return "computer"; case 3: return "watch";
    case 5: return "display"; case 7: return "clock"; case 10: return "tag";
    case 15: return "fitness"; case 17: return "media"; case 20: return "thermo";
    case 21: return "sensor"; case 25: return "gamepad"; case 61: return "earbuds";
    default: return a ? "device" : "";
  }
}
}  // namespace blesc

void app_blescan(AppCtx &c) {
  using namespace blesc;
  devs.clear();
  sys::radiosOff();
  ui::clearBody();
  ui::centerText("Starting Bluetooth scan...", 160, 120, C_DIM, C_BG, 2);
  NimBLEDevice::init("");
  NimBLEScan *scan = NimBLEDevice::getScan();
  scan->setAdvertisedDeviceCallbacks(new CB(), false);
  scan->setActiveScan(false);                // passive: receive public adverts only
  scan->setInterval(100); scan->setWindow(90);
  scan->start(0, nullptr, false);            // continuous, non-blocking
  ui::clearBody();
  int top = 0;
  const int RH = 23, Y0 = 30, ROWS = 7;
  uint32_t lastDraw = 0;
  auto draw = [&]() {
    std::vector<Dev> snap;
    portENTER_CRITICAL(&mux); snap = devs; portEXIT_CRITICAL(&mux);
    std::sort(snap.begin(), snap.end(), [](const Dev &a, const Dev &b) { return a.rssi > b.rssi; });
    tft.fillRect(0, Y0 - 2, SCR_W, ROWS * RH + 4, C_BG);
    for (int i = 0; i < ROWS && top + i < (int)snap.size(); ++i) {
      const Dev &d = snap[top + i];
      int y = Y0 + i * RH;
      tft.fillRoundRect(4, y, 312, RH - 3, 4, C_PANEL);
      int bars = constrain((d.rssi + 100) / 12, 0, 4);
      for (int b = 0; b < 4; ++b) tft.fillRect(8 + b * 5, y + 15 - b * 3, 4, 3 + b * 3, b < bars ? C_OK : RGB565(40, 46, 70));
      tft.setTextColor(C_TEXT, C_PANEL);
      String nm = d.name.length() ? d.name : String("(no name)");
      tft.drawString(nm.substring(0, 20), 34, y + 2, 2);
      tft.setTextColor(C_DIM, C_PANEL);
      char info[48]; snprintf(info, sizeof(info), "%s  %ddBm %s%s", d.addr.c_str(), d.rssi,
                              d.type == BLE_ADDR_RANDOM ? "rnd " : "pub ", appearName(d.appear));
      tft.drawString(info, 34, y + 15, 1);
    }
    char hb[16]; snprintf(hb, sizeof(hb), "%d found", (int)snap.size()); hud(hb, C_ACCENT);
    tft.fillRect(0, 214, SCR_W, 26, C_BG);
    ui::button(4, 214, 90, 24, "SCROLL", C_PANEL2, C_TEXT, 1);
    ui::button(228, 214, 88, 24, "CLEAR", C_PANEL2, C_TEXT, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("passive scan - public adverts only", 100, 221, 1);
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 4, 214, 90, 24)) { int n; portENTER_CRITICAL(&mux); n = devs.size(); portEXIT_CRITICAL(&mux);
        top += ROWS; if (top >= n) top = 0; draw(); }
      else if (ui::inRect(t.sx, t.sy, 228, 214, 88, 24)) { portENTER_CRITICAL(&mux); devs.clear(); portEXIT_CRITICAL(&mux); top = 0; draw(); }
    }
    if (t.swipe == SW_UP) { top += ROWS; draw(); }
    else if (t.swipe == SW_DOWN) { top = max(0, top - ROWS); draw(); }
    if (millis() - lastDraw > 800) { lastDraw = millis(); draw(); }
  }
  scan->stop();
  NimBLEDevice::deinit(true);
  devs.clear();
}

// ============================================================================
//  47  SIGNAL MAPPER  - live RSSI of one of YOUR access points
// ============================================================================
void app_sigmap(AppCtx &c) {
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  // --- pick a network from a scan
  ui::clearBody();
  ui::centerText("Scanning for networks...", 160, 120, C_WARN, C_BG, 2);
  int n = WiFi.scanNetworks(false, true);
  if (n <= 0) { ui::msgBox("SIGNAL MAPPER", "No networks found."); WiFi.scanDelete(); return; }
  uint8_t bssid[6]; String ssid; int channel = 1;
  {
    int idx[40]; int m = min(n, 40); for (int i = 0; i < m; ++i) idx[i] = i;
    std::sort(idx, idx + m, [](int a, int b) { return WiFi.RSSI(a) > WiFi.RSSI(b); });
    int top = 0, picked = -1;
    const int RH = 25, Y0 = 32, ROWS = 6;
    auto draw = [&]() {
      ui::clearBody();
      ui::centerText("Pick YOUR access point", 160, 28, C_DIM, C_BG, 1);
      for (int i = 0; i < ROWS && top + i < m; ++i) {
        int k = idx[top + i], y = Y0 + i * RH;
        tft.fillRoundRect(4, y, 312, RH - 3, 4, C_PANEL);
        String s = WiFi.SSID(k); if (!s.length()) s = "(hidden)";
        tft.setTextColor(C_TEXT, C_PANEL); tft.drawString(s.substring(0, 24), 10, y + 4, 2);
        char b[24]; snprintf(b, 24, "ch%d %ddBm", WiFi.channel(k), WiFi.RSSI(k));
        tft.setTextColor(C_DIM, C_PANEL); tft.setTextDatum(TR_DATUM); tft.drawString(b, 308, y + 6, 1); tft.setTextDatum(TL_DATUM);
      }
      ui::button(110, 206, 100, 30, top + ROWS < m ? "MORE" : "RESCAN", C_PANEL2);
    };
    draw();
    while (picked < 0) {
      if (!c.loop()) { WiFi.scanDelete(); return; }
      Touch &t = *c.t;
      if (t.tap) {
        if (ui::inRect(t.sx, t.sy, 110, 206, 100, 30)) { if (top + ROWS < m) top += ROWS; else top = 0; draw(); }
        else if (t.sy >= Y0 && t.sy < Y0 + ROWS * RH) { int i = top + (t.sy - Y0) / RH; if (i < m) picked = idx[i]; }
      }
    }
    memcpy(bssid, WiFi.BSSID(picked), 6); ssid = WiFi.SSID(picked); channel = WiFi.channel(picked);
    if (!ssid.length()) ssid = "(hidden)";
  }
  WiFi.scanDelete();

  // --- live meter
  struct Sample { char label[8]; int rssi; };
  std::vector<Sample> samples;
  int16_t hist[300]; int hp = 0; for (auto &h : hist) h = -100;
  c.header();
  ui::clearBody();
  tft.setTextColor(C_TEXT, C_BG); tft.drawString(ssid.substring(0, 24), 6, 30, 2);
  const int GX = 6, GY = 118, GW = 308, GH = 70;
  auto buttons = [&]() {
    ui::button(6, 200, 120, 36, "SAMPLE", C_OK, TFT_BLACK);
    ui::button(134, 200, 100, 36, "CLEAR", C_PANEL2);
  };
  tft.drawRect(GX - 1, GY - 1, GW + 2, GH + 2, C_PANEL2);
  buttons();
  int rssi = -100; uint32_t lastScan = 0;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 6, 200, 120, 36)) {
        Sample s; snprintf(s.label, 8, "P%d", (int)samples.size() + 1); s.rssi = rssi;
        if (samples.size() < 10) samples.push_back(s);
        audio::beep(1400, 40);
      } else if (ui::inRect(t.sx, t.sy, 134, 200, 100, 36)) samples.clear();
    }
    if (millis() - lastScan > 250) {
      lastScan = millis();
      int m = WiFi.scanNetworks(false, true, false, 110, channel);
      rssi = -127;
      for (int i = 0; i < m; ++i) if (!memcmp(WiFi.BSSID(i), bssid, 6)) { rssi = WiFi.RSSI(i); break; }
      WiFi.scanDelete();
      hist[hp] = rssi > -127 ? rssi : -100; hp = (hp + 1) % 300;
      // big meter
      tft.fillRect(0, 52, 320, 60, C_BG);
      int q = rssi <= -127 ? 0 : constrain((rssi + 100) * 100 / 70, 0, 100);
      uint16_t col = rssi <= -127 ? C_ERR : (q > 66 ? C_OK : q > 33 ? C_WARN : C_ERR);
      char b[24]; if (rssi <= -127) strcpy(b, "-- out of range"); else snprintf(b, 24, "%d dBm", rssi);
      tft.setTextColor(col, C_BG); tft.drawString(b, 6, 56, 6);
      const char *qual = rssi <= -127 ? "" : q > 66 ? "excellent" : q > 45 ? "good" : q > 25 ? "weak" : "very weak";
      tft.setTextColor(C_DIM, C_BG); tft.drawString(qual, 180, 86, 2);
      ui::bar(6, 104, 308, 10, q / 100.0f, col, C_PANEL);
      // graph
      tft.fillRect(GX, GY, GW, GH, TFT_BLACK);
      for (int i = 1; i < GW; ++i) {
        int a = hist[(hp + (300 - GW) + i - 1) % 300], bb = hist[(hp + (300 - GW) + i) % 300];
        auto yv = [&](int r) { return GY + GH - 1 - constrain((r + 100) * (GH - 2) / 70, 0, GH - 2); };
        tft.drawLine(GX + i - 1, yv(a), GX + i, yv(bb), C_ACCENT);
      }
    }
    // sample list
    tft.fillRect(240, 52, 80, 140, C_BG);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("samples", 244, 52, 1);
    for (int i = 0; i < (int)samples.size(); ++i) {
      char s[16]; snprintf(s, 16, "%s %ddB", samples[i].label, samples[i].rssi);
      tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 244, 64 + i * 13, 1);
    }
  }
  WiFi.scanDelete();
  sys::radiosOff();
}

// ============================================================================
//  48  LAN DISCOVERY  - ping sweep of YOUR own subnet
// ============================================================================
void app_landisc(AppCtx &c) {
  ui::clearBody();
  if (!sys::wifiConnect(10000, true)) { if (!c.exitReq) ui::msgBox("LAN DISCOVERY", "WiFi connection failed."); return; }
  IPAddress me = WiFi.localIP(), gw = WiFi.gatewayIP(), mask = WiFi.subnetMask();
  struct Host { uint8_t last; int rtt; bool gw; };
  std::vector<Host> hosts;
  c.header();
  ui::clearBody();
  char hdr[48]; snprintf(hdr, sizeof(hdr), "me %s", me.toString().c_str());
  tft.setTextColor(C_DIM, C_BG); tft.drawString(hdr, 6, 30, 1);
  const int Y0 = 44, RH = 15, ROWS = 10;
  int top = 0;
  bool sweeping = true; int cur = 1;
  uint8_t base3[3] = {me[0], me[1], me[2]};
  bool classC = (mask[0] == 255 && mask[1] == 255 && mask[2] == 255);
  auto drawList = [&]() {
    tft.fillRect(0, Y0, 320, ROWS * RH + 2, C_BG);
    for (int i = 0; i < ROWS && top + i < (int)hosts.size(); ++i) {
      const Host &h = hosts[top + i];
      int y = Y0 + i * RH;
      char line[48]; snprintf(line, sizeof(line), "%u.%u.%u.%-3u   %3d ms  %s", base3[0], base3[1], base3[2], h.last, h.rtt, h.gw ? "<- gateway" : "");
      tft.setTextColor(h.gw ? C_WARN : C_OK, C_BG); tft.drawString(line, 6, y, 1);
    }
  };
  auto status = [&]() {
    tft.fillRect(0, 196, 320, 44, C_BG);
    ui::bar(6, 198, 308, 8, classC ? cur / 254.0f : 1.0f, C_ACCENT, C_PANEL);
    char b[48]; snprintf(b, sizeof(b), "%s  %d hosts up", sweeping ? "scanning..." : "done", (int)hosts.size());
    tft.setTextColor(C_TEXT, C_BG); tft.drawString(b, 6, 210, 2);
    ui::button(214, 208, 100, 28, sweeping ? "STOP" : "RESCAN", C_PANEL2);
  };
  if (!classC) { ui::msgBox("LAN DISCOVERY", "Only /24 (255.255.255.0) subnets are swept."); sweeping = false; }
  status();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && ui::inRect(t.sx, t.sy, 214, 208, 100, 28)) {
      if (sweeping) sweeping = false;
      else { hosts.clear(); top = 0; cur = 1; sweeping = classC; drawList(); }
      status();
    }
    if (t.swipe == SW_UP && top + ROWS < (int)hosts.size()) { top += ROWS; drawList(); }
    if (t.swipe == SW_DOWN && top > 0) { top = max(0, top - ROWS); drawList(); }
    if (sweeping && cur <= 254) {
      IPAddress ip(base3[0], base3[1], base3[2], cur);
      int rtt;
      if (ip != me && wping::once(ip, 120, rtt)) {
        Host h{(uint8_t)cur, max(0, rtt), ip == gw};
        hosts.push_back(h);
        std::sort(hosts.begin(), hosts.end(), [](const Host &a, const Host &b) { return a.last < b.last; });
        drawList();
      }
      cur++;
      if ((cur & 7) == 0 || !sweeping) status();
      if (cur > 254) { sweeping = false; status(); }
    }
  }
  sys::radiosOff();
}

// ============================================================================
//  49  NET HEALTH  - DNS / latency / jitter / loss
// ============================================================================
void app_nethealth(AppCtx &c) {
  ui::clearBody();
  if (!sys::wifiConnect(10000, true)) { if (!c.exitReq) ui::msgBox("NET HEALTH", "WiFi connection failed."); return; }
  IPAddress gw = WiFi.gatewayIP(), host;
  String hostName = c.pStr("host", "1.1.1.1");
  if (!WiFi.hostByName(hostName.c_str(), host)) host = IPAddress(1, 1, 1, 1);
  String dnsName = c.pStr("dns_test", "example.com");
  c.header();
  ui::clearBody();
  float samples[30]; int ns = 0, si = 0; int sent = 0, recv = 0;
  int16_t spark[120]; for (auto &s : spark) s = -1; int sp = 0;
  uint32_t lastDns = 0; int dnsMs = -1;
  auto tile = [&](int x, int y, const char *k, const String &v, uint16_t col) {
    tft.fillRoundRect(x, y, 100, 44, 6, C_PANEL);
    tft.setTextColor(C_DIM, C_PANEL); tft.drawString(k, x + 6, y + 4, 1);
    tft.setTextColor(col, C_PANEL); tft.drawString(v, x + 6, y + 17, 4);
  };
  tft.setTextColor(C_DIM, C_BG);
  char sub[48]; snprintf(sub, sizeof(sub), "gw %s   host %s", gw.toString().c_str(), host.toString().c_str());
  tft.drawString(sub, 6, 28, 1);
  const int GX = 6, GY = 150, GW = 308, GH = 58;
  while (c.frame(700)) {
    int gwR, hR;
    bool gwUp = wping::once(gw, 400, gwR);
    bool up = wping::once(host, 600, hR);
    sent++; if (up) recv++;
    if (up) { samples[si] = hR; si = (si + 1) % 30; if (ns < 30) ns++; }
    spark[sp] = up ? hR : -1; sp = (sp + 1) % 120;
    float avg = 0; for (int i = 0; i < ns; ++i) avg += samples[i]; if (ns) avg /= ns;
    float jit = 0; for (int i = 0; i < ns; ++i) jit += (samples[i] - avg) * (samples[i] - avg); jit = ns ? sqrtf(jit / ns) : 0;
    float loss = sent ? 100.0f * (sent - recv) / sent : 0;
    if (millis() - lastDns > 5000) { lastDns = millis(); IPAddress tmp; uint32_t t0 = millis(); dnsMs = WiFi.hostByName(dnsName.c_str(), tmp) ? (int)(millis() - t0) : -1; }
    char b[16];
    snprintf(b, 16, gwUp ? "%dms" : "down", gwR); tile(6, 36, "GATEWAY", b, gwUp ? C_OK : C_ERR);
    snprintf(b, 16, up ? "%dms" : "down", hR); tile(110, 36, "INTERNET", b, up ? C_OK : C_ERR);
    snprintf(b, 16, dnsMs >= 0 ? "%dms" : "fail", dnsMs); tile(214, 36, "DNS", b, dnsMs >= 0 ? C_OK : C_ERR);
    snprintf(b, 16, "%.0fms", avg); tile(6, 88, "AVG RTT", b, C_ACCENT);
    snprintf(b, 16, "%.0fms", jit); tile(110, 88, "JITTER", b, jit < 30 ? C_OK : C_WARN);
    snprintf(b, 16, "%.0f%%", loss); tile(214, 88, "LOSS", b, loss < 2 ? C_OK : C_ERR);
    tft.fillRect(GX, GY, GW, GH, TFT_BLACK); tft.drawRect(GX, GY, GW, GH, C_PANEL2);
    int mx = 50; for (auto s : spark) mx = max(mx, (int)s); mx = ((mx + 24) / 25) * 25;
    char ml[12]; snprintf(ml, 12, "%dms", mx); tft.setTextColor(C_DIM, TFT_BLACK); tft.drawString(ml, GX + 2, GY + 2, 1);
    for (int i = 1; i < GW && i < 120; ++i) {
      int a = spark[(sp + 120 - GW % 120 + i - 1) % 120], bb = spark[(sp + 120 - GW % 120 + i) % 120];
      int x = GX + i;
      if (a < 0 || bb < 0) { if (bb < 0) tft.drawFastVLine(x, GY + 1, GH - 2, RGB565(80, 20, 20)); continue; }
      tft.drawLine(x - 1, GY + GH - 1 - a * (GH - 2) / mx, x, GY + GH - 1 - bb * (GH - 2) / mx, C_ACCENT);
    }
    tft.setTextColor(C_DIM, C_BG); tft.drawString("latency history (red = timeout). Host in app_49.json", 6, 212, 1);
  }
  sys::radiosOff();
}

// ============================================================================
//  50  AIRTIME MONITOR  - frames/sec over time on one channel (counts only)
// ============================================================================