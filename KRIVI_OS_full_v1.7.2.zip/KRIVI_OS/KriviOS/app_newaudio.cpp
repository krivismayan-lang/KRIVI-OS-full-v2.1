// ============================================================================
//  New audio apps (page 2)
//   55  FFT Spectrum Analyzer  - real-time mic spectrum (IO35)
//   56  Theremin               - touch-controlled continuous synth
//   57  Beat Sequencer         - 4-track x 16-step drum machine
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  55  FFT SPECTRUM ANALYZER
// ============================================================================
namespace fftm {
static const int N = 128;
static float re[N], im[N];
static uint16_t bitrev[N];
static bool revInit = false;
static void fft() {
  if (!revInit) { for (int i = 0; i < N; ++i) { int r = 0, x = i; for (int b = 0; b < 7; ++b) { r = (r << 1) | (x & 1); x >>= 1; } bitrev[i] = r; } revInit = true; }
  for (int i = 0; i < N; ++i) if (i < bitrev[i]) { float t = re[i]; re[i] = re[bitrev[i]]; re[bitrev[i]] = t; t = im[i]; im[i] = im[bitrev[i]]; im[bitrev[i]] = t; }
  for (int len = 2; len <= N; len <<= 1) {
    float ang = -2 * PI / len, wr = cosf(ang), wi = sinf(ang);
    for (int i = 0; i < N; i += len) {
      float cr = 1, ci = 0;
      for (int j = 0; j < len / 2; ++j) {
        int a = i + j, b = i + j + len / 2;
        float tr = cr * re[b] - ci * im[b], ti = cr * im[b] + ci * re[b];
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
        float ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
      }
    }
  }
}
}  // namespace fftm

void app_spectrum(AppCtx &c) {
  using namespace fftm;
  analogSetPinAttenuation(PIN_MIC, ADC_11db);
  const int BARS = 32, GX = 8, GY = 32, GW = 304, GH = 168, BW = GW / BARS;
  float peak[BARS]; for (auto &p : peak) p = 0;
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("Live mic spectrum (IO35)  -  128-pt FFT", 8, 214, 1);
  while (c.loop()) {
    // sample N points at ~a fixed cadence (~16 kHz)
    for (int i = 0; i < N; ++i) { re[i] = analogRead(PIN_MIC); im[i] = 0; delayMicroseconds(55); }
    float mean = 0; for (int i = 0; i < N; ++i) mean += re[i]; mean /= N;
    for (int i = 0; i < N; ++i) re[i] = (re[i] - mean) * (0.5f - 0.5f * cosf(2 * PI * i / (N - 1)));   // Hann window
    fft();
    for (int b = 0; b < BARS; ++b) {
      int bin = 1 + b * (N / 2 - 1) / BARS;
      float mag = sqrtf(re[bin] * re[bin] + im[bin] * im[bin]);
      float db = logf(mag + 1) * 26;
      int h = (int)constrain(db, 0.f, (float)GH);
      peak[b] = h > peak[b] ? h : peak[b] * 0.90f;
      int x = GX + b * BW;
      tft.fillRect(x, GY, BW - 1, GH - h, C_BG);
      tft.fillRect(x, GY + GH - h, BW - 1, h, ui::hsv(200 + b * 5, 230, 255));
      int py = GY + GH - (int)peak[b];
      tft.fillRect(x, py, BW - 1, 2, TFT_WHITE);
    }
    if (!c.loop()) return;
  }
}

// ============================================================================
//  56  THEREMIN
// ============================================================================
// ============================================================================
//  57  BEAT SEQUENCER
// ============================================================================