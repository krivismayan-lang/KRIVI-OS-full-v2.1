// ============================================================================
//  Page 2: Acoustic studio & sensors
//  10 Piano  11 Oscilloscope  12 VU meter  13 Tone generator  14 Clap switch
//  15 MOD tracker  16 Metronome  17 Drum pad
// ============================================================================
#include "apps_common.h"

static const char *WAVE_NAMES[5] = {"SQUARE", "SINE", "TRIANGLE", "SAW", "NOISE"};

// ============================================================================
//  10  PIANO FREQUENCY SYNTH
// ============================================================================
void app_piano(AppCtx &c) {
  const int KY = 66, KH = 172, NW = 14;
  const float KW = 320.0f / NW;
  static const int8_t WHITE_ST[7] = {0, 2, 4, 5, 7, 9, 11};
  static const int8_t BLACK_AFTER[5] = {0, 1, 3, 4, 5};   // black key after white index
  int octave = c.pInt("octave", 4);
  int wave = audio::SQUARE;
  auto keyAt = [&](int x, int y, bool &black) -> int {  // returns semitone 0..23 or -1
    black = false;
    if (y < KY) return -1;
    if (y < KY + KH * 0.6f) {
      for (int o = 0; o < 2; ++o) for (int b : BLACK_AFTER) {
        float cx = (o * 7 + b + 1) * KW;
        if (x >= cx - KW * 0.32f && x <= cx + KW * 0.32f) { black = true; return o * 12 + WHITE_ST[b] + 1; }
      }
    }
    int w = (int)(x / KW); if (w >= NW) w = NW - 1;
    return (w / 7) * 12 + WHITE_ST[w % 7];
  };
  auto drawKeys = [&](int hl) {
    for (int w = 0; w < NW; ++w) {
      int st = (w / 7) * 12 + WHITE_ST[w % 7];
      int x = (int)(w * KW);
      tft.fillRect(x + 1, KY, (int)KW - 1, KH, st == hl ? C_ACCENT : RGB565(240, 240, 235));
      if (w % 7 == 0) { char s[4]; snprintf(s, 4, "C%d", octave + w / 7); tft.setTextColor(C_DIM, st == hl ? C_ACCENT : RGB565(240, 240, 235)); tft.drawString(s, x + 5, KY + KH - 14, 1); }
    }
    for (int o = 0; o < 2; ++o) for (int b : BLACK_AFTER) {
      int st = o * 12 + WHITE_ST[b] + 1;
      int cx = (int)((o * 7 + b + 1) * KW);
      tft.fillRoundRect(cx - (int)(KW * 0.32f), KY, (int)(KW * 0.64f), (int)(KH * 0.6f), 2, st == hl ? C_ACCENT : RGB565(25, 25, 30));
    }
  };
  auto drawTop = [&]() {
    tft.fillRect(0, 26, 320, 40, C_BG);
    ui::button(4, 30, 50, 32, "OCT-");
    ui::button(58, 30, 50, 32, "OCT+");
    char s[16]; snprintf(s, 16, "Octave %d", octave);
    ui::centerText(s, 150, 46, C_TEXT, C_BG, 2);
    ui::button(196, 30, 120, 32, WAVE_NAMES[wave], RGB565(90, 50, 160));
  };
  tft.fillRect(0, 26, 320, 214, C_BG);
  drawTop(); drawKeys(-1);
  int cur = -1;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && t.sy < KY) {
      if (ui::inRect(t.sx, t.sy, 4, 30, 50, 32) && octave > 1) octave--;
      else if (ui::inRect(t.sx, t.sy, 58, 30, 50, 32) && octave < 7) octave++;
      else if (ui::inRect(t.sx, t.sy, 196, 30, 120, 32)) wave = (wave + 1) % 4;
      drawTop(); drawKeys(-1); continue;
    }
    bool black;
    int k = t.down ? keyAt(t.x, t.y, black) : -1;
    if (k != cur) {
      if (k >= 0) {
        float hz = 261.6256f * powf(2.0f, (octave - 4) + k / 12.0f);
        audio::tone(0, hz, 110, (audio::Wave)wave);
      } else audio::tone(0, 0, 0, audio::SQUARE, 1);
      cur = k; drawKeys(cur);
    }
  }
}

// ============================================================================
//  11  AUDIO OSCILLOSCOPE (IO35)
// ============================================================================
void app_scope(AppCtx &c) {
  const int PW = 270, PY = 30, PH = 180;
  static const uint16_t TB_US[] = {0, 25, 50, 100, 250, 500, 1000};
  static const char *TB_L[] = {"max", "25us", "50us", "100us", "250us", "0.5ms", "1ms"};
  int tb = 1; bool hold = false;
  uint16_t *buf = (uint16_t *)malloc(PW * 2 * 2);
  uint8_t *prevY = (uint8_t *)malloc(PW);
  if (!buf || !prevY) { free(buf); free(prevY); return; }
  memset(prevY, 0, PW);
  analogSetPinAttenuation(PIN_MIC, ADC_11db);
  auto grid = [&]() {
    tft.fillRect(0, PY, PW, PH, TFT_BLACK);
    for (int i = 0; i <= 6; ++i) tft.drawFastVLine(i * 45, PY, PH, RGB565(20, 40, 20));
    for (int i = 0; i <= 4; ++i) tft.drawFastHLine(0, PY + i * 45, PW, RGB565(20, 40, 20));
  };
  auto side = [&]() {
    tft.fillRect(PW, 26, 50, 214, C_BG);
    ui::button(273, 30, 45, 34, TB_L[tb], C_PANEL2, C_TEXT, 1);
    ui::button(273, 70, 45, 34, hold ? "RUN" : "HOLD", hold ? C_WARN : C_PANEL2, hold ? TFT_BLACK : C_TEXT, 1);
  };
  grid(); side();
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString("IO35  0..3.3V", 4, 216, 1);
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 273, 30, 45, 34)) { tb = (tb + 1) % 7; side(); }
      else if (ui::inRect(t.sx, t.sy, 273, 70, 45, 34)) { hold = !hold; side(); }
    }
    if (hold) continue;
    // capture 2x width so we can trigger
    uint32_t t0 = micros();
    for (int i = 0; i < PW * 2; ++i) {
      buf[i] = analogRead(PIN_MIC);
      if (TB_US[tb]) { uint32_t target = t0 + (uint32_t)(i + 1) * TB_US[tb]; while ((int32_t)(micros() - target) < 0) {} }
    }
    uint32_t dt = micros() - t0;
    float usPerSample = dt / (float)(PW * 2);
    int lo = 4095, hi = 0; long sum = 0;
    for (int i = 0; i < PW * 2; ++i) { lo = min(lo, (int)buf[i]); hi = max(hi, (int)buf[i]); sum += buf[i]; }
    int mid = sum / (PW * 2);
    int trig = 0, hyst = max(20, (hi - lo) / 10);
    for (int i = 1; i < PW; ++i) if (buf[i - 1] < mid - hyst / 2 && buf[i] >= mid) { trig = i; break; }
    int crossings = 0, firstX = -1, lastX = -1; bool below = buf[0] < mid;
    for (int i = 1; i < PW * 2; ++i) {
      bool b = buf[i] < mid - hyst / 2; bool a = buf[i] > mid + hyst / 2;
      if (below && a) { crossings++; if (firstX < 0) firstX = i; lastX = i; below = false; }
      else if (b) below = true;
    }
    float freq = (crossings > 1 && lastX > firstX) ? (crossings - 1) * 1e6f / ((lastX - firstX) * usPerSample) : 0;
    // draw
    for (int x = 1; x < PW; ++x) {
      int y0 = PY + PH - 1 - (buf[trig + x - 1] * (PH - 1) / 4095);
      int y1 = PY + PH - 1 - (buf[trig + x] * (PH - 1) / 4095);
      int py0 = prevY[x - 1], py1 = prevY[x];
      if (py0 && py1) tft.drawLine(x - 1, py0, x, py1, (x % 45 == 0) ? RGB565(20, 40, 20) : TFT_BLACK);
      tft.drawLine(x - 1, y0, x, y1, RGB565(60, 255, 120));
      prevY[x - 1] = y0; if (x == PW - 1) prevY[x] = y1;
    }
    static uint32_t lastTxt = 0;
    if (millis() - lastTxt > 300) {
      lastTxt = millis();
      char s[40];
      tft.fillRect(273, 112, 47, 100, C_BG);
      tft.setTextColor(C_DIM, C_BG); tft.drawString("Vpp", 274, 114, 1);
      snprintf(s, 40, "%.2fV", (hi - lo) * 3.3f / 4095); tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 274, 126, 1);
      tft.setTextColor(C_DIM, C_BG); tft.drawString("Freq", 274, 144, 1);
      if (freq > 0) snprintf(s, 40, freq >= 1000 ? "%.1fk" : "%.0fHz", freq >= 1000 ? freq / 1000 : freq); else strcpy(s, "--");
      tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 274, 156, 1);
      tft.setTextColor(C_DIM, C_BG); tft.drawString("Avg", 274, 174, 1);
      snprintf(s, 40, "%.2fV", mid * 3.3f / 4095); tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 274, 186, 1);
      snprintf(s, 40, "%.0fus/div  ", usPerSample * 45);
      tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 120, 216, 1);
    }
  }
  free(buf); free(prevY);
}

// ============================================================================
//  12  VU DECIBEL METER (IO35)
// ============================================================================
void app_vu(AppCtx &c) {
  const int SEG = 30, BX = 10, BY = 60, BW = 300, BH = 34;
  const int HX = 10, HY = 130, HW = 300, HH = 90;
  float peakDb = -60, holdDb = -60; uint32_t holdT = 0;
  uint8_t hist[HW]; memset(hist, HH - 1, HW);
  int hpos = 0;
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG);
  for (int d = -60; d <= 0; d += 10) {
    int x = BX + (d + 60) * BW / 60;
    tft.drawFastVLine(x, BY + BH + 2, 4, C_DIM);
    char s[6]; snprintf(s, 6, "%d", d); tft.drawString(s, x - 6, BY + BH + 8, 1);
  }
  tft.drawRect(HX - 1, HY - 1, HW + 2, HH + 2, C_PANEL2);
  tft.drawString("10 s history", HX, HY + HH + 4, 1);
  int lastLit = -1, lastHold = -1;
  while (c.loop()) {
    uint32_t t0 = millis(); int lo = 4095, hi = 0;
    while (millis() - t0 < 25) { int v = analogRead(PIN_MIC); lo = min(lo, v); hi = max(hi, v); }
    int pp = max(1, hi - lo);
    float db = 20.0f * log10f(pp / 4095.0f);
    db = max(db, -60.0f);
    peakDb = db > peakDb ? db : peakDb * 0.85f + db * 0.15f;
    if (db > holdDb || millis() - holdT > 1500) { holdDb = db; holdT = millis(); }
    int lit = (int)((peakDb + 60) / 60 * SEG + 0.5f);
    int hs = (int)((holdDb + 60) / 60 * SEG);
    if (lit != lastLit || hs != lastHold) {
      for (int i = 0; i < SEG; ++i) {
        uint16_t on = i < SEG * 0.7 ? C_OK : (i < SEG * 0.88 ? C_WARN : C_ERR);
        uint16_t col = (i < lit || i == hs) ? on : RGB565(25, 30, 35);
        tft.fillRect(BX + i * BW / SEG, BY, BW / SEG - 2, BH, col);
      }
      lastLit = lit; lastHold = hs;
    }
    char s[24]; snprintf(s, sizeof(s), "%5.1f dBFS ", peakDb);
    tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 10, 32, 4);
    snprintf(s, sizeof(s), "pp %4d  ", pp);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 230, 38, 2);
    static uint32_t lastH = 0;
    if (millis() - lastH > 33) {               // 300 samples over 10 s
      lastH = millis();
      int y = (int)(HH - 1 - (peakDb + 60) / 60 * (HH - 1));
      hist[hpos] = constrain(y, 0, HH - 1); hpos = (hpos + 1) % HW;
      tft.fillRect(HX, HY, HW, HH, TFT_BLACK);
      for (int i = 1; i < HW; ++i) {
        int a = hist[(hpos + i - 1) % HW], b = hist[(hpos + i) % HW];
        tft.drawLine(HX + i - 1, HY + a, HX + i, HY + b, C_ACCENT);
      }
    }
  }
}

// ============================================================================
//  13  TONE SIGNAL GENERATOR
// ============================================================================
// ============================================================================
//  14  CLAP RELAY SWITCH
// ============================================================================
// ============================================================================
//  15  CHIPTUNES TRACKER PLAYER (ProTracker .mod)
// ============================================================================
// (ProTracker .mod player removed)

// ============================================================================
//  16  ADJUSTABLE METRONOME
// ============================================================================
// ============================================================================
//  17  SAMPLE DRUM PAD  - percussion synthesized at launch
// ============================================================================
static int8_t *synthDrum(int kind, uint32_t &len) {
  const float R = audio::RATE;
  static const float DUR[8] = {0.35f, 0.22f, 0.06f, 0.35f, 0.25f, 0.30f, 0.25f, 0.05f};
  len = (uint32_t)(DUR[kind] * R);
  int8_t *d = (int8_t *)malloc(len);
  if (!d) return nullptr;
  float ph = 0, ph2 = 0, prevN = 0;
  uint32_t rng = 0xBEEF + kind;
  for (uint32_t i = 0; i < len; ++i) {
    float t = i / R, v = 0;
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    float n = ((rng & 0xFFFF) / 32768.0f) - 1.0f;
    switch (kind) {
      case 0: { float f = 45 + 110 * expf(-t * 30); ph += f / R; v = sinf(ph * 2 * PI) * expf(-t * 9); } break;            // kick
      case 1: { ph += 185 / R; v = (0.5f * sinf(ph * 2 * PI) * expf(-t * 25) + 0.7f * n * expf(-t * 14)); } break;     // snare
      case 2: { v = (n - prevN) * 0.6f * expf(-t * 70); } break;                                                        // closed hat
      case 3: { v = (n - prevN) * 0.5f * expf(-t * 9); } break;                                                         // open hat
      case 4: { float env = 0; for (int k = 0; k < 3; ++k) { float tt = t - k * 0.012f; if (tt >= 0) env = max(env, expf(-tt * 120)); }
                env = max(env, t > 0.036f ? expf(-(t - 0.036f) * 18) * 0.7f : 0.f); v = n * env; } break;              // clap
      case 5: { float f = 110 + 60 * expf(-t * 20); ph += f / R; v = sinf(ph * 2 * PI) * expf(-t * 11); } break;      // low tom
      case 6: { ph += 540 / R; ph2 += 800 / R; v = ((fmodf(ph, 1) < 0.5f ? 0.5f : -0.5f) + (fmodf(ph2, 1) < 0.5f ? 0.5f : -0.5f)) * 0.6f * expf(-t * 14); } break; // cowbell
      case 7: { ph += 1700 / R; v = (sinf(ph * 2 * PI) * 0.8f + n * 0.4f) * expf(-t * 90); } break;                    // rim
    }
    prevN = n;
    d[i] = (int8_t)constrain((int)(v * 120), -127, 127);
  }
  return d;
}

void app_drumpad(AppCtx &c) {
  static const char *NAMES[8] = {"KICK", "SNARE", "HAT", "OPEN HAT", "CLAP", "TOM", "COWBELL", "RIM"};
  int8_t *smp[8]; uint32_t len[8];
  ui::clearBody();
  ui::centerText("Synthesizing drum kit...", 160, 120, C_DIM, C_BG, 2);
  for (int i = 0; i < 8; ++i) smp[i] = synthDrum(i, len[i]);
  ui::clearBody();
  const int PW = 76, PH = 100, OX = 6, OY = 32;
  auto pad = [&](int i, bool lit) {
    int x = OX + (i % 4) * (PW + 2), y = OY + (i / 4) * (PH + 4);
    uint16_t col = ui::hsv(i * 45, lit ? 120 : 220, lit ? 255 : 150);
    tft.fillRoundRect(x, y, PW, PH, 8, col);
    tft.drawRoundRect(x, y, PW, PH, 8, lit ? TFT_WHITE : C_PANEL2);
    ui::centerText(NAMES[i], x + PW / 2, y + PH / 2, TFT_BLACK, col, 2);
  };
  for (int i = 0; i < 8; ++i) pad(i, false);
  int voice = 0; int lit = -1; uint32_t litT = 0;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.pressed) {
      int col = (t.x - OX) / (PW + 2), row = (t.y - OY) / (PH + 4);
      if (t.y >= OY && col >= 0 && col < 4 && row >= 0 && row < 2) {
        int i = row * 4 + col;
        if (smp[i]) { audio::sample(voice, smp[i], len[i], audio::RATE, 127); voice = (voice + 1) % 6; }
        if (lit >= 0) pad(lit, false);
        pad(i, true); lit = i; litT = millis();
      }
    }
    if (lit >= 0 && millis() - litT > 90) { pad(lit, false); lit = -1; }
  }
  audio::stopAll();
  delay(15);
  for (int i = 0; i < 8; ++i) free(smp[i]);
}
