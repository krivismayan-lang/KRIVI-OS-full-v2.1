// ============================================================================
//  KRIVI OS - UI toolkit: input events, header/exit box, widgets, file picker,
//  on-screen keyboard
// ============================================================================
#include "krivi.h"

namespace ui {
static Touch T;
static uint8_t s_pressCnt = 0, s_relCnt = 0;
static const char *s_title = nullptr;
static const char *s_sub = nullptr;
static uint16_t s_accent = C_ACCENT;
static bool s_banner = false;

Touch &state() { return T; }
void clearEvents() { T.pressed = T.released = T.tap = false; T.swipe = 0; }

static void drawAlarmBanner() {
  tft.fillRect(0, 0, SCR_W, HDR_H, C_ERR);
  char b[48];
  snprintf(b, sizeof(b), "ALARM %02d:%02d  -  TAP TO STOP", sys::alarm.h, sys::alarm.m);
  tft.setTextColor(TFT_WHITE, C_ERR);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(b, SCR_W / 2, HDR_H / 2, 2);
  tft.setTextDatum(TL_DATUM);
}

Touch &poll() {
  int16_t x, y;
  bool d = touch::read(x, y);
  if (d) {
    s_relCnt = 0;
    if (!T.down) {
      if (++s_pressCnt >= 2) {
        T.down = true; T.pressed = true;
        T.x = T.sx = x; T.y = T.sy = y; T.t0 = millis();
        Serial.printf("touch: press at %d,%d\n", x, y);   // handy when debugging calibration
      }
    } else {
      T.x = (T.x + 3 * x) / 4;      // light smoothing of resistive jitter
      T.y = (T.y + 3 * y) / 4;
    }
  } else {
    s_pressCnt = 0;
    if (T.down && ++s_relCnt >= 3) {
      T.down = false; T.released = true;
      int dx = T.x - T.sx, dy = T.y - T.sy;
      uint32_t dur = millis() - T.t0;
      if (abs(dx) < 20 && abs(dy) < 20 && dur < 800) T.tap = true;
      if (max(abs(dx), abs(dy)) > 32) {
        if (abs(dx) > abs(dy)) T.swipe = dx > 0 ? SW_RIGHT : SW_LEFT;
        else T.swipe = dy > 0 ? SW_DOWN : SW_UP;
      }
    }
  }
  sys::tick();
  if (sys::alarm.ringing) {
    if (!s_banner) { drawAlarmBanner(); s_banner = true; }
    if (T.pressed) {                       // any touch silences, event consumed
      sys::alarm.ringing = false;
      audio::stop(6);
      sys::led(0, 0, 0);
      clearEvents();
      T.down = true;                       // swallow until release
    }
  } else if (s_banner) {
    s_banner = false;
    redrawHeader();
  }
  return T;
}

bool inRect(int x, int y, int rx, int ry, int rw, int rh) {
  return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
}
bool hit(const Touch &t, int rx, int ry, int rw, int rh) {
  return t.pressed && inRect(t.x, t.y, rx, ry, rw, rh);
}
bool tapIn(const Touch &t, int rx, int ry, int rw, int rh) {
  return t.tap && inRect(t.sx, t.sy, rx, ry, rw, rh);
}
bool exitHit(const Touch &t) {
  return t.pressed && t.x >= EXIT_X0 && t.x <= EXIT_X1 && t.y >= EXIT_Y0 && t.y <= EXIT_Y1;
}

void exitBox() {
  tft.fillRoundRect(EXIT_X0, EXIT_Y0, EXIT_X1 - EXIT_X0 + 1, EXIT_Y1 - EXIT_Y0 + 1, 4, C_EXIT);
  tft.drawRoundRect(EXIT_X0, EXIT_Y0, EXIT_X1 - EXIT_X0 + 1, EXIT_Y1 - EXIT_Y0 + 1, 4, TFT_WHITE);
  int cx = EXIT_X0 + 10, cy = (EXIT_Y0 + EXIT_Y1) / 2;
  tft.drawLine(cx - 4, cy - 4, cx + 4, cy + 4, TFT_WHITE);
  tft.drawLine(cx + 4, cy - 4, cx - 4, cy + 4, TFT_WHITE);
  tft.setTextColor(TFT_WHITE, C_EXIT);
  tft.drawString("EXIT", EXIT_X0 + 20, EXIT_Y0 + 2, 2);
}

void header(const char *title, uint16_t accent, const char *sub) {
  s_title = title; s_accent = accent; s_sub = sub;
  redrawHeader();
}
void redrawHeader() {
  if (!s_title) return;
  tft.fillRect(0, 0, SCR_W, HDR_H - 2, C_PANEL);
  tft.fillRect(0, HDR_H - 2, SCR_W, 2, s_accent);
  tft.fillRoundRect(4, 6, 6, 14, 2, s_accent);
  tft.setTextColor(C_TEXT, C_PANEL);
  tft.drawString(s_title, 15, 5, 2);
  if (s_sub) {
    int w = tft.textWidth(s_title, 2);
    tft.setTextColor(C_DIM, C_PANEL);
    tft.drawString(s_sub, 22 + w, 8, 1);
  }
  exitBox();
}

void clearBody(uint16_t c) { tft.fillRect(0, HDR_H, SCR_W, SCR_H - HDR_H, c); }

void button(int x, int y, int w, int h, const char *label, uint16_t bg, uint16_t fg, uint8_t font) {
  tft.fillRoundRect(x, y, w, h, 5, bg);
  tft.drawRoundRect(x, y, w, h, 5, RGB565(90, 100, 130));
  tft.setTextColor(fg, bg);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(label, x + w / 2, y + h / 2 + 1, font);
  tft.setTextDatum(TL_DATUM);
}

void centerText(const char *s, int cx, int cy, uint16_t fg, uint16_t bg, uint8_t font) {
  tft.setTextColor(fg, bg);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(s, cx, cy, font);
  tft.setTextDatum(TL_DATUM);
}

void bar(int x, int y, int w, int h, float f, uint16_t fg, uint16_t bg) {
  f = constrain(f, 0.f, 1.f);
  int fw = (int)((w - 2) * f);
  tft.drawRect(x, y, w, h, C_DIM);
  tft.fillRect(x + 1, y + 1, fw, h - 2, fg);
  tft.fillRect(x + 1 + fw, y + 1, w - 2 - fw, h - 2, bg);
}

void toast(const char *msg, uint16_t color) {
  tft.fillRoundRect(20, 206, 280, 26, 6, C_PANEL2);
  tft.drawRoundRect(20, 206, 280, 26, 6, color);
  centerText(msg, 160, 219, color, C_PANEL2, 2);
}

uint16_t hsv(uint16_t h, uint8_t s, uint8_t v) {
  h %= 360;
  uint8_t region = h / 60;
  uint16_t rem = (h - region * 60) * 255 / 60;
  uint8_t p = (v * (255 - s)) >> 8;
  uint8_t q = (v * (255 - ((s * rem) >> 8))) >> 8;
  uint8_t t = (v * (255 - ((s * (255 - rem)) >> 8))) >> 8;
  uint8_t r, g, b;
  switch (region) {
    case 0: r = v; g = t; b = p; break;
    case 1: r = q; g = v; b = p; break;
    case 2: r = p; g = v; b = t; break;
    case 3: r = p; g = q; b = v; break;
    case 4: r = t; g = p; b = v; break;
    default: r = v; g = p; b = q; break;
  }
  return RGB565(r, g, b);
}

// Word-wrap helper (font 2 ~ 7px avg width)
static int drawWrapped(const char *msg, int x, int y, int w, uint16_t fg, uint16_t bg) {
  tft.setTextColor(fg, bg);
  String line, word;
  int lh = 16;
  auto flush = [&]() { tft.drawString(line, x, y, 2); y += lh; line = ""; };
  for (const char *p = msg;; ++p) {
    char c = *p;
    if (c == ' ' || c == '\n' || c == 0) {
      String cand = line.length() ? line + " " + word : word;
      if (tft.textWidth(cand, 2) > w && line.length()) { flush(); line = word; }
      else line = cand;
      word = "";
      if (c == '\n') flush();
      if (c == 0) { if (line.length()) flush(); break; }
    } else word += c;
  }
  return y;
}

static bool modal(const char *title, const char *msg, bool twoButtons) {
  int x = 20, y = 36, w = 280, h = 180;
  tft.fillRoundRect(x, y, w, h, 8, C_PANEL);
  tft.drawRoundRect(x, y, w, h, 8, C_ACCENT);
  tft.setTextColor(C_ACCENT, C_PANEL);
  tft.drawString(title, x + 12, y + 8, 2);
  tft.drawFastHLine(x + 10, y + 27, w - 20, C_PANEL2);
  drawWrapped(msg, x + 12, y + 34, w - 24, C_TEXT, C_PANEL);
  if (twoButtons) {
    button(x + 20, y + h - 40, 110, 32, "YES", C_OK, TFT_BLACK);
    button(x + w - 130, y + h - 40, 110, 32, "NO", C_PANEL2, C_TEXT);
  } else {
    button(x + w / 2 - 55, y + h - 40, 110, 32, "OK", C_ACCENT, TFT_BLACK);
  }
  clearEvents();
  while (true) {
    clearEvents();
    Touch &t = poll();
    delay(5);
    if (!t.tap) continue;
    if (!twoButtons) return true;
    if (inRect(t.sx, t.sy, x + 20, y + h - 40, 110, 32)) return true;
    if (inRect(t.sx, t.sy, x + w - 130, y + h - 40, 110, 32)) return false;
  }
}
void msgBox(const char *title, const char *msg) { modal(title, msg, false); }
bool confirm(const char *title, const char *msg) { return modal(title, msg, true); }

// ---------------------------------------------------------------- file picker
String pickFile(const char *dir, const char *ext, const char *title, bool allowDirs) {
  String cur = dir;
  const char *prevTitle = s_title; uint16_t prevAcc = s_accent; const char *prevSub = s_sub;
  std::vector<String> items;
  int top = 0;
  const int ROWS = 6, RH = 29, Y0 = 30;
  bool reload = true, redraw = true;
  String result = "";
  header(title, C_ACCENT, nullptr);
  while (true) {
    if (reload) {
      items = sys::listDir(cur.c_str(), ext, allowDirs);
      if (allowDirs && cur != "/") items.insert(items.begin(), String("../"));
      top = 0; reload = false; redraw = true;
    }
    if (redraw) {
      clearBody();
      tft.setTextColor(C_DIM, C_BG);
      tft.drawString(cur, 6, Y0 - 2 + ROWS * RH + 2, 1);
      if (items.empty()) {
        centerText(sys::sdOk ? "(no matching files)" : "(SD card not mounted)", 160, 110, C_DIM, C_BG, 2);
      }
      for (int i = 0; i < ROWS && top + i < (int)items.size(); ++i) {
        const String &s = items[top + i];
        bool isDir = s.endsWith("/");
        int y = Y0 + i * RH;
        tft.fillRoundRect(4, y, 312, RH - 3, 4, C_PANEL);
        tft.fillRect(10, y + 7, 12, 12, isDir ? C_WARN : C_ACCENT);
        tft.setTextColor(C_TEXT, C_PANEL);
        String shown = s.length() > 36 ? s.substring(0, 35) + "~" : s;
        tft.drawString(shown, 30, y + 6, 2);
      }
      button(4, 212, 100, 26, "< PREV");
      button(110, 212, 100, 26, "NEXT >");
      char pg[20];
      snprintf(pg, sizeof(pg), "%d-%d / %d", items.empty() ? 0 : top + 1,
               min(top + ROWS, (int)items.size()), (int)items.size());
      tft.fillRect(214, 212, 106, 26, C_BG);
      centerText(pg, 266, 225, C_DIM, C_BG, 2);
      redraw = false;
    }
    clearEvents();
    Touch &t = poll();
    delay(4);
    if (exitHit(t)) { result = ""; break; }
    if (t.swipe == SW_UP || (t.tap && inRect(t.sx, t.sy, 110, 212, 100, 26))) {
      if (top + ROWS < (int)items.size()) { top += ROWS; redraw = true; }
    } else if (t.swipe == SW_DOWN || (t.tap && inRect(t.sx, t.sy, 4, 212, 100, 26))) {
      if (top > 0) { top = max(0, top - ROWS); redraw = true; }
    } else if (t.tap && t.sy >= Y0 && t.sy < Y0 + ROWS * RH) {
      int idx = top + (t.sy - Y0) / RH;
      if (idx < (int)items.size()) {
        audio::click();
        String s = items[idx];
        if (s == "../") {
          int p = cur.lastIndexOf('/', cur.length() - 2);
          cur = p <= 0 ? "/" : cur.substring(0, p);
          reload = true;
        } else if (s.endsWith("/")) {
          cur = (cur.endsWith("/") ? cur : cur + "/") + s.substring(0, s.length() - 1);
          reload = true;
        } else {
          result = (cur.endsWith("/") ? cur : cur + "/") + s;
          break;
        }
      }
    }
  }
  s_title = prevTitle; s_accent = prevAcc; s_sub = prevSub;
  clearEvents();
  return result;
}

// ---------------------------------------------------------------- keyboard
struct Key { const char *label; int code; uint8_t w; };
static const Key ROW3_ALPHA[] = {{"123", Keyboard::K_SYM, 2}, {"space", ' ', 4},
                                 {"<", Keyboard::K_LEFT, 1}, {">", Keyboard::K_RIGHT, 1},
                                 {"ENTER", Keyboard::K_ENTER, 2}};
static const Key ROW3_SYM[] = {{"ABC", Keyboard::K_SYM, 2}, {"space", ' ', 4},
                               {"<", Keyboard::K_LEFT, 1}, {">", Keyboard::K_RIGHT, 1},
                               {"ENTER", Keyboard::K_ENTER, 2}};

static void rowKeys(const Keyboard &kb, int row, Key *out, int &n, char *labels) {
  // labels: scratch buffer 2 bytes per key
  n = 0;
  const char *alpha[3] = {"qwertyuiop", "asdfghjkl", "zxcvbnm,."};
  const char *sym[3]   = {"1234567890", "-/:;()$&@", "_!?'\"#%*+="};
  if (row == 3) {
    const Key *src = kb.sym ? ROW3_SYM : ROW3_ALPHA;
    for (int i = 0; i < 5; ++i) out[n++] = src[i];
    return;
  }
  const char *s = kb.sym ? sym[row] : alpha[row];
  if (row == 2 && !kb.sym) out[n++] = {"SHIFT", Keyboard::K_SHIFT, 1};
  for (int i = 0; s[i]; ++i) {
    char c = s[i];
    if (!kb.sym && kb.shift && c >= 'a' && c <= 'z') c -= 32;
    labels[2 * n] = c; labels[2 * n + 1] = 0;
    out[n] = {&labels[2 * n], (int)(uint8_t)c, 1};
    n++;
  }
  if (row == 1) out[n++] = {"DEL", Keyboard::K_BKSP, 1};
}

void Keyboard::draw() {
  int rh = (SCR_H - y0) / 4;
  tft.fillRect(0, y0, SCR_W, SCR_H - y0, RGB565(16, 18, 28));
  for (int r = 0; r < 4; ++r) {
    Key keys[12]; char labels[26]; int n;
    rowKeys(*this, r, keys, n, labels);
    int units = 0; for (int i = 0; i < n; ++i) units += keys[i].w;
    int uw = SCR_W / 10;
    int x = (SCR_W - units * uw) / 2;
    for (int i = 0; i < n; ++i) {
      int w = keys[i].w * uw;
      bool special = keys[i].code < 32;
      uint16_t bg = special ? C_PANEL2 : C_PANEL;
      if (keys[i].code == K_SHIFT && shift) bg = C_ACCENT;
      if (keys[i].code == K_ENTER) bg = RGB565(0, 110, 160);
      tft.fillRoundRect(x + 1, y0 + r * rh + 1, w - 2, rh - 2, 4, bg);
      tft.setTextColor(C_TEXT, bg);
      tft.setTextDatum(MC_DATUM);
      tft.drawString(keys[i].label, x + w / 2, y0 + r * rh + rh / 2, special || strlen(keys[i].label) > 1 ? 1 : 2);
      tft.setTextDatum(TL_DATUM);
      x += w;
    }
  }
}

int Keyboard::hit(int x, int y) {
  if (y < y0) return 0;
  int rh = (SCR_H - y0) / 4;
  int r = (y - y0) / rh;
  if (r > 3) r = 3;
  Key keys[12]; char labels[26]; int n;
  rowKeys(*this, r, keys, n, labels);
  int units = 0; for (int i = 0; i < n; ++i) units += keys[i].w;
  int uw = SCR_W / 10;
  int kx = (SCR_W - units * uw) / 2;
  for (int i = 0; i < n; ++i) {
    int w = keys[i].w * uw;
    if (x >= kx && x < kx + w) {
      int c = keys[i].code;
      audio::click();
      if (c == K_SHIFT) { shift = !shift; draw(); return 0; }
      if (c == K_SYM) { sym = !sym; shift = false; draw(); return 0; }
      if (c >= 32 && shift && !sym) { shift = false; draw(); }
      return c;
    }
    kx += w;
  }
  return 0;
}

bool textInput(String &text, const char *prompt, int maxLen, bool password) {
  const char *prevTitle = s_title; uint16_t prevAcc = s_accent; const char *prevSub = s_sub;
  header(prompt, C_ACCENT, nullptr);
  clearBody();
  Keyboard kb; kb.y0 = 96;
  kb.draw();
  String s = text;
  int cur = s.length();
  bool redraw = true, ok = false;
  while (true) {
    if (redraw) {
      tft.fillRoundRect(6, 34, 308, 54, 6, C_PANEL);
      tft.drawRoundRect(6, 34, 308, 54, 6, C_ACCENT);
      String shown = password ? String() : s;
      if (password) for (unsigned i = 0; i < s.length(); ++i) shown += '*';
      int start = max(0, cur - 34);
      String vis = shown.substring(start, start + 36);
      tft.setTextColor(C_TEXT, C_PANEL);
      tft.drawString(vis, 14, 46, 2);
      int cx = 14 + tft.textWidth(vis.substring(0, cur - start), 2);
      tft.drawFastVLine(cx, 44, 18, C_ACCENT);
      char cnt[16]; snprintf(cnt, sizeof(cnt), "%d/%d", (int)s.length(), maxLen);
      tft.setTextColor(C_DIM, C_PANEL);
      tft.drawString(cnt, 250, 72, 1);
      redraw = false;
    }
    clearEvents();
    Touch &t = poll();
    delay(3);
    if (exitHit(t)) break;
    if (t.pressed) {
      int c = kb.hit(t.x, t.y);
      if (!c) continue;
      if (c == Keyboard::K_ENTER) { ok = true; break; }
      if (c == Keyboard::K_BKSP) { if (cur > 0) { s.remove(cur - 1, 1); cur--; } }
      else if (c == Keyboard::K_LEFT) { if (cur > 0) cur--; }
      else if (c == Keyboard::K_RIGHT) { if (cur < (int)s.length()) cur++; }
      else if (c >= 32 && (int)s.length() < maxLen) {
        s = s.substring(0, cur) + (char)c + s.substring(cur); cur++;
      }
      redraw = true;
    }
  }
  if (ok) text = s;
  s_title = prevTitle; s_accent = prevAcc; s_sub = prevSub;
  clearEvents();
  return ok;
}
}  // namespace ui

// ============================================================================
//  AppCtx
// ============================================================================
bool AppCtx::loop() {
  ui::clearEvents();
  t = &ui::poll();
  delay(1);
  if (ui::exitHit(*t)) { exitReq = true; audio::click(); return false; }
  return true;
}

bool AppCtx::frame(uint32_t ms) {
  ui::clearEvents();
  do {
    t = &ui::poll();
    if (ui::exitHit(*t)) { exitReq = true; audio::click(); return false; }
    int32_t left = (int32_t)ms - (int32_t)(millis() - lastFrame);
    if (left > 2) delay(1);
  } while (millis() - lastFrame < ms);
  lastFrame = millis();
  return true;
}

void AppCtx::header(const char *sub) { ui::header(def->name, def->color, sub); }
int AppCtx::pInt(const char *k, int d) const { return params[k] | d; }
float AppCtx::pFloat(const char *k, float d) const { return params[k] | d; }
String AppCtx::pStr(const char *k, const char *d) const { return String(params[k] | d); }
