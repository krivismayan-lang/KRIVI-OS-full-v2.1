// ============================================================================
//  New games
//   59 CHIP-8 Virtual Machine   60 Space Invaders   61 Asteroids
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  59  CHIP-8 VM
//  Full CHIP-8 interpreter. Loads .ch8 from /roms, or a built-in original demo.
//  64x32 display scaled 4x; 16-key pad mapped to on-screen buttons.
// ============================================================================
namespace chip8 {
static uint8_t mem[4096], V[16], disp[64 * 32];
static uint16_t I, pc, stack[16]; static uint8_t sp, dt, st, keys[16];
static bool draw;
static const uint8_t FONT[80] = {
  0xF0,0x90,0x90,0x90,0xF0, 0x20,0x60,0x20,0x20,0x70, 0xF0,0x10,0xF0,0x80,0xF0, 0xF0,0x10,0xF0,0x10,0xF0,
  0x90,0x90,0xF0,0x10,0x10, 0xF0,0x80,0xF0,0x10,0xF0, 0xF0,0x80,0xF0,0x90,0xF0, 0xF0,0x10,0x20,0x40,0x40,
  0xF0,0x90,0xF0,0x90,0xF0, 0xF0,0x90,0xF0,0x10,0xF0, 0xF0,0x90,0xF0,0x90,0x90, 0xE0,0x90,0xE0,0x90,0xE0,
  0xF0,0x80,0x80,0x80,0xF0, 0xE0,0x90,0x90,0x90,0xE0, 0xF0,0x80,0xF0,0x80,0xF0, 0xF0,0x80,0xF0,0x80,0x80};
// A tiny original program: bounces a 4x4 ball around the screen (public, trivial).
static const uint8_t DEMO[] = {
  0x60,0x1C, 0x61,0x0E, 0x62,0x01, 0x63,0x01, 0xA2,0x40, 0x22,0x30,          // x=28,y=14,dx=1,dy=1; draw
  0xD0,0x14, 0x80,0x24, 0x81,0x34, 0xD0,0x14,                               // erase? (we just redraw)
  0x30,0x00,                                                                 // nop-ish
  0x40,0x3C, 0x62,0xFF, 0x30,0x00, 0x40,0x00, 0x62,0x01,                     // bounce x
  0x41,0x1C, 0x63,0xFF, 0x31,0x00, 0x41,0x00, 0x63,0x01,                     // bounce y
  0x12,0x08};
static void reset() {
  memset(mem, 0, sizeof(mem)); memset(V, 0, 16); memset(disp, 0, sizeof(disp)); memset(keys, 0, 16);
  memcpy(mem, FONT, 80); I = 0; pc = 0x200; sp = 0; dt = st = 0; draw = true;
}
static void step() {
  uint16_t op = (mem[pc] << 8) | mem[pc + 1]; pc += 2;
  uint8_t x = (op >> 8) & 0xF, y = (op >> 4) & 0xF, n = op & 0xF, kk = op & 0xFF; uint16_t nnn = op & 0xFFF;
  switch (op >> 12) {
    case 0x0: if (op == 0x00E0) { memset(disp, 0, sizeof(disp)); draw = true; } else if (op == 0x00EE) pc = stack[--sp & 0xF]; break;
    case 0x1: pc = nnn; break;
    case 0x2: stack[sp++ & 0xF] = pc; pc = nnn; break;
    case 0x3: if (V[x] == kk) pc += 2; break;
    case 0x4: if (V[x] != kk) pc += 2; break;
    case 0x5: if (V[x] == V[y]) pc += 2; break;
    case 0x6: V[x] = kk; break;
    case 0x7: V[x] += kk; break;
    case 0x8: switch (n) {
        case 0: V[x] = V[y]; break; case 1: V[x] |= V[y]; break; case 2: V[x] &= V[y]; break; case 3: V[x] ^= V[y]; break;
        case 4: { int s = V[x] + V[y]; V[0xF] = s > 255; V[x] = s; } break;
        case 5: { V[0xF] = V[x] >= V[y]; V[x] -= V[y]; } break;
        case 6: V[0xF] = V[x] & 1; V[x] >>= 1; break;
        case 7: { V[0xF] = V[y] >= V[x]; V[x] = V[y] - V[x]; } break;
        case 0xE: V[0xF] = V[x] >> 7; V[x] <<= 1; break; } break;
    case 0x9: if (V[x] != V[y]) pc += 2; break;
    case 0xA: I = nnn; break;
    case 0xB: pc = nnn + V[0]; break;
    case 0xC: V[x] = (esp_random() & 0xFF) & kk; break;
    case 0xD: {
      V[0xF] = 0;
      for (int r = 0; r < n; ++r) { uint8_t px = mem[(I + r) & 0xFFF];
        for (int b = 0; b < 8; ++b) if (px & (0x80 >> b)) {
          int dx = (V[x] + b) & 63, dy = (V[y] + r) & 31; int idx = dy * 64 + dx;
          if (disp[idx]) V[0xF] = 1; disp[idx] ^= 1; } }
      draw = true; } break;
    case 0xE: if (kk == 0x9E) { if (keys[V[x] & 0xF]) pc += 2; } else if (kk == 0xA1) { if (!keys[V[x] & 0xF]) pc += 2; } break;
    case 0xF: switch (kk) {
        case 0x07: V[x] = dt; break;
        case 0x0A: { int k = -1; for (int i = 0; i < 16; ++i) if (keys[i]) k = i; if (k < 0) pc -= 2; else V[x] = k; } break;
        case 0x15: dt = V[x]; break; case 0x18: st = V[x]; break; case 0x1E: I += V[x]; break;
        case 0x29: I = V[x] * 5; break;
        case 0x33: mem[I & 0xFFF] = V[x] / 100; mem[(I + 1) & 0xFFF] = (V[x] / 10) % 10; mem[(I + 2) & 0xFFF] = V[x] % 10; break;
        case 0x55: for (int i = 0; i <= x; ++i) mem[(I + i) & 0xFFF] = V[i]; break;
        case 0x65: for (int i = 0; i <= x; ++i) V[i] = mem[(I + i) & 0xFFF]; break; } break;
  }
}
}  // namespace chip8

void app_chip8(AppCtx &c) {
  using namespace chip8;
  String path = ui::pickFile("/roms", ".ch8", "CHIP-8 - pick a ROM (or EXIT for demo)");
  reset();
  if (path.length()) { File f = SD.open(path); if (f) { int n = f.read(mem + 0x200, 4096 - 0x200); f.close(); sys::log("chip8: %s %dB", path.c_str(), n); } }
  else { memcpy(mem + 0x200, DEMO, sizeof(DEMO)); }
  c.header(path.length() ? path.substring(path.lastIndexOf('/') + 1).c_str() : "built-in demo");
  // keypad layout (CHIP-8 hex) on the bottom third
  static const uint8_t KP[16] = {1, 2, 3, 0xC, 4, 5, 6, 0xD, 7, 8, 9, 0xE, 0xA, 0, 0xB, 0xF};
  const int KY = 140, KW = 80, KH = 25;
  auto drawKeys = [&]() {
    for (int i = 0; i < 16; ++i) { int kx = (i % 4) * KW, ky = KY + (i / 4) * KH;
      char s[3]; snprintf(s, 3, "%X", KP[i]);
      ui::button(kx + 1, ky + 1, KW - 2, KH - 2, s, C_PANEL2, C_TEXT, 2); }
  };
  auto render = [&]() {
    const int SX = 0, SY = 20, SC = 5;
    for (int y = 0; y < 32; ++y) for (int x = 0; x < 64; ++x)
      tft.fillRect(SX + x * SC, SY + y * SC, SC, SC, disp[y * 64 + x] ? RGB565(120, 255, 140) : RGB565(6, 20, 8));
  };
  tft.fillRect(0, 20, 320, 160, TFT_BLACK); drawKeys();
  uint32_t lastTimer = millis();
  while (true) {
    ui::clearEvents(); Touch &t = ui::poll();
    if (ui::exitHit(t)) break;
    memset(keys, 0, 16);
    if (t.down && t.y >= KY) { int i = (t.x / KW) + ((t.y - KY) / KH) * 4; if (i >= 0 && i < 16) keys[KP[i]] = 1; }
    for (int i = 0; i < 12; ++i) step();           // ~720 insns/s at 60fps
    if (millis() - lastTimer >= 16) { lastTimer = millis(); if (dt) dt--; if (st) { st--; audio::tone(7, 440, 60, audio::SQUARE, 20); } }
    if (draw) { render(); draw = false; }
    delay(14);
  }
  audio::stop(7);
}

// ============================================================================
//  60  SPACE INVADERS
// ============================================================================
// ============================================================================
//  61  ASTEROIDS
// ============================================================================