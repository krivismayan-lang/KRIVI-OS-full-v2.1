// ============================================================================
//  09  TABLETOP BOARD GAMES - Tic-Tac-Toe (minimax) and Chess (legal moves,
//      castling, en passant, promotion, check/mate/stalemate, alpha-beta CPU)
// ============================================================================
#include "apps_common.h"

// ---------------------------------------------------------------- Tic-Tac-Toe
static int ttWin(const int8_t *b) {
  static const uint8_t L[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
  for (auto &l : L) if (b[l[0]] && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return b[l[0]];
  for (int i = 0; i < 9; ++i) if (!b[i]) return 0;
  return 2;   // draw
}
static int ttMinimax(int8_t *b, int who, int depth) {   // who: 1 X(human) / -1 O(cpu)
  int w = ttWin(b);
  if (w == 2) return 0;
  if (w) return w == -1 ? 10 - depth : depth - 10;
  int best = who == -1 ? -100 : 100;
  for (int i = 0; i < 9; ++i) if (!b[i]) {
    b[i] = who; int s = ttMinimax(b, -who, depth + 1); b[i] = 0;
    best = who == -1 ? max(best, s) : min(best, s);
  }
  return best;
}
static bool ticTacToe(AppCtx &c, bool vsCpu) {
  int8_t b[9];
  const int CS = 62, OX = 30, OY = 36;
  while (true) {
    memset(b, 0, 9);
    ui::clearBody();
    for (int i = 1; i < 3; ++i) {
      tft.fillRect(OX + i * CS - 2, OY, 4, CS * 3, C_DIM);
      tft.fillRect(OX, OY + i * CS - 2, CS * 3, 4, C_DIM);
    }
    tft.setTextColor(C_TEXT, C_BG);
    tft.drawString(vsCpu ? "You: X" : "2 players", 230, 50, 2);
    tft.drawString(vsCpu ? "CPU: O" : "", 230, 70, 2);
    ui::button(226, 190, 88, 34, "MENU");
    int turn = 1, w = 0;
    auto mark = [&](int i) {
      int cx = OX + (i % 3) * CS + CS / 2, cy = OY + (i / 3) * CS + CS / 2;
      if (b[i] == 1) { for (int k = -2; k <= 2; ++k) { tft.drawLine(cx - 18 + k, cy - 18, cx + 18 + k, cy + 18, C_ACCENT); tft.drawLine(cx + 18 + k, cy - 18, cx - 18 + k, cy + 18, C_ACCENT); } }
      else { tft.fillCircle(cx, cy, 20, C_WARN); tft.fillCircle(cx, cy, 15, C_BG); }
    };
    while (!w) {
      tft.fillRect(226, 110, 94, 20, C_BG);
      tft.setTextColor(turn == 1 ? C_ACCENT : C_WARN, C_BG);
      tft.drawString(turn == 1 ? "X to move" : "O to move", 226, 110, 2);
      int pick = -1;
      if (vsCpu && turn == -1) {
        int best = -1000;
        for (int i = 0; i < 9; ++i) if (!b[i]) { b[i] = -1; int s = ttMinimax(b, 1, 0); b[i] = 0; if (s > best) { best = s; pick = i; } }
        delay(250);
      } else {
        while (pick < 0) {
          if (!c.loop()) return false;
          Touch &t = *c.t;
          if (t.tap && ui::inRect(t.sx, t.sy, 226, 190, 88, 34)) return true;
          if (t.tap) {
            int gx = (t.sx - OX) / CS, gy = (t.sy - OY) / CS;
            if (t.sx >= OX && t.sy >= OY && gx < 3 && gy < 3 && !b[gy * 3 + gx]) pick = gy * 3 + gx;
          }
        }
      }
      b[pick] = turn; mark(pick); audio::beep(turn == 1 ? 900 : 600, 30);
      turn = -turn; w = ttWin(b);
    }
    banner(w == 2 ? "DRAW" : (w == 1 ? "X WINS" : "O WINS"), "tap to play again", w == 2 ? C_WARN : C_OK);
    if (!waitTap(c)) return false;
  }
}

// ---------------------------------------------------------------- Chess
namespace chess {
enum { P = 1, N, B, R, Q, K };
struct Pos { int8_t b[64]; uint8_t castle; int8_t ep; int8_t side; };   // side 1 white, -1 black
struct Mv { uint8_t f, t; int8_t promo; };

static const int8_t KN[8][2] = {{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1},{-2,1},{-1,2}};
static const int8_t KD[8][2] = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
static const int VAL[7] = {0, 100, 320, 330, 500, 900, 20000};

static void init(Pos &p) {
  static const int8_t back[8] = {R, N, B, Q, K, B, N, R};
  memset(p.b, 0, 64);
  for (int i = 0; i < 8; ++i) { p.b[i] = -back[i]; p.b[8 + i] = -P; p.b[48 + i] = P; p.b[56 + i] = back[i]; }
  p.castle = 15; p.ep = -1; p.side = 1;
}
static inline bool on(int x, int y) { return x >= 0 && x < 8 && y >= 0 && y < 8; }

static bool attacked(const Pos &p, int sq, int by) {   // is sq attacked by colour `by`
  int x = sq & 7, y = sq >> 3;
  int pd = by == 1 ? 1 : -1;                            // white pawns attack upward (y-1)
  for (int dx : {-1, 1}) { int ax = x + dx, ay = y + pd; if (on(ax, ay) && p.b[ay * 8 + ax] == by * P) return true; }
  for (auto &d : KN) { int ax = x + d[0], ay = y + d[1]; if (on(ax, ay) && p.b[ay * 8 + ax] == by * N) return true; }
  for (auto &d : KD) { int ax = x + d[0], ay = y + d[1]; if (on(ax, ay) && p.b[ay * 8 + ax] == by * K) return true; }
  for (int i = 0; i < 8; ++i) {
    int ax = x, ay = y;
    while (true) {
      ax += KD[i][0]; ay += KD[i][1];
      if (!on(ax, ay)) break;
      int8_t q = p.b[ay * 8 + ax];
      if (!q) continue;
      if (q * by > 0) {
        int t = abs(q);
        if (t == Q || (i < 4 && t == R) || (i >= 4 && t == B)) return true;
      }
      break;
    }
  }
  return false;
}
static int kingSq(const Pos &p, int side) { for (int i = 0; i < 64; ++i) if (p.b[i] == side * K) return i; return -1; }
static bool inCheck(const Pos &p, int side) { int k = kingSq(p, side); return k >= 0 && attacked(p, k, -side); }

static int gen(const Pos &p, Mv *out) {
  int n = 0, s = p.side;
  for (int sq = 0; sq < 64; ++sq) {
    int8_t pc = p.b[sq];
    if (pc * s <= 0) continue;
    int x = sq & 7, y = sq >> 3, t = abs(pc);
    auto add = [&](int to) { int8_t pr = 0; if (t == P && ((to >> 3) == 0 || (to >> 3) == 7)) pr = Q; out[n++] = {(uint8_t)sq, (uint8_t)to, pr}; };
    if (t == P) {
      int dy = s == 1 ? -1 : 1, start = s == 1 ? 6 : 1;
      if (on(x, y + dy) && !p.b[(y + dy) * 8 + x]) {
        add((y + dy) * 8 + x);
        if (y == start && !p.b[(y + 2 * dy) * 8 + x]) add((y + 2 * dy) * 8 + x);
      }
      for (int dx : {-1, 1}) {
        int ax = x + dx, ay = y + dy; if (!on(ax, ay)) continue;
        int to = ay * 8 + ax;
        if (p.b[to] * s < 0 || to == p.ep) add(to);
      }
    } else if (t == N || t == K) {
      auto &D = t == N ? KN : KD;
      for (auto &d : D) { int ax = x + d[0], ay = y + d[1]; if (on(ax, ay) && p.b[ay * 8 + ax] * s <= 0) add(ay * 8 + ax); }
      if (t == K) {
        int row = s == 1 ? 7 : 0;
        if (sq == row * 8 + 4 && !attacked(p, sq, -s)) {
          int ks = s == 1 ? 1 : 4, qs = s == 1 ? 2 : 8;
          if ((p.castle & ks) && !p.b[row * 8 + 5] && !p.b[row * 8 + 6] && p.b[row * 8 + 7] == s * R &&
              !attacked(p, row * 8 + 5, -s)) add(row * 8 + 6);
          if ((p.castle & qs) && !p.b[row * 8 + 3] && !p.b[row * 8 + 2] && !p.b[row * 8 + 1] && p.b[row * 8] == s * R &&
              !attacked(p, row * 8 + 3, -s)) add(row * 8 + 2);
        }
      }
    } else {
      int i0 = t == B ? 4 : 0, i1 = t == R ? 4 : 8;
      for (int i = i0; i < i1; ++i) {
        int ax = x, ay = y;
        while (true) {
          ax += KD[i][0]; ay += KD[i][1];
          if (!on(ax, ay)) break;
          int8_t q = p.b[ay * 8 + ax];
          if (q * s > 0) break;
          add(ay * 8 + ax);
          if (q) break;
        }
      }
    }
  }
  return n;
}
static void make(Pos &p, const Mv &m) {
  int8_t pc = p.b[m.f]; int s = p.side, t = abs(pc);
  if (t == P && m.t == p.ep) p.b[m.t + (s == 1 ? 8 : -8)] = 0;          // en passant capture
  if (t == K && abs((m.t & 7) - (m.f & 7)) == 2) {                       // castling rook hop
    int row = m.f & ~7;
    if ((m.t & 7) == 6) { p.b[row + 5] = p.b[row + 7]; p.b[row + 7] = 0; }
    else { p.b[row + 3] = p.b[row]; p.b[row] = 0; }
  }
  p.ep = (t == P && abs(m.t - m.f) == 16) ? (m.t + m.f) / 2 : -1;
  p.b[m.t] = m.promo ? s * m.promo : pc; p.b[m.f] = 0;
  if (t == K) p.castle &= s == 1 ? ~3 : ~12;
  if (m.f == 63 || m.t == 63) p.castle &= ~1; if (m.f == 56 || m.t == 56) p.castle &= ~2;
  if (m.f == 7 || m.t == 7) p.castle &= ~4;   if (m.f == 0 || m.t == 0) p.castle &= ~8;
  p.side = -s;
}
static int legal(const Pos &p, Mv *out) {
  Mv tmp[128]; int n = gen(p, tmp), k = 0;
  for (int i = 0; i < n; ++i) { Pos q = p; make(q, tmp[i]); if (!inCheck(q, p.side)) out[k++] = tmp[i]; }
  return k;
}
static int eval(const Pos &p) {     // from side-to-move perspective
  int s = 0;
  for (int i = 0; i < 64; ++i) {
    int8_t q = p.b[i]; if (!q) continue;
    int t = abs(q), v = VAL[t];
    int x = i & 7, y = i >> 3;
    if (t == N || t == B) v += 10 - 3 * (abs(2 * x - 7) + abs(2 * y - 7)) / 2;   // centralise
    if (t == P) v += (q > 0 ? (6 - y) : (y - 1)) * 6;                           // advance
    s += q > 0 ? v : -v;
  }
  return s * p.side;
}
static int nodes;
static int search(const Pos &p, int depth, int alpha, int beta) {
  if (depth == 0) return eval(p);
  Mv mv[128]; int n = gen(p, mv);
  // MVV ordering: captures first
  std::sort(mv, mv + n, [&](const Mv &a, const Mv &b) { return VAL[abs(p.b[a.t])] > VAL[abs(p.b[b.t])]; });
  bool any = false;
  for (int i = 0; i < n; ++i) {
    if (abs(p.b[mv[i].t]) == K) return 30000;          // king capture = previous move illegal
    Pos q = p; make(q, mv[i]);
    if (++nodes % 512 == 0) yield();
    int sc = -search(q, depth - 1, -beta, -alpha);
    if (sc == -30000) continue;                         // illegal move
    any = true;
    if (sc > alpha) alpha = sc;
    if (alpha >= beta) break;
  }
  if (!any) return inCheck(p, p.side) ? -29000 - depth : 0;
  return alpha;
}
static bool cpuMove(const Pos &p, Mv &best) {
  Mv mv[128]; int n = legal(p, mv);
  if (!n) return false;
  int bestS = -100000; nodes = 0;
  for (int i = 0; i < n; ++i) {
    Pos q = p; make(q, mv[i]);
    int s = -search(q, 2, -100000, 100000) + (int)rnd(6);
    if (s > bestS) { bestS = s; best = mv[i]; }
  }
  return true;
}
}  // namespace chess

static void drawPiece(int x, int y, int8_t pc) {
  static const char *L = " PNBRQK";
  bool w = pc > 0; int t = abs(pc);
  uint16_t fill = w ? RGB565(245, 240, 225) : RGB565(30, 30, 40);
  uint16_t edge = w ? RGB565(60, 50, 40) : RGB565(220, 200, 150);
  if (t == chess::P) { tft.fillCircle(x + 13, y + 10, 5, fill); tft.fillTriangle(x + 6, y + 21, x + 20, y + 21, x + 13, y + 11, fill); tft.drawCircle(x + 13, y + 10, 5, edge); }
  else {
    tft.fillRoundRect(x + 4, y + 3, 18, 20, 5, fill);
    tft.drawRoundRect(x + 4, y + 3, 18, 20, 5, edge);
    char s[2] = {L[t], 0};
    tft.setTextColor(edge, fill); tft.setTextDatum(MC_DATUM); tft.drawString(s, x + 13, y + 14, 2); tft.setTextDatum(TL_DATUM);
  }
}

static bool chessGame(AppCtx &c, bool vsCpu) {
  using namespace chess;
  const int CS = 26, OX = 4, OY = 30;
  Pos p; init(p);
  int sel = -1; Mv legalM[128]; int nl = legal(p, legalM);
  int lastF = -1, lastT = -1;
  auto sqDraw = [&](int sq) {
    int x = OX + (sq & 7) * CS, y = OY + (sq >> 3) * CS;
    bool light = ((sq & 7) + (sq >> 3)) % 2 == 0;
    uint16_t col = light ? RGB565(220, 200, 160) : RGB565(140, 100, 70);
    if (sq == lastF || sq == lastT) col = light ? RGB565(220, 220, 110) : RGB565(170, 160, 60);
    if (sq == sel) col = RGB565(80, 170, 220);
    tft.fillRect(x, y, CS, CS, col);
    if (sel >= 0) for (int i = 0; i < nl; ++i) if (legalM[i].f == sel && legalM[i].t == sq) tft.fillCircle(x + 13, y + 13, 4, RGB565(40, 120, 60));
    if (p.b[sq]) drawPiece(x, y, p.b[sq]);
  };
  auto drawAll = [&]() { for (int i = 0; i < 64; ++i) sqDraw(i); };
  auto status = [&](const char *msg, uint16_t col) {
    tft.fillRect(216, 30, 104, 120, C_BG);
    tft.setTextColor(C_TEXT, C_BG);
    tft.drawString(p.side == 1 ? "WHITE" : "BLACK", 220, 34, 4);
    tft.drawString("to move", 220, 60, 2);
    tft.setTextColor(col, C_BG);
    tft.drawString(msg, 220, 84, 2);
    tft.setTextColor(C_DIM, C_BG);
    tft.drawString(vsCpu ? "vs CPU" : "2 players", 220, 110, 2);
  };
  ui::clearBody();
  ui::button(218, 160, 98, 30, "NEW GAME");
  ui::button(218, 196, 98, 30, "MENU");
  drawAll(); status("", C_TEXT);
  while (true) {
    if (nl == 0) {
      status(inCheck(p, p.side) ? "CHECKMATE" : "STALEMATE", C_ERR);
      audio::tone(0, 220, 100, audio::TRIANGLE, 600, 600);
    }
    if (vsCpu && p.side == -1 && nl) {
      status("thinking...", C_WARN);
      Mv m; cpuMove(p, m);
      lastF = m.f; lastT = m.t; make(p, m); sel = -1;
      nl = legal(p, legalM); drawAll();
      audio::beep(500, 40);
      status(inCheck(p, p.side) ? "CHECK!" : "", C_ERR);
      continue;
    }
    if (!c.loop()) return false;
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 218, 160, 98, 30)) { init(p); sel = lastF = lastT = -1; nl = legal(p, legalM); drawAll(); status("", C_TEXT); continue; }
    if (ui::inRect(t.sx, t.sy, 218, 196, 98, 30)) return true;
    int gx = (t.sx - OX) / CS, gy = (t.sy - OY) / CS;
    if (t.sx < OX || t.sy < OY || gx > 7 || gy > 7 || !nl) continue;
    int sq = gy * 8 + gx;
    if (sel >= 0) {
      for (int i = 0; i < nl; ++i) if (legalM[i].f == sel && legalM[i].t == sq) {
        lastF = sel; lastT = sq; make(p, legalM[i]); sel = -1;
        nl = legal(p, legalM); drawAll();
        audio::beep(800, 40);
        status(inCheck(p, p.side) ? "CHECK!" : "", C_ERR);
        goto next;
      }
    }
    {
      int old = sel;
      sel = (p.b[sq] * p.side > 0 && sq != old) ? sq : -1;
      drawAll();
    }
  next:;
  }
}

void app_board(AppCtx &c) {
  while (true) {
    ui::clearBody();
    ui::centerText("Choose a game", 160, 44, C_DIM, C_BG, 2);
    ui::button(20, 60, 135, 70, "Tic-Tac-Toe", RGB565(0, 110, 160), TFT_WHITE, 2);
    ui::button(165, 60, 135, 70, "Chess", RGB565(120, 80, 40), TFT_WHITE, 4);
    ui::button(20, 140, 135, 40, "vs CPU", C_PANEL2);
    ui::button(165, 140, 135, 40, "2 players", C_PANEL2);
    bool vsCpu = true;
    auto modeDraw = [&]() {
      tft.drawRoundRect(20, 140, 135, 40, 5, vsCpu ? C_OK : C_PANEL2);
      tft.drawRoundRect(165, 140, 135, 40, 5, !vsCpu ? C_OK : C_PANEL2);
    };
    modeDraw();
    while (true) {
      if (!c.loop()) return;
      Touch &t = *c.t;
      if (!t.tap) continue;
      if (ui::inRect(t.sx, t.sy, 20, 140, 135, 40)) { vsCpu = true; modeDraw(); }
      else if (ui::inRect(t.sx, t.sy, 165, 140, 135, 40)) { vsCpu = false; modeDraw(); }
      else if (ui::inRect(t.sx, t.sy, 20, 60, 135, 70)) { if (!ticTacToe(c, vsCpu)) return; break; }
      else if (ui::inRect(t.sx, t.sy, 165, 60, 135, 70)) { if (!chessGame(c, vsCpu)) return; break; }
    }
  }
}
