// ============================================================================
//  KRIVI OS - Bluetooth MP3 Music Player  +  FTP server        (app_btaudio.cpp)
//
//  Three tabs in one app:
//    BLUETOOTH  scan for headphones / speakers, tap one to pair + connect
//               (the last device is reconnected automatically next time)
//    PLAYER     plays the .mp3 files in /music on the SD card to the headset
//    FTP SERVER upload / download / delete music from a PC or phone over WiFi
//
//  Libraries (Arduino Library Manager):
//    "ESP32-A2DP"   by pschatzmann    (Bluetooth A2DP source)
//    "ESP8266Audio" by Earle Philhower (MP3 decoder; used only for decoding)
//  Needs a Bluedroid build: it cannot share a build with NimBLE apps.
//
//  Bluetooth and WiFi are never on at the same time (not enough RAM on a plain
//  ESP32): starting the FTP server turns Bluetooth off, and going back to the
//  BLUETOOTH tab turns the FTP server + WiFi off.
//
//  FTP login:  user "krivi"  password "krivi"  (change in /sys/settings.json:
//              "ftp": {"user": "...", "pass": "..."} )   port 21, passive mode.
//  Optional manifest param:  "dir": "/music"
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <SD.h>
#include "BluetoothA2DPSource.h"
#include "src/helix/mp3dec.h"     // in-tree Helix MP3 decoder (same one app_mp3 uses)
#include <vector>

// ============================================================================
//  FTP server (minimal, passive mode only, SD card)
// ============================================================================
namespace ftp {

static const uint16_t PASV_PORT = 50021;
static WiFiServer ctl(21), pasv(PASV_PORT);
static WiFiClient cc, dc;
static bool running = false, authed = false;
static String cwd = "/", rnfr, line, user = "krivi", pass = "krivi", loginName;
enum Xfer { X_NONE, X_STOR, X_RETR };
static Xfer xf = X_NONE;
static File xfile;
static uint32_t xbytes = 0, xlast = 0;
static String xname;
static uint8_t *buf = nullptr;
static const size_t BUFSZ = 2048;

static void reply(int code, const char *text) { cc.printf("%d %s\r\n", code, text); }

static String norm(const String &base, const String &arg) {
  String p = arg.startsWith("/") ? arg : (base + "/" + arg);
  std::vector<String> parts;
  int i = 0;
  while (i <= (int)p.length()) {
    int j = p.indexOf('/', i); if (j < 0) j = p.length();
    String seg = p.substring(i, j);
    if (seg.length() && seg != ".") {
      if (seg == "..") { if (!parts.empty()) parts.pop_back(); }
      else parts.push_back(seg);
    }
    i = j + 1;
  }
  String out;
  for (auto &s : parts) { out += "/"; out += s; }
  if (!out.length()) out = "/";
  return out;
}
static String baseName(const String &p) { int s = p.lastIndexOf('/'); return s >= 0 ? p.substring(s + 1) : p; }

static bool begin(const String &u, const String &p, const char *startDir) {
  if (running) return true;
  buf = (uint8_t *)malloc(BUFSZ);
  if (!buf) return false;
  user = u; pass = p; cwd = startDir; xf = X_NONE; authed = false;
  ctl.begin(); pasv.begin();
  running = true;
  return true;
}
static void end() {
  if (!running) return;
  if (xfile) xfile.close();
  if (dc) dc.stop();
  if (cc) cc.stop();
  ctl.end(); pasv.end();
  free(buf); buf = nullptr;
  xf = X_NONE; running = false;
}

static bool openData() {
  if (dc) dc.stop();
  uint32_t t0 = millis();
  while (!pasv.hasClient() && millis() - t0 < 4000) delay(5);
  if (!pasv.hasClient()) return false;
  dc = pasv.available();
  return dc.connected();
}

static void xferDone(int code, const char *msg) {
  if (xfile) xfile.close();
  if (dc) dc.stop();
  xf = X_NONE;
  reply(code, msg);
}

static void doList(const String &arg, bool namesOnly) {
  String p = (arg.length() && arg[0] != '-') ? norm(cwd, arg) : cwd;
  File d = SD.open(p.c_str());
  if (!d || !d.isDirectory()) { if (d) d.close(); reply(550, "No such directory"); return; }
  reply(150, "Here comes the listing");
  if (!openData()) { d.close(); reply(425, "Cannot open data connection"); return; }
  File f;
  while ((f = d.openNextFile())) {
    String nm = baseName(String(f.name()));
    if (namesOnly) dc.printf("%s\r\n", nm.c_str());
    else dc.printf("%s 1 ftp ftp %10u Jan 01 00:00 %s\r\n", f.isDirectory() ? "drwxr-xr-x" : "-rw-r--r--", (unsigned)f.size(), nm.c_str());
    f.close();
  }
  d.close();
  dc.stop();
  reply(226, "Directory send OK");
}

static void handle(String l) {
  l.trim();
  if (!l.length()) return;
  int sp = l.indexOf(' ');
  String cmd = sp < 0 ? l : l.substring(0, sp);
  String arg = sp < 0 ? String("") : l.substring(sp + 1);
  cmd.toUpperCase(); arg.trim();

  if (cmd == "USER") { loginName = arg; authed = false; reply(331, "Password required"); return; }
  if (cmd == "PASS") { authed = (loginName == user && arg == pass); reply(authed ? 230 : 530, authed ? "Logged in" : "Login incorrect"); return; }
  if (cmd == "QUIT") { reply(221, "Goodbye"); cc.stop(); return; }
  if (cmd == "NOOP") { reply(200, "OK"); return; }
  if (!authed) { reply(530, "Please log in"); return; }

  if (cmd == "SYST") reply(215, "UNIX Type: L8");
  else if (cmd == "FEAT") cc.print("211-Features:\r\n SIZE\r\n211 End\r\n");
  else if (cmd == "OPTS" || cmd == "TYPE" || cmd == "MODE" || cmd == "STRU") reply(200, "OK");
  else if (cmd == "PWD" || cmd == "XPWD") cc.printf("257 \"%s\" is the current directory\r\n", cwd.c_str());
  else if (cmd == "CWD" || cmd == "CDUP") {
    String p = (cmd == "CDUP") ? norm(cwd, "..") : norm(cwd, arg);
    File d = SD.open(p.c_str());
    if (d && d.isDirectory()) { cwd = p; reply(250, "Directory changed"); } else reply(550, "No such directory");
    if (d) d.close();
  }
  else if (cmd == "PASV") {
    if (dc) dc.stop();
    IPAddress ip = WiFi.localIP();
    cc.printf("227 Entering Passive Mode (%d,%d,%d,%d,%d,%d)\r\n", ip[0], ip[1], ip[2], ip[3], PASV_PORT >> 8, PASV_PORT & 255);
  }
  else if (cmd == "LIST") doList(arg, false);
  else if (cmd == "NLST") doList(arg, true);
  else if (cmd == "RETR") {
    String p = norm(cwd, arg);
    xfile = SD.open(p.c_str());
    if (!xfile || xfile.isDirectory()) { if (xfile) xfile.close(); reply(550, "File not found"); return; }
    reply(150, "Sending file");
    if (!openData()) { xfile.close(); reply(425, "Cannot open data connection"); return; }
    xf = X_RETR; xbytes = 0; xname = baseName(p); xlast = millis();
  }
  else if (cmd == "STOR" || cmd == "APPE") {
    String p = norm(cwd, arg);
    xfile = SD.open(p.c_str(), cmd == "APPE" ? FILE_APPEND : FILE_WRITE);
    if (!xfile) { reply(550, "Cannot create file"); return; }
    reply(150, "OK to send data");
    if (!openData()) { xfile.close(); reply(425, "Cannot open data connection"); return; }
    xf = X_STOR; xbytes = 0; xname = baseName(p); xlast = millis();
  }
  else if (cmd == "DELE") reply(SD.remove(norm(cwd, arg).c_str()) ? 250 : 550, "Delete");
  else if (cmd == "MKD" || cmd == "XMKD") reply(SD.mkdir(norm(cwd, arg).c_str()) ? 257 : 550, "Make directory");
  else if (cmd == "RMD" || cmd == "XRMD") reply(SD.rmdir(norm(cwd, arg).c_str()) ? 250 : 550, "Remove directory");
  else if (cmd == "SIZE") {
    File f = SD.open(norm(cwd, arg).c_str());
    if (f && !f.isDirectory()) cc.printf("213 %u\r\n", (unsigned)f.size()); else reply(550, "No such file");
    if (f) f.close();
  }
  else if (cmd == "RNFR") { rnfr = norm(cwd, arg); reply(350, "Ready for RNTO"); }
  else if (cmd == "RNTO") { reply(SD.rename(rnfr.c_str(), norm(cwd, arg).c_str()) ? 250 : 550, "Rename"); }
  else if (cmd == "ABOR") { if (xf != X_NONE) xferDone(426, "Transfer aborted"); else reply(226, "OK"); }
  else if (cmd == "PORT" || cmd == "EPSV" || cmd == "EPRT") reply(502, "Use passive mode (PASV)");
  else reply(502, "Command not implemented");
}

static void pump() {
  if (xf == X_STOR) {
    int guard = 0;
    while (dc.available() && guard++ < 4) {
      int n = dc.read(buf, BUFSZ);
      if (n > 0) { xfile.write(buf, n); xbytes += n; xlast = millis(); }
    }
    if (!dc.connected() && !dc.available()) xferDone(226, "Upload complete");
    else if (millis() - xlast > 20000) xferDone(426, "Transfer timed out");
  } else if (xf == X_RETR) {
    int n = xfile.read(buf, BUFSZ);
    if (n <= 0) { xferDone(226, "Download complete"); return; }
    int off = 0; uint32_t t0 = millis();
    while (off < n && dc.connected() && millis() - t0 < 5000) {
      int w = dc.write(buf + off, n - off);
      if (w > 0) { off += w; t0 = millis(); } else delay(1);
    }
    if (off < n) { xferDone(426, "Connection lost"); return; }
    xbytes += n; xlast = millis();
  }
}

// call often; never blocks for long (except waiting for a data connection)
static void service() {
  if (!running) return;
  if (!cc || !cc.connected()) {
    if (cc) cc.stop();
    if (xf != X_NONE) { if (xfile) xfile.close(); if (dc) dc.stop(); xf = X_NONE; }
    if (ctl.hasClient()) { cc = ctl.available(); authed = false; line = ""; reply(220, "KRIVI OS FTP ready"); }
    return;
  }
  if (xf != X_NONE) pump();
  int guard = 0;
  while (cc.connected() && cc.available() && guard++ < 256) {
    char ch = cc.read();
    if (ch == '\n') { String l = line; line = ""; handle(l); }
    else if (ch != '\r' && line.length() < 200) line += ch;
  }
}

static void status(char *out, size_t n) {
  if (!running) { snprintf(out, n, "stopped"); return; }
  if (xf == X_STOR) snprintf(out, n, "receiving %.18s  %u KB", xname.c_str(), (unsigned)(xbytes / 1024));
  else if (xf == X_RETR) snprintf(out, n, "sending %.20s  %u KB", xname.c_str(), (unsigned)(xbytes / 1024));
  else if (cc && cc.connected()) snprintf(out, n, "client connected");
  else snprintf(out, n, "waiting for a client");
}

}  // namespace ftp

// ============================================================================
//  Bluetooth A2DP source + MP3 decoder
// ============================================================================
namespace btmp3 {

static BluetoothA2DPSource a2dp;

// Stereo ring buffer between the MP3 decoder and the Bluetooth task.
// The decoder writes at the file's sample rate; the BT callback resamples
// (linear) to the 44.1 kHz A2DP wants, so 44.1 / 48 / 32 / 22 kHz files all work.
static const uint32_t RING = 4096, MASK = RING - 1;       // frames (16 KB, heap-allocated)
static int16_t *s_ring = nullptr;                         // interleaved L,R
static volatile uint32_t s_head = 0, s_tail = 0, s_consumed = 0;
static volatile float s_step = 1.0f, s_phase = 0;
static volatile bool s_play = false, s_flush = false;
static volatile int s_gain = 160;                         // 0..256
static volatile uint32_t s_rate = 44100;

static uint32_t ringFree() { return (s_tail - s_head - 1) & MASK; }

static int32_t a2dpFrames(Frame *f, int32_t n) {
  int16_t *ring = s_ring;
  if (!ring) { for (int i = 0; i < n; ++i) { f[i].channel1 = 0; f[i].channel2 = 0; } return n; }
  uint32_t tail = s_tail, used = 0;
  float ph = s_phase; const float step = s_step; const int g = s_gain; const bool play = s_play;
  if (s_flush) { tail = s_head; ph = 0; s_flush = false; }
  for (int i = 0; i < n; ++i) {
    uint32_t head = s_head;
    if (!play || ((head - tail) & MASK) < 2) { f[i].channel1 = 0; f[i].channel2 = 0; continue; }   // pause / underrun
    uint32_t t1 = (tail + 1) & MASK;
    int32_t l0 = ring[tail * 2], r0 = ring[tail * 2 + 1], l1 = ring[t1 * 2], r1 = ring[t1 * 2 + 1];
    int32_t l = l0 + (int32_t)((l1 - l0) * ph), r = r0 + (int32_t)((r1 - r0) * ph);
    f[i].channel1 = (int16_t)((l * g) >> 8);
    f[i].channel2 = (int16_t)((r * g) >> 8);
    ph += step;
    while (ph >= 1.0f) { ph -= 1.0f; tail = (tail + 1) & MASK; ++used; if (tail == head) { ph = 0; break; } }
  }
  s_tail = tail; s_phase = ph; s_consumed = s_consumed + used;
  return n;
}

// ---- in-tree Helix MP3 decoder -> stereo ring buffer ----------------------
static File        s_mp3file;
static HMP3Decoder s_dec      = nullptr;
static uint8_t    *s_inbuf    = nullptr;      // compressed input (2*MAINBUF_SIZE)
static int16_t    *s_pcm      = nullptr;      // one decoded frame
static int         s_bytesLeft = 0;
static uint8_t    *s_rp       = nullptr;
static bool        s_eof      = false;
static bool        s_hasTrack = false;
static uint32_t    s_fileSize = 0;

// push one interleaved stereo frame into the ring (caller checks room first)
static inline bool ringPush(int16_t l, int16_t r) {
  uint32_t h = s_head, nh = (h + 1) & MASK;
  if (nh == s_tail) return false;             // full
  s_ring[h * 2] = l; s_ring[h * 2 + 1] = r;
  s_head = nh;
  return true;
}

// ---- discovery results (BT task -> UI)
static const int MAXDEV = 12;
static char s_names[MAXDEV][32];
static int  s_rssi[MAXDEV];
static volatile int s_count = 0;
static char s_target[32] = "";          // device we are trying to connect to
static char s_conn[32] = "";            // device we are connected to
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;

static bool ssidCb(const char *ssid, esp_bd_addr_t addr, int rssi) {
  if (ssid && ssid[0]) {
    portENTER_CRITICAL(&s_mux);
    bool found = false;
    for (int i = 0; i < s_count; ++i) if (!strcmp(s_names[i], ssid)) { s_rssi[i] = rssi; found = true; break; }
    if (!found && s_count < MAXDEV) { strlcpy(s_names[s_count], ssid, 32); s_rssi[s_count] = rssi; s_count++; }
    portEXIT_CRITICAL(&s_mux);
  }
  return s_target[0] && ssid && !strcmp(ssid, s_target);  // true = connect to this one
}

static bool s_btOn = false;

static bool btConnected() { return s_btOn && a2dp.is_connected(); }

static bool btBegin() {
  if (s_btOn) return true;
  if (ESP.getFreeHeap() < 75000) return false;
  s_ring  = (int16_t *)malloc(RING * 2 * sizeof(int16_t));
  s_inbuf = (uint8_t *)malloc(2 * MAINBUF_SIZE);
  s_pcm   = (int16_t *)malloc(MAX_NSAMP * MAX_NCHAN * MAX_NGRAN * sizeof(int16_t));
  if (!s_dec) s_dec = MP3InitDecoder();
  if (!s_ring || !s_inbuf || !s_pcm || !s_dec) {
    free(s_ring);  s_ring  = nullptr;
    free(s_inbuf); s_inbuf = nullptr;
    free(s_pcm);   s_pcm   = nullptr;
    if (s_dec) { MP3FreeDecoder(s_dec); s_dec = nullptr; }
    return false;
  }
  s_head = s_tail = 0; s_phase = 0; s_consumed = 0; s_play = false; s_flush = false; s_count = 0;
  s_target[0] = 0; s_conn[0] = 0;
  s_hasTrack = false; s_eof = false; s_bytesLeft = 0; s_rp = s_inbuf;
  a2dp.set_ssid_callback(ssidCb);
  a2dp.set_data_callback_in_frames(a2dpFrames);
  a2dp.set_auto_reconnect(false);
  a2dp.set_volume(127);                   // volume is applied by our own gain
  a2dp.start();                           // starts discovery
  s_btOn = true;
  return true;
}

static void stopTrack() {
  s_play = false;
  s_hasTrack = false;
  if (s_mp3file) s_mp3file.close();
  s_bytesLeft = 0; s_rp = s_inbuf; s_eof = false;
  s_flush = true;
}

// skip an ID3v2 tag at the start of the file so the sync search starts clean
static void skipID3(File &f) {
  uint8_t h[10];
  if (f.read(h, 10) == 10 && h[0] == 'I' && h[1] == 'D' && h[2] == '3') {
    uint32_t sz = ((uint32_t)(h[6] & 0x7f) << 21) | ((uint32_t)(h[7] & 0x7f) << 14) |
                  ((uint32_t)(h[8] & 0x7f) << 7)  |  (uint32_t)(h[9] & 0x7f);
    f.seek(10 + sz);
  } else f.seek(0);
}

static bool startTrack(const String &path) {
  stopTrack();
  s_mp3file = SD.open(path.c_str());
  if (!s_mp3file || s_mp3file.isDirectory()) { if (s_mp3file) s_mp3file.close(); return false; }
  s_fileSize = s_mp3file.size();
  skipID3(s_mp3file);
  s_bytesLeft = 0; s_rp = s_inbuf; s_eof = false;
  s_consumed = 0; s_rate = 44100; s_step = 1.0f; s_flush = true;
  s_hasTrack = true;
  uint32_t t0 = millis();
  while (s_flush && millis() - t0 < 80) delay(2);          // let the BT task drop the old audio first
  s_play = true;
  return true;
}

// decode as many frames as the ring has room for; returns false when the track
// has fully finished (eof reached AND the ring has drained).
static bool mp3Pump() {
  if (!s_hasTrack) return true;
  while (!s_eof && ringFree() > (uint32_t)(MAX_NSAMP * MAX_NGRAN + 8)) {
    if (s_bytesLeft < MAINBUF_SIZE && !s_eof) {
      memmove(s_inbuf, s_rp, s_bytesLeft);
      int n = s_mp3file.read(s_inbuf + s_bytesLeft, 2 * MAINBUF_SIZE - s_bytesLeft);
      if (n > 0) s_bytesLeft += n;
      s_rp = s_inbuf;
      if (n <= 0 && s_bytesLeft < 4) { s_eof = true; break; }
    }
    int off = MP3FindSyncWord(s_rp, s_bytesLeft);
    if (off < 0) { s_bytesLeft = 0; continue; }
    s_rp += off; s_bytesLeft -= off;
    int err = MP3Decode(s_dec, &s_rp, &s_bytesLeft, s_pcm, 0);
    if (err == ERR_MP3_INDATA_UNDERFLOW || err == ERR_MP3_MAINDATA_UNDERFLOW) {
      if (s_mp3file.available() == 0 && err == ERR_MP3_INDATA_UNDERFLOW) { s_eof = true; break; }
      if (s_bytesLeft >= MAINBUF_SIZE) { s_rp++; s_bytesLeft--; }
      continue;
    }
    if (err) { if (s_bytesLeft > 0) { s_rp++; s_bytesLeft--; } continue; }
    MP3FrameInfo fi; MP3GetLastFrameInfo(s_dec, &fi);
    if (fi.samprate && fi.samprate != (int)s_rate) { s_rate = fi.samprate; s_step = fi.samprate / 44100.0f; }
    int chans  = max(1, fi.nChans);
    int frames = fi.outputSamps / chans;
    if (chans == 2) {
      for (int i = 0; i < frames; ++i) if (!ringPush(s_pcm[2 * i], s_pcm[2 * i + 1])) break;
    } else {
      for (int i = 0; i < frames; ++i) if (!ringPush(s_pcm[i], s_pcm[i])) break;
    }
  }
  if (s_eof && ((s_head - s_tail) & MASK) < 64) return false;   // finished
  return true;
}

static void btEnd() {
  if (!s_btOn) return;
  stopTrack();
  a2dp.end(false);                        // false: keep the ability to start Bluetooth again
  if (s_dec) { MP3FreeDecoder(s_dec); s_dec = nullptr; }
  free(s_ring);  s_ring  = nullptr;
  free(s_inbuf); s_inbuf = nullptr;
  free(s_pcm);   s_pcm   = nullptr;
  s_target[0] = 0; s_conn[0] = 0;
  s_btOn = false;
}

}  // namespace btmp3

// ============================================================================
//  The app
// ============================================================================
void app_btaudio(AppCtx &c) {
  using namespace btmp3;
  c.header("bt mp3 + ftp");
  ui::clearBody();
  if (!sys::sdOk) { ui::msgBox("NO SD CARD", "Music is played from the SD card.\nInsert one and relaunch."); return; }

  const String dir = c.pStr("dir", "/music");
  SD.mkdir(dir.c_str());

  // ---- layout
  const int RH = 25, Y0 = 76, ROWS = 5;                    // bluetooth list
  const int LY = 120, LRH = 24, LROWS = 3;                 // track list
  const int BY = 206, BH = 32;                             // bottom bar

  // ---- state
  int tab = 0;                                             // 0 bluetooth, 1 player, 2 ftp
  int btTop = 0, trTop = 0, cur = -1, mode = 0;            // mode: 0 all, 1 shuffle, 2 repeat one
  int vol = 80;                                            // 0..127
  bool paused = false, wasConn = false;
  uint32_t connT0 = 0, lastUi = 0, lastScan = 0;
  std::vector<String> tracks;
  static const char *MODE_L[3] = {"ALL", "SHUF", "ONE"};

  s_gain = (vol * 256) / 127;

  auto rescan = [&]() { tracks = sys::listDir(dir.c_str(), ".mp3"); if (trTop >= (int)tracks.size()) trTop = 0; };
  auto titleOf = [&](int i) -> String { String n = (i >= 0 && i < (int)tracks.size()) ? tracks[i] : String(""); if (n.length() > 4) n.remove(n.length() - 4); return n; };

  // ---------------------------------------------------------------- drawing
  auto drawTabs = [&]() {
    static const char *L[3] = {"BLUETOOTH", "PLAYER", "FTP SERVER"};
    for (int i = 0; i < 3; ++i)
      ui::button(4 + i * 106, 28, 102, 22, L[i], tab == i ? C_ACCENT : C_PANEL2, tab == i ? TFT_BLACK : C_TEXT, 1);
  };
  auto drawStatus = [&]() {
    tft.fillRect(0, 52, 320, 20, C_BG);
    char s[56]; uint16_t col;
    if (btConnected()) { snprintf(s, sizeof(s), "BT: connected - %.26s", s_conn[0] ? s_conn : "device"); col = C_OK; }
    else if (s_btOn && s_target[0]) { snprintf(s, sizeof(s), "BT: connecting to %.24s...", s_target); col = C_WARN; }
    else if (s_btOn) { snprintf(s, sizeof(s), "BT: not connected - tap a device"); col = C_WARN; }
    else { snprintf(s, sizeof(s), "BT: off (FTP mode)"); col = C_DIM; }
    tft.fillCircle(12, 62, 4, col);
    tft.setTextColor(col, C_BG); tft.drawString(s, 22, 58, 1);
  };
  auto drawBtList = [&]() {
    tft.fillRect(0, Y0 - 2, 320, ROWS * RH + 4, C_BG);
    if (!s_btOn) { ui::centerText("Bluetooth is off", 160, Y0 + 40, C_DIM, C_BG, 2); return; }
    int n; portENTER_CRITICAL(&s_mux); n = s_count; portEXIT_CRITICAL(&s_mux);
    if (!n) {
      ui::centerText("scanning for devices...", 160, Y0 + 30, C_DIM, C_BG, 2);
      ui::centerText("put your headphones in pairing mode", 160, Y0 + 58, C_DIM, C_BG, 1);
    }
    for (int i = 0; i < ROWS && btTop + i < n; ++i) {
      char nm[32]; int rssi;
      portENTER_CRITICAL(&s_mux); strlcpy(nm, s_names[btTop + i], 32); rssi = s_rssi[btTop + i]; portEXIT_CRITICAL(&s_mux);
      int y = Y0 + i * RH;
      bool isConn = btConnected() && !strcmp(nm, s_conn);
      uint16_t bg = isConn ? RGB565(10, 60, 40) : C_PANEL;
      tft.fillRoundRect(4, y, 312, RH - 3, 4, bg);
      int bars = constrain((rssi + 100) / 12, 0, 4);
      for (int b = 0; b < 4; ++b) tft.fillRect(10 + b * 5, y + 16 - b * 3, 4, 4 + b * 3, b < bars ? C_OK : C_PANEL2);
      char b[24]; snprintf(b, sizeof(b), "%.20s", nm);
      tft.setTextColor(C_TEXT, bg); tft.drawString(b, 38, y + 4, 2);
      if (isConn) { tft.setTextColor(C_OK, bg); tft.drawString("CONNECTED", 252, y + 8, 1); }
    }
  };
  auto drawBtBar = [&]() {
    ui::button(4, BY, 90, BH, "SCROLL", C_PANEL2, C_TEXT, 1);
    ui::button(98, BY, 90, BH, "RESCAN", C_PANEL2, C_TEXT, 1);
    ui::button(192, BY, 124, BH, "DISCONNECT", RGB565(150, 40, 40), TFT_WHITE, 1);
  };
  auto drawNow = [&]() {
    tft.fillRect(0, 74, 320, 18, C_BG);
    char s[40]; snprintf(s, sizeof(s), "%.34s", cur >= 0 ? titleOf(cur).c_str() : "no track playing");
    tft.setTextColor(cur >= 0 ? C_TEXT : C_DIM, C_BG); tft.drawString(s, 10, 75, 2);
  };
  auto drawProgress = [&]() {
    float frac = (s_hasTrack && s_fileSize) ? (float)s_mp3file.position() / (float)s_fileSize : 0;
    ui::bar(10, 94, 300, 8, frac, C_ACCENT, C_PANEL);
    uint32_t sec = s_rate ? s_consumed / s_rate : 0;
    char s[48]; snprintf(s, sizeof(s), "%u:%02u   %d%%   vol %d%%   %s", (unsigned)(sec / 60), (unsigned)(sec % 60), (int)(frac * 100), vol * 100 / 127, MODE_L[mode]);
    tft.fillRect(0, 104, 320, 12, C_BG);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 10, 106, 1);
  };
  auto drawTracks = [&]() {
    tft.fillRect(0, LY - 2, 320, 86, C_BG);
    int n = (int)tracks.size();
    if (!n) {
      ui::centerText("no .mp3 files in the music folder", 140, LY + 24, C_DIM, C_BG, 1);
      ui::centerText("use the FTP SERVER tab to upload", 140, LY + 40, C_DIM, C_BG, 1);
    }
    for (int i = 0; i < LROWS && trTop + i < n; ++i) {
      int idx = trTop + i, y = LY + i * LRH;
      uint16_t bg = (idx == cur) ? RGB565(10, 60, 90) : C_PANEL;
      tft.fillRoundRect(4, y, 270, LRH - 2, 4, bg);
      char s[40]; snprintf(s, sizeof(s), "%2d %.27s", idx + 1, titleOf(idx).c_str());
      tft.setTextColor(idx == cur ? C_ACCENT : C_TEXT, bg); tft.drawString(s, 10, y + 4, 2);
    }
    ui::button(278, LY, 38, 34, "UP", C_PANEL2, C_TEXT, 1);
    ui::button(278, LY + 38, 38, 34, "DN", C_PANEL2, C_TEXT, 1);
  };
  auto drawControls = [&]() {
    bool playing = s_hasTrack && !paused;
    ui::button(4, BY, 50, BH, "<<", C_PANEL2, C_TEXT, 2);
    ui::button(56, BY, 50, BH, playing ? "||" : "PLAY", playing ? C_WARN : C_OK, TFT_BLACK, playing ? 2 : 1);
    ui::button(108, BY, 50, BH, ">>", C_PANEL2, C_TEXT, 2);
    ui::button(160, BY, 50, BH, "VOL-", C_PANEL2, C_TEXT, 1);
    ui::button(212, BY, 50, BH, "VOL+", C_PANEL2, C_TEXT, 1);
    ui::button(264, BY, 52, BH, MODE_L[mode], C_PANEL2, C_ACCENT, 1);
  };
  auto drawFtp = [&]() {
    tft.fillRect(0, 74, 320, 130, C_BG);
    tft.setTextColor(ftp::running ? C_OK : C_DIM, C_BG);
    tft.drawString(ftp::running ? "FTP SERVER RUNNING" : "FTP SERVER STOPPED", 10, 78, 2);
    char s[64];
    if (ftp::running) {
      tft.setTextColor(C_ACCENT, C_BG);
      snprintf(s, sizeof(s), "ftp://%s:21", WiFi.localIP().toString().c_str()); tft.drawString(s, 10, 100, 2);
      tft.setTextColor(C_TEXT, C_BG);
      snprintf(s, sizeof(s), "user: %s   pass: %s", ftp::user.c_str(), ftp::pass.c_str()); tft.drawString(s, 10, 122, 1);
      snprintf(s, sizeof(s), "folder: %s   (passive mode)", dir.c_str()); tft.drawString(s, 10, 136, 1);
    } else {
      tft.setTextColor(C_DIM, C_BG);
      tft.drawString("Upload MP3s from a PC or phone over WiFi.", 10, 102, 1);
      tft.drawString("WiFi comes from Settings. Starting the server", 10, 118, 1);
      tft.drawString("turns Bluetooth off (not enough RAM for both).", 10, 130, 1);
    }
  };
  auto drawFtpLive = [&]() {
    char s[64]; ftp::status(s, sizeof(s));
    tft.fillRect(0, 160, 320, 14, C_BG);
    tft.setTextColor(C_WARN, C_BG); tft.drawString(s, 10, 162, 1);
  };
  auto drawFtpBar = [&]() {
    ui::button(4, BY, 312, BH, ftp::running ? "STOP FTP SERVER" : "START FTP SERVER", ftp::running ? RGB565(150, 40, 40) : RGB565(0, 110, 60), TFT_WHITE, 2);
  };
  auto redraw = [&]() {
    ui::clearBody();
    drawTabs(); drawStatus();
    if (tab == 0) { drawBtList(); drawBtBar(); }
    else if (tab == 1) { drawNow(); drawProgress(); drawTracks(); drawControls(); }
    else { drawFtp(); drawFtpLive(); drawFtpBar(); }
  };

  // ---------------------------------------------------------------- actions
  auto startBt = [&]() -> bool {
    if (s_btOn) return true;
    if (ftp::running) { ftp::end(); sys::radiosOff(); }
    sys::radiosOff();
    if (!btBegin()) {
      char m[96]; snprintf(m, sizeof(m), "Bluetooth needs ~75 KB free.\nOnly %u KB available. Reboot and try again.", (unsigned)(ESP.getFreeHeap() / 1024));
      ui::msgBox("NOT ENOUGH MEMORY", m);
      c.header("bt mp3 + ftp");
      return false;
    }
    return true;
  };
  auto playIdx = [&](int i) {
    if (i < 0 || i >= (int)tracks.size()) return;
    if (!btConnected()) { ui::toast("connect a Bluetooth device first", C_WARN); tab = 0; redraw(); return; }
    String p = dir + "/" + tracks[i];
    if (startTrack(p)) {
      cur = i; paused = false;
      trTop = constrain(i - 1, 0, max(0, (int)tracks.size() - LROWS));
    } else ui::toast("cannot play this file (or no RAM)", C_ERR);
    if (tab == 1) { drawNow(); drawProgress(); drawTracks(); drawControls(); }
  };
  auto nextIdx = [&](bool forward) -> int {
    int n = (int)tracks.size(); if (!n) return -1;
    if (mode == 1) return (int)rnd(n);
    return forward ? (cur + 1) % n : (cur - 1 + n) % n;
  };
  auto startFtp = [&]() {
    if (ftp::running) return;
    if (btConnected() && !ui::confirm("FTP SERVER", "Bluetooth music will stop. Continue?")) { c.header("bt mp3 + ftp"); return; }
    c.header("bt mp3 + ftp");
    btEnd();                                              // frees ~70 KB for WiFi
    cur = -1; paused = false;
    ui::clearBody(); ui::centerText("Joining WiFi...", 160, 120, C_WARN, C_BG, 2);
    String fu = sys::cfg["ftp"]["user"] | "krivi", fp = sys::cfg["ftp"]["pass"] | "krivi";
    if (!sys::wifiConnect(12000, false)) { ui::toast("WiFi failed - set it up in Settings", C_ERR); delay(1200); }
    else if (!ftp::begin(fu, fp, dir.c_str())) ui::toast("not enough RAM for FTP", C_ERR);
    redraw();
  };
  auto stopFtp = [&]() { ftp::end(); sys::radiosOff(); redraw(); };

  // ---------------------------------------------------------------- startup
  if (!startBt()) tab = 2;
  else {
    String last = sys::cfg["bt"]["last"] | "";
    if (last.length()) { strlcpy(s_target, last.c_str(), 32); connT0 = millis(); }   // auto-reconnect
  }
  rescan();
  redraw();

  // ---------------------------------------------------------------- main loop
  while (c.loop()) {
    bool conn = btConnected();

    if (conn != wasConn) {                                  // connection changed
      wasConn = conn;
      if (conn) {
        if (s_target[0]) strlcpy(s_conn, s_target, 32);
        s_target[0] = 0;
        if (s_conn[0]) { sys::cfg["bt"]["last"] = String(s_conn); sys::saveSettings(); }
        tab = 1; rescan();
      } else {
        s_conn[0] = 0;
        if (s_hasTrack) { paused = true; s_play = false; }       // headset dropped: pause
      }
      redraw();
    }
    if (s_btOn && !conn && s_target[0] && millis() - connT0 > 30000) {   // gave up
      s_target[0] = 0; ui::toast("device not found - is it on?", C_ERR); redraw();
    }

    // ---- decoder pump (keeps the Bluetooth ring topped up)
    bool ended = false;
    if (s_hasTrack && !paused && conn) {
      if (!mp3Pump()) ended = true;
    }
    if (ended) {
      int nx = (mode == 2) ? cur : nextIdx(true);
      if (nx >= 0) playIdx(nx); else { stopTrack(); cur = -1; if (tab == 1) redraw(); }
    }

    // ---- FTP
    if (ftp::running) ftp::service();

    // ---- periodic UI refresh
    if (millis() - lastUi > 500) {
      lastUi = millis();
      if (tab == 1 && s_hasTrack) drawProgress();
      else if (tab == 2 && ftp::running) drawFtpLive();
    }
    if (tab == 0 && s_btOn && !conn && millis() - lastScan > 800) { lastScan = millis(); drawBtList(); }

    // ---- touch
    Touch &t = *c.t;
    if (!t.tap) continue;

    if (t.sy >= 28 && t.sy < 50 && t.sx < 322) {            // tabs
      int nt = constrain((t.sx - 4) / 106, 0, 2);
      if (nt != tab) {
        tab = nt;
        if (tab == 0) { if (ftp::running) { ftp::end(); sys::radiosOff(); } startBt(); }
        if (tab == 1) rescan();
        redraw();
      }
      continue;
    }

    if (tab == 0) {
      if (ui::inRect(t.sx, t.sy, 4, BY, 90, BH)) {          // SCROLL
        btTop += ROWS; if (btTop >= s_count) btTop = 0; drawBtList();
      } else if (ui::inRect(t.sx, t.sy, 98, BY, 90, BH)) {  // RESCAN
        s_count = 0; btTop = 0; drawBtList();
      } else if (ui::inRect(t.sx, t.sy, 192, BY, 124, BH)) {   // DISCONNECT: restart the stack
        ui::toast("disconnecting...", C_WARN);
        btEnd(); startBt(); wasConn = false; redraw();
      } else if (s_btOn && !conn && t.sy >= Y0 && t.sy < Y0 + ROWS * RH) {   // tap a device
        int idx = btTop + (t.sy - Y0) / RH;
        char nm[32] = "";
        portENTER_CRITICAL(&s_mux); if (idx < s_count) strlcpy(nm, s_names[idx], 32); portEXIT_CRITICAL(&s_mux);
        if (nm[0]) { strlcpy(s_target, nm, 32); connT0 = millis(); audio::click(); drawStatus(); }
      }
    }
    else if (tab == 1) {
      int n = (int)tracks.size();
      if (ui::inRect(t.sx, t.sy, 4, BY, 50, BH)) {          // previous
        int p = nextIdx(false); if (p >= 0) playIdx(p);
      } else if (ui::inRect(t.sx, t.sy, 56, BY, 50, BH)) {  // play / pause
        if (!s_hasTrack) { playIdx(cur >= 0 ? cur : 0); }
        else { paused = !paused; s_play = !paused; drawControls(); }
      } else if (ui::inRect(t.sx, t.sy, 108, BY, 50, BH)) { // next
        int p = nextIdx(true); if (p >= 0) playIdx(p);
      } else if (ui::inRect(t.sx, t.sy, 160, BY, 50, BH)) { vol = max(0, vol - 8); s_gain = (vol * 256) / 127; drawProgress(); }
      else if (ui::inRect(t.sx, t.sy, 212, BY, 50, BH)) { vol = min(127, vol + 8); s_gain = (vol * 256) / 127; drawProgress(); }
      else if (ui::inRect(t.sx, t.sy, 264, BY, 52, BH)) { mode = (mode + 1) % 3; drawControls(); drawProgress(); }
      else if (ui::inRect(t.sx, t.sy, 278, LY, 38, 34)) { trTop = max(0, trTop - LROWS); drawTracks(); }
      else if (ui::inRect(t.sx, t.sy, 278, LY + 38, 38, 34)) { if (trTop + LROWS < n) trTop += LROWS; drawTracks(); }
      else if (t.sx < 276 && t.sy >= LY && t.sy < LY + LROWS * LRH) {      // tap a track
        int idx = trTop + (t.sy - LY) / LRH; if (idx < n) playIdx(idx);
      }
    }
    else {
      if (ui::inRect(t.sx, t.sy, 4, BY, 312, BH)) { if (ftp::running) stopFtp(); else startFtp(); }
    }
  }

  // ---- leaving the app: stop everything and give the RAM back
  ftp::end();
  btEnd();
  sys::radiosOff();
}