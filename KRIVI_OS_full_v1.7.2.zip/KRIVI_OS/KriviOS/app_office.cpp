// ============================================================================
//  Office / time apps
//   65 World Clock   66 Currency Converter   67 Unit Converter   76 Desk Clock
// ============================================================================
#include "apps_common.h"
#include <time.h>

// small numeric keypad used by the converters -> returns edited string
// draws into area y0..240; caller redraws its display on change
namespace kp {
static const char *KEYS[4][4] = {{"7", "8", "9", "DEL"}, {"4", "5", "6", "C"},
                                 {"1", "2", "3", "+/-"}, {"0", ".", "<", ">"}};
static void draw(int y0) {
  int kw = 80, kh = (240 - y0) / 4;
  for (int r = 0; r < 4; ++r) for (int ccol = 0; ccol < 4; ++ccol) {
    const char *l = KEYS[r][ccol];
    bool dig = (l[0] >= '0' && l[0] <= '9') || l[0] == '.';
    ui::button(ccol * kw + 1, y0 + r * kh + 1, kw - 2, kh - 2, l, dig ? C_PANEL : C_PANEL2, C_TEXT, 2);
  }
}
// handle a tap; returns true if the value string changed. '<'/'>' set swap=-1/1
static bool hit(int x, int y, int y0, String &val, int &nav) {
  int kw = 80, kh = (240 - y0) / 4;
  if (y < y0) return false;
  int r = (y - y0) / kh, ccol = x / kw;
  if (r > 3 || ccol > 3) return false;
  String k = KEYS[r][ccol]; audio::click();
  if (k == "DEL") { if (val.length()) val.remove(val.length() - 1); }
  else if (k == "C") val = "";
  else if (k == "+/-") { if (val.startsWith("-")) val.remove(0, 1); else val = "-" + val; }
  else if (k == "<") { nav = -1; return false; }
  else if (k == ">") { nav = 1; return false; }
  else if (k == ".") { if (val.indexOf('.') < 0) val += (val.length() ? "." : "0."); }
  else { if (val == "0") val = k; else if (val.length() < 12) val += k; }
  return true;
}
}  // namespace kp

// ============================================================================
//  65  WORLD CLOCK
// ============================================================================
void app_worldclock(AppCtx &c) {
  struct Z { const char *city; int off; };   // offset in minutes from UTC (standard)
  static const Z ZONES[] = {
    {"Los Angeles", -480}, {"New York", -300}, {"Sao Paulo", -180}, {"London", 0},
    {"Paris", 60}, {"Dubai", 240}, {"India", 330}, {"Singapore", 480},
    {"Tokyo", 540}, {"Sydney", 600}};
  const int N = sizeof(ZONES) / sizeof(ZONES[0]);
  ui::clearBody();
  char last[64] = "";
  while (c.loop()) {
    if (!sys::timeValid()) { ui::centerText("clock not set", 160, 110, C_WARN, C_BG, 4);
      ui::centerText("set WiFi (NTP) or use the Alarm app", 160, 140, C_DIM, C_BG, 2);
      if (!c.loop()) return; delay(200); continue; }
    time_t now = time(nullptr);
    char chk[16]; snprintf(chk, 16, "%ld", (long)(now / 30)); if (!strcmp(chk, last)) { delay(100); continue; }
    strcpy(last, chk);
    for (int i = 0; i < N; ++i) {
      time_t z = now + ZONES[i].off * 60;
      struct tm tm; gmtime_r(&z, &tm);
      int col = i / 5, row = i % 5;
      int x = col * 160, y = 30 + row * 42;
      tft.fillRect(x + 2, y, 156, 40, C_PANEL);
      tft.setTextColor(C_TEXT, C_PANEL); tft.drawString(ZONES[i].city, x + 8, y + 3, 2);
      char t[16]; snprintf(t, 16, "%02d:%02d", tm.tm_hour, tm.tm_min);
      tft.setTextColor(C_ACCENT, C_PANEL); tft.drawString(t, x + 8, y + 19, 4);
      static const char *DN[7] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
      snprintf(t, 16, "%s %d", DN[tm.tm_wday], tm.tm_mday);
      tft.setTextColor(C_DIM, C_PANEL); tft.setTextDatum(TR_DATUM); tft.drawString(t, x + 152, y + 24, 2); tft.setTextDatum(TL_DATUM);
    }
  }
}

// ============================================================================
//  66  CURRENCY CONVERTER   (rates relative to USD, from /sys/rates.json or defaults)
// ============================================================================
void app_currency(AppCtx &c) {
  struct Cur { String code; float perUsd; };
  std::vector<Cur> cur;
  // defaults (editable in /sys/rates.json: {"USD":1,"EUR":0.92,...})
  const char *defC[] = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD", "INR", "CNY", "MXN", "BRL"};
  const float defR[] = {1.0f, 0.92f, 0.79f, 150.0f, 1.36f, 1.52f, 83.2f, 7.24f, 17.1f, 5.05f};
  if (sys::sdOk) { File f = SD.open("/sys/rates.json"); if (f) { JsonDocument d; if (!deserializeJson(d, f)) {
    for (JsonPair kv : d.as<JsonObject>()) cur.push_back({String(kv.key().c_str()), kv.value().as<float>()}); } f.close(); } }
  if (cur.empty()) for (int i = 0; i < 10; ++i) cur.push_back({defC[i], defR[i]});
  int from = 0, to = 1; String val = "100";
  const int KY = 128;
  auto disp = [&]() {
    tft.fillRect(0, 28, 320, KY - 28, C_BG);
    ui::button(6, 32, 150, 34, (String("FROM  ") + cur[from].code).c_str(), C_PANEL2);
    ui::button(164, 32, 150, 34, (String("TO  ") + cur[to].code).c_str(), C_PANEL2);
    tft.setTextColor(C_TEXT, C_BG); tft.setTextDatum(TR_DATUM);
    tft.drawString(val + " " + cur[from].code, 314, 74, 4);
    float out = val.toFloat() / cur[from].perUsd * cur[to].perUsd;
    char r[24]; snprintf(r, 24, "%.2f %s", out, cur[to].code.c_str());
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(r, 314, 100, 4);
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("tap FROM/TO to change; rates in /sys/rates.json", 6, 118, 1);
  };
  ui::clearBody(); kp::draw(KY); disp();
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 6, 32, 150, 34)) { from = (from + 1) % cur.size(); disp(); }
    else if (ui::inRect(t.sx, t.sy, 164, 32, 150, 34)) { to = (to + 1) % cur.size(); disp(); }
    else { int nav = 0; if (kp::hit(t.sx, t.sy, KY, val, nav)) disp(); if (nav) { to = (to + nav + cur.size()) % cur.size(); disp(); } }
  }
}

// ============================================================================
//  67  UNIT CONVERTER
// ============================================================================
void app_units(AppCtx &c) {
  struct U { const char *name; double factor; };    // to base unit
  struct Cat { const char *name; const U *u; int n; bool temp; };
  static const U LEN[] = {{"m", 1}, {"km", 1000}, {"cm", 0.01}, {"mm", 0.001}, {"in", 0.0254}, {"ft", 0.3048}, {"yd", 0.9144}, {"mi", 1609.34}};
  static const U MASS[] = {{"kg", 1}, {"g", 0.001}, {"mg", 1e-6}, {"lb", 0.453592}, {"oz", 0.0283495}, {"ton", 1000}};
  static const U SPD[] = {{"m/s", 1}, {"km/h", 0.277778}, {"mph", 0.44704}, {"knot", 0.514444}, {"ft/s", 0.3048}};
  static const U DATA[] = {{"B", 1}, {"KB", 1024}, {"MB", 1048576}, {"GB", 1073741824.0}, {"Mbit", 131072}, {"Gbit", 134217728.0}};
  static const U TMP[] = {{"C", 0}, {"F", 0}, {"K", 0}};
  static const Cat CATS[] = {{"Length", LEN, 8, false}, {"Mass", MASS, 6, false}, {"Speed", SPD, 5, false},
                             {"Data", DATA, 6, false}, {"Temp", TMP, 3, true}};
  const int NC = 5;
  int cat = 0, from = 0, to = 1; String val = "1";
  const int KY = 128;
  auto conv = [&]() -> double {
    double x = val.toFloat();
    const Cat &C = CATS[cat];
    if (C.temp) { double cC = from == 0 ? x : from == 1 ? (x - 32) * 5.0 / 9 : x - 273.15;
      return to == 0 ? cC : to == 1 ? cC * 9.0 / 5 + 32 : cC + 273.15; }
    return x * C.u[from].factor / C.u[to].factor;
  };
  auto disp = [&]() {
    tft.fillRect(0, 28, 320, KY - 28, C_BG);
    ui::button(6, 30, 100, 28, CATS[cat].name, RGB565(0, 110, 160));
    ui::button(112, 30, 100, 28, (String("FROM ") + CATS[cat].u[from].name).c_str(), C_PANEL2, C_TEXT, 1);
    ui::button(216, 30, 100, 28, (String("TO ") + CATS[cat].u[to].name).c_str(), C_PANEL2, C_TEXT, 1);
    tft.setTextColor(C_TEXT, C_BG); tft.setTextDatum(TR_DATUM);
    tft.drawString(val + " " + CATS[cat].u[from].name, 314, 66, 4);
    char r[32]; double o = conv(); snprintf(r, 32, (fabs(o) < 1e-3 || fabs(o) > 1e7) ? "%.4g %s" : "%.4f %s", o, CATS[cat].u[to].name);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(r, 314, 94, 4); tft.setTextDatum(TL_DATUM);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("tap CAT / FROM / TO to cycle", 6, 118, 1);
  };
  ui::clearBody(); kp::draw(KY); disp();
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 6, 30, 100, 28)) { cat = (cat + 1) % NC; from = 0; to = 1; disp(); }
    else if (ui::inRect(t.sx, t.sy, 112, 30, 100, 28)) { from = (from + 1) % CATS[cat].n; disp(); }
    else if (ui::inRect(t.sx, t.sy, 216, 30, 100, 28)) { to = (to + 1) % CATS[cat].n; disp(); }
    else { int nav = 0; if (kp::hit(t.sx, t.sy, KY, val, nav)) disp(); if (nav) { to = (to + nav + CATS[cat].n) % CATS[cat].n; disp(); } }
  }
}

// ============================================================================
//  76  DESK CLOCK
// ============================================================================
void app_deskclock(AppCtx &c) {
  bool h24 = c.pInt("h24", 0);
  tft.fillScreen(TFT_BLACK);
  char last[24] = "";
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && t.sy > 40) { h24 = !h24; last[0] = 0; }
    struct tm tm;
    if (!sys::now(tm)) { ui::centerText("clock not set", 160, 120, C_WARN, TFT_BLACK, 4); delay(200); continue; }
    char s[24];
    if (h24) snprintf(s, 24, "%02d:%02d:%02d", tm.tm_hour, tm.tm_min, tm.tm_sec);
    else { int h = tm.tm_hour % 12; if (!h) h = 12; snprintf(s, 24, "%d:%02d:%02d", h, tm.tm_min, tm.tm_sec); }
    if (strcmp(s, last)) {
      strcpy(last, s);
      tft.fillRect(0, 70, 320, 70, TFT_BLACK);
      tft.setTextColor(C_ACCENT, TFT_BLACK); tft.setTextDatum(MC_DATUM);
      tft.drawString(s, 160, 104, 7);
      if (!h24) { tft.setTextColor(C_DIM, TFT_BLACK); tft.drawString(tm.tm_hour < 12 ? "AM" : "PM", 290, 78, 2); }
      static const char *DN[7] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
      static const char *MN[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
      char d[40]; snprintf(d, 40, "%s, %s %d %d", DN[tm.tm_wday], MN[tm.tm_mon], tm.tm_mday, tm.tm_year + 1900);
      tft.setTextColor(C_TEXT, TFT_BLACK); tft.drawString(d, 160, 160, 4);
      tft.setTextDatum(TL_DATUM);
    }
    delay(100);
  }
}
