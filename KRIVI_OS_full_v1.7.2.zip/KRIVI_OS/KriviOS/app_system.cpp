// ============================================================================
//  System apps
//   74 System Settings Panel    75 NVS Flash Editor
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <nvs.h>
#include <nvs_flash.h>

// ============================================================================
//  74  SYSTEM SETTINGS
// ============================================================================
void app_settings(AppCtx &c) {
  int bright = sys::cfg["display"]["brightness"] | 100;      // 10..100 %
  int vol = audio::master();
  // backlight PWM on GPIO21
  ledcSetup(7, 5000, 8); ledcAttachPin(TFT_BL, 7);
  auto applyBright = [&]() { ledcWrite(7, map(constrain(bright, 10, 100), 0, 100, 0, 255)); };
  applyBright();
  auto draw = [&]() {
    ui::clearBody();
    tft.setTextColor(C_TEXT, C_BG);
    tft.drawString("Brightness", 10, 32, 2); char s[16]; snprintf(s, 16, "%d%%", bright);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 32, 2);
    ui::bar(10, 50, 300, 12, bright / 100.0f, C_ACCENT, C_PANEL);
    tft.setTextColor(C_TEXT, C_BG); tft.drawString("Volume", 10, 72, 2); snprintf(s, 16, "%d", vol);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 72, 2);
    ui::bar(10, 90, 300, 12, vol / 255.0f, C_OK, C_PANEL);
    ui::button(10, 112, 150, 34, "SET WIFI", C_PANEL2);
    ui::button(166, 112, 150, 34, "SET CLOCK >Alarm", C_PANEL2, C_TEXT, 1);
    const char *ssid = sys::cfg["wifi"]["ssid"] | "";
    tft.setTextColor(C_DIM, C_BG);
    tft.drawString(String("WiFi: ") + (ssid[0] ? ssid : "(none)") + "   " + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("not connected")), 10, 152, 1);
    char info[64]; snprintf(info, 64, "Heap %u KB   Firmware " KRIVI_VERSION "   %s", ESP.getFreeHeap() / 1024, KRIVI_PANEL_NAME);
    tft.drawString(info, 10, 166, 1);
    ui::button(10, 182, 150, 34, "SAVE", RGB565(0, 110, 60), TFT_WHITE, 2);
    ui::button(166, 182, 150, 34, "REBOOT", C_PANEL2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("drag the bars; SAVE writes /sys/settings.json", 10, 220, 1);
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.down && ui::inRect(t.x, t.y, 10, 44, 300, 24)) { bright = constrain((t.x - 10) * 100 / 300, 10, 100); applyBright();
      tft.fillRect(10, 32, 300, 30, C_BG); tft.setTextColor(C_TEXT, C_BG); tft.drawString("Brightness", 10, 32, 2);
      char s[16]; snprintf(s, 16, "%d%%", bright); tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 32, 2); ui::bar(10, 50, 300, 12, bright / 100.0f, C_ACCENT, C_PANEL); continue; }
    if (t.down && ui::inRect(t.x, t.y, 10, 84, 300, 24)) { vol = constrain((t.x - 10) * 255 / 300, 0, 255); audio::setMaster(vol);
      tft.fillRect(10, 72, 300, 30, C_BG); tft.setTextColor(C_TEXT, C_BG); tft.drawString("Volume", 10, 72, 2);
      char s[16]; snprintf(s, 16, "%d", vol); tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 270, 72, 2); ui::bar(10, 90, 300, 12, vol / 255.0f, C_OK, C_PANEL); audio::beep(1500, 10); continue; }
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 10, 112, 150, 34)) {
      String ssid = sys::cfg["wifi"]["ssid"] | "", pass = sys::cfg["wifi"]["pass"] | "";
      if (ui::textInput(ssid, "WiFi network name (SSID)", 32)) {
        if (ui::textInput(pass, "WiFi password", 63, true)) { sys::cfg["wifi"]["ssid"] = ssid; sys::cfg["wifi"]["pass"] = pass; }
      }
      c.header(); draw();
    } else if (ui::inRect(t.sx, t.sy, 10, 182, 150, 34)) {
      sys::cfg["display"]["brightness"] = bright; sys::cfg["sound"]["volume"] = vol;
      bool ok = sys::saveSettings(); ui::toast(ok ? "saved to settings.json" : "SD not available", ok ? C_OK : C_ERR); delay(1000); draw();
    } else if (ui::inRect(t.sx, t.sy, 166, 182, 150, 34)) {
      if (ui::confirm("REBOOT", "Restart KRIVI OS now?")) { sys::saveSettings(); ESP.restart(); } c.header(); draw();
    }
  }
  sys::cfg["display"]["brightness"] = bright;
}

// ============================================================================
//  75  NVS FLASH EDITOR
// ============================================================================
void app_nvsedit(AppCtx &c) {
  nvs_flash_init();
  struct Ent { char ns[16]; char key[16]; uint8_t type; };
  std::vector<Ent> ents;
  auto scan = [&]() {
    ents.clear();
    nvs_iterator_t it = nvs_entry_find("nvs", nullptr, NVS_TYPE_ANY);
    while (it && ents.size() < 200) { nvs_entry_info_t info; nvs_entry_info(it, &info);
      Ent e; strlcpy(e.ns, info.namespace_name, 16); strlcpy(e.key, info.key, 16); e.type = info.type; ents.push_back(e);
      it = nvs_entry_next(it); }
    if (it) nvs_release_iterator(it);
  };
  scan();
  const char *tyName = "?";
  auto typeStr = [](uint8_t t) -> const char * {
    switch (t) { case NVS_TYPE_I8: return "i8"; case NVS_TYPE_U8: return "u8"; case NVS_TYPE_I16: return "i16"; case NVS_TYPE_U16: return "u16";
      case NVS_TYPE_I32: return "i32"; case NVS_TYPE_U32: return "u32"; case NVS_TYPE_I64: return "i64"; case NVS_TYPE_U64: return "u64";
      case NVS_TYPE_STR: return "str"; case NVS_TYPE_BLOB: return "blob"; default: return "?"; }
  };
  auto readVal = [&](const Ent &e) -> String {
    nvs_handle_t h; if (nvs_open(e.ns, NVS_READONLY, &h) != ESP_OK) return "?";
    String r = "?";
    if (e.type == NVS_TYPE_STR) { size_t n = 0; if (nvs_get_str(h, e.key, nullptr, &n) == ESP_OK && n < 128) { char *b = (char *)malloc(n); if (b) { nvs_get_str(h, e.key, b, &n); r = b; free(b); } } }
    else if (e.type == NVS_TYPE_I32) { int32_t v; if (nvs_get_i32(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_U32) { uint32_t v; if (nvs_get_u32(h, e.key, &v) == ESP_OK) r = String((unsigned)v); }
    else if (e.type == NVS_TYPE_U8) { uint8_t v; if (nvs_get_u8(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_I8) { int8_t v; if (nvs_get_i8(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_U16) { uint16_t v; if (nvs_get_u16(h, e.key, &v) == ESP_OK) r = String(v); }
    else if (e.type == NVS_TYPE_I16) { int16_t v; if (nvs_get_i16(h, e.key, &v) == ESP_OK) r = String(v); }
    nvs_close(h); return r;
  };
  int top = 0; const int RH = 18, Y0 = 44, ROWS = 9;
  auto draw = [&]() {
    ui::clearBody();
    tft.setTextColor(C_DIM, C_BG); char hd[48]; snprintf(hd, 48, "%d NVS entries (namespace : key = value)", (int)ents.size()); tft.drawString(hd, 6, 30, 1);
    for (int i = 0; i < ROWS && top + i < (int)ents.size(); ++i) { Ent &e = ents[top + i]; int y = Y0 + i * RH;
      tft.setTextColor(C_TEXT, C_BG); char s[64]; snprintf(s, 64, "%s:%s", e.ns, e.key); tft.drawString(s, 6, y, 1);
      tft.setTextColor(C_DIM, C_BG); tft.drawString(typeStr(e.type), 150, y, 1);
      tft.setTextColor(C_ACCENT, C_BG); tft.drawString(readVal(e).substring(0, 20), 182, y, 1); }
    ui::button(4, 210, 90, 26, "< UP", C_PANEL2, C_TEXT, 1); ui::button(226, 210, 90, 26, "DOWN >", C_PANEL2, C_TEXT, 1);
    tft.setTextColor(C_WARN, C_BG); tft.drawString("tap a str/int row to edit (caution!)", 100, 218, 1);
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.swipe == SW_UP || (t.tap && ui::inRect(t.sx, t.sy, 226, 210, 90, 26))) { if (top + ROWS < (int)ents.size()) { top += ROWS; draw(); } }
    else if (t.swipe == SW_DOWN || (t.tap && ui::inRect(t.sx, t.sy, 4, 210, 90, 26))) { if (top > 0) { top = max(0, top - ROWS); draw(); } }
    else if (t.tap && t.sy >= Y0 && t.sy < Y0 + ROWS * RH) {
      int idx = top + (t.sy - Y0) / RH; if (idx >= (int)ents.size()) continue;
      Ent &e = ents[idx];
      bool isStr = e.type == NVS_TYPE_STR;
      bool isInt = e.type == NVS_TYPE_I32 || e.type == NVS_TYPE_U32 || e.type == NVS_TYPE_U8 || e.type == NVS_TYPE_I8 || e.type == NVS_TYPE_U16 || e.type == NVS_TYPE_I16;
      if (!isStr && !isInt) { ui::msgBox("NVS", "Only string and integer keys are editable here."); c.header(); draw(); continue; }
      String v = readVal(e);
      if (ui::textInput(v, (String(e.ns) + ":" + e.key).c_str(), 64, false)) {
        nvs_handle_t h;
        if (nvs_open(e.ns, NVS_READWRITE, &h) == ESP_OK) {
          esp_err_t r;
          if (isStr) r = nvs_set_str(h, e.key, v.c_str());
          else { long n = v.toInt();
            if (e.type == NVS_TYPE_I32) r = nvs_set_i32(h, e.key, n); else if (e.type == NVS_TYPE_U32) r = nvs_set_u32(h, e.key, n);
            else if (e.type == NVS_TYPE_U8) r = nvs_set_u8(h, e.key, n); else if (e.type == NVS_TYPE_I8) r = nvs_set_i8(h, e.key, n);
            else if (e.type == NVS_TYPE_U16) r = nvs_set_u16(h, e.key, n); else r = nvs_set_i16(h, e.key, n); }
          if (r == ESP_OK) nvs_commit(h);
          nvs_close(h);
          ui::toast(r == ESP_OK ? "written" : "write failed", r == ESP_OK ? C_OK : C_ERR); delay(800);
        }
      }
      c.header(); draw();
    }
  }
}