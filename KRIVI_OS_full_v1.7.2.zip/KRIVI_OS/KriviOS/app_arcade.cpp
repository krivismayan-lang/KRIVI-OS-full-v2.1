// ============================================================================
//  KRIVI OS - Arcade  (a single "list of games" hub)              app 80
//
//  One scrollable menu that launches 10 classics. The sub-games are the normal
//  KRIVI app functions; the hub runs one at a time, and when a game's EXIT
//  button is tapped control returns here (its RAM is already freed on return).
//
//  Two games live in this file: Ludo and Snakes & Ladders. They draw straight
//  to the screen (no frame-buffer sprite) so they use almost no RAM. High
//  scores / nothing persistent is kept in RAM between games.
// ============================================================================
#include "apps_common.h"

// new games defined below
static void game_ludo(AppCtx &c);
static void game_snl(AppCtx &c);

namespace arcade {

struct GameEntry { const char *name; const char *desc; void (*fn)(AppCtx &); };

static const GameEntry GAMES[] = {
  {"Flappy Bird",      "tap to flap through the pipes", app_flappy},
  {"Snake",            "eat, grow, don't bite yourself", app_snake},
  {"Tetris",           "stack and clear the lines",      app_tetris},
  {"Pong",             "classic paddle bat-and-ball",    app_pong},
  {"Breakout",         "bounce the ball, break bricks",  app_breakout},
  {"Minesweeper",      "flag the mines, clear the grid",  app_mines},
  {"Chess",            "full two-player chess board",    app_board},
  {"3D Dice",          "roll two tumbling dice",          app_dice},
  {"Ludo",             "2-4 players, race your tokens",   game_ludo},
  {"Snakes & Ladders", "2-4 players, climb and slide",    game_snl},
};
static const int NGAMES = sizeof(GAMES) / sizeof(GAMES[0]);

// Run one sub-game, then swallow the EXIT tap that ended it so this hub does
// not immediately exit too.
static void runSub(AppCtx &c, void (*fn)(AppCtx &)) {
  c.exitReq = false;
  tft.fillScreen(C_BG);
  fn(c);
  c.exitReq = false;
  uint32_t t0 = millis();
  while (ui::state().down && millis() - t0 < 1500) { ui::poll(); delay(5); }
  ui::clearEvents();
}

}  // namespace arcade

void app_arcade(AppCtx &c) {
  using namespace arcade;
  // Screen body is y 26..240. Fit 4 rows of 40px (30..190), the nav bar
  // (194..226) and a page counter (228..238) entirely on-screen.
  const int RH = 40, Y0 = 30, ROWS = 4;
  const int BY = 194, BH = 32;
  int top = 0;

  auto draw = [&]() {
    c.header("10 classics");
    ui::clearBody();
    for (int i = 0; i < ROWS && top + i < NGAMES; ++i) {
      int idx = top + i, y = Y0 + i * RH;
      tft.fillRoundRect(6, y, 308, RH - 4, 6, C_PANEL);
      tft.setTextColor(C_TEXT, C_PANEL); tft.drawString(GAMES[idx].name, 14, y + 4, 2);
      tft.setTextColor(C_DIM, C_PANEL);  tft.drawString(GAMES[idx].desc, 14, y + 22, 1);
      tft.fillTriangle(296, y + 12, 296, y + 24, 305, y + 18, C_ACCENT);   // play arrow
    }
    ui::button(6, BY, 150, BH, "UP", top > 0 ? C_PANEL2 : C_PANEL, C_TEXT, 2);
    ui::button(164, BY, 150, BH, "DOWN", top + ROWS < NGAMES ? C_PANEL2 : C_PANEL, C_TEXT, 2);
    char cnt[28]; snprintf(cnt, sizeof(cnt), "games %d-%d of %d", top + 1, min(top + ROWS, NGAMES), NGAMES);
    tft.fillRect(0, 228, 320, 11, C_BG);
    tft.setTextColor(C_DIM, C_BG); tft.setTextDatum(TC_DATUM); tft.drawString(cnt, 160, 229, 1); tft.setTextDatum(TL_DATUM);
  };
  draw();

  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 6, BY, 150, BH)) { if (top > 0) { top = max(0, top - ROWS); draw(); } }
    else if (ui::inRect(t.sx, t.sy, 164, BY, 150, BH)) { if (top + ROWS < NGAMES) { top += ROWS; draw(); } }
    else if (t.sy >= Y0 && t.sy < Y0 + ROWS * RH) {
      int idx = top + (t.sy - Y0) / RH;
      if (idx < NGAMES) { audio::click(); runSub(c, GAMES[idx].fn); draw(); }
    }
  }
}

// ============================================================================
//  shared helpers for the two board games
// ============================================================================
namespace board {

static const uint16_t PCOL[4] = { RGB565(230, 70, 70), RGB565(70, 200, 90),
                                  RGB565(240, 200, 60), RGB565(80, 150, 240) };
static const char *PNAME[4] = { "RED", "GREEN", "YELLOW", "BLUE" };

// Ask how many players (2-4); returns 2..4, or 0 if the user exited.
static int askPlayers(AppCtx &c, const char *title) {
  c.header(title);
  ui::clearBody();
  ui::centerText("How many players?", 160, 70, C_TEXT, C_BG, 2);
  ui::button(40, 110, 70, 60, "2", C_PANEL2, C_TEXT, 4);
  ui::button(125, 110, 70, 60, "3", C_PANEL2, C_TEXT, 4);
  ui::button(210, 110, 70, 60, "4", C_PANEL2, C_TEXT, 4);
  ui::centerText("pass the device each turn", 160, 196, C_DIM, C_BG, 1);
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 40, 110, 70, 60)) return 2;
    if (ui::inRect(t.sx, t.sy, 125, 110, 70, 60)) return 3;
    if (ui::inRect(t.sx, t.sy, 210, 110, 70, 60)) return 4;
  }
  return 0;
}

// a simple die roll with a short tumble animation; returns 1..6
static int rollDie(AppCtx &c, int bx, int by, uint16_t accent) {
  for (int f = 0; f < 10; ++f) {
    int v = (int)rnd(6) + 1;
    tft.fillRoundRect(bx, by, 44, 44, 8, TFT_WHITE);
    tft.drawRoundRect(bx, by, 44, 44, 8, accent);
    int cx = bx + 22, cy = by + 22;
    const int8_t P[7][7][2] = {}; (void)P;
    // pips
    auto pip = [&](int dx, int dy){ tft.fillCircle(cx + dx, cy + dy, 4, TFT_BLACK); };
    if (v & 1) pip(0, 0);
    if (v >= 2) { pip(-10, -10); pip(10, 10); }
    if (v >= 4) { pip(10, -10); pip(-10, 10); }
    if (v == 6) { pip(-10, 0); pip(10, 0); }
    audio::beep(900 + v * 60, 18);
    delay(45 + f * 8);
    if (f == 9) return v;
  }
  return 1;
}

}  // namespace board

// ============================================================================
//  LUDO  (2-4 players, 4 tokens each, verified 52-cell track)
// ============================================================================
namespace ludo {

// 52-cell main ring on a 15x15 grid (col,row). Verified: 48 orthogonal steps
// + 4 corner diagonals, player entries 13 apart.
static const uint8_t PATH[52][2] = {
  {6,14},{6,13},{6,12},{6,11},{6,10},{6,9},{5,8},{4,8},{3,8},{2,8},{1,8},{0,8},{0,7},
  {0,6},{1,6},{2,6},{3,6},{4,6},{5,6},{6,5},{6,4},{6,3},{6,2},{6,1},{6,0},{7,0},
  {8,0},{8,1},{8,2},{8,3},{8,4},{8,5},{9,6},{10,6},{11,6},{12,6},{13,6},{14,6},{14,7},
  {14,8},{13,8},{12,8},{11,8},{10,8},{9,8},{8,9},{8,10},{8,11},{8,12},{8,13},{8,14},{7,14} };
static const int START[4] = { 0, 13, 26, 39 };          // entry index per player
// home-column cells (col,row) leading to centre, per player (6 cells each)
static const uint8_t HOME[4][6][2] = {
  { {7,13},{7,12},{7,11},{7,10},{7,9},{7,8} },           // red  (up)
  { {1,7},{2,7},{3,7},{4,7},{5,7},{6,7} },               // green(right)
  { {7,1},{7,2},{7,3},{7,4},{7,5},{7,6} },               // yellow(down)
  { {13,7},{12,7},{11,7},{10,7},{9,7},{8,7} } };         // blue (left)
// base parking spots (col,row), 4 per player
static const uint8_t BASE[4][4][2] = {
  { {1,13},{3,13},{1,11},{3,11} },                       // red  bottom-left
  { {1,3},{3,3},{1,1},{3,1} },                           // green top-left
  { {11,3},{13,3},{11,1},{13,1} },                       // yellow top-right
  { {11,13},{13,13},{11,11},{13,11} } };                 // blue bottom-right
// safe cells (stars) - no capture here
static bool isSafe(int idx) {
  static const int S[8] = { 0, 8, 13, 21, 26, 34, 39, 47 };
  for (int i = 0; i < 8; ++i) if (S[i] == idx) return true;
  return false;
}

static int GX, GY, CS;                                   // grid origin + cell size
static inline int sx(int col) { return GX + col * CS; }
static inline int sy(int row) { return GY + row * CS; }

// token progress: -1 in base; 0..51 travel the whole shared ring from own
// start (position 51 is the turn-off square, just before the start, which sits
// right next to the player's home column); 52..57 the 6 home-column cells;
// 57 = finished (innermost home cell). Win when all four reach 57.
static const int FINISH = 57;
static int prog[4][4];

static void cellOf(int p, int tok, int &col, int &row) {
  int s = prog[p][tok];
  if (s < 0) { col = BASE[p][tok][0]; row = BASE[p][tok][1]; return; }
  if (s <= 51) { int idx = (START[p] + s) % 52; col = PATH[idx][0]; row = PATH[idx][1]; return; }
  int h = s - 52; if (h > 5) h = 5;                      // 52..57 -> home 0..5
  col = HOME[p][h][0]; row = HOME[p][h][1];
}
static int mainIdxOf(int p, int tok) {                   // -1 if not on shared ring
  int s = prog[p][tok];
  return (s >= 0 && s <= 51) ? (START[p] + s) % 52 : -1;
}

}  // namespace ludo

static void game_ludo(AppCtx &c) {
  using namespace ludo; using namespace board;
  int NP = askPlayers(c, "Ludo");
  if (NP == 0) return;

  const int BOARDPX = 210;
  CS = BOARDPX / 15; GX = (320 - CS * 15) / 2; GY = 28 + (210 - CS * 15) / 2;
  for (int p = 0; p < 4; ++p) for (int t = 0; t < 4; ++t) prog[p][t] = -1;

  auto drawBoard = [&]() {
    ui::clearBody();
    // yards (quadrant blocks 6x6)
    const int Q[4][2] = { {0,9},{0,0},{9,0},{9,9} };     // red,green,yellow,blue corners
    for (int p = 0; p < 4; ++p) {
      tft.fillRect(sx(Q[p][0]), sy(Q[p][1]), CS * 6, CS * 6, PCOL[p]);
      tft.fillRect(sx(Q[p][0]) + CS, sy(Q[p][1]) + CS, CS * 4, CS * 4, C_BG);
    }
    // main ring
    for (int i = 0; i < 52; ++i) {
      int col = PATH[i][0], row = PATH[i][1];
      uint16_t fill = C_PANEL;
      for (int p = 0; p < 4; ++p) if (START[p] == i) fill = PCOL[p];
      if (isSafe(i) && fill == C_PANEL) fill = C_PANEL2;
      tft.fillRect(sx(col), sy(row), CS, CS, fill);
      tft.drawRect(sx(col), sy(row), CS, CS, RGB565(60, 70, 90));
    }
    // home columns
    for (int p = 0; p < NP; ++p)
      for (int h = 0; h < 6; ++h) { tft.fillRect(sx(HOME[p][h][0]), sy(HOME[p][h][1]), CS, CS, PCOL[p]); tft.drawRect(sx(HOME[p][h][0]), sy(HOME[p][h][1]), CS, CS, RGB565(60,70,90)); }
    // centre
    tft.fillRect(sx(6), sy(6), CS * 3, CS * 3, C_PANEL2);
  };
  auto drawTokens = [&]() {
    for (int p = 0; p < NP; ++p)
      for (int t = 0; t < 4; ++t) {
        int col, row; cellOf(p, t, col, row);
        int cx = sx(col) + CS / 2, cy = sy(row) + CS / 2;
        tft.fillCircle(cx, cy, CS / 2 - 1, PCOL[p]);
        tft.drawCircle(cx, cy, CS / 2 - 1, TFT_BLACK);
      }
  };
  auto panel = [&](int cur, int die, const char *msg) {
    tft.fillRect(0, 210, 320, 30, C_BG);
    tft.fillRect(0, 210, 10, 30, PCOL[cur]);
    tft.setTextColor(PCOL[cur], C_BG); tft.drawString(PNAME[cur], 16, 216, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(msg, 90, 216, 1);
    ui::button(250, 208, 66, 30, die ? String(String("ROLL ") + die).c_str() : "ROLL", C_OK, TFT_BLACK, 1);
  };

  c.header("Ludo");
  drawBoard(); drawTokens(); panel(0, 0, "tap ROLL");
  int cur = 0, winner = -1;

  while (c.loop() && winner < 0) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (!ui::inRect(t.sx, t.sy, 250, 208, 66, 30)) continue;
    int die = rollDie(c, 258, 210, PCOL[cur]);
    panel(cur, die, "tap a token");

    // which tokens can move?
    int movable[4], nm = 0;
    for (int tk = 0; tk < 4; ++tk) {
      int s = prog[cur][tk];
      if (s == 57) continue;                             // finished
      if (s < 0) { if (die == 6) movable[nm++] = tk; }    // need 6 to leave base
      else if (s + die <= 57) movable[nm++] = tk;
    }
    if (nm == 0) { panel(cur, die, "no move"); delay(700); cur = (cur + 1) % NP; panel(cur, 0, "tap ROLL"); continue; }

    // let the player tap one of the movable tokens (auto-pick if only one)
    int chosen = -1;
    if (nm == 1) { chosen = movable[0]; delay(250); }
    else {
      // highlight movable tokens
      for (int m = 0; m < nm; ++m) { int col,row; cellOf(cur, movable[m], col, row); tft.drawCircle(sx(col)+CS/2, sy(row)+CS/2, CS/2+1, TFT_WHITE); }
      while (c.loop() && chosen < 0) {
        Touch &tt = *c.t; if (!tt.tap) continue;
        for (int m = 0; m < nm; ++m) {
          int col,row; cellOf(cur, movable[m], col, row);
          if (abs(tt.sx - (sx(col)+CS/2)) < CS && abs(tt.sy - (sy(row)+CS/2)) < CS) { chosen = movable[m]; break; }
        }
      }
      if (chosen < 0) break;                             // exited
    }

    // move the token
    if (prog[cur][chosen] < 0) prog[cur][chosen] = 0;    // enter board at start
    else prog[cur][chosen] += die;

    // capture: if we landed on a shared-ring, non-safe cell holding a lone enemy, send it home
    int myIdx = mainIdxOf(cur, chosen);
    if (myIdx >= 0 && !isSafe(myIdx)) {
      for (int p = 0; p < NP; ++p) if (p != cur)
        for (int tk = 0; tk < 4; ++tk)
          if (mainIdxOf(p, tk) == myIdx) { prog[p][tk] = -1; audio::beep(300, 120); }
    }
    drawBoard(); drawTokens();

    // win?
    bool allHome = true;
    for (int tk = 0; tk < 4; ++tk) if (prog[cur][tk] != 57) allHome = false;
    if (allHome) { winner = cur; break; }

    if (die != 6) cur = (cur + 1) % NP;                  // 6 rolls again
    panel(cur, 0, die == 6 ? "rolled 6 - again!" : "tap ROLL");
  }

  if (winner >= 0) {
    tft.fillRect(0, 90, 320, 60, C_BG);
    char s[32]; snprintf(s, sizeof(s), "%s WINS!", PNAME[winner]);
    ui::centerText(s, 160, 112, PCOL[winner], C_BG, 4);
    audio::beep(1600, 200); delay(2200);
  }
}

// ============================================================================
//  SNAKES & LADDERS  (2-4 players, 10x10 board, exact 100 to win)
// ============================================================================
static void game_snl(AppCtx &c) {
  using namespace board;
  int NP = askPlayers(c, "Snakes & Ladders");
  if (NP == 0) return;

  const int CS = 21, OX = 4, OY = 28;                    // 10x10 board = 210px
  // jumps: positive = ladder (up), handled by value; map square -> destination
  struct Jump { uint8_t from, to; };
  static const Jump J[] = {
    {4,14},{9,31},{20,38},{28,84},{40,59},{51,67},{63,81},      // ladders
    {17,7},{54,34},{62,19},{64,60},{87,24},{93,73},{95,75},{99,78} };  // snakes
  const int NJ = sizeof(J) / sizeof(J[0]);
  auto jumpTo = [&](int sq) -> int { for (int i = 0; i < NJ; ++i) if (J[i].from == sq) return J[i].to; return sq; };

  auto cellXY = [&](int n, int &x, int &y) {             // n 1..100
    int r = (n - 1) / 10, col = (n - 1) % 10;
    if (r & 1) col = 9 - col;                            // boustrophedon
    x = OX + col * CS; y = OY + (9 - r) * CS;
  };
  int pos[4] = {0, 0, 0, 0};

  auto drawBoard = [&]() {
    ui::clearBody();
    for (int n = 1; n <= 100; ++n) {
      int x, y; cellXY(n, x, y);
      uint16_t bg = ((n + (n - 1) / 10) & 1) ? RGB565(32, 42, 58) : RGB565(22, 30, 42);
      tft.fillRect(x, y, CS, CS, bg); tft.drawRect(x, y, CS, CS, RGB565(55, 65, 85));
      tft.setTextColor(C_DIM, bg); tft.drawString(String(n), x + 2, y + 2, 1);
    }
    // draw ladders (green) and snakes (red) as lines
    for (int i = 0; i < NJ; ++i) {
      int x1, y1, x2, y2; cellXY(J[i].from, x1, y1); cellXY(J[i].to, x2, y2);
      uint16_t col = (J[i].to > J[i].from) ? C_OK : C_ERR;
      tft.drawLine(x1 + CS / 2, y1 + CS / 2, x2 + CS / 2, y2 + CS / 2, col);
      tft.drawLine(x1 + CS / 2 + 1, y1 + CS / 2, x2 + CS / 2 + 1, y2 + CS / 2, col);
    }
    tft.setTextColor(C_DIM, C_BG); tft.drawString("ladders up . snakes down", 218, 28, 1);
  };
  auto drawTokens = [&]() {
    for (int p = 0; p < NP; ++p) {
      if (pos[p] < 1) continue;
      int x, y; cellXY(pos[p], x, y);
      tft.fillCircle(x + 5 + (p % 2) * 10, y + 6 + (p / 2) * 9, 4, PCOL[p]);
      tft.drawCircle(x + 5 + (p % 2) * 10, y + 6 + (p / 2) * 9, 4, TFT_BLACK);
    }
  };
  auto panel = [&](int cur, const char *msg) {
    tft.fillRect(216, 48, 104, 160, C_BG);
    for (int p = 0; p < NP; ++p) {
      tft.fillRect(220, 52 + p * 20, 10, 10, PCOL[p]);
      char s[20]; snprintf(s, sizeof(s), "%s %d", PNAME[p], pos[p]);
      tft.setTextColor(p == cur ? C_TEXT : C_DIM, C_BG); tft.drawString(s, 234, 51 + p * 20, 1);
    }
    tft.fillRect(216, 140, 104, 20, C_BG);
    tft.setTextColor(PCOL[cur], C_BG); tft.drawString(PNAME[cur], 218, 142, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(msg, 218, 158, 1);
    ui::button(234, 174, 70, 34, "ROLL", C_OK, TFT_BLACK, 2);
  };

  c.header("Snakes & Ladders");
  drawBoard(); drawTokens(); panel(0, "tap ROLL");
  int cur = 0, winner = -1;

  while (c.loop() && winner < 0) {
    Touch &t = *c.t;
    if (!t.tap || !ui::inRect(t.sx, t.sy, 234, 174, 70, 34)) continue;
    int die = rollDie(c, 246, 60, PCOL[cur]);
    int np = pos[cur] + die;
    if (np > 100) { panel(cur, "overshoot - stay"); delay(650); cur = (cur + 1) % NP; panel(cur, "tap ROLL"); continue; }
    pos[cur] = np;
    drawBoard(); drawTokens(); panel(cur, "...");
    delay(250);
    int after = jumpTo(pos[cur]);
    if (after != pos[cur]) { audio::beep(after > pos[cur] ? 1400 : 300, 120); pos[cur] = after; drawBoard(); drawTokens(); }
    if (pos[cur] == 100) { winner = cur; break; }
    cur = (cur + 1) % NP;
    panel(cur, "tap ROLL");
  }

  if (winner >= 0) {
    tft.fillRect(0, 90, 320, 60, C_BG);
    char s[32]; snprintf(s, sizeof(s), "%s WINS!", PNAME[winner]);
    ui::centerText(s, 160, 112, PCOL[winner], C_BG, 4);
    audio::beep(1600, 200); delay(2200);
  }
}
