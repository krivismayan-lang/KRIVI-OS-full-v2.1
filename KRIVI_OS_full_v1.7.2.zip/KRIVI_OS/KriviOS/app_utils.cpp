// ============================================================================
//  Page 3: Utilities & time
//  18 Stopwatch 19 Pomodoro 20 Calculator 21 Calendar 22 Text editor
//  23 Hex viewer 24 3D dice 25 Scorecard 26 Alarm clock
// ============================================================================
#include "apps_common.h"
#include <time.h>

// ============================================================================
//  18  CHRONOMETER STOPWATCH
// ============================================================================
void app_stopwatch(AppCtx &c) {
  bool run = false; uint64_t acc = 0, start = 0; uint32_t laps[6]; int nl = 0;
  auto fmt = [](char *s, uint64_t us) {
    uint32_t ms = us / 1000;
    snprintf(s, 24, "%02lu:%02lu.%03lu", (unsigned long)(ms / 60000), (unsigned long)(ms / 1000 % 60), (unsigned long)(ms % 1000));
  };
  auto buttons = [&]() {
    ui::button(6, 196, 100, 38, run ? "STOP" : "START", run ? C_ERR : C_OK, TFT_BLACK, 2);
    ui::button(110, 196, 100, 38, "LAP", C_PANEL2);
    ui::button(214, 196, 100, 38, "RESET", C_PANEL2);
  };
  auto drawLaps = [&]() {
    tft.fillRect(0, 100, 320, 92, C_BG);
    for (int i = 0; i < nl; ++i) {
      char s[24], l[40]; fmt(s, (uint64_t)laps[i] * 1000);
      uint32_t split = i ? laps[i] - laps[i - 1] : laps[i];
      char sp[24]; fmt(sp, (uint64_t)split * 1000);
      snprintf(l, 40, "LAP %d  %s  (+%s)", i + 1, s, sp);
      tft.setTextColor(i == nl - 1 ? C_ACCENT : C_DIM, C_BG);
      tft.drawString(l, 30 + (i % 2) * 0, 102 + i * 15, 2);
    }
  };
  ui::clearBody(); buttons();
  char last[24] = "";
  while (c.frame(20)) {
    Touch &t = *c.t;
    uint64_t now = esp_timer_get_time();
    uint64_t el = acc + (run ? now - start : 0);
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 6, 196, 100, 38)) { if (run) acc += now - start; else start = now; run = !run; buttons(); audio::click(); }
      else if (ui::inRect(t.sx, t.sy, 110, 196, 100, 38) && run) {
        if (nl == 6) { memmove(laps, laps + 1, 5 * 4); nl = 5; }
        laps[nl++] = el / 1000; drawLaps(); audio::click(); }
      else if (ui::inRect(t.sx, t.sy, 214, 196, 100, 38) && !run) { acc = 0; nl = 0; drawLaps(); }
    }
    char s[24]; fmt(s, el);
    if (strcmp(s, last)) { strcpy(last, s); ui::centerText(s, 160, 62, run ? C_TEXT : C_DIM, C_BG, 7); }
  }
}

// ============================================================================
//  19  POMODORO EFFICIENCY TIMER
// ============================================================================
void app_pomodoro(AppCtx &c) {
  const uint32_t WORK = c.pInt("work_min", 25) * 60, SHORT = c.pInt("break_min", 5) * 60,
                 LONG = c.pInt("long_break_min", 15) * 60;
  int phase = 0, round = 1;   // 0 work, 1 short, 2 long
  uint32_t left = WORK; bool run = false; uint32_t lastSec = millis();
  auto col = [&]() { return phase == 0 ? RGB565(200, 40, 50) : (phase == 1 ? RGB565(30, 160, 80) : RGB565(30, 110, 200)); };
  auto full = [&]() {
    tft.fillRect(0, 26, 320, 214, col());
    ui::centerText(phase == 0 ? "FOCUS" : (phase == 1 ? "SHORT BREAK" : "LONG BREAK"), 160, 46, TFT_WHITE, col(), 4);
    char s[24]; snprintf(s, 24, "Round %d of 4", (round - 1) % 4 + 1);
    ui::centerText(s, 160, 72, TFT_WHITE, col(), 2);
    ui::button(20, 190, 130, 40, run ? "PAUSE" : "START", TFT_WHITE, TFT_BLACK);
    ui::button(170, 190, 130, 40, "SKIP", TFT_WHITE, TFT_BLACK);
    sys::led(phase == 0 ? 80 : 0, phase ? 80 : 0, phase == 2 ? 80 : 0);
  };
  auto clock = [&]() {
    char s[16]; snprintf(s, 16, "%02lu:%02lu", (unsigned long)(left / 60), (unsigned long)(left % 60));
    ui::centerText(s, 160, 128, TFT_WHITE, col(), 7);
    uint32_t total = phase == 0 ? WORK : (phase == 1 ? SHORT : LONG);
    ui::bar(20, 170, 280, 10, 1.0f - (float)left / total, TFT_WHITE, col());
  };
  auto nextPhase = [&]() {
    if (phase == 0) { phase = (round % 4 == 0) ? 2 : 1; } else { phase = 0; round++; }
    left = phase == 0 ? WORK : (phase == 1 ? SHORT : LONG);
    for (int i = 0; i < 3; ++i) { audio::tone(0, phase ? 1046 : 784, 100, audio::SINE, 180, 180); delay(220); }
    full(); clock();
  };
  full(); clock();
  while (c.frame(50)) {
    Touch &t = *c.t;
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 20, 190, 130, 40)) { run = !run; lastSec = millis(); full(); clock(); }
      else if (ui::inRect(t.sx, t.sy, 170, 190, 130, 40)) nextPhase();
    }
    if (run && millis() - lastSec >= 1000) {
      lastSec += 1000;
      if (left) left--;
      clock();
      if (!left) nextPhase();
    }
  }
  sys::led(0, 0, 0);
}

// ============================================================================
//  20  MATH CALCULATOR  (recursive-descent expression parser)
// ============================================================================
namespace calc {
static const char *p; static bool err; static double ans = 0;
static double expr();
static void ws() { while (*p == ' ') p++; }
static double prim() {
  ws();
  if (*p == '(') { p++; double v = expr(); ws(); if (*p == ')') p++; else err = true; return v; }
  if (*p == '-') { p++; return -prim(); }
  if (*p == '+') { p++; return prim(); }
  if (isdigit((unsigned char)*p) || *p == '.') { char *e; double v = strtod(p, &e); p = e; return v; }
  struct F { const char *n; double (*f)(double); };
  static const F fns[] = {{"sqrt", sqrt}, {"sin", nullptr}, {"cos", nullptr}, {"tan", nullptr}, {"log", log10}, {"ln", log}, {"abs", fabs}};
  if (!strncmp(p, "pi", 2)) { p += 2; return M_PI; }
  if (!strncmp(p, "ANS", 3)) { p += 3; return ans; }
  if (*p == 'e' && p[1] != 'x') { p++; return M_E; }
  for (auto &f : fns) {
    size_t l = strlen(f.n);
    if (!strncmp(p, f.n, l)) {
      p += l; double a = prim();
      if (!strcmp(f.n, "sin")) return sin(a * M_PI / 180);
      if (!strcmp(f.n, "cos")) return cos(a * M_PI / 180);
      if (!strcmp(f.n, "tan")) return tan(a * M_PI / 180);
      return f.f(a);
    }
  }
  err = true; return 0;
}
static double power() { double b = prim(); ws(); if (*p == '^') { p++; return pow(b, power()); } return b; }
static double term() {
  double v = power();
  while (true) { ws();
    if (*p == '*') { p++; v *= power(); } else if (*p == '/') { p++; double d = power(); if (d == 0) err = true; else v /= d; }
    else if (*p == '%') { p++; v = fmod(v, power()); }
    else if (*p == '(' || isalpha((unsigned char)*p)) v *= power();        // implicit multiply 2pi, 3(4)
    else return v; }
}
static double expr() {
  double v = term();
  while (true) { ws(); if (*p == '+') { p++; v += term(); } else if (*p == '-') { p++; v -= term(); } else return v; }
}
static bool eval(const String &s, double &out) { p = s.c_str(); err = false; out = expr(); ws(); if (*p) err = true; return !err && isfinite(out); }
}

void app_calc(AppCtx &c) {
  static const char *K[5][6] = {
    {"sin", "cos", "tan", "sqrt", "^", "AC"},
    {"7", "8", "9", "(", ")", "DEL"},
    {"4", "5", "6", "*", "/", "pi"},
    {"1", "2", "3", "+", "-", "ln"},
    {"0", ".", "ANS", "log", "%", "="}};
  String e; String res = "0";
  const int KX = 4, KY = 88, KW = 52, KH = 29;
  auto keys = [&]() {
    for (int r = 0; r < 5; ++r) for (int k = 0; k < 6; ++k) {
      const char *l = K[r][k];
      uint16_t bg = isdigit((unsigned char)l[0]) || l[0] == '.' ? C_PANEL : C_PANEL2;
      if (!strcmp(l, "=")) bg = C_OK; if (!strcmp(l, "AC")) bg = C_ERR;
      ui::button(KX + k * KW, KY + r * (KH + 1), KW - 3, KH, l, bg, !strcmp(l, "=") ? TFT_BLACK : C_TEXT, 2);
    }
  };
  auto disp = [&]() {
    tft.fillRoundRect(4, 30, 312, 54, 6, RGB565(12, 22, 18));
    String shown = e.length() > 38 ? "~" + e.substring(e.length() - 37) : e;
    tft.setTextColor(C_DIM, RGB565(12, 22, 18)); tft.drawString(shown, 10, 34, 2);
    tft.setTextColor(RGB565(120, 255, 170), RGB565(12, 22, 18));
    tft.setTextDatum(TR_DATUM); tft.drawString(res, 310, 54, 4); tft.setTextDatum(TL_DATUM);
  };
  ui::clearBody(); keys(); disp();
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap || t.sy < KY) continue;
    int k = (t.sx - KX) / KW, r = (t.sy - KY) / (KH + 1);
    if (k < 0 || k > 5 || r > 4) continue;
    String l = K[r][k]; audio::click();
    if (l == "AC") { e = ""; res = "0"; }
    else if (l == "DEL") { if (e.length()) e.remove(e.length() - 1); }
    else if (l == "=") {
      double v;
      if (calc::eval(e, v)) {
        calc::ans = v; char b[32];
        if (fabs(v) >= 1e10 || (fabs(v) < 1e-6 && v != 0)) snprintf(b, 32, "%.6e", v);
        else { snprintf(b, 32, "%.10f", v); char *q = b + strlen(b) - 1; while (*q == '0') *q-- = 0; if (*q == '.') *q = 0; }
        res = b;
      } else res = "Error";
    }
    else if (l == "sin" || l == "cos" || l == "tan" || l == "sqrt" || l == "ln" || l == "log") e += l + "(";
    else e += l;
    disp();
  }
}

// ============================================================================
//  21  INTERACTIVE CALENDAR
// ============================================================================
static bool isLeap(int y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }
static int daysIn(int y, int m) { static const int D[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; return m == 2 && isLeap(y) ? 29 : D[m - 1]; }
static int dow(int y, int m, int d) {           // Sakamoto, 0 = Sunday
  static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
  if (m < 3) y -= 1;
  return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
}
void app_calendar(AppCtx &c) {
  static const char *MN[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
  struct tm now; bool valid = sys::now(now);
  int y = valid ? now.tm_year + 1900 : 2026, m = valid ? now.tm_mon + 1 : 1;
  auto draw = [&]() {
    ui::clearBody();
    char s[32]; snprintf(s, 32, "%s %d", MN[m - 1], y);
    ui::centerText(s, 160, 42, C_TEXT, C_BG, 4);
    ui::button(4, 30, 44, 28, "<", C_PANEL2, C_TEXT, 4);
    ui::button(272, 30, 44, 28, ">", C_PANEL2, C_TEXT, 4);
    static const char *DN[7] = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
    for (int i = 0; i < 7; ++i) ui::centerText(DN[i], 23 + i * 45, 70, i == 0 ? C_ERR : C_DIM, C_BG, 2);
    int first = dow(y, m, 1), nd = daysIn(y, m);
    for (int d = 1; d <= nd; ++d) {
      int cell = first + d - 1, cx = 23 + (cell % 7) * 45, cy = 92 + (cell / 7) * 25;
      bool today = valid && y == now.tm_year + 1900 && m == now.tm_mon + 1 && d == now.tm_mday;
      if (today) tft.fillRoundRect(cx - 18, cy - 11, 36, 22, 5, C_ACCENT);
      char b[4]; snprintf(b, 4, "%d", d);
      ui::centerText(b, cx, cy, today ? TFT_BLACK : (cell % 7 == 0 ? C_ERR : C_TEXT), today ? C_ACCENT : C_BG, 2);
    }
    snprintf(s, 32, "%d is %sa leap year (%d days)", y, isLeap(y) ? "" : "not ", isLeap(y) ? 366 : 365);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 6, 230, 1);
    if (!valid) { tft.setTextColor(C_WARN, C_BG); tft.drawString("clock not set", 240, 230, 1); }
  };
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    bool prev = t.swipe == SW_RIGHT || (t.tap && ui::inRect(t.sx, t.sy, 4, 30, 44, 28));
    bool next = t.swipe == SW_LEFT || (t.tap && ui::inRect(t.sx, t.sy, 272, 30, 44, 28));
    if (t.swipe == SW_UP) { y++; draw(); }
    else if (t.swipe == SW_DOWN) { y--; draw(); }
    else if (prev) { if (--m < 1) { m = 12; y--; } draw(); }
    else if (next) { if (++m > 12) { m = 1; y++; } draw(); }
  }
}

// ============================================================================
//  22  TEXT DOCUMENT EDITOR
// ============================================================================
void app_editor(AppCtx &c) {
  String text, path;
  int cur = 0, top = 0;           // cursor index, first visible line
  bool dirty = false;
  ui::Keyboard kb; kb.y0 = 128;
  const int TY = 52, TH = 74, LH = 12, COLS = 52, VIS = TH / LH;
  auto lines = [&](std::vector<int> &starts) {        // soft-wrapped line starts
    starts.clear(); starts.push_back(0);
    int col = 0;
    for (int i = 0; i < (int)text.length(); ++i) {
      if (text[i] == '\n') { starts.push_back(i + 1); col = 0; }
      else if (++col >= COLS) { starts.push_back(i + 1); col = 0; }
    }
  };
  auto toolbar = [&]() {
    tft.fillRect(0, 26, 320, 24, C_BG);
    ui::button(2, 28, 52, 22, "NEW", C_PANEL2, C_TEXT, 1);
    ui::button(56, 28, 52, 22, "OPEN", C_PANEL2, C_TEXT, 1);
    ui::button(110, 28, 52, 22, "SAVE", dirty ? RGB565(0, 110, 60) : C_PANEL2, C_TEXT, 1);
    ui::button(164, 28, 30, 22, "^", C_PANEL2, C_TEXT, 1);
    ui::button(196, 28, 30, 22, "v", C_PANEL2, C_TEXT, 1);
    String nm = path.length() ? path.substring(path.lastIndexOf('/') + 1) : String("untitled");
    if (dirty) nm += "*";
    tft.setTextColor(C_DIM, C_BG); tft.drawString(nm.substring(0, 15), 230, 34, 1);
  };
  auto body = [&]() {
    std::vector<int> st; lines(st);
    int cl = 0; for (int i = 0; i < (int)st.size(); ++i) if (st[i] <= cur) cl = i;
    if (cl < top) top = cl; if (cl >= top + VIS) top = cl - VIS + 1;
    tft.fillRect(0, TY, 320, TH, RGB565(250, 248, 240));
    for (int i = 0; i < VIS && top + i < (int)st.size(); ++i) {
      int s0 = st[top + i], s1 = top + i + 1 < (int)st.size() ? st[top + i + 1] : text.length();
      String ln = text.substring(s0, s1); ln.replace("\n", "");
      tft.setTextColor(RGB565(20, 20, 30), RGB565(250, 248, 240));
      tft.drawString(ln, 4, TY + 1 + i * LH, 1);
      if (top + i == cl) tft.drawFastVLine(4 + (cur - s0) * 6, TY + i * LH, LH, C_ERR);
    }
  };
  auto save = [&]() {
    if (!path.length()) {
      String nm = "note.txt";
      if (!ui::textInput(nm, "Save as (in /data/reader)", 30)) { c.header(); toolbar(); body(); kb.draw(); return; }
      if (!nm.endsWith(".txt")) nm += ".txt";
      path = "/data/reader/" + nm;
      c.header();
    }
    File f = SD.open(path, FILE_WRITE);
    if (f) { f.print(text); f.close(); dirty = false; sys::log("editor: saved %s (%u B)", path.c_str(), text.length()); }
    else ui::msgBox("SAVE FAILED", "Could not write to the SD card.");
    ui::clearBody(); toolbar(); body(); kb.draw();
  };
  ui::clearBody(); toolbar(); body(); kb.draw();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.pressed && t.y >= kb.y0) {
      int k = kb.hit(t.x, t.y);
      if (!k) continue;
      if (k == ui::Keyboard::K_BKSP) { if (cur > 0) { text.remove(cur - 1, 1); cur--; } }
      else if (k == ui::Keyboard::K_LEFT) { if (cur > 0) cur--; }
      else if (k == ui::Keyboard::K_RIGHT) { if (cur < (int)text.length()) cur++; }
      else if (k == ui::Keyboard::K_ENTER) { text = text.substring(0, cur) + "\n" + text.substring(cur); cur++; }
      else if (k >= 32) { if (text.length() < 16000) { text = text.substring(0, cur) + (char)k + text.substring(cur); cur++; } }
      bool wasDirty = dirty; dirty = true; if (!wasDirty) toolbar();
      body();
    } else if (t.tap && t.sy >= TY && t.sy < TY + TH) {          // tap to place cursor
      std::vector<int> st; lines(st);
      int li = top + (t.sy - TY) / LH;
      if (li < (int)st.size()) {
        int s0 = st[li], s1 = li + 1 < (int)st.size() ? st[li + 1] - 1 : text.length();
        cur = constrain(s0 + (t.sx - 4 + 3) / 6, s0, max(s0, s1));
        body();
      }
    } else if (t.tap && t.sy < TY) {
      if (ui::inRect(t.sx, t.sy, 2, 28, 52, 22)) {
        if (!dirty || ui::confirm("NEW FILE", "Discard unsaved changes?")) { text = ""; path = ""; cur = top = 0; dirty = false; }
        ui::clearBody(); toolbar(); body(); kb.draw();
      } else if (ui::inRect(t.sx, t.sy, 56, 28, 52, 22)) {
        String p = ui::pickFile("/data/reader", ".txt", "OPEN text file");
        if (p.length()) {
          File f = SD.open(p);
          if (f) { size_t n = min((size_t)f.size(), (size_t)16000); text = ""; text.reserve(n);
            while (f.available() && text.length() < n) text += (char)f.read(); f.close(); path = p; cur = top = 0; dirty = false; }
        }
        c.header(); ui::clearBody(); toolbar(); body(); kb.draw();
      } else if (ui::inRect(t.sx, t.sy, 110, 28, 52, 22)) save();
      else if (ui::inRect(t.sx, t.sy, 164, 28, 30, 22)) { if (top > 0) top--; std::vector<int> st; lines(st); cur = st[top]; body(); }
      else if (ui::inRect(t.sx, t.sy, 196, 28, 30, 22)) { std::vector<int> st; lines(st); if (top + 1 < (int)st.size()) top++; cur = st[top]; body(); }
    }
  }
  if (dirty && sys::sdOk) {
    tft.fillScreen(C_BG);
    if (ui::confirm("UNSAVED", "Save changes before closing?")) {
      if (!path.length()) path = "/data/reader/autosave.txt";
      File f = SD.open(path, FILE_WRITE); if (f) { f.print(text); f.close(); }
    }
  }
}

// ============================================================================
//  23  RAW HEX VIEWER
// ============================================================================
void app_hexview(AppCtx &c) {
  while (true) {
    String path = ui::pickFile("/", nullptr, "HEX - open any file", true);
    if (!path.length()) return;
    File f = SD.open(path);
    if (!f) continue;
    uint32_t size = f.size(), off = 0;
    const int ROWS = 12;
    c.header();
    ui::clearBody();
    String nm = path.substring(path.lastIndexOf('/') + 1);
    auto draw = [&]() {
      uint8_t buf[8 * ROWS];
      f.seek(off); int n = f.read(buf, sizeof(buf));
      tft.fillRect(0, 28, 320, 180, TFT_BLACK);
      for (int r = 0; r < ROWS; ++r) {
        char line[64]; int p = snprintf(line, 64, "%06lX ", (unsigned long)(off + r * 8));
        tft.setTextColor(C_WARN, TFT_BLACK); tft.drawString(line, 2, 30 + r * 14, 1);
        p = 0;
        for (int k = 0; k < 8; ++k) {
          int i = r * 8 + k;
          p += snprintf(line + p, 64 - p, i < n ? "%02X " : "   ", i < n ? buf[i] : 0);
        }
        tft.setTextColor(RGB565(120, 255, 170), TFT_BLACK); tft.drawString(line, 48, 30 + r * 14, 1);
        p = 0;
        for (int k = 0; k < 8; ++k) { int i = r * 8 + k; line[p++] = i < n ? (isprint(buf[i]) ? buf[i] : '.') : ' '; }
        line[p] = 0;
        tft.setTextColor(C_ACCENT, TFT_BLACK); tft.drawString(line, 200, 30 + r * 14, 1);
      }
      tft.fillRect(0, 200, 320, 8, C_BG);
      char s[64]; snprintf(s, 64, "%s  %lu/%lu B", nm.substring(0, 24).c_str(), (unsigned long)off, (unsigned long)size);
      tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 2, 200, 1);
    };
    ui::button(2, 210, 60, 28, "-4K"); ui::button(66, 210, 60, 28, "PG UP");
    ui::button(130, 210, 60, 28, "PG DN"); ui::button(194, 210, 60, 28, "+4K"); ui::button(258, 210, 60, 28, "FILES");
    draw();
    bool back = false;
    while (!back) {
      if (!c.loop()) { f.close(); return; }
      Touch &t = *c.t;
      int32_t delta = 0;
      if (t.swipe == SW_UP) delta = 8 * ROWS; else if (t.swipe == SW_DOWN) delta = -8 * ROWS;
      if (t.tap) {
        if (ui::inRect(t.sx, t.sy, 2, 210, 60, 28)) delta = -4096;
        else if (ui::inRect(t.sx, t.sy, 66, 210, 60, 28)) delta = -8 * ROWS;
        else if (ui::inRect(t.sx, t.sy, 130, 210, 60, 28)) delta = 8 * ROWS;
        else if (ui::inRect(t.sx, t.sy, 194, 210, 60, 28)) delta = 4096;
        else if (ui::inRect(t.sx, t.sy, 258, 210, 60, 28)) back = true;
      }
      if (delta) {
        int64_t no = (int64_t)off + delta;
        if (no < 0) no = 0;
        if (no >= size) no = size ? ((size - 1) / 8) * 8 : 0;
        if ((uint32_t)no != off) { off = no; draw(); }
      }
    }
    f.close();
  }
}

// ============================================================================
//  24  3D RANDOM DICE ENGINE
// ============================================================================
namespace dice {
struct V3 { float x, y, z; };
static const int8_t CV[8][3] = {{-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},{-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}};
// faces: vertex indices (CCW seen from outside), value, normal
static const uint8_t FV[6][4] = {{4,5,6,7},{1,0,3,2},{0,4,7,3},{5,1,2,6},{0,1,5,4},{7,6,2,3}};
static const uint8_t FVAL[6] = {1, 6, 2, 5, 3, 4};      // opposite faces sum to 7
static const int8_t FN[6][3] = {{0,0,1},{0,0,-1},{-1,0,0},{1,0,0},{0,-1,0},{0,1,0}};
static const int8_t PIPS[7][7][2] = {
  {}, {{0,0}}, {{-1,-1},{1,1}}, {{-1,-1},{0,0},{1,1}}, {{-1,-1},{1,-1},{-1,1},{1,1}},
  {{-1,-1},{1,-1},{0,0},{-1,1},{1,1}}, {{-1,-1},{1,-1},{-1,0},{1,0},{-1,1},{1,1}}};
static const uint8_t NP[7] = {0, 1, 2, 3, 4, 5, 6};
static void rot(float m[9], float ax, float ay, float az) {
  float cx = cosf(ax), sx = sinf(ax), cy = cosf(ay), sy = sinf(ay), cz = cosf(az), sz = sinf(az);
  m[0] = cy * cz; m[1] = -cy * sz; m[2] = sy;
  m[3] = sx * sy * cz + cx * sz; m[4] = -sx * sy * sz + cx * cz; m[5] = -sx * cy;
  m[6] = -cx * sy * cz + sx * sz; m[7] = cx * sy * sz + sx * cz; m[8] = cx * cy;
}
static inline V3 mul(const float m[9], float x, float y, float z) {
  return {m[0] * x + m[1] * y + m[2] * z, m[3] * x + m[4] * y + m[5] * z, m[6] * x + m[7] * y + m[8] * z};
}
static void drawDie(TFT_eSprite &s, int cx, int cy, float sz, const float m[9], uint16_t body) {
  V3 v[8]; int16_t px[8], py[8];
  for (int i = 0; i < 8; ++i) {
    v[i] = mul(m, CV[i][0], CV[i][1], CV[i][2]);
    float zc = 5.0f / (5.0f - v[i].z);
    px[i] = cx + (int)(v[i].x * sz * zc); py[i] = cy + (int)(v[i].y * sz * zc);
  }
  for (int f = 0; f < 6; ++f) {
    V3 n = mul(m, FN[f][0], FN[f][1], FN[f][2]);
    if (n.z <= 0.05f) continue;                      // back-face cull
    const uint8_t *q = FV[f];
    uint8_t shade = 120 + (uint8_t)(n.z * 135);
    uint16_t col = tft.alphaBlend(shade, body, TFT_BLACK);
    s.fillTriangle(px[q[0]], py[q[0]], px[q[1]], py[q[1]], px[q[2]], py[q[2]], col);
    s.fillTriangle(px[q[0]], py[q[0]], px[q[2]], py[q[2]], px[q[3]], py[q[3]], col);
    int val = FVAL[f];
    // face axes in model space
    V3 a = {(float)CV[q[1]][0] - CV[q[0]][0], (float)CV[q[1]][1] - CV[q[0]][1], (float)CV[q[1]][2] - CV[q[0]][2]};
    V3 b = {(float)CV[q[3]][0] - CV[q[0]][0], (float)CV[q[3]][1] - CV[q[0]][1], (float)CV[q[3]][2] - CV[q[0]][2]};
    for (int k = 0; k < NP[val]; ++k) {
      float u = 0.5f + PIPS[val][k][0] * 0.28f, w = 0.5f + PIPS[val][k][1] * 0.28f;
      float mx = CV[q[0]][0] + a.x * u + b.x * w, my = CV[q[0]][1] + a.y * u + b.y * w, mz = CV[q[0]][2] + a.z * u + b.z * w;
      V3 p = mul(m, mx, my, mz);
      float zc = 5.0f / (5.0f - p.z);
      s.fillCircle(cx + (int)(p.x * sz * zc), cy + (int)(p.y * sz * zc), max(2, (int)(sz * 0.13f * n.z)), TFT_BLACK);
    }
  }
}
// orientation (ax, ay) that shows face value v toward the viewer (+z)
static void restFor(int v, float &ax, float &ay) {
  switch (v) { case 1: ax = 0; ay = 0; break; case 6: ax = 0; ay = PI; break;
               case 2: ax = 0; ay = PI / 2; break; case 5: ax = 0; ay = -PI / 2; break;
               case 3: ax = -PI / 2; ay = 0; break; default: ax = PI / 2; ay = 0; break; }
}
}  // namespace dice

void app_dice(AppCtx &c) {
  // Render the 320x170 dice area in horizontal strips so we only need a
  // 320x34 sprite (~11 KB) instead of a full 320x170 buffer (~54 KB).
  const int SPW = 320, AREA_H = 170, STRIP = 34, NS = AREA_H / STRIP;  // 5 strips
  TFT_eSprite spr(&tft);
  spr.setColorDepth(8);
  if (!spr.createSprite(SPW, STRIP)) { ui::msgBox("DICE", "Not enough RAM"); return; }
  float ax[2] = {0.5f, -0.4f}, ay[2] = {0.6f, 0.9f}, az[2] = {0, 0.3f};
  float vx[2] = {0}, vy[2] = {0}, vz[2] = {0};
  int val[2] = {(int)rnd(6) + 1, (int)rnd(6) + 1};
  bool rolling = false; uint32_t rollT = 0;
  float tax[2], tay[2];
  for (int i = 0; i < 2; ++i) dice::restFor(val[i], tax[i], tay[i]);
  ui::clearBody();
  ui::button(110, 204, 100, 32, "ROLL", C_OK, TFT_BLACK);
  int total = 0;
  while (c.frame(30)) {
    Touch &t = *c.t;
    if (!rolling && (t.tap || t.swipe)) {
      rolling = true; rollT = millis();
      for (int i = 0; i < 2; ++i) { vx[i] = 0.25f + rnd(100) / 400.0f; vy[i] = 0.3f + rnd(100) / 300.0f; vz[i] = (rnd(100) - 50) / 400.0f;
        val[i] = rnd(6) + 1; dice::restFor(val[i], tax[i], tay[i]); }
      audio::tone(2, 300, 60, audio::NOISE, 500, 500);
    }
    uint32_t el = millis() - rollT;
    for (int i = 0; i < 2; ++i) {
      if (rolling && el < 900) { ax[i] += vx[i]; ay[i] += vy[i]; az[i] += vz[i]; vx[i] *= 0.985f; vy[i] *= 0.985f; }
      else {                                   // settle onto the result face
        auto ease = [](float &a, float target) { float d = fmodf(target - a, 2 * PI); if (d > PI) d -= 2 * PI; if (d < -PI) d += 2 * PI; a += d * 0.25f; };
        ease(ax[i], tax[i]); ease(ay[i], tay[i]); ease(az[i], (i ? 0.25f : -0.2f));
      }
    }
    if (rolling && el > 1500) { rolling = false; total = val[0] + val[1]; audio::beep(1200, 40); }
    // rotation matrices + bounce computed once, then each strip reuses them
    float m[2][9]; int bounce[2];
    for (int i = 0; i < 2; ++i) {
      dice::rot(m[i], ax[i], ay[i], az[i]);
      bounce[i] = rolling && el < 900 ? (int)(fabsf(sinf(el / 90.0f + i)) * 25 * (1 - el / 900.0f)) : 0;
    }
    for (int sp = 0; sp < NS; ++sp) {
      int y0 = sp * STRIP;
      spr.fillSprite(RGB565(20, 70, 40));
      for (int i = 0; i < 2; ++i)
        dice::drawDie(spr, 90 + i * 140, (90 - bounce[i]) - y0, 42, m[i], i ? RGB565(250, 250, 245) : RGB565(230, 60, 60));
      spr.pushSprite(0, 28 + y0);
    }
    if (!rolling && total) {
      char s[24]; snprintf(s, 24, "%d + %d = %d  ", val[0], val[1], total);
      tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 8, 210, 2);
      total = 0;
    }
  }
  spr.deleteSprite();
}

// ============================================================================
//  25  DUAL SCORECARD COUNTER
// ============================================================================
// ============================================================================
//  26  SYNC ALARM CLOCK
// ============================================================================
void app_alarm(AppCtx &c) {
  auto draw = [&]() {
    ui::clearBody();
    ui::button(4, 104, 60, 30, "H-"); ui::button(68, 104, 60, 30, "H+");
    ui::button(132, 104, 60, 30, "M-"); ui::button(196, 104, 60, 30, "M+");
    char s[24]; snprintf(s, 24, "ALARM %02d:%02d", sys::alarm.h, sys::alarm.m);
    tft.setTextColor(sys::alarm.enabled ? C_WARN : C_DIM, C_BG); tft.drawString(s, 8, 142, 4);
    ui::button(200, 140, 116, 30, sys::alarm.enabled ? "ARMED" : "OFF", sys::alarm.enabled ? C_OK : C_PANEL2, sys::alarm.enabled ? TFT_BLACK : C_TEXT);
    ui::button(4, 200, 150, 34, "SET CLOCK");
    ui::button(160, 200, 156, 34, "SYNC NTP");
    tft.setTextColor(C_DIM, C_BG);
    tft.drawString(String("clock: ") + sys::ntpState(), 262, 106, 1);
    tft.drawString("Rings anywhere in KRIVI OS. Tap the banner to stop.", 4, 180, 1);
  };
  draw();
  char last[16] = "";
  while (c.frame(100)) {
    Touch &t = *c.t;
    struct tm tm; bool v = sys::now(tm);
    char s[16];
    if (v) snprintf(s, 16, "%02d:%02d:%02d", tm.tm_hour, tm.tm_min, tm.tm_sec); else strcpy(s, "--:--:--");
    if (strcmp(s, last)) { strcpy(last, s); ui::centerText(s, 160, 64, v ? C_TEXT : C_DIM, C_BG, 7); }
    if (!t.tap) continue;
    bool ch = true;
    if (ui::inRect(t.sx, t.sy, 4, 104, 60, 30)) sys::alarm.h = (sys::alarm.h + 23) % 24;
    else if (ui::inRect(t.sx, t.sy, 68, 104, 60, 30)) sys::alarm.h = (sys::alarm.h + 1) % 24;
    else if (ui::inRect(t.sx, t.sy, 132, 104, 60, 30)) sys::alarm.m = (sys::alarm.m + 59) % 60;
    else if (ui::inRect(t.sx, t.sy, 196, 104, 60, 30)) sys::alarm.m = (sys::alarm.m + 1) % 60;
    else if (ui::inRect(t.sx, t.sy, 200, 140, 116, 30)) { sys::alarm.enabled = !sys::alarm.enabled; sys::alarm.lastDay = 255; }
    else if (ui::inRect(t.sx, t.sy, 160, 200, 156, 34)) { sys::startNtp(); }
    else if (ui::inRect(t.sx, t.sy, 4, 200, 150, 34)) {
      String in = v ? String(tm.tm_year + 1900) + "-" + (tm.tm_mon < 9 ? "0" : "") + String(tm.tm_mon + 1) + "-" +
                      (tm.tm_mday < 10 ? "0" : "") + String(tm.tm_mday) + " " + (tm.tm_hour < 10 ? "0" : "") + String(tm.tm_hour) + ":" +
                      (tm.tm_min < 10 ? "0" : "") + String(tm.tm_min) : String("2026-01-01 12:00");
      if (ui::textInput(in, "Clock: YYYY-MM-DD HH:MM", 16)) {
        int Y, Mo, D, H, Mi;
        if (sscanf(in.c_str(), "%d-%d-%d %d:%d", &Y, &Mo, &D, &H, &Mi) == 5) sys::setClock(Y, Mo, D, H, Mi, 0);
      }
      c.header(); last[0] = 0;
    } else ch = false;
    if (ch) { sys::saveSettings(); draw(); last[0] = 0; }
  }
  sys::saveSettings();
}
