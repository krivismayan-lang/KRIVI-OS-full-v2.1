// ============================================================================
//  Media players
//   App 44  MP3 Music Player   - Helix fixed-point MP3 decoder (vendored in
//                                src/helix), any MPEG-1/2 layer III file,
//                                mixed to mono and streamed to the DAC
//   App 40  Video & MP4 Player - the ESP32 cannot decode H.264, so MP4s are
//                                converted on a computer (tools/convert_media.py)
//                                into AVI = Motion-JPEG video + 8-bit PCM audio,
//                                played with audio as the master clock.
//                                Raw .mjpeg clips (Bad Apple) still play too.
// ============================================================================
#include "apps_common.h"
#include <TJpg_Decoder.h>
#include "src/helix/mp3dec.h"

// ---------------------------------------------------------------- shared
static bool mediaJpgOut(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bmp) {
  if (y >= SCR_H) return false;
  tft.pushImage(x, y, w, h, bmp);
  return true;
}
static String fmtTime(uint32_t s) {
  char b[12]; snprintf(b, sizeof(b), "%lu:%02lu", (unsigned long)(s / 60), (unsigned long)(s % 60));
  return b;
}

// ============================================================================
//  44  MP3 MUSIC PLAYER
// ============================================================================
namespace mp3 {
struct Tags { String title, artist, album; };

// ID3v2 text frame -> plain ASCII (ISO-8859-1 or UTF-16 with BOM)
static String id3Text(const uint8_t *d, int n) {
  if (n <= 1) return "";
  uint8_t enc = d[0]; String s;
  if (enc == 1 || enc == 2) {
    int i = 1; bool le = true;
    if (enc == 1 && n >= 3) { le = !(d[1] == 0xFE && d[2] == 0xFF); i = 3; }
    for (; i + 1 < n; i += 2) {
      uint16_t c = le ? (d[i] | (d[i + 1] << 8)) : ((d[i] << 8) | d[i + 1]);
      if (!c) break;
      s += (c < 128) ? (char)c : '?';
    }
  } else {
    for (int i = 1; i < n && d[i]; ++i) s += (d[i] < 128) ? (char)d[i] : '?';
  }
  s.trim();
  return s;
}
// Returns the byte offset of the first audio frame (past any ID3v2 tag)
static uint32_t readTags(File &f, Tags &t) {
  uint8_t h[10];
  f.seek(0);
  if (f.read(h, 10) != 10 || memcmp(h, "ID3", 3)) return 0;
  uint8_t ver = h[3];
  uint32_t size = ((h[6] & 0x7F) << 21) | ((h[7] & 0x7F) << 14) | ((h[8] & 0x7F) << 7) | (h[9] & 0x7F);
  uint32_t end = 10 + size, pos = 10;
  while (pos + 10 < end) {
    uint8_t fh[10];
    f.seek(pos);
    if (f.read(fh, 10) != 10 || !fh[0]) break;
    uint32_t fs = ver >= 4 ? (((fh[4] & 0x7F) << 21) | ((fh[5] & 0x7F) << 14) | ((fh[6] & 0x7F) << 7) | (fh[7] & 0x7F))
                           : ((uint32_t)fh[4] << 24 | fh[5] << 16 | fh[6] << 8 | fh[7]);
    if (fs == 0 || pos + 10 + fs > end) break;
    bool want = !memcmp(fh, "TIT2", 4) || !memcmp(fh, "TPE1", 4) || !memcmp(fh, "TALB", 4);
    if (want && fs < 256) {
      uint8_t buf[256]; f.read(buf, fs);
      String v = id3Text(buf, fs);
      if (!memcmp(fh, "TIT2", 4)) t.title = v; else if (!memcmp(fh, "TPE1", 4)) t.artist = v; else t.album = v;
    }
    pos += 10 + fs;
  }
  return end + ((h[5] & 0x10) ? 10 : 0);          // + footer
}
}  // namespace mp3

void app_mp3(AppCtx &c) {
  String first = ui::pickFile("/data/music", ".mp3", "MP3 - pick a song");
  if (!first.length()) return;
  String dir = first.substring(0, first.lastIndexOf('/'));
  std::vector<String> list = sys::listDir(dir.c_str(), ".mp3");
  int idx = 0;
  for (int i = 0; i < (int)list.size(); ++i) if (dir + "/" + list[i] == first) idx = i;

  HMP3Decoder dec = MP3InitDecoder();
  const int INBUF = 2 * MAINBUF_SIZE;
  uint8_t *inbuf = (uint8_t *)sys::bigAlloc(INBUF);
  int16_t *pcm = (int16_t *)sys::bigAlloc(MAX_NSAMP * MAX_NCHAN * MAX_NGRAN * 2);
  if (!dec || !inbuf || !pcm || !audio::streamBegin(44100, 8192)) {
    if (dec) MP3FreeDecoder(dec); free(inbuf); free(pcm);
    c.header(); ui::msgBox("MP3", "Not enough RAM for the decoder."); return;
  }
  int vol = c.pInt("volume", 220);
  audio::streamVolume(vol);
  bool shuffle = false, repeatAll = true;

  // ---------------- UI
  const int VX = 10, VY = 104, VW = 300, VH = 60;    // visualizer
  uint8_t bars[30]; memset(bars, 0, sizeof(bars));
  auto controls = [&](bool paused) {
    ui::button(4, 200, 58, 36, "|<", C_PANEL2, C_TEXT, 2);
    ui::button(66, 200, 78, 36, paused ? "PLAY" : "PAUSE", paused ? C_OK : RGB565(90, 50, 160), paused ? TFT_BLACK : C_TEXT, 2);
    ui::button(148, 200, 58, 36, ">|", C_PANEL2, C_TEXT, 2);
    ui::button(210, 200, 34, 36, "-", C_PANEL2, C_TEXT, 4);
    ui::button(248, 200, 34, 36, "+", C_PANEL2, C_TEXT, 4);
    ui::button(286, 200, 30, 36, shuffle ? "SH" : (repeatAll ? "RA" : "1x"), shuffle ? C_WARN : C_PANEL2, shuffle ? TFT_BLACK : C_TEXT, 1);
  };

  bool quit = false;
  while (!quit && !list.empty()) {
    String path = dir + "/" + list[idx];
    File f = SD.open(path);
    if (!f) { idx = (idx + 1) % list.size(); continue; }
    mp3::Tags tags;
    uint32_t dataStart = mp3::readTags(f, tags);
    uint32_t fileSize = f.size();
    if (!tags.title.length()) { tags.title = list[idx]; tags.title.replace(".mp3", ""); tags.title.replace(".MP3", ""); }
    f.seek(dataStart);

    c.header();
    ui::clearBody();
    tft.setTextColor(C_TEXT, C_BG); tft.drawString(tags.title.substring(0, 26), 10, 32, 4);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString((tags.artist.length() ? tags.artist : String("Unknown artist")).substring(0, 40), 10, 60, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString(tags.album.substring(0, 50), 10, 78, 1);
    char hb[24]; snprintf(hb, sizeof(hb), "%d / %d", idx + 1, (int)list.size()); hud(hb, C_DIM);
    tft.drawRect(VX - 1, VY - 1, VW + 2, VH + 2, C_PANEL2);
    bool paused = false;
    controls(paused);

    int bytesLeft = 0; uint8_t *rp = inbuf;
    bool eof = false, rateSet = false;
    int bitrate = 0, srate = 44100, chans = 2;
    uint32_t playedBase = audio::streamPlayed();
    uint32_t lastUi = 0;
    int peak = 0, next = 0;          // next: 0 none, 1 next, -1 prev
    while (true) {
      // ---- decode while the ring has room for a whole frame
      while (!paused && !eof && audio::streamSpace() > 1200) {
        if (bytesLeft < MAINBUF_SIZE) {
          memmove(inbuf, rp, bytesLeft);
          int n = f.read(inbuf + bytesLeft, INBUF - bytesLeft);
          if (n > 0) bytesLeft += n;
          rp = inbuf;
          if (n <= 0 && bytesLeft < 4) { eof = true; break; }
        }
        int off = MP3FindSyncWord(rp, bytesLeft);
        if (off < 0) { bytesLeft = 0; continue; }
        rp += off; bytesLeft -= off;
        int err = MP3Decode(dec, &rp, &bytesLeft, pcm, 0);
        if (err == ERR_MP3_INDATA_UNDERFLOW || err == ERR_MP3_MAINDATA_UNDERFLOW) {
          if (f.available() == 0 && err == ERR_MP3_INDATA_UNDERFLOW) { eof = true; break; }
          if (bytesLeft >= MAINBUF_SIZE) { rp++; bytesLeft--; }
          continue;
        }
        if (err) { if (bytesLeft > 0) { rp++; bytesLeft--; } continue; }
        MP3FrameInfo fi; MP3GetLastFrameInfo(dec, &fi);
        if (!rateSet || fi.samprate != srate) { srate = fi.samprate; audio::streamSetRate(srate); rateSet = true; }
        chans = fi.nChans; bitrate = fi.bitrate;
        int frames = fi.outputSamps / max(1, chans);
        if (chans == 2) for (int i = 0; i < frames; ++i) pcm[i] = (pcm[2 * i] + pcm[2 * i + 1]) / 2;
        for (int i = 0; i < frames; i += 8) peak = max(peak, abs((int)pcm[i]));
        audio::streamWrite(pcm, frames);
      }
      if (eof && audio::streamQueued() < 64) { next = 1; break; }

      // ---- input
      if (!c.loop()) { quit = true; break; }
      Touch &t = *c.t;
      if (t.tap) {
        if (ui::inRect(t.sx, t.sy, 4, 200, 58, 36)) { next = -1; break; }
        if (ui::inRect(t.sx, t.sy, 148, 200, 58, 36)) { next = 1; break; }
        if (ui::inRect(t.sx, t.sy, 66, 200, 78, 36)) { paused = !paused; audio::streamPause(paused); controls(paused); }
        if (ui::inRect(t.sx, t.sy, 210, 200, 34, 36)) { vol = max(20, vol - 30); audio::streamVolume(vol); }
        if (ui::inRect(t.sx, t.sy, 248, 200, 34, 36)) { vol = min(255, vol + 30); audio::streamVolume(vol); }
        if (ui::inRect(t.sx, t.sy, 286, 200, 30, 36)) {
          if (shuffle) { shuffle = false; repeatAll = false; } else if (!repeatAll) repeatAll = true; else shuffle = true;
          controls(paused);
        }
        // seek: tap the progress bar
        if (t.sy >= 170 && t.sy < 192 && fileSize > dataStart) {
          float fr = constrain((t.sx - 10) / 300.0f, 0.f, 1.f);
          uint32_t pos = dataStart + (uint32_t)((fileSize - dataStart) * fr);
          audio::streamFlush(); f.seek(pos); bytesLeft = 0; rp = inbuf; eof = false;
          playedBase = audio::streamPlayed() - (uint32_t)((pos - dataStart) * 8.0f / max(1, bitrate) * srate);
        }
      }
      if (t.swipe == SW_LEFT) { next = 1; break; }
      if (t.swipe == SW_RIGHT) { next = -1; break; }

      // ---- display @ ~15 fps
      if (millis() - lastUi > 66) {
        lastUi = millis();
        memmove(bars, bars + 1, sizeof(bars) - 1);
        bars[sizeof(bars) - 1] = paused ? 0 : (uint8_t)min(VH - 2, peak * (VH - 2) / 20000);
        peak = 0;
        for (int i = 0; i < (int)sizeof(bars); ++i) {
          int bw = VW / sizeof(bars), x = VX + i * bw, hgt = bars[i];
          tft.fillRect(x, VY, bw - 2, VH - hgt, TFT_BLACK);
          tft.fillRect(x, VY + VH - hgt, bw - 2, hgt, ui::hsv(200 + i * 4, 200, 255));
        }
        float secs = (audio::streamPlayed() - playedBase) / (float)max(8000, srate);
        float total = bitrate ? (fileSize - dataStart) * 8.0f / bitrate : 0;
        float frac = fileSize > dataStart ? (float)(f.position() - dataStart) / (fileSize - dataStart) : 0;
        ui::bar(10, 172, 300, 10, frac, C_ACCENT, C_PANEL);
        String tl = fmtTime((uint32_t)secs) + " / " + (total > 0 ? fmtTime((uint32_t)total) : String("--:--"));
        char info[48]; snprintf(info, sizeof(info), "%s   %d kbps  %.1f kHz %s   vol %d%%   ", tl.c_str(), bitrate / 1000,
                                srate / 1000.0f, chans == 2 ? "stereo" : "mono", vol * 100 / 255);
        tft.setTextColor(C_DIM, C_BG); tft.drawString(info, 10, 186, 1);
      }
    }
    f.close();
    audio::streamFlush();
    if (quit) break;
    if (next == 1) {
      if (shuffle) idx = rnd(list.size());
      else if (idx + 1 < (int)list.size()) idx++;
      else if (repeatAll) idx = 0;
      else break;
    } else if (next == -1) idx = (idx + list.size() - 1) % list.size();
    MP3FreeDecoder(dec); dec = MP3InitDecoder();       // clean state per track
    if (!dec) break;
  }
  audio::streamEnd();
  if (dec) MP3FreeDecoder(dec);
  free(inbuf); free(pcm);
}

// ============================================================================
//  40  VIDEO & MP4 PLAYER
// ============================================================================
namespace avi {
struct Info {
  uint32_t usPerFrame = 66666, width = 0, height = 0;
  bool hasAudio = false; uint16_t aFmt = 0, aChans = 1, aBits = 8; uint32_t aRate = 22050;
  uint32_t moviStart = 0, moviEnd = 0, frames = 0;
};
static uint32_t rd32(File &f) { uint8_t b[4]; f.read(b, 4); return b[0] | (b[1] << 8) | (b[2] << 16) | ((uint32_t)b[3] << 24); }
static bool parse(File &f, Info &in, String &err) {
  char id[5] = {0};
  f.seek(0);
  f.read((uint8_t *)id, 4); rd32(f);
  char type[5] = {0}; f.read((uint8_t *)type, 4);
  if (strcmp(id, "RIFF") || strcmp(type, "AVI ")) { err = "not an AVI file"; return false; }
  uint32_t fileEnd = f.size();
  char curStream[5] = {0};
  uint32_t pos = 12;
  while (pos + 8 <= fileEnd) {
    f.seek(pos);
    f.read((uint8_t *)id, 4);
    uint32_t sz = rd32(f);
    if (!strcmp(id, "LIST")) {
      char lt[5] = {0}; f.read((uint8_t *)lt, 4);
      if (!strcmp(lt, "movi")) { in.moviStart = pos + 12; in.moviEnd = min(fileEnd, pos + 8 + sz); return true; }
      pos += 12;                            // descend into hdrl / strl
      continue;
    }
    if (!strcmp(id, "avih")) {
      in.usPerFrame = rd32(f); rd32(f); rd32(f); rd32(f); in.frames = rd32(f); rd32(f); rd32(f); rd32(f);
      in.width = rd32(f); in.height = rd32(f);
    } else if (!strcmp(id, "strh")) {
      f.read((uint8_t *)curStream, 4);
    } else if (!strcmp(id, "strf") && !strcmp(curStream, "auds")) {
      uint8_t w[16]; f.read(w, 16);
      in.aFmt = w[0] | (w[1] << 8); in.aChans = w[2] | (w[3] << 8);
      in.aRate = w[4] | (w[5] << 8) | (w[6] << 16) | ((uint32_t)w[7] << 24);
      in.aBits = w[14] | (w[15] << 8);
      in.hasAudio = in.aFmt == 1 && (in.aBits == 8 || in.aBits == 16);
    }
    pos += 8 + sz + (sz & 1);
  }
  err = "no movie data";
  return false;
}
}  // namespace avi

// returns false if the user hit EXIT
static bool playAvi(AppCtx &c, const String &path) {
  File f = SD.open(path);
  if (!f) return true;
  avi::Info in; String err;
  if (!avi::parse(f, in, err)) { f.close(); ui::msgBox("MOVIE", (err + "\nConvert MP4s with tools/convert_media.py").c_str()); return true; }
  const uint32_t MAXF = c.pInt("max_frame_kb", 32) * 1024;
  // Try a RAM frame buffer (fast). If the heap can't spare it, fb stays null
  // and we decode each frame straight off the SD card instead - slower, but it
  // plays instead of refusing with "Not enough RAM".
  uint8_t *fb = (uint8_t *)sys::bigAlloc(MAXF);
  bool sdDecode = (fb == nullptr);
  bool audioOk = in.hasAudio && audio::streamBegin(in.aRate, 8192);
  audio::streamVolume(c.pInt("volume", 230));
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(mediaJpgOut);
  tft.fillScreen(TFT_BLACK);
  int sc = (in.width > 320 || in.height > 240) ? 2 : 1;
  TJpgDec.setJpgScale(sc);
  int ox = max(0, (int)(320 - in.width / sc) / 2), oy = max(0, (int)(240 - in.height / sc) / 2);
  int16_t abuf[512];
  uint32_t frame = 0, shown = 0, dropped = 0, t0 = micros(), pauseAcc = 0, pausedAt = 0;
  bool exitReq = false, paused = false;
  uint32_t pos = in.moviStart;
  while (pos + 8 <= in.moviEnd) {
    f.seek(pos);
    char id[5] = {0}; f.read((uint8_t *)id, 4);
    uint32_t sz = avi::rd32(f);
    uint32_t nextPos = pos + 8 + sz + (sz & 1);
    if (!strcmp(id, "LIST")) { pos += 12; continue; }               // 'rec ' groups
    if (id[0] == 'i' && id[1] == 'x') { pos = nextPos; continue; }   // OpenDML index
    if (id[2] == 'w' && id[3] == 'b' && audioOk) {
      uint32_t left = sz;
      uint8_t raw[1024];
      while (left) {
        uint32_t want = min(left, (uint32_t)(in.aBits == 8 ? 512 * in.aChans : 1024));
        want -= want % (in.aChans * in.aBits / 8);
        if (!want) break;
        int n = f.read(raw, want); if (n <= 0) break;
        left -= n;
        int ns = n / (in.aBits / 8) / in.aChans;
        for (int i = 0; i < ns; ++i) {
          int32_t s = 0;
          for (int ch = 0; ch < in.aChans; ++ch) {
            int k = i * in.aChans + ch;
            s += in.aBits == 8 ? ((int)raw[k] - 128) << 8 : (int16_t)(raw[2 * k] | (raw[2 * k + 1] << 8));
          }
          abuf[i] = s / in.aChans;
        }
        audio::streamWrite(abuf, ns);       // blocks when the ring is full -> natural pacing
      }
    } else if (id[2] == 'd' && (id[3] == 'c' || id[3] == 'b')) {
      frame++;
      uint32_t due = frame * in.usPerFrame;
      uint32_t clock = audioOk ? (uint32_t)((uint64_t)audio::streamPlayed() * 1000000ULL / in.aRate)
                               : (micros() - t0 - pauseAcc);
      if ((sdDecode || sz <= MAXF) && clock < due + in.usPerFrame * 2) {   // late frames are dropped
        if (!audioOk && clock < due) delayMicroseconds(min((uint32_t)50000, due - clock));
        if (sdDecode) {
          // stream this frame straight from the card (no RAM buffer needed)
          File jf = SD.open(path);
          if (jf) { jf.seek(pos + 8); TJpgDec.drawSdJpg(ox, oy, jf); }     // drawSdJpg closes jf
        } else {
          f.read(fb, sz);
          TJpgDec.drawJpg(ox, oy, fb, sz);
        }
        shown++;
        if (shown % 30 == 1) ui::exitBox();
      } else dropped++;
      ui::clearEvents(); Touch &t = ui::poll();
      if (ui::exitHit(t)) { exitReq = true; break; }
      if (t.swipe == SW_DOWN) break;                                   // back to the list
      if (t.tap) {
        paused = true; pausedAt = micros(); audio::streamPause(true);
        ui::toast("PAUSED - tap to resume, swipe down for list", C_WARN);
        bool back = false;
        while (paused) {
          ui::clearEvents(); Touch &p = ui::poll(); delay(5);
          if (ui::exitHit(p)) { exitReq = true; break; }
          if (p.swipe == SW_DOWN) { back = true; break; }
          if (p.tap) paused = false;
        }
        pauseAcc += micros() - pausedAt;
        audio::streamPause(false);
        if (exitReq || back) break;
        ui::exitBox();
      }
    }
    pos = nextPos;
  }
  if (!exitReq && pos + 8 > in.moviEnd) {                              // let the tail of the audio drain
    uint32_t w = millis(); while (audioOk && audio::streamQueued() > 64 && millis() - w < 1000) delay(10);
  }
  sys::log("movie: %s shown %lu dropped %lu", path.c_str(), (unsigned long)shown, (unsigned long)dropped);
  audio::streamEnd();
  free(fb); f.close();
  return !exitReq;
}

// Raw Motion-JPEG stream (concatenated JPEG frames, no audio) - Bad Apple etc.
static bool playMjpeg(AppCtx &c, const String &path) {
  File f = SD.open(path);
  if (!f) return true;
  uint32_t MAXF = c.pInt("max_frame_kb", 32) * 1024;
  // If the heap can't give the full frame buffer, keep halving it rather than
  // refusing - frames bigger than the buffer are simply skipped, so a tight-RAM
  // moment degrades the video instead of crashing it.
  uint8_t *fb = (uint8_t *)sys::bigAlloc(MAXF);
  while (!fb && MAXF > 6144) { MAXF /= 2; fb = (uint8_t *)sys::bigAlloc(MAXF); }
  uint8_t *rd = (uint8_t *)malloc(2048);
  if (!fb || !rd) { free(fb); free(rd); f.close(); ui::msgBox("VIDEO", "Not enough RAM"); return true; }
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(mediaJpgOut);
  tft.fillScreen(TFT_BLACK);
  uint32_t fpsCap = max(1, c.pInt("fps", 30)), frameUs = 1000000 / fpsCap, nextT = micros();
  uint32_t flen = 0, frames = 0; bool inFrame = false; uint8_t prev = 0;
  int ox = 0, oy = 0; bool sized = false, quit = false, back = false;
  while (!quit && !back) {
    int n = f.read(rd, 2048);
    if (n <= 0) { f.seek(0); continue; }                     // loop
    for (int i = 0; i < n && !quit && !back; ++i) {
      uint8_t b = rd[i];
      if (!inFrame) { if (prev == 0xFF && b == 0xD8) { inFrame = true; fb[0] = 0xFF; fb[1] = 0xD8; flen = 2; } }
      else {
        if (flen < MAXF) fb[flen++] = b; else inFrame = false;
        if (prev == 0xFF && b == 0xD9 && inFrame) {
          inFrame = false;
          if (!sized) {
            uint16_t w = 0, h = 0; TJpgDec.getJpgSize(&w, &h, fb, flen);
            int sc = (w > 320 || h > 240) ? 2 : 1; TJpgDec.setJpgScale(sc);
            ox = max(0, (320 - w / sc) / 2); oy = max(0, (240 - h / sc) / 2); sized = true;
          }
          TJpgDec.drawJpg(ox, oy, fb, flen);
          if (++frames % 30 == 1) ui::exitBox();
          ui::clearEvents(); Touch &t = ui::poll();
          if (ui::exitHit(t)) quit = true;
          else if (t.tap || t.swipe == SW_DOWN) back = true;
          int32_t wait = (int32_t)(nextT + frameUs - micros());
          if (wait > 0) delayMicroseconds(wait);
          nextT = micros();
        }
      }
      prev = b;
    }
  }
  free(fb); free(rd); f.close();
  return !quit;
}

void app_video(AppCtx &c) {
  String dir = "/data/movies";
  while (true) {
    // movies (converted MP4 -> .avi) live in /data/movies, raw clips in /data/video;
    // the picker shows both kinds and can browse between folders
    String path = ui::pickFile(dir.c_str(), ".avi|.mjpeg", "VIDEO - .avi (MP4) / .mjpeg", true);
    if (!path.length()) return;
    dir = path.substring(0, path.lastIndexOf('/'));
    if (!dir.length()) dir = "/";
    String lower = path; lower.toLowerCase();
    bool keepGoing = lower.endsWith(".avi") ? playAvi(c, path) : playMjpeg(c, path);
    if (!keepGoing) return;
    tft.fillScreen(C_BG); c.header();
  }
}
