// ============================================================================
//  Sensor / audio-in apps
//   62 Morse Keyer   63 Voice Pitch Tracker   64 Ultrasonic Range   77 Noise Floor Log
// ============================================================================
#include "apps_common.h"
#include <time.h>

// ============================================================================
//  62  MORSE CODE KEYER
// ============================================================================
static const char *MORSE[] = {    // A-Z then 0-9
  ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--",
  "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..",
  "-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----."};
void app_morse(AppCtx &c) {
  int wpm = 15; int unit = 1200 / wpm;   // ms per dit
  String cur, text;
  uint32_t downT = 0, upT = millis();
  bool keyDown = false;
  auto decodeCur = [&]() -> char {
    for (int i = 0; i < 36; ++i) if (cur == MORSE[i]) return i < 26 ? 'A' + i : '0' + (i - 26);
    return '?';
  };
  auto draw = [&]() {
    tft.fillRect(0, 28, 320, 70, C_BG);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(cur.length() ? cur : String("_"), 10, 32, 6);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("WPM", 250, 32, 2);
    char w[8]; snprintf(w, 8, "%d", wpm); tft.setTextColor(C_TEXT, C_BG); tft.drawString(w, 250, 50, 4);
    tft.fillRect(0, 100, 320, 60, C_PANEL);
    String show = text.length() > 60 ? text.substring(text.length() - 60) : text;
    tft.setTextColor(C_TEXT, C_PANEL); tft.drawString(show, 6, 104, 2);
  };
  ui::clearBody();
  ui::button(4, 164, 230, 72, "KEY  (hold)", RGB565(0, 110, 90), TFT_WHITE, 4);
  ui::button(240, 164, 76, 34, "WPM-", C_PANEL2); ui::button(240, 202, 76, 34, "WPM+", C_PANEL2);
  draw();
  while (c.loop()) {
    Touch &t = *c.t;
    bool onKey = t.down && ui::inRect(t.x, t.y, 4, 164, 230, 72);
    if (onKey && !keyDown) { keyDown = true; downT = millis();
      uint32_t gap = downT - upT;
      if (gap > unit * 7 && text.length() && text[text.length() - 1] != ' ') text += ' ';     // word gap already handled below
      audio::tone(0, 650, 110, audio::SINE); }
    if (!onKey && keyDown) { keyDown = false; audio::stop(0);
      uint32_t dur = millis() - downT; cur += (dur < unit * 2) ? '.' : '-'; upT = millis(); draw(); }
    if (!keyDown && cur.length() && millis() - upT > unit * 3) {       // letter gap -> commit
      text += decodeCur(); cur = ""; draw();
    }
    if (!keyDown && text.length() && text[text.length() - 1] != ' ' && millis() - upT > unit * 7) { text += ' '; draw(); }
    if (t.tap) {
      if (ui::inRect(t.sx, t.sy, 240, 164, 76, 34)) { wpm = max(5, wpm - 1); unit = 1200 / wpm; draw(); }
      else if (ui::inRect(t.sx, t.sy, 240, 202, 76, 34)) { wpm = min(40, wpm + 1); unit = 1200 / wpm; draw(); }
    }
  }
  audio::stop(0);
}

// ============================================================================
//  63  VOICE PITCH TRACKER  (autocorrelation on mic)
// ============================================================================
void app_pitch(AppCtx &c) {
  const int N = 512;
  int16_t *buf = (int16_t *)malloc(N * 2);
  if (!buf) return;
  analogSetPinAttenuation(PIN_MIC, ADC_11db);
  const char *NM[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("Sing or play a note into the mic (IO35)", 10, 214, 1);
  int16_t hist[300]; for (auto &h : hist) h = -1; int hp = 0;
  while (c.loop()) {
    uint32_t t0 = micros();
    for (int i = 0; i < N; ++i) { buf[i] = analogRead(PIN_MIC); delayMicroseconds(60); }
    float sr = N * 1e6f / (micros() - t0);
    long mean = 0; for (int i = 0; i < N; ++i) mean += buf[i]; mean /= N;
    for (int i = 0; i < N; ++i) buf[i] -= mean;
    // autocorrelation for lag 20..260
    float bestv = 0; int bestlag = 0; long e0 = 1;
    for (int i = 0; i < N; ++i) e0 += (long)buf[i] * buf[i];
    for (int lag = (int)(sr / 1000); lag < N / 2; ++lag) {
      long s = 0; for (int i = 0; i + lag < N; ++i) s += (long)buf[i] * buf[i + lag];
      float v = s / (float)e0;
      if (v > bestv) { bestv = v; bestlag = lag; }
    }
    float freq = (bestlag && bestv > 0.35f) ? sr / bestlag : 0;
    tft.fillRect(0, 28, 320, 150, C_BG);
    if (freq > 50 && freq < 2000) {
      float midi = 69 + 12 * log2f(freq / 440.0f);
      int n = (int)roundf(midi); int cents = (int)roundf((midi - n) * 100);
      int note = ((n % 12) + 12) % 12, oct = n / 12 - 1;
      char s[16]; snprintf(s, 16, "%s%d", NM[note], oct);
      tft.setTextColor(C_TEXT, C_BG); tft.setTextDatum(MC_DATUM); tft.drawString(s, 160, 70, 7);
      snprintf(s, 16, "%.1f Hz", freq); tft.setTextColor(C_ACCENT, C_BG); tft.drawString(s, 160, 112, 4);
      // tuning needle
      int nx = 160 + cents * 1.3;
      tft.fillRect(10, 134, 300, 16, C_PANEL); tft.fillRect(159, 132, 2, 20, C_DIM);
      tft.fillRect(nx - 2, 134, 4, 16, abs(cents) < 8 ? C_OK : C_WARN);
      snprintf(s, 16, "%+d cents", cents); tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 160, 160, 2);
      tft.setTextDatum(TL_DATUM);
    } else { tft.setTextColor(C_DIM, C_BG); ui::centerText("listening...", 160, 90, C_DIM, C_BG, 4); }
  }
  free(buf);
}

// ============================================================================
//  64  ULTRASONIC RANGE  (HC-SR04: TRIG = IO22 / CN1, ECHO = IO35 / P3)
// ============================================================================
void app_ultrasonic(AppCtx &c) {
  const int TRIG = PIN_RELAY, ECHO = PIN_MIC;   // 22 and 35
  pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT);
  digitalWrite(TRIG, LOW);
  bool metric = c.pStr("units", "cm") != "in";
  int16_t hist[300]; for (auto &h : hist) h = -1; int hp = 0;
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("HC-SR04: TRIG=IO22 (CN1), ECHO=IO35 (P3), VCC 5V", 8, 214, 1);
  const int GX = 6, GY = 120, GW = 308, GH = 84;
  tft.drawRect(GX, GY, GW, GH, C_PANEL2);
  uint32_t lastT = 0;
  while (c.loop()) {
    if (millis() - lastT < 60) { delay(5); continue; }
    lastT = millis();
    digitalWrite(TRIG, LOW); delayMicroseconds(3);
    digitalWrite(TRIG, HIGH); delayMicroseconds(10); digitalWrite(TRIG, LOW);
    unsigned long us = pulseIn(ECHO, HIGH, 30000);
    float cm = us ? us / 58.0f : -1;
    tft.fillRect(0, 28, 320, 80, C_BG);
    if (cm > 1 && cm < 450) {
      char s[20];
      if (metric) snprintf(s, 20, "%.1f cm", cm); else snprintf(s, 20, "%.1f in", cm / 2.54f);
      tft.setTextColor(C_ACCENT, C_BG); tft.setTextDatum(MC_DATUM); tft.drawString(s, 160, 64, 7); tft.setTextDatum(TL_DATUM);
      hist[hp] = (int)constrain(cm, 0.f, 400.f); hp = (hp + 1) % 300;
    } else { ui::centerText("no echo", 160, 60, C_DIM, C_BG, 4); hist[hp] = -1; hp = (hp + 1) % 300; }
    tft.fillRect(GX + 1, GY + 1, GW - 2, GH - 2, TFT_BLACK);
    for (int i = 1; i < GW - 2; ++i) {
      int a = hist[(hp + 300 - (GW - 2) + i - 1) % 300], b = hist[(hp + 300 - (GW - 2) + i) % 300];
      if (a < 0 || b < 0) continue;
      auto yy = [&](int v) { return GY + GH - 1 - v * (GH - 2) / 400; };
      tft.drawLine(GX + i - 1, yy(a), GX + i, yy(b), C_OK);
    }
  }
  pinMode(TRIG, OUTPUT); digitalWrite(TRIG, LOW);
}

// ============================================================================
//  77  NOISE FLOOR LOG
// ============================================================================
void app_noiselog(AppCtx &c) {
  analogSetPinAttenuation(PIN_MIC, ADC_11db);
  const int GX = 6, GY = 120, GW = 308, GH = 86;
  float hist[308]; for (auto &h : hist) h = -60; int hp = 0;
  bool logging = c.pInt("log", 0);
  uint32_t lastLog = 0; int samples = 0;
  ui::clearBody();
  tft.drawRect(GX, GY, GW, GH, C_PANEL2);
  auto bar = [&]() { ui::button(6, 30, 150, 30, logging ? "LOGGING: ON" : "LOGGING: OFF", logging ? C_OK : C_PANEL2, logging ? TFT_BLACK : C_TEXT, 2);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("logs dBFS to /data/reader/noise.csv every 5 s", 6, 210, 1); };
  bar();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && ui::inRect(t.sx, t.sy, 6, 30, 150, 30)) { logging = !logging; bar(); }
    uint32_t t0 = millis(); int lo = 4095, hi = 0;
    while (millis() - t0 < 50) { int v = analogRead(PIN_MIC); lo = min(lo, v); hi = max(hi, v); }
    int pp = max(1, hi - lo);
    float db = 20 * log10f(pp / 4095.0f); db = max(db, -60.f);
    hist[hp] = db; hp = (hp + 1) % GW;
    tft.fillRect(0, 64, 320, 50, C_BG);
    char s[24]; snprintf(s, 24, "%.1f dBFS", db);
    tft.setTextColor(db > -20 ? C_ERR : db > -40 ? C_WARN : C_OK, C_BG); tft.drawString(s, 10, 68, 6);
    tft.fillRect(GX + 1, GY + 1, GW - 2, GH - 2, TFT_BLACK);
    for (int i = 1; i < GW; ++i) { float a = hist[(hp + i - 1) % GW], b = hist[(hp + i) % GW];
      auto yy = [&](float v) { return GY + GH - 1 - (int)((v + 60) / 60 * (GH - 2)); };
      tft.drawLine(GX + i - 1, yy(a), GX + i, yy(b), C_ACCENT); }
    if (logging && sys::sdOk && millis() - lastLog > 5000) {
      lastLog = millis();
      File f = SD.open("/data/reader/noise.csv", FILE_APPEND);
      if (f) { struct tm tm; char ts[24]; if (sys::now(tm)) strftime(ts, 24, "%Y-%m-%d %H:%M:%S", &tm); else snprintf(ts, 24, "%lu", millis() / 1000);
        f.printf("%s,%.1f\n", ts, db); f.close(); samples++; }
      tft.setTextColor(C_DIM, C_BG); char q[20]; snprintf(q, 20, "%d logged", samples); tft.drawString(q, 230, 50, 1);
    }
  }
}
