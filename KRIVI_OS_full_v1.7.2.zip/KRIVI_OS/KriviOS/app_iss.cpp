#include "apps_common.h"
#include <WiFi.h>
// ============================================================================
//  52  3D ISS GLOBE RADAR  - live International Space Station tracker on a
//      raycast, spinning Earth. Data: wheretheiss.at (free, no API key).
//      Drag the globe in any direction to rotate it; release to let it coast.
//      Drag from the rim toward the centre = zoom IN, toward the rim = zoom OUT
//      (or use the ZOOM- / ZOOM+ buttons). On launch the globe glides to the ISS.
//      HUD shows what ocean / continent / state / nearest capital it is over.
// ============================================================================
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>   // v7 (JsonDocument). On v6 use StaticJsonDocument<1024>

namespace iss {

// ---------------------------------------------------------------------------
//  WORLD MAP: 1-degree grid (360 x 180), run-length encoded in flash (~2.3 KB).
//  Each byte = (type << 6) | (runLength - 1), rows run north (90N) -> south,
//  each row covers lon -180 -> +180.   type: 0 ocean, 1 land, 2 desert, 3 ice
// ---------------------------------------------------------------------------
static const uint8_t WORLD_RLE[] = {
  63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,39,
  63,63,63,63,63,39,63,32,75,17,221,63,63,63,10,63,26,89,1,232,63,63,63,7,63,23,89,2,235,63,51,70,63,11,63,24,
  84,3,239,28,207,63,4,72,63,10,63,24,81,3,241,29,205,63,63,26,63,24,79,3,243,31,201,63,16,65,63,9,63,25,76,7,
  240,63,21,65,31,73,63,5,63,22,76,15,236,63,17,66,23,86,63,2,63,22,76,20,231,63,14,67,20,91,25,72,31,55,71,30,
  68,21,229,63,14,66,17,101,61,54,69,3,74,16,74,19,226,63,25,123,9,71,32,60,80,13,79,17,223,63,10,67,11,127,80,
  29,20,73,30,80,4,66,6,79,14,222,46,69,38,127,89,21,16,87,6,71,10,75,3,68,10,76,13,220,42,78,26,127,116,2,68,8,
  111,19,74,10,73,11,218,42,80,20,127,125,71,4,127,80,11,73,9,213,45,82,7,127,127,74,73,2,127,80,11,75,7,210,12,
  69,28,84,6,127,127,74,71,3,127,81,9,76,9,207,12,73,25,74,0,74,5,127,127,74,67,9,127,78,11,74,11,205,14,72,24,
  73,3,73,4,127,127,75,65,15,127,73,16,68,14,202,19,65,26,73,4,127,127,91,15,127,73,39,200,46,75,4,127,127,92,
  14,127,72,13,69,23,197,46,75,4,127,127,70,2,75,7,14,127,71,14,71,24,194,46,76,3,127,127,69,3,74,8,17,73,0,65,
  8,109,15,71,3,65,63,4,77,4,127,127,66,3,69,14,20,68,16,106,16,77,57,64,8,67,1,70,5,127,117,15,68,16,19,68,20,
  104,15,78,55,67,13,68,4,127,117,16,70,15,18,67,23,108,10,79,54,67,9,66,0,67,4,127,117,16,70,16,16,67,26,110,7,
  80,54,66,9,68,0,64,5,127,115,18,69,17,48,110,5,83,49,65,2,65,8,65,7,127,89,0,90,19,68,18,49,110,3,85,46,67,1,
  67,6,127,98,1,96,0,64,12,67,19,50,110,2,86,45,67,1,69,2,127,99,0,98,0,64,12,65,21,51,127,72,45,64,2,70,1,127,
  127,72,0,65,11,64,22,52,127,67,0,67,48,65,3,127,127,75,0,65,35,55,121,7,68,51,127,127,76,1,65,35,55,99,1,85,4,
  69,48,127,127,79,1,65,35,55,96,5,83,5,69,49,127,127,77,2,65,35,55,123,61,101,1,74,3,127,84,3,64,36,55,101,0,
  64,2,82,60,94,2,66,0,74,4,127,83,42,55,100,1,65,1,76,0,67,61,77,1,77,8,72,3,109,138,91,4,65,36,55,100,0,66,0,
  75,3,64,56,78,2,66,2,75,10,71,3,107,143,87,5,67,34,55,99,1,79,60,75,5,64,0,66,3,73,12,70,3,72,132,93,142,83,8,
  67,35,55,104,0,75,60,75,5,64,1,68,1,73,3,66,4,71,3,67,136,96,134,87,10,64,37,55,113,63,0,73,6,65,4,66,0,68,1,
  87,2,64,139,78,134,96,0,70,10,65,37,55,113,63,0,73,6,65,5,64,2,66,2,86,4,139,75,139,92,2,64,1,66,11,65,37,56,
  111,63,1,72,15,64,3,66,2,85,4,64,136,78,137,92,6,67,10,64,38,57,110,63,1,71,13,66,4,65,3,85,4,69,128,82,135,
  94,0,65,3,66,9,65,38,57,71,129,99,63,5,66,3,73,10,64,5,127,91,4,67,6,67,38,58,68,132,99,63,4,66,1,75,24,127,
  84,4,66,4,69,39,59,65,135,96,63,5,80,25,83,129,125,11,68,42,61,64,136,92,63,6,82,23,81,133,124,9,65,0,64,45,
  62,64,136,90,63,6,78,130,69,5,66,10,81,134,124,8,65,47,62,66,136,87,63,7,70,139,69,3,70,6,81,136,124,7,64,48,
  63,64,0,65,135,86,63,6,67,153,65,133,71,135,72,135,124,57,63,65,0,65,135,77,4,66,63,6,64,169,65,140,64,0,69,
  132,74,128,112,57,63,0,65,0,65,134,71,11,65,63,5,171,65,140,64,1,70,129,73,131,111,57,63,0,66,0,65,134,68,13,
  66,63,2,174,0,141,64,1,80,132,110,58,63,1,65,1,65,133,68,14,65,63,1,175,1,141,5,77,130,110,59,63,2,65,1,66,
  131,68,14,65,63,0,64,176,1,141,64,2,65,0,75,130,109,60,63,3,65,1,74,63,17,177,1,142,1,66,9,114,2,64,57,63,4,
  64,2,72,63,17,64,178,1,142,69,8,112,2,65,57,63,9,71,13,68,62,180,1,142,69,8,109,5,64,57,63,9,72,17,66,58,181,
  1,143,68,9,81,3,82,63,4,63,10,71,5,67,8,66,57,181,1,144,66,13,77,4,78,63,8,63,10,72,4,67,11,68,53,180,2,143,
  65,14,76,6,76,2,65,63,4,63,12,71,1,68,13,68,52,180,64,2,140,66,15,75,7,76,2,64,10,64,57,63,13,77,63,7,179,66,
  2,138,66,16,73,10,76,12,65,57,63,16,74,63,6,178,68,2,64,135,66,18,72,11,77,11,66,56,63,21,73,63,2,80,128,77,
  137,78,2,64,132,66,20,71,15,75,10,65,57,63,23,72,63,1,121,1,70,23,69,16,75,10,65,57,63,25,70,63,1,122,0,67,27,
  68,17,74,63,6,63,28,67,63,1,123,31,68,17,65,1,70,63,6,63,29,66,9,65,54,123,4,65,24,67,17,65,2,69,63,6,63,29,
  66,7,76,46,127,129,24,67,17,64,4,66,14,66,54,63,30,66,5,78,46,121,134,24,66,18,65,4,65,14,67,53,63,32,86,46,
  117,136,26,64,1,64,16,66,22,65,53,63,34,64,1,82,46,116,136,29,65,16,65,21,67,52,63,37,84,45,115,135,30,65,17,
  65,13,64,5,66,53,63,37,87,43,73,4,99,134,51,66,11,66,61,63,37,90,42,65,12,97,133,48,65,1,66,10,67,61,63,37,90,
  59,96,130,64,49,66,1,66,8,68,61,63,36,92,59,98,51,66,1,65,7,70,60,63,36,92,58,98,53,67,0,64,4,72,5,64,54,63,
  35,93,58,98,53,68,5,72,1,64,58,63,34,95,57,86,1,72,55,68,5,71,0,66,57,63,34,99,53,86,1,71,57,68,4,71,0,67,7,
  67,44,63,35,99,53,85,0,71,59,68,4,69,1,66,9,66,0,68,38,63,35,104,49,92,61,67,5,67,2,66,10,74,35,63,34,107,47,
  92,62,66,12,65,14,72,5,64,27,63,34,109,46,90,63,0,65,12,64,16,72,2,66,27,63,34,109,46,90,63,2,68,26,73,31,63,
  35,108,47,89,63,3,70,23,73,31,63,35,108,47,89,63,9,64,25,67,0,66,31,63,36,107,47,90,63,41,67,29,63,37,105,48,
  90,63,44,64,29,63,37,104,49,91,63,36,64,36,63,38,102,50,91,7,64,63,16,69,4,64,36,63,38,101,50,92,6,65,63,15,
  69,4,66,35,63,39,100,50,92,5,66,63,12,65,0,69,4,67,34,63,40,99,50,91,5,68,63,9,75,3,68,33,63,41,98,50,91,4,68,
  63,9,77,2,68,33,63,43,96,50,64,128,88,4,69,63,8,86,33,63,44,129,93,50,64,131,83,6,68,63,8,87,33,63,45,128,92,
  52,136,77,7,68,63,7,89,32,63,45,128,92,52,138,74,8,68,63,2,73,131,82,30,63,45,128,91,54,138,74,7,68,63,1,69,
  144,75,29,63,45,128,90,55,138,74,7,67,63,0,68,148,75,28,63,44,129,87,59,137,74,7,66,63,2,65,151,75,27,63,44,
  129,85,61,137,73,8,65,63,3,64,152,75,27,63,44,129,84,62,136,73,63,15,65,152,75,26,63,44,129,84,62,135,73,63,
  16,66,151,75,26,63,44,129,84,63,64,131,75,63,16,67,150,76,25,63,44,129,83,63,0,80,63,17,67,149,76,25,63,44,
  129,83,63,1,78,63,18,70,146,76,25,63,43,85,63,2,77,63,19,75,140,76,26,63,43,84,63,3,76,63,20,79,134,78,26,63,
  43,84,63,4,74,63,21,74,7,81,27,63,43,83,63,5,73,63,22,73,9,80,27,63,43,82,63,7,65,63,29,68,14,64,1,76,28,63,
  42,79,63,63,63,2,76,21,64,5,63,42,79,63,63,63,3,74,23,64,4,63,41,80,63,63,63,4,73,23,67,1,63,41,78,63,63,63,8,
  68,26,67,1,63,41,67,132,66,63,63,63,43,66,2,63,41,67,132,66,63,63,63,44,65,2,63,41,67,132,63,63,63,17,67,21,
  66,5,63,41,67,132,64,63,63,63,17,65,21,67,5,63,41,67,132,63,63,63,18,64,21,68,5,63,41,67,132,63,63,63,40,67,7,
  63,41,67,131,63,63,63,40,67,8,63,41,67,130,63,63,63,42,65,9,63,40,69,129,64,63,63,63,53,63,40,72,63,63,63,53,
  63,40,71,63,63,63,54,63,40,70,63,63,63,55,63,40,69,63,63,63,56,63,41,68,63,63,63,56,63,42,68,63,63,63,55,63,
  43,69,63,63,63,53,63,46,65,63,63,63,54,63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,
  39,63,63,63,63,63,39,63,63,63,63,63,39,63,63,63,63,63,39,63,54,194,63,63,63,45,63,51,196,63,63,63,46,63,49,
  197,63,63,63,47,63,48,197,63,63,20,243,39,63,47,198,63,40,215,10,255,194,33,63,45,200,63,34,222,7,255,199,30,
  63,44,200,63,29,255,249,25,63,43,201,55,255,255,229,19,63,42,202,49,255,255,238,16,63,20,202,10,203,43,255,
  255,245,14,63,17,228,39,255,255,250,13,47,255,199,35,255,255,253,13,40,255,207,32,255,255,255,13,33,255,218,
  25,255,255,255,194,13,23,255,231,21,255,255,255,195,13,255,255,255,255,255,231,255,255,255,255,255,231,255,
  255,255,255,255,231,255,255,255,255,255,231,255,255,255,255,255,231,255,255,255,255,255,231,255,255,255,255,
  255,231,255,255,255,255,255,231,255,255,255,255,255,231,255,255,255,255,255,231,255,255,255,255,255,231,255,
  255,255,255,255,231
};

static uint16_t s_rowStart[181];
static bool s_rowInit = false;
static void initRows() {
  int i = 0;
  for (int r = 0; r < 180; ++r) {
    s_rowStart[r] = i;
    int s = 0;
    while (s < 360 && i < (int)sizeof(WORLD_RLE)) { s += (WORLD_RLE[i] & 63) + 1; ++i; }
  }
  s_rowStart[180] = i;
  s_rowInit = true;
}

// returns 0 ocean, 1 land, 2 desert, 3 ice
static inline int worldAt(int latDeg, int lonDeg) {
  if (!s_rowInit) initRows();
  while (lonDeg < -180) lonDeg += 360;
  while (lonDeg >= 180) lonDeg -= 360;
  int row = 89 - latDeg; if (row < 0) row = 0; if (row > 179) row = 179;
  int col = lonDeg + 180;
  int s = 0;
  for (int i = s_rowStart[row]; i < (int)sizeof(WORLD_RLE); ++i) {
    s += (WORLD_RLE[i] & 63) + 1;
    if (col < s) return WORLD_RLE[i] >> 6;
  }
  return 0;
}

// ---------------------------------------------------------------------------
//  LOCATION LOOKUP (offline): continent / state-or-country / nearest capital
// ---------------------------------------------------------------------------
enum { CT_NA, CT_SA, CT_EU, CT_AF, CT_AS, CT_OC };
static const char *const CONT_NAME[] = {"NORTH AMERICA", "SOUTH AMERICA", "EUROPE", "AFRICA", "ASIA", "OCEANIA"};

struct Place { const char *city; const char *region; float lat, lon; uint8_t cont; };
static const Place PLACES[] = {
  // ---- USA state capitals ----
  {"Montgomery","Alabama, USA",32.38,-86.30,CT_NA}, {"Phoenix","Arizona, USA",33.45,-112.07,CT_NA},
  {"Little Rock","Arkansas, USA",34.75,-92.29,CT_NA}, {"Sacramento","California, USA",38.58,-121.49,CT_NA},
  {"Denver","Colorado, USA",39.74,-104.99,CT_NA}, {"Hartford","Connecticut, USA",41.76,-72.67,CT_NA},
  {"Dover","Delaware, USA",39.16,-75.52,CT_NA}, {"Tallahassee","Florida, USA",30.44,-84.28,CT_NA},
  {"Atlanta","Georgia, USA",33.75,-84.39,CT_NA}, {"Honolulu","Hawaii, USA",21.31,-157.86,CT_NA},
  {"Boise","Idaho, USA",43.62,-116.20,CT_NA}, {"Springfield","Illinois, USA",39.78,-89.65,CT_NA},
  {"Indianapolis","Indiana, USA",39.77,-86.16,CT_NA}, {"Des Moines","Iowa, USA",41.59,-93.62,CT_NA},
  {"Topeka","Kansas, USA",39.05,-95.68,CT_NA}, {"Frankfort","Kentucky, USA",38.20,-84.87,CT_NA},
  {"Baton Rouge","Louisiana, USA",30.45,-91.19,CT_NA}, {"Augusta","Maine, USA",44.31,-69.78,CT_NA},
  {"Annapolis","Maryland, USA",38.98,-76.49,CT_NA}, {"Boston","Massachusetts, USA",42.36,-71.06,CT_NA},
  {"Lansing","Michigan, USA",42.73,-84.56,CT_NA}, {"Saint Paul","Minnesota, USA",44.95,-93.09,CT_NA},
  {"Jackson","Mississippi, USA",32.30,-90.18,CT_NA}, {"Jefferson City","Missouri, USA",38.58,-92.17,CT_NA},
  {"Helena","Montana, USA",46.59,-112.04,CT_NA}, {"Lincoln","Nebraska, USA",40.81,-96.70,CT_NA},
  {"Carson City","Nevada, USA",39.16,-119.77,CT_NA}, {"Concord","New Hampshire, USA",43.21,-71.54,CT_NA},
  {"Trenton","New Jersey, USA",40.22,-74.76,CT_NA}, {"Santa Fe","New Mexico, USA",35.69,-105.94,CT_NA},
  {"Albany","New York, USA",42.65,-73.76,CT_NA}, {"Raleigh","North Carolina, USA",35.78,-78.64,CT_NA},
  {"Bismarck","North Dakota, USA",46.81,-100.78,CT_NA}, {"Columbus","Ohio, USA",39.96,-83.00,CT_NA},
  {"Oklahoma City","Oklahoma, USA",35.47,-97.52,CT_NA}, {"Salem","Oregon, USA",44.94,-123.04,CT_NA},
  {"Harrisburg","Pennsylvania, USA",40.27,-76.88,CT_NA}, {"Providence","Rhode Island, USA",41.82,-71.41,CT_NA},
  {"Columbia","South Carolina, USA",34.00,-81.03,CT_NA}, {"Pierre","South Dakota, USA",44.37,-100.35,CT_NA},
  {"Nashville","Tennessee, USA",36.16,-86.78,CT_NA}, {"Austin","Texas, USA",30.27,-97.74,CT_NA},
  {"Salt Lake City","Utah, USA",40.76,-111.89,CT_NA}, {"Montpelier","Vermont, USA",44.26,-72.58,CT_NA},
  {"Richmond","Virginia, USA",37.54,-77.44,CT_NA}, {"Olympia","Washington, USA",47.04,-122.90,CT_NA},
  {"Charleston","West Virginia, USA",38.35,-81.63,CT_NA}, {"Madison","Wisconsin, USA",43.07,-89.40,CT_NA},
  {"Cheyenne","Wyoming, USA",41.14,-104.82,CT_NA},
  // ---- Canada provincial capitals ----
  {"Victoria","B.C., Canada",48.43,-123.37,CT_NA}, {"Edmonton","Alberta, Canada",53.55,-113.49,CT_NA},
  {"Regina","Saskatchewan, Canada",50.45,-104.62,CT_NA}, {"Winnipeg","Manitoba, Canada",49.90,-97.14,CT_NA},
  {"Toronto","Ontario, Canada",43.65,-79.38,CT_NA}, {"Quebec City","Quebec, Canada",46.81,-71.21,CT_NA},
  {"Fredericton","N. Brunswick, Canada",45.96,-66.64,CT_NA}, {"Halifax","Nova Scotia, Canada",44.65,-63.57,CT_NA},
  {"Charlottetown","PEI, Canada",46.24,-63.13,CT_NA}, {"St. John's","Newfoundland, Canada",47.56,-52.71,CT_NA},
  // ---- Mexico / Central America / Caribbean ----
  {"Mexico City","Mexico",19.43,-99.13,CT_NA}, {"Hermosillo","Sonora, Mexico",29.07,-110.96,CT_NA},
  {"Chihuahua","Chihuahua, Mexico",28.63,-106.07,CT_NA}, {"Guadalajara","Jalisco, Mexico",20.66,-103.35,CT_NA},
  {"Merida","Yucatan, Mexico",20.97,-89.62,CT_NA}, {"Guatemala City","Guatemala",14.63,-90.51,CT_NA},
  {"Tegucigalpa","Honduras",14.07,-87.19,CT_NA}, {"San Salvador","El Salvador",13.69,-89.19,CT_NA},
  {"Managua","Nicaragua",12.13,-86.25,CT_NA}, {"San Jose","Costa Rica",9.93,-84.08,CT_NA},
  {"Panama City","Panama",8.98,-79.52,CT_NA}, {"Havana","Cuba",23.11,-82.37,CT_NA},
  {"Kingston","Jamaica",18.00,-76.79,CT_NA}, {"Santo Domingo","Dominican Republic",18.49,-69.93,CT_NA},
  // ---- South America ----
  {"Bogota","Colombia",4.71,-74.07,CT_SA}, {"Caracas","Venezuela",10.48,-66.90,CT_SA},
  {"Georgetown","Guyana",6.80,-58.16,CT_SA}, {"Paramaribo","Suriname",5.85,-55.20,CT_SA},
  {"Quito","Ecuador",-0.18,-78.47,CT_SA}, {"Lima","Peru",-12.05,-77.04,CT_SA},
  {"La Paz","Bolivia",-16.50,-68.15,CT_SA}, {"Santiago","Chile",-33.45,-70.67,CT_SA},
  {"Buenos Aires","Argentina",-34.60,-58.38,CT_SA}, {"Cordoba","Cordoba, Argentina",-31.42,-64.18,CT_SA},
  {"Mendoza","Mendoza, Argentina",-32.89,-68.83,CT_SA}, {"Rio Gallegos","Santa Cruz, Argentina",-51.62,-69.22,CT_SA},
  {"Montevideo","Uruguay",-34.90,-56.16,CT_SA}, {"Asuncion","Paraguay",-25.26,-57.58,CT_SA},
  {"Brasilia","Federal Dist., Brazil",-15.79,-47.88,CT_SA}, {"Manaus","Amazonas, Brazil",-3.12,-60.02,CT_SA},
  {"Belem","Para, Brazil",-1.46,-48.50,CT_SA}, {"Recife","Pernambuco, Brazil",-8.05,-34.88,CT_SA},
  {"Salvador","Bahia, Brazil",-12.97,-38.51,CT_SA}, {"Cuiaba","Mato Grosso, Brazil",-15.60,-56.10,CT_SA},
  {"Sao Paulo","Sao Paulo, Brazil",-23.55,-46.63,CT_SA}, {"Porto Alegre","Rio Grande Sul, Brazil",-30.03,-51.23,CT_SA},
  // ---- Europe ----
  {"London","England, UK",51.51,-0.13,CT_EU}, {"Cardiff","Wales, UK",51.48,-3.18,CT_EU},
  {"Edinburgh","Scotland, UK",55.95,-3.19,CT_EU}, {"Dublin","Ireland",53.35,-6.26,CT_EU},
  {"Paris","France",48.86,2.35,CT_EU}, {"Brussels","Belgium",50.85,4.35,CT_EU},
  {"Amsterdam","Netherlands",52.37,4.90,CT_EU}, {"Luxembourg","Luxembourg",49.61,6.13,CT_EU},
  {"Berlin","Germany",52.52,13.40,CT_EU}, {"Bern","Switzerland",46.95,7.45,CT_EU},
  {"Vienna","Austria",48.21,16.37,CT_EU}, {"Prague","Czechia",50.08,14.44,CT_EU},
  {"Warsaw","Poland",52.23,21.01,CT_EU}, {"Bratislava","Slovakia",48.15,17.11,CT_EU},
  {"Budapest","Hungary",47.50,19.04,CT_EU}, {"Ljubljana","Slovenia",46.06,14.51,CT_EU},
  {"Zagreb","Croatia",45.81,15.98,CT_EU}, {"Sarajevo","Bosnia",43.86,18.41,CT_EU},
  {"Belgrade","Serbia",44.79,20.45,CT_EU}, {"Bucharest","Romania",44.43,26.10,CT_EU},
  {"Sofia","Bulgaria",42.70,23.32,CT_EU}, {"Skopje","N. Macedonia",42.00,21.43,CT_EU},
  {"Tirana","Albania",41.33,19.82,CT_EU}, {"Athens","Greece",37.98,23.73,CT_EU},
  {"Rome","Italy",41.90,12.50,CT_EU}, {"Madrid","Spain",40.42,-3.70,CT_EU},
  {"Lisbon","Portugal",38.72,-9.14,CT_EU}, {"Kyiv","Ukraine",50.45,30.52,CT_EU},
  {"Chisinau","Moldova",47.01,28.86,CT_EU}, {"Minsk","Belarus",53.90,27.57,CT_EU},
  {"Vilnius","Lithuania",54.69,25.28,CT_EU}, {"Riga","Latvia",56.95,24.11,CT_EU},
  {"Moscow","Russia",55.76,37.62,CT_EU}, {"Kazan","Tatarstan, Russia",55.80,49.11,CT_EU},
  // ---- Africa ----
  {"Rabat","Morocco",34.02,-6.84,CT_AF}, {"Algiers","Algeria",36.75,3.06,CT_AF},
  {"Tunis","Tunisia",36.81,10.18,CT_AF}, {"Tripoli","Libya",32.89,13.19,CT_AF},
  {"Cairo","Egypt",30.04,31.24,CT_AF}, {"Khartoum","Sudan",15.50,32.56,CT_AF},
  {"Juba","South Sudan",4.85,31.58,CT_AF}, {"Asmara","Eritrea",15.32,38.93,CT_AF},
  {"Addis Ababa","Ethiopia",9.03,38.74,CT_AF}, {"Djibouti","Djibouti",11.59,43.15,CT_AF},
  {"Mogadishu","Somalia",2.05,45.32,CT_AF}, {"Nairobi","Kenya",-1.29,36.82,CT_AF},
  {"Kampala","Uganda",0.35,32.58,CT_AF}, {"Kigali","Rwanda",-1.95,30.06,CT_AF},
  {"Dodoma","Tanzania",-6.16,35.75,CT_AF}, {"Kinshasa","DR Congo",-4.44,15.27,CT_AF},
  {"Brazzaville","Rep. of Congo",-4.27,15.28,CT_AF}, {"Libreville","Gabon",0.42,9.47,CT_AF},
  {"Yaounde","Cameroon",3.85,11.50,CT_AF}, {"Bangui","Central African Rep.",4.36,18.56,CT_AF},
  {"N'Djamena","Chad",12.13,15.06,CT_AF}, {"Niamey","Niger",13.51,2.11,CT_AF},
  {"Abuja","Nigeria",9.08,7.40,CT_AF}, {"Lome","Togo",6.13,1.22,CT_AF},
  {"Accra","Ghana",5.60,-0.19,CT_AF}, {"Yamoussoukro","Ivory Coast",6.82,-5.28,CT_AF},
  {"Monrovia","Liberia",6.30,-10.80,CT_AF}, {"Freetown","Sierra Leone",8.48,-13.23,CT_AF},
  {"Conakry","Guinea",9.64,-13.58,CT_AF}, {"Bamako","Mali",12.64,-8.00,CT_AF},
  {"Ouagadougou","Burkina Faso",12.37,-1.52,CT_AF}, {"Dakar","Senegal",14.72,-17.47,CT_AF},
  {"Nouakchott","Mauritania",18.09,-15.98,CT_AF}, {"Luanda","Angola",-8.84,13.23,CT_AF},
  {"Lusaka","Zambia",-15.39,28.32,CT_AF}, {"Lilongwe","Malawi",-13.97,33.77,CT_AF},
  {"Harare","Zimbabwe",-17.83,31.05,CT_AF}, {"Maputo","Mozambique",-25.97,32.57,CT_AF},
  {"Windhoek","Namibia",-22.56,17.08,CT_AF}, {"Gaborone","Botswana",-24.65,25.91,CT_AF},
  {"Pretoria","South Africa",-25.75,28.19,CT_AF}, {"Cape Town","W. Cape, S. Africa",-33.92,18.42,CT_AF},
  {"Antananarivo","Madagascar",-18.88,47.51,CT_AF},
  // ---- Middle East / Central Asia ----
  {"Ankara","Turkey",39.93,32.86,CT_AS}, {"Beirut","Lebanon",33.89,35.50,CT_AS},
  {"Damascus","Syria",33.51,36.29,CT_AS}, {"Amman","Jordan",31.95,35.93,CT_AS},
  {"Baghdad","Iraq",33.31,44.37,CT_AS}, {"Tehran","Iran",35.69,51.39,CT_AS},
  {"Riyadh","Saudi Arabia",24.71,46.68,CT_AS}, {"Kuwait City","Kuwait",29.38,47.99,CT_AS},
  {"Doha","Qatar",25.29,51.53,CT_AS}, {"Abu Dhabi","UAE",24.45,54.38,CT_AS},
  {"Muscat","Oman",23.59,58.38,CT_AS}, {"Sanaa","Yemen",15.37,44.19,CT_AS},
  {"Baku","Azerbaijan",40.41,49.87,CT_AS}, {"Tbilisi","Georgia",41.72,44.79,CT_AS},
  {"Yerevan","Armenia",40.18,44.51,CT_AS}, {"Ashgabat","Turkmenistan",37.96,58.33,CT_AS},
  {"Tashkent","Uzbekistan",41.30,69.24,CT_AS}, {"Dushanbe","Tajikistan",38.56,68.79,CT_AS},
  {"Bishkek","Kyrgyzstan",42.87,74.59,CT_AS}, {"Astana","Kazakhstan",51.17,71.43,CT_AS},
  {"Almaty","Kazakhstan",43.24,76.89,CT_AS}, {"Kabul","Afghanistan",34.53,69.17,CT_AS},
  {"Islamabad","Pakistan",33.68,73.05,CT_AS},
  // ---- South / Southeast Asia ----
  {"New Delhi","India",28.61,77.21,CT_AS}, {"Mumbai","Maharashtra, India",19.08,72.88,CT_AS},
  {"Hyderabad","Telangana, India",17.39,78.49,CT_AS}, {"Bengaluru","Karnataka, India",12.97,77.59,CT_AS},
  {"Chennai","Tamil Nadu, India",13.08,80.27,CT_AS}, {"Kolkata","W. Bengal, India",22.57,88.36,CT_AS},
  {"Kathmandu","Nepal",27.72,85.32,CT_AS}, {"Dhaka","Bangladesh",23.81,90.41,CT_AS},
  {"Colombo","Sri Lanka",6.93,79.86,CT_AS}, {"Naypyidaw","Myanmar",19.76,96.08,CT_AS},
  {"Bangkok","Thailand",13.76,100.50,CT_AS}, {"Vientiane","Laos",17.97,102.60,CT_AS},
  {"Hanoi","Vietnam",21.03,105.85,CT_AS}, {"Phnom Penh","Cambodia",11.56,104.92,CT_AS},
  {"Kuala Lumpur","Malaysia",3.14,101.69,CT_AS}, {"Singapore","Singapore",1.35,103.82,CT_AS},
  {"Jakarta","Indonesia",-6.21,106.85,CT_AS}, {"Manila","Philippines",14.60,120.98,CT_AS},
  // ---- East Asia ----
  {"Beijing","China",39.90,116.41,CT_AS}, {"Shanghai","China",31.23,121.47,CT_AS},
  {"Guangzhou","Guangdong, China",23.13,113.26,CT_AS}, {"Wuhan","Hubei, China",30.59,114.31,CT_AS},
  {"Xi'an","Shaanxi, China",34.34,108.94,CT_AS}, {"Chengdu","Sichuan, China",30.57,104.07,CT_AS},
  {"Lanzhou","Gansu, China",36.06,103.83,CT_AS}, {"Urumqi","Xinjiang, China",43.83,87.62,CT_AS},
  {"Lhasa","Tibet, China",29.65,91.13,CT_AS}, {"Hohhot","Inner Mongolia, China",40.84,111.75,CT_AS},
  {"Harbin","Heilongjiang, China",45.80,126.53,CT_AS}, {"Ulaanbaatar","Mongolia",47.89,106.91,CT_AS},
  {"Seoul","South Korea",37.57,126.98,CT_AS}, {"Pyongyang","North Korea",39.04,125.76,CT_AS},
  {"Tokyo","Japan",35.68,139.69,CT_AS}, {"Sapporo","Hokkaido, Japan",43.06,141.35,CT_AS},
  {"Taipei","Taiwan",25.03,121.57,CT_AS}, {"Novosibirsk","Siberia, Russia",55.03,82.92,CT_AS},
  {"Irkutsk","Siberia, Russia",52.29,104.30,CT_AS}, {"Khabarovsk","Far East, Russia",48.48,135.08,CT_AS},
  {"Vladivostok","Far East, Russia",43.12,131.89,CT_AS},
  // ---- Oceania ----
  {"Canberra","ACT, Australia",-35.28,149.13,CT_OC}, {"Sydney","NSW, Australia",-33.87,151.21,CT_OC},
  {"Melbourne","Victoria, Australia",-37.81,144.96,CT_OC}, {"Brisbane","Queensland, Australia",-27.47,153.03,CT_OC},
  {"Adelaide","S. Australia",-34.93,138.60,CT_OC}, {"Perth","W. Australia",-31.95,115.86,CT_OC},
  {"Darwin","N. Territory, Australia",-12.46,130.84,CT_OC}, {"Alice Springs","N. Territory, Australia",-23.70,133.88,CT_OC},
  {"Hobart","Tasmania, Australia",-42.88,147.33,CT_OC}, {"Wellington","New Zealand",-41.29,174.78,CT_OC},
  {"Port Moresby","Papua New Guinea",-9.44,147.18,CT_OC}, {"Suva","Fiji",-18.14,178.44,CT_OC},
  {"Noumea","New Caledonia",-22.28,166.46,CT_OC}
};
static const int NPLACES = sizeof(PLACES) / sizeof(PLACES[0]);

static float distKm(float la1, float lo1, float la2, float lo2) {
  const float D = 0.0174533f;
  float dLa = (la2 - la1) * D, dLo = (lo2 - lo1) * D;
  float sa = sinf(dLa * 0.5f), so = sinf(dLo * 0.5f);
  float a = sa * sa + cosf(la1 * D) * cosf(la2 * D) * so * so;
  if (a > 1.0f) a = 1.0f;
  return 12742.0f * asinf(sqrtf(a));
}

static const char *oceanName(float lat, float lon) {
  if (lat > 41 && lat < 47 && lon > 27.5f && lon < 41.5f) return "Black Sea";
  if (lat > 36 && lat < 47.5f && lon > 47 && lon < 54.5f) return "Caspian Sea";
  if (lat > 18 && lat < 30.5f && lon > -97.5f && lon < -81) return "Gulf of Mexico";
  if (lat > 9 && lat < 22 && lon > -84 && lon < -60) return "Caribbean Sea";
  if (lat > 30 && lat < 45.5f && lon > -5.5f && lon < 36) return "Mediterranean Sea";
  if (lat > 12 && lat < 28 && lon > 32 && lon < 43.5f) return "Red Sea";
  if (lat > 5 && lat < 22 && lon > 80 && lon < 100) return "Bay of Bengal";
  if (lat > 8 && lat < 25 && lon > 57 && lon < 77) return "Arabian Sea";
  if (lat > 0 && lat < 23 && lon > 105 && lon < 120) return "South China Sea";
  if (lat > 66) return "Arctic Ocean";
  if (lat < -60) return "Southern Ocean";
  if (lon >= -70 && lon < 20) return lat >= 0 ? "North Atlantic Ocean" : "South Atlantic Ocean";
  if (lon >= 20 && lon < 115) return "Indian Ocean";
  if (lon >= 115 && lon < 147 && lat < -10) return "Indian Ocean";
  return lat >= 0 ? "North Pacific Ocean" : "South Pacific Ocean";
}

// Fills 4 HUD lines. Land: continent / state-country / nearest capital / distance.
// Water: ocean name / "Over water" / nearest city / distance.
static void locate(float lat, float lon, char *a, char *b, char *c, char *d, size_t n) {
  int best = 0; float bd = 1e9f;
  for (int i = 0; i < NPLACES; ++i) {
    float dk = distKm(lat, lon, PLACES[i].lat, PLACES[i].lon);
    if (dk < bd) { bd = dk; best = i; }
  }
  const Place &p = PLACES[best];
  bool land = worldAt((int)floorf(lat), (int)floorf(lon)) > 0;
  if (land) {
    snprintf(a, n, "%s", CONT_NAME[p.cont]);
    snprintf(b, n, "%.22s", p.region);
  } else {
    snprintf(a, n, "%.22s", oceanName(lat, lon));
    snprintf(b, n, "Over water");
  }
  snprintf(c, n, "Near: %.17s", p.city);
  snprintf(d, n, "~%d km away", (int)bd);
}

static bool fetch(float &lat, float &lon, float &alt, float &vel) {
  if (WiFi.status() != WL_CONNECTED) { Serial.println("[ISS] no wifi"); return false; }
  Serial.printf("[ISS] heap free=%u maxblock=%u\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap());

  // 1) HTTPS: full data (lat, lon, altitude, velocity). Needs ~45 KB contiguous heap
  //    for TLS; skip straight to the plain-HTTP fallback if that isn't available.
  if (ESP.getMaxAllocHeap() >= 45000) {
    WiFiClientSecure cl;
    cl.setInsecure();
    cl.setHandshakeTimeout(8);
    HTTPClient http;
    http.setTimeout(6000);
    http.useHTTP10(true);
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    if (http.begin(cl, "https://api.wheretheiss.at/v1/satellites/25544")) {
      int code = http.GET();
      if (code == 200) {
        String body = http.getString();
        http.end();
        JsonDocument d;
        if (!deserializeJson(d, body)) {
          float la = d["latitude"] | 0.0f, lo = d["longitude"] | 0.0f;
          if (la != 0.0f || lo != 0.0f) {
            lat = la; lon = lo; alt = d["altitude"] | alt; vel = d["velocity"] | vel;
            return true;
          }
        }
        Serial.println("[ISS] https: bad JSON");
      } else {
        Serial.printf("[ISS] https failed: %d (%s)\n", code, HTTPClient::errorToString(code).c_str());
      }
      http.end();
    } else Serial.println("[ISS] https begin failed");
  }   // TLS memory is freed here

  // 2) Fallback: plain HTTP, no TLS (lat/lon only)
  {
    WiFiClient cl;
    HTTPClient http;
    http.setTimeout(6000);
    http.useHTTP10(true);
    http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
    if (!http.begin(cl, "http://api.open-notify.org/iss-now.json")) return false;
    int code = http.GET();
    if (code != 200) {
      Serial.printf("[ISS] http fallback failed: %d (%s)\n", code, HTTPClient::errorToString(code).c_str());
      http.end();
      return false;
    }
    String body = http.getString();
    http.end();
    JsonDocument d;
    if (deserializeJson(d, body)) { Serial.println("[ISS] fallback: bad JSON"); return false; }
    float la = d["iss_position"]["latitude"].as<float>();
    float lo = d["iss_position"]["longitude"].as<float>();
    if (la == 0.0f && lo == 0.0f) return false;
    lat = la; lon = lo;
    return true;
  }
}
}  // namespace iss

void app_iss(AppCtx &c) {
  using namespace iss;
  const int BX = 4, BY = 46, SZ = 168, NG = 84;        // globe area 168x168, 84x84 grid drawn as 2x2 blocks
  const int STRIP = 24, NSTRIP = SZ / STRIP;           // drawn in 7 strips of 168x24 (4 KB) instead of one 28 KB frame
  const float CXl = 84, CYl = 84, R = 76;              // globe centre / radius inside the sprite at zoom 1
  const float DEG = 0.0174533f, RAD = 57.2958f;
  const float AUTO_SPIN = 0.35f;
  const float ZMIN = 0.5f, ZMAX = 3.0f;                // zoom limits
  const float RING_R = 62.0f;                          // touches starting farther than this from the centre = zoom gesture

  // Colours
  const uint16_t COL_OCEAN  = RGB565(0, 42, 120);
  const uint16_t COL_LAND   = RGB565(34, 139, 52);
  const uint16_t COL_TUNDRA = RGB565(120, 150, 110);
  const uint16_t COL_DESERT = RGB565(196, 168, 104);
  const uint16_t COL_ICE    = RGB565(235, 240, 245);
  const uint16_t COL_SEAICE = RGB565(190, 215, 235);

  // Low-RAM rendering: the sphere is computed per pixel (needed for zoom) and drawn
  // through ONE small strip buffer (168x24x1 byte = 4 KB) that is pushed 7 times per
  // frame, instead of a 28 KB full-frame sprite.
  TFT_eSprite spr(&tft); spr.setColorDepth(8);
  if (!spr.createSprite(SZ, STRIP)) {
    c.header(); ui::msgBox("ISS GLOBE", "Not enough RAM for the globe."); return;
  }

  struct Star { uint8_t x, y; uint16_t c; };
  Star stars[40];
  for (auto &s : stars) { s.x = rnd(SZ); s.y = rnd(SZ); s.c = rnd(3) ? RGB565(80, 84, 96) : TFT_WHITE; }

  float issLat = 0, issLon = 0, alt = 420, vel = 27600; bool haveFix = false, online = false;
  float trailLat[10], trailLon[10]; int trailN = 0, trailHead = 0;
  float theta = 0, tilt = 0, spin = AUTO_SPIN;
  float idleSpin = AUTO_SPIN;      // spin speed the globe eases back to when not touched
  bool centering = true;           // glide to the ISS once on launch
  float zoom = 1.0f, shownZoom = -1.0f; uint32_t lastZoomDraw = 0;
  bool zoomDrag = false; float lastRad = 0;
  uint32_t lastFetch = 0, lastWifiTry = 0;
  int lastTx = -1, lastTy = -1; bool dragging = false;
  char loc1[24] = "", loc2[24] = "", loc3[24] = "", loc4[24] = "";   // location readout lines

  ui::clearBody(TFT_BLACK);
  c.header("live ISS tracker");

  ui::centerText("Connecting WiFi...", 96, 128, C_WARN, TFT_BLACK, 2);
  if (sys::wifiConnect(10000, false)) online = true;
  tft.fillRect(0, 26, 176, 214, TFT_BLACK);

  auto zoomBar = [&]() {
    char z[12]; snprintf(z, sizeof(z), "x%.1f", zoom);
    ui::button(4, 28, 44, 16, "ZOOM-", C_PANEL2, C_TEXT, 1);
    ui::button(52, 28, 72, 16, z, C_PANEL, C_ACCENT, 1);          // tap = reset to x1.0
    ui::button(128, 28, 44, 16, "ZOOM+", C_PANEL2, C_TEXT, 1);
    shownZoom = zoom; lastZoomDraw = millis();
  };
  zoomBar();

  auto hud = [&]() {
    int x = 180; tft.fillRect(x, 28, 140, 210, C_BG);
    tft.drawFastVLine(x - 2, 28, 210, C_PANEL2);
    tft.setTextColor(online ? C_OK : C_ERR, C_BG); tft.drawString(online ? "SYS LINK: ONLINE" : "SYS LINK: OFFLINE", x, 32, 1);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString("TARGET: ISS (25544)", x, 46, 1);
    char b[24];
    tft.setTextColor(C_DIM, C_BG); tft.drawString("LAT", x, 66, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, sizeof(b), "%+.3f", issLat); tft.drawString(b, x + 30, 66, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("LON", x, 80, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, sizeof(b), "%+.3f", issLon); tft.drawString(b, x + 30, 80, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("ALT", x, 94, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, sizeof(b), "%.0f km", alt); tft.drawString(b, x + 30, 94, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("VEL", x, 108, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, sizeof(b), "%.0f km/h", vel); tft.drawString(b, x + 30, 108, 1);
    tft.setTextColor(haveFix ? C_OK : C_WARN, C_BG); tft.drawString(haveFix ? "TRACKING" : "acquiring...", x, 128, 1);

    // ---- location readout: what the ISS is flying over ----
    tft.setTextColor(C_DIM, C_BG); tft.drawString("OVER", x, 146, 1);
    if (haveFix) {
      tft.setTextColor(C_ACCENT, C_BG); tft.drawString(loc1, x, 158, 1);   // continent / ocean
      tft.setTextColor(C_TEXT, C_BG);   tft.drawString(loc2, x, 170, 1);   // state, country / over water
      tft.setTextColor(C_TEXT, C_BG);   tft.drawString(loc3, x, 182, 1);   // nearest capital / city
      tft.setTextColor(C_DIM, C_BG);    tft.drawString(loc4, x, 194, 1);   // distance
    } else {
      tft.setTextColor(C_DIM, C_BG); tft.drawString("waiting for fix...", x, 158, 1);
    }

    tft.setTextColor(C_DIM, C_BG); tft.drawString("drag=spin  rim>in=zoom", x, 210, 1);
    tft.drawString("wheretheiss.at", x, 224, 1);
  };
  hud();

  while (c.loop()) {
    Touch &t = *c.t;

    // ---------------- zoom buttons (strip above the globe) ----------------
    if (t.tap && t.sy < BY && t.sx < 176) {
      if (ui::inRect(t.sx, t.sy, 4, 28, 44, 16))        zoom = constrain(zoom / 1.25f, ZMIN, ZMAX);
      else if (ui::inRect(t.sx, t.sy, 128, 28, 44, 16)) zoom = constrain(zoom * 1.25f, ZMIN, ZMAX);
      else if (ui::inRect(t.sx, t.sy, 52, 28, 72, 16))  zoom = 1.0f;
      zoomBar();
    }

    // ---------------- touch: drag = rotate, rim->centre / centre->rim = zoom ----------------
    bool inPane = t.down && t.x < 176 && (t.y >= BY || lastTx >= 0);
    if (inPane) {
      centering = false;                                   // user took control
      float fx = t.x - (BX + CXl), fy = t.y - (BY + CYl);
      float rad = sqrtf(fx * fx + fy * fy);
      if (lastTx < 0) { zoomDrag = rad > RING_R; lastRad = rad; }   // decide mode at touch-down
      else if (zoomDrag) {
        // finger moving toward the centre -> zoom IN, toward the rim -> zoom OUT
        zoom = constrain(zoom * (1.0f + (lastRad - rad) * 0.012f), ZMIN, ZMAX);
        lastRad = rad; spin = 0; dragging = true;
      } else {
        float dxs = (t.x - lastTx) * 1.2f / zoom;          // slower drag when zoomed in
        theta += dxs;
        spin = spin * 0.5f + dxs * 0.5f;
        spin = constrain(spin, -25.0f, 25.0f);
        tilt = constrain(tilt - (t.y - lastTy) * 0.8f / zoom, -80.f, 80.f);
        dragging = true;
      }
      lastTx = t.x; lastTy = t.y;
    } else {
      lastTx = -1; zoomDrag = false;
      if (t.released) dragging = false;
    }
    if (!dragging) {
      theta += spin;
      spin += (idleSpin - spin) * 0.04f;
    }
    theta = fmodf(theta, 360.0f);
    if (theta < 0) theta += 360.0f;

    if (fabsf(zoom - shownZoom) > 0.05f && millis() - lastZoomDraw > 150) zoomBar();

    // ---------------- auto-center on the ISS at launch ----------------
    if (centering && haveFix && !dragging) {
      float dT = fmodf(-issLon - theta, 360.0f);           // shortest way around
      if (dT > 180.0f) dT -= 360.0f;
      if (dT < -180.0f) dT += 360.0f;
      float dP = -issLat - tilt;                           // tilt that puts the ISS's latitude at center
      theta += dT * 0.08f;
      tilt  += dP * 0.08f;
      spin = 0;
      if (fabsf(dT) < 0.5f && fabsf(dP) < 0.5f) {          // arrived
        centering = false;
        idleSpin = 0;                                      // hold on the ISS (delete this line to keep slow spin)
      }
    }

    // ---------------- WiFi retry ----------------
    bool nowOnline = (WiFi.status() == WL_CONNECTED);
    if (!nowOnline && millis() - lastWifiTry > 15000) {
      lastWifiTry = millis();
      sys::wifiConnect(5000, false);
      nowOnline = (WiFi.status() == WL_CONNECTED);
    }
    if (nowOnline != online) { online = nowOnline; hud(); }

    // ---------------- ISS fetch ----------------
    if (online && (lastFetch == 0 || millis() - lastFetch > 3000)) {
      lastFetch = millis();
      float la = issLat, lo = issLon, al = alt, ve = vel;
      if (fetch(la, lo, al, ve)) {
        issLat = la; issLon = lo; alt = al; vel = ve; haveFix = true;
        trailLat[trailHead] = la; trailLon[trailHead] = lo; trailHead = (trailHead + 1) % 10; if (trailN < 10) trailN++;
        locate(la, lo, loc1, loc2, loc3, loc4, sizeof(loc1));   // update "what is it over"
      }
      hud();
    }

    // ---------------- render (strip by strip) ----------------
    const float ct = cosf(tilt * DEG), st = sinf(tilt * DEG);
    const float Rz = R * zoom, inv = 1.0f / Rz;

    // ISS marker position (computed once per frame)
    bool showSat = false; int satX = 0, satY = 0;
    if (haveFix) {
      float cosLat = cosf(issLat * DEG), sinLat = sinf(issLat * DEG);
      float lonA = (issLon + theta) * DEG;
      float px = cosLat * sinf(lonA);
      float py = sinLat;
      float pz = cosLat * cosf(lonA);
      float y2 = py * ct + pz * st;
      float z2 = -py * st + pz * ct;
      if (z2 > 0.0f) {
        satX = (int)(CXl + Rz * px);
        satY = (int)(CYl - Rz * y2);
        showSat = satX >= 6 && satX < SZ - 6 && satY >= 6 && satY < SZ - 6;
      }
    }
    uint16_t pulseColor = (millis() % 500 < 250) ? TFT_RED : TFT_WHITE;

    for (int sp = 0; sp < NSTRIP; ++sp) {
      const int y0 = sp * STRIP;                           // first screen row of this strip
      spr.fillSprite(TFT_BLACK);
      for (auto &s : stars) if (s.y >= y0 && s.y < y0 + STRIP) spr.drawPixel(s.x, s.y - y0, s.c);

      for (int gy = y0 / 2; gy < (y0 + STRIP) / 2; ++gy) {
        float dy = (gy * 2 + 1 - CYl) * inv;
        float dy2 = dy * dy;
        if (dy2 > 1.2f) continue;
        const int ry = gy * 2 - y0;                        // row inside the strip
        for (int gx = 0; gx < NG; ++gx) {
          float dx = (gx * 2 + 1 - CXl) * inv;
          float d2 = dx * dx + dy2;
          if (d2 <= 1.0f) {
            float z = sqrtf(1.0f - d2);
            float y = -dy;                                 // screen up = +Y
            float y1 = y * ct - z * st;                    // undo tilt
            float z1 = y * st + z * ct;
            float latD = asinf(constrain(y1, -1.0f, 1.0f)) * RAD;
            float lonD = atan2f(dx, z1) * RAD - theta;     // undo spin
            int type = worldAt((int)floorf(latD), (int)floorf(lonD));
            uint16_t col;
            switch (type) {
              case 1:  col = (fabsf(latD) > 62.0f) ? COL_TUNDRA : COL_LAND; break;
              case 2:  col = COL_DESERT; break;
              case 3:  col = COL_ICE; break;
              default: col = (fabsf(latD) >= 82.0f) ? COL_SEAICE : COL_OCEAN; break;   // polar sea ice
            }
            uint8_t sh = (uint8_t)constrain(45 + 210 * z, 0, 255);
            col = tft.alphaBlend(sh, col, TFT_BLACK);
            spr.fillRect(gx * 2, ry, 2, 2, col);
          } else if (d2 <= 1.20f) {                        // atmosphere glow
            uint8_t sh = (uint8_t)constrain((int)((1.20f - d2) / 0.20f * 180), 0, 180);
            spr.fillRect(gx * 2, ry, 2, 2, tft.alphaBlend(sh, 0x5DFF, TFT_BLACK));
          }
        }
      }

      if (showSat && satY + 5 >= y0 && satY - 5 < y0 + STRIP) {
        int sy = satY - y0;
        spr.drawFastHLine(satX - 5, sy, 11, TFT_WHITE);
        spr.drawFastVLine(satX, sy - 5, 11, TFT_WHITE);
        spr.fillCircle(satX, sy, 2, pulseColor);
      }
      tft.startWrite();
      spr.pushSprite(BX, BY + y0);
      tft.endWrite();
    }
  }
  spr.deleteSprite();
}