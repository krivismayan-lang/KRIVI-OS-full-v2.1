Optional external firmware images (.bin) for the binary launcher.
Reference one from a manifest: "bin": "/apps/myapp.bin". Max 1.56 MB (ota_1 slot).
Include tools/krivi_return.h in that firmware so it can hand control back to KRIVI OS.
