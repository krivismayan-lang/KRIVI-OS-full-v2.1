Copy your own legally-dumped NES ROMs here (e.g. mario.nes, tetris.nes).
Supported: iNES mapper 0 (NROM), 1 (MMC1), 2 (UxROM), 3 (CNROM); PRG+CHR must fit in RAM (~96 KB).
