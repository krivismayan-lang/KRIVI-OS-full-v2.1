#!/usr/bin/env python3
"""
KRIVI OS media converter  (needs ffmpeg:  macOS `brew install ffmpeg`,
Debian/Raspberry Pi `sudo apt install ffmpeg`, Windows: ffmpeg.org)

The ESP32 in the CYD has no hardware video decoder and is far too slow to
decode H.264/MP4 in software, so videos are converted into a format it CAN
play in real time:

  video  (.mp4 .mov .mkv .webm .avi ...) -> data/movies/<name>.avi
         Motion-JPEG 320x240 max, 15 fps, + 22.05 kHz 8-bit mono PCM audio
  audio  (.wav .flac .m4a .aac .ogg .mp3) -> data/music/<name>.mp3
         MP3 128 kbps 44.1 kHz (MP3s that are already fine are copied as-is)

Usage:
  python3 convert_media.py  movie.mp4 song.flac ...          # -> ../sd_card/data/...
  python3 convert_media.py  ~/Videos/*.mp4  --sd /Volumes/KRIVI   # straight onto the card
  options:  --fps 12      lower = smoother on long/complex videos (default 15)
            --quality 9   JPEG quality 2 (best) .. 31 (smallest); default 8
            --bad-apple   also write a silent .mjpeg to data/video (legacy clip mode)
"""
import argparse, os, shutil, subprocess, sys

VIDEO_EXT = {'.mp4', '.m4v', '.mov', '.mkv', '.webm', '.avi', '.wmv', '.flv', '.mpg', '.mpeg', '.3gp'}
AUDIO_EXT = {'.mp3', '.wav', '.flac', '.m4a', '.aac', '.ogg', '.opus', '.wma', '.aiff', '.aif'}
HERE = os.path.dirname(os.path.abspath(__file__))


def ffmpeg():
    exe = shutil.which('ffmpeg')
    if not exe:
        sys.exit('ffmpeg not found. macOS: brew install ffmpeg   |   Linux/Pi: sudo apt install ffmpeg')
    return exe


def run(cmd):
    print('  $', ' '.join(f'"{c}"' if ' ' in c else c for c in cmd[:3]), '...')
    r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    if r.returncode:
        print(r.stderr[-800:])
        raise SystemExit('ffmpeg failed')


def safe_name(path, ext):
    base = os.path.splitext(os.path.basename(path))[0]
    keep = ''.join(ch if ch.isalnum() or ch in '-_ ' else '_' for ch in base).strip().replace(' ', '_')
    return (keep[:40] or 'media') + ext


def convert_video(src, sd, a):
    out_dir = os.path.join(sd, 'data', 'movies'); os.makedirs(out_dir, exist_ok=True)
    dst = os.path.join(out_dir, safe_name(src, '.avi'))
    vf = f"fps={a.fps},scale=320:240:force_original_aspect_ratio=decrease:flags=lanczos,scale=trunc(iw/2)*2:trunc(ih/2)*2"
    run([ffmpeg(), '-y', '-i', src, '-vf', vf, '-c:v', 'mjpeg', '-q:v', str(a.quality), '-pix_fmt', 'yuvj420p',
         '-c:a', 'pcm_u8', '-ar', '22050', '-ac', '1', '-f', 'avi', dst])
    print(f'  -> {dst}  ({os.path.getsize(dst) / 1e6:.1f} MB)')
    if a.bad_apple:
        vdir = os.path.join(sd, 'data', 'video'); os.makedirs(vdir, exist_ok=True)
        mj = os.path.join(vdir, safe_name(src, '.mjpeg'))
        run([ffmpeg(), '-y', '-i', src, '-vf', vf, '-q:v', str(a.quality), '-an', '-f', 'mjpeg', mj])
        print(f'  -> {mj}')


def convert_audio(src, sd, a):
    out_dir = os.path.join(sd, 'data', 'music'); os.makedirs(out_dir, exist_ok=True)
    dst = os.path.join(out_dir, safe_name(src, '.mp3'))
    if src.lower().endswith('.mp3') and not a.reencode:
        shutil.copyfile(src, dst)
        print(f'  -> {dst} (copied)')
        return
    run([ffmpeg(), '-y', '-i', src, '-vn', '-c:a', 'libmp3lame', '-b:a', '128k', '-ar', '44100',
         '-map_metadata', '0', '-id3v2_version', '3', dst])
    print(f'  -> {dst}')


def main():
    ap = argparse.ArgumentParser(description='Convert media for KRIVI OS on the CYD')
    ap.add_argument('files', nargs='+')
    ap.add_argument('--sd', default=os.path.join(HERE, '..', 'sd_card'), help='SD card root (or the sd_card folder)')
    ap.add_argument('--fps', type=int, default=15)
    ap.add_argument('--quality', type=int, default=8)
    ap.add_argument('--bad-apple', action='store_true', help='also write a silent .mjpeg clip')
    ap.add_argument('--reencode', action='store_true', help='re-encode MP3 inputs too')
    a = ap.parse_args()
    for f in a.files:
        ext = os.path.splitext(f)[1].lower()
        print(os.path.basename(f))
        if ext in VIDEO_EXT:
            convert_video(f, a.sd, a)
        elif ext in AUDIO_EXT:
            convert_audio(f, a.sd, a)
        else:
            print('  skipped (unknown type)')


if __name__ == '__main__':
    main()
