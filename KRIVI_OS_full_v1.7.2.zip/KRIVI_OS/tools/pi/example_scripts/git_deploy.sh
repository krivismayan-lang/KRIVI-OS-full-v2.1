#!/bin/bash
# Example deployment trigger: pull a repo and restart its service.
# Edit REPO / SERVICE, and allow the restart without a password via sudoers:
#   USERNAME ALL=(root) NOPASSWD: /bin/systemctl restart myapp
REPO="$HOME/myapp"
SERVICE="myapp"
set -e
cd "$REPO"
echo "Pulling $(git rev-parse --abbrev-ref HEAD)..."
git pull --ff-only 2>&1
echo "Restarting $SERVICE"
sudo -n systemctl restart "$SERVICE" 2>&1 || echo "restart needs sudoers entry (see script)"
echo "Deployed $(git rev-parse --short HEAD)"
